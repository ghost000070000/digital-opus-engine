// Digital Opus Editor.
// Proves the core no-code loop: drag an object in, select it (in the
// viewport or the Scene list), edit it via the inspector, save/export the
// project — all without writing JavaScript. Built entirely through
// window.Opus, same discipline as the demo.

const canvas = document.getElementById('game');
const app = Opus.create(canvas, { hud: false });

const cubeMesh = Opus.Mesh.cube();
// Wave 6 (Priority B/Section 14): the Ramp placement tool's render mesh --
// a Ramp is still kind:'cube' underneath (it inherits solid/collider/
// hierarchy/behaviors/serialization exactly like any other cube), only its
// rendered shape and its collision resolution (resolveRampCollision instead
// of the flat-top box check) differ, gated on the item's own `isRamp` flag.
const wedgeMesh = Opus.Mesh.wedge();

// Crates/hazards/boost pads were all literally cubes, distinguished only by
// color — hard to tell apart at a glance or in fog/motion. Built via the
// public Opus.Mesh.fromArrays escape hatch (flat-shaded, matching the cube
// mesh's own per-face-normal convention), no engine change needed.
function buildOctahedronMesh() {
  const v = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
  const faces = [
    [0, 2, 4], [0, 4, 3], [0, 3, 5], [0, 5, 2],
    [1, 2, 5], [1, 5, 3], [1, 3, 4], [1, 4, 2],
  ];
  const positions = [];
  const normals = [];
  const indices = [];
  let idx = 0;
  for (const [a, b, c] of faces) {
    const tri = [v[a], v[b], v[c]];
    const nx = (tri[0][0] + tri[1][0] + tri[2][0]) / 3;
    const ny = (tri[0][1] + tri[1][1] + tri[2][1]) / 3;
    const nz = (tri[0][2] + tri[1][2] + tri[2][2]) / 3;
    const nLen = Math.hypot(nx, ny, nz);
    for (const p of tri) {
      positions.push(p[0] * 0.6, p[1] * 0.6, p[2] * 0.6);
      normals.push(nx / nLen, ny / nLen, nz / nLen);
    }
    indices.push(idx, idx + 1, idx + 2);
    idx += 3;
  }
  return Opus.Mesh.fromArrays(new Float32Array(positions), new Float32Array(normals), new Uint16Array(indices));
}

function buildPyramidMesh() {
  const base = [[-0.5, -0.5, -0.5], [0.5, -0.5, -0.5], [0.5, -0.5, 0.5], [-0.5, -0.5, 0.5]];
  const apex = [0, 0.5, 0];
  const positions = [];
  const normals = [];
  const indices = [];
  let idx = 0;
  const pushTri = (p0, p1, p2) => {
    const ux = p1[0] - p0[0], uy = p1[1] - p0[1], uz = p1[2] - p0[2];
    const vx = p2[0] - p0[0], vy = p2[1] - p0[1], vz = p2[2] - p0[2];
    let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    const nLen = Math.hypot(nx, ny, nz) || 1;
    nx /= nLen; ny /= nLen; nz /= nLen;
    for (const p of [p0, p1, p2]) { positions.push(p[0], p[1], p[2]); normals.push(nx, ny, nz); }
    indices.push(idx, idx + 1, idx + 2);
    idx += 3;
  };
  // 4 sloped sides
  for (let i = 0; i < 4; i++) pushTri(base[i], base[(i + 1) % 4], apex);
  // base (2 triangles, facing down)
  pushTri(base[0], base[3], base[2]);
  pushTri(base[0], base[2], base[1]);
  return Opus.Mesh.fromArrays(new Float32Array(positions), new Float32Array(normals), new Uint16Array(indices));
}

const mineMesh = buildOctahedronMesh();
const boostMesh = buildPyramidMesh();

// Wave 6 (Priority I): the Billboard/Sprite placement tool's render mesh --
// a VERTICAL unit quad in the local XY plane (normal +Z), unlike the
// engine's existing 'plane' mesh (Opus.Mesh.plane, normal +Y, meant for a
// flat ground decal) -- a billboard needs its rest orientation facing
// outward along local +Z specifically so "rotate this entity to face the
// camera" (syncBillboards below) has a well-defined meaning. Real UVs
// (0,0..1,1) so an imported cutout-texture sprite (the primary use case
// this priority exists to serve, see the LIT_FRAG_SRC texture-alpha fix
// above) maps onto it right-side-up with no extra authoring step. No
// engine change needed for the geometry itself -- built via the same
// public Opus.Mesh.fromArrays escape hatch mine/boost already use.
function buildBillboardMesh() {
  const positions = new Float32Array([
    -0.5, -0.5, 0, 0.5, -0.5, 0, 0.5, 0.5, 0, -0.5, 0.5, 0,
  ]);
  const normals = new Float32Array([
    0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1,
  ]);
  const uvs = new Float32Array([
    0, 0, 1, 0, 1, 1, 0, 1,
  ]);
  const indices = new Uint16Array([0, 1, 2, 0, 2, 3]);
  return Opus.Mesh.fromArrays(positions, normals, indices, uvs);
}
const billboardMesh = buildBillboardMesh();

// A landmark built via Opus.Mesh.fromGLTF (see friction #19) rather than
// buildOctahedronMesh-style hand-authored arrays -- proves the importer on
// something with a real, non-trivial node hierarchy (two mesh nodes, a
// pole and a beacon light, each with their own transform, flattened into
// one mesh) rather than only the synthetic single-node fixtures it was
// unit-tested against. A pole this shape would be tedious to hand-author
// directly as one set of arrays; expressing it as two simple primitives at
// two node transforms is exactly the case node-hierarchy flattening exists
// for.
const BEACON_GLTF_JSON = '{"asset":{"version":"2.0"},"scene":0,"scenes":[{"nodes":[0,1]}],"nodes":[{"mesh":0,"translation":[0,1.2,0]},{"mesh":1,"translation":[0,2.6,0],"scale":[1,1,1]}],"meshes":[{"primitives":[{"attributes":{"POSITION":0,"NORMAL":1},"indices":2,"mode":4}]},{"primitives":[{"attributes":{"POSITION":3,"NORMAL":4},"indices":5,"mode":4}]}],"accessors":[{"bufferView":0,"componentType":5126,"count":24,"type":"VEC3"},{"bufferView":1,"componentType":5126,"count":24,"type":"VEC3"},{"bufferView":2,"componentType":5123,"count":36,"type":"SCALAR"},{"bufferView":3,"componentType":5126,"count":24,"type":"VEC3"},{"bufferView":4,"componentType":5126,"count":24,"type":"VEC3"},{"bufferView":5,"componentType":5123,"count":24,"type":"SCALAR"}],"bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":288},{"buffer":0,"byteOffset":288,"byteLength":288},{"buffer":0,"byteOffset":576,"byteLength":72},{"buffer":0,"byteOffset":648,"byteLength":288},{"buffer":0,"byteOffset":936,"byteLength":288},{"buffer":0,"byteOffset":1224,"byteLength":48}],"buffers":[{"byteLength":1272,"uri":"data:application/octet-stream;base64,mpkZPpqZmb+amRm+mpkZPpqZmb+amRk+mpkZPpqZmT+amRk+mpkZPpqZmT+amRm+mpkZvpqZmb+amRk+mpkZvpqZmb+amRm+mpkZvpqZmT+amRm+mpkZvpqZmT+amRk+mpkZvpqZmT+amRm+mpkZPpqZmT+amRm+mpkZPpqZmT+amRk+mpkZvpqZmT+amRk+mpkZvpqZmb+amRk+mpkZPpqZmb+amRk+mpkZPpqZmb+amRm+mpkZvpqZmb+amRm+mpkZvpqZmb+amRk+mpkZvpqZmT+amRk+mpkZPpqZmT+amRk+mpkZPpqZmb+amRk+mpkZPpqZmb+amRm+mpkZPpqZmT+amRm+mpkZvpqZmT+amRm+mpkZvpqZmb+amRm+AACAPwAAAAAAAAAAAACAPwAAAAAAAAAAAACAPwAAAAAAAAAAAACAPwAAAAAAAAAAAACAvwAAAAAAAAAAAACAvwAAAAAAAAAAAACAvwAAAAAAAAAAAACAvwAAAAAAAAAAAAAAAAAAgD8AAAAAAAAAAAAAgD8AAAAAAAAAAAAAgD8AAAAAAAAAAAAAgD8AAAAAAAAAAAAAgL8AAAAAAAAAAAAAgL8AAAAAAAAAAAAAgL8AAAAAAAAAAAAAgL8AAAAAAAAAAAAAAAAAAIA/AAAAAAAAAAAAAIA/AAAAAAAAAAAAAIA/AAAAAAAAAAAAAIA/AAAAAAAAAAAAAIC/AAAAAAAAAAAAAIC/AAAAAAAAAAAAAIC/AAAAAAAAAAAAAIC/AAABAAIAAAACAAMABAAFAAYABAAGAAcACAAJAAoACAAKAAsADAANAA4ADAAOAA8AEAARABIAEAASABMAFAAVABYAFAAWABcAzczMPgAAAAAAAAAAAAAAAM3MzD4AAAAAAAAAAAAAAADNzMw+zczMPgAAAAAAAAAAAAAAAAAAAADNzMw+AAAAAM3MzL4AAAAAzczMPgAAAAAAAAAAAAAAAM3MzL4AAAAAAAAAAAAAAADNzMy+zczMPgAAAAAAAAAAAAAAAAAAAADNzMy+AAAAAM3MzD4AAAAAzczMvgAAAAAAAAAAAAAAAM3MzD4AAAAAAAAAAAAAAADNzMy+zczMvgAAAAAAAAAAAAAAAAAAAADNzMy+AAAAAM3MzL4AAAAAzczMvgAAAAAAAAAAAAAAAM3MzL4AAAAAAAAAAAAAAADNzMw+zczMvgAAAAAAAAAAAAAAAAAAAADNzMw+AAAAAM3MzD4AAAAAOs0TPzrNEz86zRM/Os0TPzrNEz86zRM/Os0TPzrNEz86zRM/Os0TPzrNE786zRM/Os0TPzrNE786zRM/Os0TPzrNE786zRM/Os0TPzrNE786zRO/Os0TPzrNE786zRO/Os0TPzrNE786zRO/Os0TPzrNEz86zRO/Os0TPzrNEz86zRO/Os0TPzrNEz86zRO/Os0TvzrNEz86zRO/Os0TvzrNEz86zRO/Os0TvzrNEz86zRO/Os0TvzrNE786zRO/Os0TvzrNE786zRO/Os0TvzrNE786zRO/Os0TvzrNE786zRM/Os0TvzrNE786zRM/Os0TvzrNE786zRM/Os0TvzrNEz86zRM/Os0TvzrNEz86zRM/Os0TvzrNEz86zRM/AAABAAIAAwAEAAUABgAHAAgACQAKAAsADAANAA4ADwAQABEAEgATABQAFQAWABcA"}]}';
const beaconMesh = Opus.Mesh.fromGLTF(BEACON_GLTF_JSON);

// placed items: { kind: 'cube', entity, id, name? }
//             | { kind: 'terrain', handle, options, id, name? }
//             | { kind: 'water', handle, options, id, name? }
// `id` is a stable string every item gets once, at creation, and keeps for
// its whole life -- across rename, duplicate (a duplicate gets its OWN new
// id, never reuses the source's), Save/Load, Undo/Redo, and (once scenes
// exist) scene switching. This is what makes Object References (visual
// actions/Node Graph targeting "the Gate" or "EnemySpawner") possible at
// all: a raw JS reference doesn't survive serialization, but an id does.
const placed = [];
// `levels`: a project can hold more than one level, each its own full
// `placed`-shaped object list; exactly one is "active" at a time (its
// content IS `placed`/the live engine entities -- the others sit here as
// plain serialized data until switched to). `objects` starts empty and is
// only ever read after `syncCurrentLevelObjects()` has just written the
// live scene into it, so the placeholder is never actually stale.
// Stable level IDs (Wave 3): a level referenced by ID survives rename AND
// reorder, unlike the earlier name-based Switch Level lookup. Assigned once
// at creation, never reused, never renumbered on reorder/delete -- same
// "monotonic, never recycled" contract as object/prefab ids already use.
let nextLevelId = 1;
function generateLevelId() { return `level${nextLevelId++}`; }
// Every level gets `.id` assigned WHEN loaded/created (see ensureLevelIds,
// applied on load) rather than trusting older saved projects to already
// have one.
function reconcileLevelIdCounter(id) {
  const match = /^level(\d+)$/.exec(id);
  if (match) nextLevelId = Math.max(nextLevelId, Number(match[1]) + 1);
}
function ensureLevelIds(levelArray) {
  for (const l of levelArray) {
    if (l.id) reconcileLevelIdCounter(l.id);
    else l.id = generateLevelId();
  }
}

let levels = [{ id: generateLevelId(), name: 'Level 1', objects: [], environment: null, playerSettings: null, ui: null, description: '', ambientAudio: null }];
let currentLevelIndex = 0;
// Which level a fresh Play session boots into -- distinct from
// currentLevelIndex (which level is open for EDITING). A project with a
// "final boss" level authored last, but meant to be played from level 0,
// needs these to be independently settable.
let startLevelIndex = 0;
// Project-wide (not per-level) -- how switching levels DURING PLAY looks,
// not gameplay-affecting. Real wall-clock time (setTimeout), not
// simulation time, so a fade transition works identically whether or not
// the game happens to be paused at the moment it fires.
let levelTransitionConfig = { mode: 'instant', duration: 0.4 };
// Export Tiers metadata -- project-wide identification, not gameplay-
// affecting. Title (if set) becomes the exported HTML's document.title;
// Author/Version/Description are otherwise just carried through Save/
// Load/Export for the author's own record-keeping (a itch.io/TPT listing,
// a changelog entry) -- deliberately NOT forced into any in-game UI, since
// Start Screen/HUD text is already separately authorable and shouldn't be
// silently overwritten by unrelated metadata fields.
function defaultProjectMeta() { return { title: '', author: '', version: '1.0.0', description: '' }; }
let projectMeta = defaultProjectMeta();
// Matches Renderer's own constructor defaults (engine/src/09-renderer.js) --
// applied whenever a level has no saved environment of its own, so
// switching TO a level that never customized its mood doesn't inherit
// whatever a DIFFERENT level's environment happened to leave behind.
const DEFAULT_ENVIRONMENT = { lightDir: new Opus.Vec3(-0.5, -1.0, -0.3), skyTop: [0.06, 0.10, 0.24], skyHorizon: [0.62, 0.68, 0.80], groundColor: [0.16, 0.16, 0.14], sunColor: [1.0, 0.92, 0.75], fogDensity: 0.035 };
// Same "apply whenever a level never customized this" role as DEFAULT_ENVIRONMENT
// above, one entry per controller since each exposes different tunables.
const DEFAULT_PLAYER_SETTINGS = {
  hovercraft: { controllerType: 'hovercraft', maxHealth: 100 },
  topdown: { controllerType: 'topdown', moveSpeed: 6, acceleration: 24, rotateToMovement: true, collisionRadius: 0.5, maxHealth: 100 },
  thirdperson: { controllerType: 'thirdperson', moveSpeed: 6.5, acceleration: 30, collisionRadius: 0.5, maxHealth: 100, jumpEnabled: false, gravity: 20, jumpSpeed: 8 },
  firstperson: { controllerType: 'firstperson', moveSpeed: 6, acceleration: 40, collisionRadius: 0.4, maxHealth: 100, gravity: 20, jumpSpeed: 8, mouseSensitivity: 0.0022, fovDegrees: 70, eyeHeight: 0.6 },
};
function defaultPlayerSettings(controllerType) {
  const type = DEFAULT_PLAYER_SETTINGS[controllerType] ? controllerType : 'hovercraft';
  return Object.assign({}, DEFAULT_PLAYER_SETTINGS[type]);
}
// Wave 6B (Priority A): a skinned Player Character visual -- deliberately
// NOT baked into DEFAULT_PLAYER_SETTINGS above (which would need adding to
// all 4 controller types, most irrelevant), read lazily via
// `settings.visual || defaultPlayerVisual()` everywhere it's needed instead,
// so an old saved level with no `.visual` field at all keeps behaving
// exactly like "Default / Primitive" -- the pre-Wave-6B body, visible,
// unchanged. `mode: 'primitive'` is that same default; `'skinned'` swaps in
// a real character model as a SEPARATE visual entity synced to the
// (still-authoritative-for-physics) controller body, never the skeleton
// itself as the collision shape.
function defaultPlayerVisual() {
  return {
    mode: 'primitive', assetId: null, scale: 1, rotationOffsetY: 0,
    positionOffset: { x: 0, y: -0.5, z: 0 },
    clipMap: { idle: null, walk: null, run: null, jump: null, fall: null, attack: null, death: null },
    blendTime: 0.15,
  };
}
// The active level's player config -- read by spawnPlayer() to pick a
// controller and by each controller's spawn/update to read its tunables.
let currentPlayerSettings = defaultPlayerSettings('hovercraft');

// HUD/UI authoring: HUD elements, the optional Start Screen, and Win/Lose
// title/message overrides, all per-level (a boss level might want a
// different HUD than a puzzle level) -- same "apply whenever a level never
// customized this" pattern as environment/playerSettings above.
function defaultUiConfig() {
  // Wave 6 (Priority E): `howToPlay`/`credits` join the same startScreen
  // object (the Start Screen doubles as the Main Menu) -- both default to
  // '', which keeps their buttons hidden (see updateMainMenuExtras) and
  // keeps an untouched project's saved startScreen record shaped exactly
  // as it was before this priority existed once title/subtitle/buttonText
  // are also at their own defaults.
  return { hudElements: [], startScreen: { enabled: false, title: '', subtitle: '', buttonText: 'Start', howToPlay: '', credits: '' }, winTitle: '', winMessage: '', loseTitle: '', loseMessage: '' };
}
let currentUiConfig = defaultUiConfig();
let nextHudElementId = 1;
function generateHudElementId() { return `hud${nextHudElementId++}`; }

// Wave 6B (Priority E): Sequence authoring -- bounded, NOT a cinematic
// timeline. A Sequence is an ordered list of existing actions (reusing
// ACTION_TYPES/executeAction directly, no second per-action implementation)
// plus an optional Delay/Wait step between them, same "apply whenever a
// level never customized this" per-level pattern every other authoring
// surface here (Environment/Player/UI/Ambient Audio) already follows. A
// step is `{ kind: 'action', actionType, params }` or `{ kind: 'delay',
// seconds }` -- deliberately just these two shapes, no track/layer/keyframe
// concept.
let currentSequences = [];
let selectedSequenceId = null;
let nextSequenceId = 1;
function generateSequenceId() { return `sequence${nextSequenceId++}`; }
function defaultSequence(name) { return { id: generateSequenceId(), name: name || `Sequence ${currentSequences.length + 1}`, steps: [] }; }
function findSequenceById(id) { return id ? currentSequences.find((s) => s.id === id) : undefined; }
// Wave 7 (Priority F, Sections 42-46): a small structured Objective system
// on top of the pre-existing Objective Text/flags/counters/inventory -- NOT
// an RPG quest database. Definitions (`{id, title, description,
// nextObjective}`) are authored per-level data, same "global mirror synced
// into levels[currentLevelIndex] on every syncCurrentLevelObjects" pattern
// `currentSequences` immediately above already established. RUNTIME state
// (`window.__gameObjectives[id] = 'inactive'|'active'|'complete'|'failed'`)
// is separate, reset every fresh Play, and is what Priority E's Save Game
// actually persists.
let currentObjectiveDefs = [];
let nextObjectiveDefId = 1;
function generateObjectiveDefId() { return `objective${nextObjectiveDefId++}`; }
function findObjectiveDefById(id) { return id ? currentObjectiveDefs.find((o) => o.id === id) : undefined; }
// Wave 9C (Priority A): Scatter LAYERS -- persisted, level-scoped authoring
// definitions ({id, name, seed, sources:[{prefabName,weight}], scaleMin,
// scaleMax, randomYaw, minSpacing, maxSlope, brushRadius, density}) that
// CONFIGURE the existing weighted `performScatter`/`scatterPlaceOne`
// machinery (Wave 8) -- not a second Scatter implementation. Same mirror
// pattern `currentObjectiveDefs`/`currentSequences` already established:
// a global working copy, synced into `levels[currentLevelIndex]` by
// `syncCurrentLevelObjects` and read back by `applyLevelScatterLayers` on
// level switch. Level-scoped (Section 5) per the spec's own "a Forest
// Layer is normally level content."
let currentScatterLayers = [];
let selectedScatterLayerId = null;
let nextScatterLayerCounter = 1;
function generateScatterLayerId() { return `scatterlayer${nextScatterLayerCounter++}`; }
function findScatterLayerById(id) { return id ? currentScatterLayers.find((l) => l.id === id) : undefined; }
function defaultScatterLayer() {
  return {
    id: generateScatterLayerId(), name: 'New Layer', seed: Math.floor(Math.random() * 1e6),
    sources: [], scaleMin: 0.85, scaleMax: 1.2, randomYaw: true,
    minSpacing: 1.2, maxSlope: 35, brushRadius: 6, density: 0.6,
  };
}
// Wave 8 (Priority D, Sections 25-28): Item Definitions -- a bounded
// PROJECT-level registry (not per-level, unlike Objectives -- an item
// should mean the same thing on every level of one project), NOT a full
// RPG item database. `{id, name, description, iconTextureAssetId,
// stackable, maxStack, equipSlot, useAction}`. Runtime Inventory
// (`window.__gameInventory`) keeps using its EXISTING plain
// `{name: count}` shape and its existing free-typed-name actions
// unchanged (Section 27's own explicit backward-compatibility
// requirement) -- an Item Definition's own `id` is simply ONE valid
// string an author can give/remove/carry, exactly like any other
// inventory key, just one with real metadata (icon/stack limit/use
// action) attached for the Inventory UI and Use Item to read.
let currentItemDefs = [];
let nextItemDefId = 1;
function generateItemDefId() { return `item${nextItemDefId++}`; }
function findItemDefById(id) { return id ? currentItemDefs.find((d) => d.id === id) : undefined; }

// Guards the narrow window inside loadProjectFull between `levels` being
// assigned the freshly-normalized (correct) incoming data and
// loadProjectData() actually populating `placed` to match it. During that
// window `placed` still reflects whichever OLD scene was live before this
// load started -- calling syncCurrentLevelObjects() in there (e.g. from an
// asset-library render triggered by loadAssets/loadTextureAssets/
// loadAudioAssets computing a usage count) would overwrite the just-loaded
// level's real objects with a serialization of that stale scene. See
// API-FRICTION.md finding #57.
let loadingProjectGuard = false;
function syncCurrentLevelObjects() {
  if (loadingProjectGuard) return;
  levels[currentLevelIndex].objects = serializeScene();
  // Wave 6 (Priority H): app.getEnvironment().skyTexture is a LIVE GPU
  // texture handle (a WebGLTexture), never JSON-serializable -- the same
  // "handle vs persisted reference" split every other texture-bearing field
  // in this editor already follows (entity.texture is live; item.textureAssetId
  // is what's actually saved). Strip the raw handle and persist the asset id
  // instead (currentSkyTextureAssetId, kept in sync by the Sky Panorama
  // dropdown below); applyLevelEnvironment is the one place that resolves
  // it back into a live handle on the way back in.
  const env = app.getEnvironment();
  delete env.skyTexture;
  env.skyTextureAssetId = currentSkyTextureAssetId || undefined;
  levels[currentLevelIndex].environment = env;
  levels[currentLevelIndex].playerSettings = currentPlayerSettings;
  levels[currentLevelIndex].ui = currentUiConfig;
  levels[currentLevelIndex].ambientAudio = currentAmbientAudioConfig;
  levels[currentLevelIndex].sequences = currentSequences;
  levels[currentLevelIndex].objectiveDefs = currentObjectiveDefs;
  levels[currentLevelIndex].scatterLayers = currentScatterLayers;
}
let nextItemId = 1;
function generateItemId() { return `obj${nextItemId++}`; }
// Same fix shape as reconcileGraphNodeIdCounter (AUDIT.md finding #3):
// nextItemId resets to 1 on every fresh page load, so loading a project
// whose items already have higher-numbered ids must bump the counter past
// them before any NEW item is created, or a fresh id could collide with
// one already in the loaded scene.
function reconcileItemIdCounter(id) {
  const match = /^obj(\d+)$/.exec(id);
  if (match) nextItemId = Math.max(nextItemId, Number(match[1]) + 1);
}
// The single choke point every placed item is added through -- assigns an
// id if the item doesn't already have one (a fresh item) and leaves an
// existing id alone (loaded from a saved record), so every future
// placed.push call site gets id assignment for free instead of needing to
// remember it individually.
function addPlaced(item) {
  if (!item.id) item.id = generateItemId();
  reconcileItemIdCounter(item.id);
  if (item.groupId) reconcileGroupIdCounter(item.groupId);
  placed.push(item);
  return item;
}
// Group ids get their own counter/reconcile pair rather than reusing
// generateItemId's -- a loaded project's group ids ('group3', say) don't
// bump nextItemId at all (reconcileItemIdCounter only recognizes 'objN'),
// so a same-session-created group could otherwise land on a number a
// loaded project already used, silently merging two unrelated groups.
let nextGroupId = 1;
function generateGroupId() { return `group${nextGroupId++}`; }
function reconcileGroupIdCounter(id) {
  const match = /^group(\d+)$/.exec(id);
  if (match) nextGroupId = Math.max(nextGroupId, Number(match[1]) + 1);
}
function findItemById(id) {
  return id ? placed.find((p) => p.id === id) : undefined;
}

// --- Transform hierarchy (Wave 4) ---
// A parent's transform affects its children. Deliberately NOT a second
// "position" concept living alongside entity.position -- every consumer in
// this codebase (renderer, physics/collision, triggers, AI, cameras
// targeting an object) already reads `item.entity.position/rotationY/scale`
// directly as WORLD space, and none of those call sites should need to
// learn about parenting. So a parented item's `entity.*` fields are kept
// as the single always-current WORLD transform, recomputed from its stored
// LOCAL transform (`localPosition`/`localRotationY`/`localScale`, meaningful
// only while `parentId` is set) every tick via updateHierarchyTransforms()
// and immediately after any edit. This is what keeps rendering and physics
// from ever disagreeing about where a child actually is -- there is only
// ever one position field, and it is always world space.
//
// Only 'cube'/'camera'/'spawner' kinds (all entity-backed with independent
// rotationY/scale) can be full parents or rotating/scaling children.
// 'emitter' (handle-backed, position only) can be a CHILD (its position
// follows a moving/rotating parent) but not meaningfully a parent of
// rotation/scale, and its own rotationY/scale don't exist to inherit.
// Terrain/water are deliberately excluded from hierarchy entirely -- large
// environment pieces, not the "machine built from parts" use case this
// feature targets, and repositioning either already has its own established
// (and more expensive) drag path.
function hierarchyCapable(item) {
  return item.kind === 'cube' || item.kind === 'camera' || item.kind === 'spawner' || item.kind === 'emitter' || item.kind === 'light';
}
function itemLocalNode(item) {
  // Returns { position, quaternion, scale, hasOrientation } -- a uniform
  // view over the two different backing shapes (entity vs handle) so
  // hierarchy code never needs to branch on kind. `quaternion` is always a
  // real Opus.Quat (identity for a non-oriented handle-only kind like
  // 'emitter'), never a bare rotationY number -- see the Wave 5 full-XYZ
  // hierarchy comment below for why a Y-only composition was replaced.
  if (item.kind === 'emitter') return { position: item.handle.position, quaternion: Opus.Quat.identity(), scale: new Opus.Vec3(1, 1, 1), hasOrientation: false };
  return { position: item.entity.position, quaternion: item.entity.quaternion, scale: item.entity.scale, hasOrientation: true };
}
// A hierarchy child's LOCAL orientation, from whichever shape its record
// carries -- `localQuat` (Wave 5, full XYZ) if present, else derived from
// the legacy `localRotationY`-only shape (Wave 4 and every hierarchy saved
// before Wave 5) as a pure-Y quaternion. This one function is what lets
// resolveWorldTransform below stay a single quaternion-only composition
// path with no separate Y-only branch anywhere -- an old saved hierarchy
// loads and behaves identically without a distinct migration step, because
// "pure Y rotation" is just the specific quaternion Quat.fromEuler(0,y,0)
// produces, not a different code path.
function itemLocalQuat(item) {
  if (item.localQuat) return item.localQuat;
  return Opus.Quat.fromEuler(0, item.localRotationY || 0, 0);
}
// True only when an entity's orientation has genuine pitch/roll -- used to
// decide whether a serialized record needs the new `quaternion` field at
// all. A pure-yaw entity (every object saved before Wave 5, and any object
// nobody ever pitched/rolled since) keeps serializing as JUST `rotationY`,
// byte-for-byte identical to its pre-Wave-5 shape, matching the same
// "omitted entirely at defaults" discipline Materials 2.0 already
// established for its own new optional fields.
function hasPitchOrRoll(entity) {
  const e = entity.quaternion.toEuler();
  return Math.abs(e.x) > 1e-9 || Math.abs(e.z) > 1e-9;
}
function quatToArray(q) { return [q.x, q.y, q.z, q.w]; }
function quatFromArray(a) { return new Opus.Quat(a[0], a[1], a[2], a[3]); }
function isDescendantOf(candidateAncestorId, item) {
  // Cycle guard for reparenting: is `candidateAncestorId` reachable by
  // walking DOWN from `item` (i.e. would making item's descendant its new
  // parent create a loop)? Walks the item's own subtree rather than walking
  // up from the candidate, since at call time the candidate hasn't been
  // assigned as a parent yet -- there's nothing to walk up from.
  const stack = [item.id];
  const seen = new Set();
  while (stack.length) {
    const id = stack.pop();
    if (id === candidateAncestorId) return true;
    if (seen.has(id)) continue;
    seen.add(id);
    for (const child of placed) {
      if (child.parentId === id) stack.push(child.id);
    }
  }
  return false;
}
// Every item transitively parented under `rootItem`, in no particular
// order. Used by "Save as Prefab" (Prefabs 2.0) to capture a whole assembly
// from just the one object the author clicked.
function collectDescendants(rootItem) {
  const result = [];
  const stack = [rootItem.id];
  const seen = new Set([rootItem.id]);
  while (stack.length) {
    const id = stack.pop();
    for (const child of placed) {
      if (child.parentId === id && !seen.has(child.id)) {
        seen.add(child.id);
        result.push(child);
        stack.push(child.id);
      }
    }
  }
  return result;
}
// Wave 6B (Priority L): the multi-select Rotate/Scale hard edge -- when a
// selection contains BOTH a parent and its own child, only the parent may
// be transformed directly. Directly rotating/scaling the child too would
// double-transform it: `resolveWorldTransform` (below) already reapplies
// the child's fixed localPosition/localQuat/localScale against the
// PARENT'S newly-changed world transform on the very next tick (the same
// mechanism that already correctly carries a child along when only its
// parent moves), so a child whose parent is also selected is filtered out
// here and left for that existing mechanism to carry automatically -- never
// touched directly by the gizmo drag itself.
function selectionRoots(itemsSet) {
  return [...itemsSet].filter((item) => {
    if (!item.parentId) return true;
    const parent = findItemById(item.parentId);
    return !parent || !itemsSet.has(parent);
  });
}
let hierarchyTickToken = 0;
function updateHierarchyTransforms() {
  // Fresh memo token each call rather than clearing a Map -- resolving N
  // items with M average depth is O(N) total work (each item's world
  // transform computed once, parents resolved on first access by whichever
  // child reaches them first), not O(N*M).
  hierarchyTickToken++;
  for (const item of placed) {
    if (item.parentId) resolveWorldTransform(item);
  }
}
// Wave 7 (Priority A/Section 9): the socket-attachment "effective parent"
// transform -- character world x animated joint pose x socket offset, in
// EXACTLY that order, as one coherent composition (never a per-object
// special case). Returns the same `{position, quaternion, scale}` shape
// `itemLocalNode` already returns, so `resolveWorldTransform` below can use
// it as a drop-in substitute for the ordinary parent's own node -- the
// attached object's own local offset (localPosition/localQuat/localScale)
// then composes on TOP of this exactly the same way it already composes on
// top of an ordinary parent, one shared final step either way. Returns
// `null` (never throws) for anything that isn't actually a valid, resolvable
// socket right now -- a missing/renamed socket, a non-skinned character, or
// a joint name no longer present on the asset's rig -- so a dangling socket
// reference degrades to "attached to the character's own root" instead of
// crashing the whole hierarchy resolve pass.
function resolveSocketSourceTransform(characterItem, socketName) {
  const entity = characterItem.entity;
  if (!entity || !entity.skin) return null;
  const asset = findAssetById(characterItem.assetId);
  const socket = asset && asset.sockets && asset.sockets.find((s) => s.name === socketName);
  if (!socket) return null;
  const joints = Opus.Skin.computeJointTransforms(entity.skin, entity.animationClip, entity.animationTime);
  const joint = joints.find((j) => j.name === socket.jointName);
  if (!joint) return null;
  // Character world x joint (skin-local) pose.
  const scaledJointPos = new Opus.Vec3(joint.position.x * entity.scale.x, joint.position.y * entity.scale.y, joint.position.z * entity.scale.z);
  const jointWorldPos = entity.position.add(entity.quaternion.rotateVec3(scaledJointPos));
  const jointWorldQuat = entity.quaternion.multiply(joint.rotation);
  const jointWorldScale = new Opus.Vec3(entity.scale.x * joint.scale.x, entity.scale.y * joint.scale.y, entity.scale.z * joint.scale.z);
  // ...x the socket's own authored offset (in the joint's own local space).
  const off = socket.positionOffset || { x: 0, y: 0, z: 0 };
  const offQuat = socketOffsetQuat(socket);
  const offScale = socket.scaleOffset || { x: 1, y: 1, z: 1 };
  const scaledOff = new Opus.Vec3(off.x * jointWorldScale.x, off.y * jointWorldScale.y, off.z * jointWorldScale.z);
  return {
    position: jointWorldPos.add(jointWorldQuat.rotateVec3(scaledOff)),
    quaternion: jointWorldQuat.multiply(offQuat),
    scale: new Opus.Vec3(jointWorldScale.x * offScale.x, jointWorldScale.y * offScale.y, jointWorldScale.z * offScale.z),
  };
}
// A socket's own Rotation Offset is authored as XYZ degrees (matching every
// other author-facing rotation field in this editor, e.g. Player Visual's
// `rotationOffsetY`) -- generalized to all 3 axes here since a weapon socket
// genuinely needs full orientation control, not just yaw.
function socketOffsetQuat(socket) {
  const r = socket.rotationOffset || { x: 0, y: 0, z: 0 };
  return Opus.Quat.fromEuler(r.x * Math.PI / 180, r.y * Math.PI / 180, r.z * Math.PI / 180);
}
// Full XYZ hierarchy composition (Wave 5): worldQuat = parentWorldQuat *
// localQuat, worldPos = parentWorldPos + parentWorldQuat.rotateVec3(scaledLocal)
// -- the general quaternion form of what was previously a Y-only rotation-
// matrix composition. This is the ONE hierarchy transform path; there is no
// separate Y-only math running alongside it (per the explicit Wave 5
// requirement that a second parallel path would inevitably desync from
// this one) -- a legacy Y-only child is simply the special case where
// itemLocalQuat() derives a pure-Y quaternion from `localRotationY`.
// Wave 7 (Priority A): when `item.socketName` is also set, the "parent" used
// for composition is the LIVE socket transform above (character x joint x
// socket offset) instead of the parent's own plain root transform -- one
// extra substitution, the rest of this function's own composition (the
// attached object's local offset on top) is completely unchanged.
function resolveWorldTransform(item) {
  if (item._hierarchyTick === hierarchyTickToken) return; // already resolved this pass
  item._hierarchyTick = hierarchyTickToken;
  if (!item.parentId) return; // entity.* is already world space -- nothing to do
  const parent = findItemById(item.parentId);
  if (!parent || !hierarchyCapable(parent)) { item.parentId = undefined; return; } // dangling reference -- fail safe to unparented, not a crash
  resolveWorldTransform(parent); // parent must be fully world-resolved first (also self-guards cycles via the tick token)
  const parentNode = (item.socketName && resolveSocketSourceTransform(parent, item.socketName)) || itemLocalNode(parent);
  const node = itemLocalNode(item);
  const localQuat = itemLocalQuat(item);
  const worldQuat = parentNode.quaternion.multiply(localQuat);
  const worldScale = new Opus.Vec3(
    parentNode.scale.x * (item.localScale ? item.localScale.x : 1),
    parentNode.scale.y * (item.localScale ? item.localScale.y : 1),
    parentNode.scale.z * (item.localScale ? item.localScale.z : 1),
  );
  const local = item.localPosition || new Opus.Vec3(0, 0, 0);
  const scaledLocal = new Opus.Vec3(local.x * parentNode.scale.x, local.y * parentNode.scale.y, local.z * parentNode.scale.z);
  const rotatedLocal = parentNode.quaternion.rotateVec3(scaledLocal);
  const worldPos = parentNode.position.add(rotatedLocal);
  node.position.set ? node.position.set(worldPos.x, worldPos.y, worldPos.z) : Object.assign(node.position, worldPos);
  if (node.hasOrientation) {
    // Every entity-backed child kind (cube/camera/spawner/light) now
    // inherits full parent orientation, not just cubes -- Wave 4 only ever
    // wrote `rotationY` for `kind==='cube'` children, since Y-only rotation
    // had no meaningful effect on a Camera/Spawner/Light marker's own
    // concept of orientation; full XYZ orientation does (a spot light's
    // marker, a camera rig, a weapon-mount muzzle all need to visibly pitch
    // and roll with a rotated parent -- exactly this wave's own dogfood
    // requirement), so the restriction is lifted for all of them.
    item.entity.quaternion = worldQuat;
    item.entity.scale.set ? item.entity.scale.set(worldScale.x, worldScale.y, worldScale.z) : Object.assign(item.entity.scale, worldScale);
  }
}
// Parents `item` under `parentItem`, computing localPosition/localRotationY/
// localScale so the object's WORLD transform is bit-for-bit unchanged by
// becoming a child -- "an object should not visually jump simply because it
// became a child" is the explicit Wave 4 requirement this exists to satisfy.
function reparentItem(item, parentItem) {
  if (!item || !parentItem || item === parentItem) return false;
  if (!hierarchyCapable(item) || !hierarchyCapable(parentItem)) return false;
  if (isDescendantOf(parentItem.id, item)) { showStatus(`Can't parent -- "${itemDisplayName(parentItem, placed.indexOf(parentItem))}" is already a descendant of this object`); return false; }
  // Resolve current world transforms of both BEFORE reassigning parentId --
  // if item already had a different parent, its entity.* fields are already
  // its correct current world transform (kept live by updateHierarchyTransforms
  // every frame / every edit), so no special-case is needed for re-parenting
  // an already-parented object onto a new parent.
  resolveWorldTransform(item);
  resolveWorldTransform(parentItem);
  const parentNode = itemLocalNode(parentItem);
  const node = itemLocalNode(item);
  const worldPos = node.position.clone();
  const worldQuat = node.hasOrientation ? node.quaternion : Opus.Quat.identity();
  const worldScale = node.hasOrientation ? node.scale.clone() : new Opus.Vec3(1, 1, 1);
  const offset = worldPos.sub(parentNode.position);
  const parentInverse = parentNode.quaternion.conjugate();
  const unrotated = parentInverse.rotateVec3(offset);
  const localPosition = new Opus.Vec3(
    parentNode.scale.x !== 0 ? unrotated.x / parentNode.scale.x : 0,
    parentNode.scale.y !== 0 ? unrotated.y / parentNode.scale.y : 0,
    parentNode.scale.z !== 0 ? unrotated.z / parentNode.scale.z : 0,
  );
  item.parentId = parentItem.id;
  item.localPosition = localPosition;
  // localQuat = inverse(parentWorldQuat) * childWorldQuat -- the exact
  // quaternion generalization of the old `worldRotY - parentNode.rotationY`
  // subtraction, solving for whatever local orientation reproduces the
  // child's current world orientation unchanged under the new parent.
  item.localQuat = parentInverse.multiply(worldQuat);
  item.localRotationY = undefined; // superseded by localQuat -- see itemLocalQuat's own fallback for anything that still reads it
  item.localScale = new Opus.Vec3(
    parentNode.scale.x !== 0 ? worldScale.x / parentNode.scale.x : worldScale.x,
    parentNode.scale.y !== 0 ? worldScale.y / parentNode.scale.y : worldScale.y,
    parentNode.scale.z !== 0 ? worldScale.z / parentNode.scale.z : worldScale.z,
  );
  hierarchyTickToken++; // force a fresh resolve pass so entity.* reflects the new parenting immediately, not next frame
  resolveWorldTransform(item);
  return true;
}
// Unparenting is trivial by construction: entity.* already holds the
// item's correct current WORLD transform (kept live every frame), so
// clearing parentId alone is a complete, correct, non-jumping unparent.
function unparentItem(item) {
  if (!item || !item.parentId) return false;
  resolveWorldTransform(item);
  item.parentId = undefined;
  item.localPosition = undefined;
  item.localRotationY = undefined;
  item.localQuat = undefined;
  item.localScale = undefined;
  item.socketName = undefined;
  return true;
}
// Wave 7 (Priority A/Section 7): "Attach Object to Socket" -- deliberately a
// SEPARATE entry point from reparentItem above, not a variant of it: an
// ordinary reparent preserves the child's CURRENT world transform (no
// visual jump), but attaching a weapon to a hand should snap it to sit
// EXACTLY at the socket (identity local offset) -- the expected default for
// "put this in the character's hand," not "keep it wherever it happened to
// be in the world." Sets `parentId` (reusing the ordinary hierarchy field --
// a socket attachment IS a hierarchy child, just with an extra joint+socket
// transform spliced into the composition, see resolveSocketSourceTransform)
// plus the new `socketName`.
function attachToSocket(item, characterItem, socketName) {
  if (!item || !characterItem || item === characterItem) return false;
  if (!hierarchyCapable(item) || !hierarchyCapable(characterItem)) return false;
  if (isDescendantOf(characterItem.id, item)) { showStatus(`Can't attach -- "${itemDisplayName(characterItem, placed.indexOf(characterItem))}" is already a descendant of this object`); return false; }
  item.parentId = characterItem.id;
  item.socketName = socketName;
  item.localPosition = new Opus.Vec3(0, 0, 0);
  item.localQuat = Opus.Quat.identity();
  item.localRotationY = undefined;
  item.localScale = new Opus.Vec3(1, 1, 1);
  hierarchyTickToken++;
  resolveWorldTransform(item);
  return true;
}
// Detaching from a socket is unparenting -- unparentItem already clears
// `socketName` too, so this is just the one shared exit path with a name
// that reads correctly at its own call sites.
function detachFromSocket(item) { return unparentItem(item); }
let nextSocketId = 1;
function generateSocketId() { return `socket${nextSocketId++}`; }
let nextAnimEventId = 1;
function generateAnimEventId() { return `aevt${nextAnimEventId++}`; }
// Wave 7 (Priority B/Section 12): Animation Events editor -- same
// "build the DOM in JS, wire handlers after" pattern the Socket Editor
// (immediately above) and the HUD/Sequence step lists already established.
// A CURATED, deliberately bounded action list, not every ACTION_TYPES
// entry: most actions (Move Object, Set Position, etc.) only make sense
// with a specific `targetId`/self item, a context an Animation Event fired
// off a shared ASSET's clip timeline doesn't reliably have one of. The
// three offered here are exactly the ones this priority's own dogfood
// justified (fire the weapon at a specific frame, play a sound/footstep,
// show a message) -- matching the spec's own worked examples.
const ANIMATION_EVENT_ACTIONS = ['fireWeapon', 'sound', 'message'];
function renderAnimationEventList(item) {
  const listEl = document.getElementById('anim-event-list');
  if (!listEl) return;
  const asset = findAssetById(item.assetId);
  if (!asset) { listEl.innerHTML = ''; return; }
  asset.animationEvents = asset.animationEvents || [];
  const clips = item.entity.skin.clips;
  const findEvent = (id) => asset.animationEvents.find((e) => e.id === id);
  if (asset.animationEvents.length === 0) {
    listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No animation events yet -- add one below.</p>';
  } else {
    listEl.innerHTML = asset.animationEvents.map((ev) => {
      const def = ACTION_TYPES[ev.action];
      const clipLabel = clips[ev.clipIndex] ? clips[ev.clipIndex].name : '?';
      const fieldsHtml = def && def.fields.length
        ? def.fields.map((f) => `<div style="margin-top:4px"><label style="font-size:10px;color:#66759a">${escapeHtml(f.label)}</label>${renderActionFieldInput(f, (ev.params || {})[f.key], null)}</div>`).join('')
        : '';
      return `
      <div class="hud-element-row" data-event-id="${ev.id}">
        <div class="hud-element-row-header">
          <span>${escapeHtml(clipLabel)} @ ${ev.time.toFixed(2)}s -- ${escapeHtml(def ? def.label : ev.action)}</span>
          <button class="hud-remove-btn" data-event-remove="${ev.id}" title="Delete event">✕</button>
        </div>
        <div class="field-triple">
          <select data-event-clip="${ev.id}">${clips.map((c, i) => `<option value="${i}"${ev.clipIndex === i ? ' selected' : ''}>${escapeHtml(c.name)}</option>`).join('')}</select>
          <input type="number" step="0.05" min="0" data-event-time="${ev.id}" value="${ev.time}">
          <select data-event-action="${ev.id}">${ANIMATION_EVENT_ACTIONS.map((a) => `<option value="${a}"${ev.action === a ? ' selected' : ''}>${escapeHtml(ACTION_TYPES[a].label)}</option>`).join('')}</select>
        </div>
        <div data-event-fields="${ev.id}">${fieldsHtml}</div>
      </div>`;
    }).join('');
  }
  listEl.querySelectorAll('[data-event-remove]').forEach((btn) => {
    btn.onclick = () => { pushUndo(); asset.animationEvents = asset.animationEvents.filter((e) => e.id !== btn.dataset.eventRemove); renderAnimationEventList(item); };
  });
  listEl.querySelectorAll('[data-event-clip]').forEach((sel) => {
    sel.onchange = () => { pushUndo(); const ev = findEvent(sel.dataset.eventClip); if (ev) ev.clipIndex = Number(sel.value); };
  });
  listEl.querySelectorAll('[data-event-time]').forEach((input) => {
    input.oninput = () => { const ev = findEvent(input.dataset.eventTime); if (!ev) return; const v = parseFloat(input.value); if (!Number.isNaN(v)) ev.time = Math.max(0, v); };
  });
  listEl.querySelectorAll('[data-event-action]').forEach((sel) => {
    sel.onchange = () => { pushUndo(); const ev = findEvent(sel.dataset.eventAction); if (!ev) return; ev.action = sel.value; ev.params = {}; renderAnimationEventList(item); };
  });
  // Per-event param fields, reusing the SAME renderActionFieldInput/
  // data-field convention the fixed-dropdown Add Behavior UI already uses --
  // scoped per-event via each row's own `data-event-fields` container so
  // multiple events' same-named fields (two Sound events, say) never
  // collide on a shared `data-field` id the way a page-wide selector would.
  listEl.querySelectorAll('[data-event-fields]').forEach((container) => {
    const ev = findEvent(container.dataset.eventFields);
    if (!ev) return;
    container.querySelectorAll('[data-field]').forEach((input) => {
      const handler = () => {
        ev.params = ev.params || {};
        ev.params[input.dataset.field] = input.type === 'checkbox' ? input.checked : input.value;
      };
      input.oninput = handler;
      input.onchange = handler;
    });
  });
  const addBtn = document.getElementById('anim-event-add-btn');
  if (addBtn) {
    addBtn.onclick = () => {
      pushUndo();
      asset.animationEvents.push({ id: generateAnimEventId(), clipIndex: 0, time: 0, action: 'fireWeapon', params: {} });
      renderAnimationEventList(item);
    };
  }
}
// Wave 7 (Priority A/Section 6): the Socket Editor -- a real list-row UI
// over `asset.sockets`, same "build the DOM in JS, wire handlers after"
// pattern the HUD Element list/Sequence step list already established, not
// a second authoring convention. Called with the currently-selected SKINNED
// ITEM (not the asset directly) so it can resolve `item.assetId` itself,
// same as every other per-instance-but-asset-scoped panel in this Inspector.
function renderSocketList(item) {
  const listEl = document.getElementById('socket-list');
  if (!listEl) return;
  const asset = findAssetById(item.assetId);
  if (!asset) { listEl.innerHTML = ''; return; }
  asset.sockets = asset.sockets || [];
  const jointNames = item.entity.skin.jointNames || [];
  if (asset.sockets.length === 0) {
    listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No sockets yet -- add one below.</p>';
  } else {
    listEl.innerHTML = asset.sockets.map((s) => `
      <div class="hud-element-row" data-socket-id="${s.id}">
        <div class="hud-element-row-header">
          <span>${escapeHtml(s.name)} <span style="color:#66759a;font-size:10px">(${escapeHtml(s.jointName)})</span></span>
          <button class="hud-remove-btn" data-socket-remove="${s.id}" title="Delete socket">✕</button>
        </div>
        <div class="field-triple">
          <input type="text" data-socket-name="${s.id}" value="${escapeHtml(s.name)}" placeholder="Name">
          <select data-socket-bone="${s.id}">${jointNames.map((n) => `<option value="${escapeHtml(n)}"${s.jointName === n ? ' selected' : ''}>${escapeHtml(n)}</option>`).join('')}</select>
        </div>
        <div class="field-triple" style="margin-top:4px">
          <div><label style="font-size:10px;color:#66759a">Pos X/Y/Z</label></div>
        </div>
        <div class="field-triple">
          <input type="number" step="0.05" data-socket-posx="${s.id}" value="${(s.positionOffset || { x: 0 }).x}">
          <input type="number" step="0.05" data-socket-posy="${s.id}" value="${(s.positionOffset || { y: 0 }).y}">
          <input type="number" step="0.05" data-socket-posz="${s.id}" value="${(s.positionOffset || { z: 0 }).z}">
        </div>
        <div class="field-triple" style="margin-top:4px">
          <div><label style="font-size:10px;color:#66759a">Rot X/Y/Z (deg)</label></div>
        </div>
        <div class="field-triple">
          <input type="number" step="5" data-socket-rotx="${s.id}" value="${(s.rotationOffset || { x: 0 }).x}">
          <input type="number" step="5" data-socket-roty="${s.id}" value="${(s.rotationOffset || { y: 0 }).y}">
          <input type="number" step="5" data-socket-rotz="${s.id}" value="${(s.rotationOffset || { z: 0 }).z}">
        </div>
        <div class="field-triple" style="margin-top:4px">
          <div><label style="font-size:10px;color:#66759a">Scale X/Y/Z</label></div>
        </div>
        <div class="field-triple">
          <input type="number" step="0.05" min="0.01" data-socket-scalex="${s.id}" value="${(s.scaleOffset || { x: 1 }).x}">
          <input type="number" step="0.05" min="0.01" data-socket-scaley="${s.id}" value="${(s.scaleOffset || { y: 1 }).y}">
          <input type="number" step="0.05" min="0.01" data-socket-scalez="${s.id}" value="${(s.scaleOffset || { z: 1 }).z}">
        </div>
      </div>`).join('');
  }
  const findSocket = (id) => asset.sockets.find((s) => s.id === id);
  listEl.querySelectorAll('[data-socket-remove]').forEach((btn) => {
    btn.onclick = () => { pushUndo(); asset.sockets = asset.sockets.filter((s) => s.id !== btn.dataset.socketRemove); renderSocketList(item); };
  });
  listEl.querySelectorAll('[data-socket-name]').forEach((input) => {
    input.oninput = () => { const s = findSocket(input.dataset.socketName); if (s) s.name = input.value; };
  });
  listEl.querySelectorAll('[data-socket-bone]').forEach((sel) => {
    sel.onchange = () => { pushUndo(); const s = findSocket(sel.dataset.socketBone); if (s) s.jointName = sel.value; };
  });
  // Nine offset fields (position/rotation/scale x/y/z) -- wired explicitly
  // rather than via a generic dataset-name-mangling loop, so the mapping
  // from DOM attribute to {field, axis} stays plainly readable and can't
  // silently mis-wire from a camelCase-conversion mistake.
  const offsetFieldWiring = [
    ['data-socket-posx', 'socketPosx', 'positionOffset', 'x'], ['data-socket-posy', 'socketPosy', 'positionOffset', 'y'], ['data-socket-posz', 'socketPosz', 'positionOffset', 'z'],
    ['data-socket-rotx', 'socketRotx', 'rotationOffset', 'x'], ['data-socket-roty', 'socketRoty', 'rotationOffset', 'y'], ['data-socket-rotz', 'socketRotz', 'rotationOffset', 'z'],
    ['data-socket-scalex', 'socketScalex', 'scaleOffset', 'x'], ['data-socket-scaley', 'socketScaley', 'scaleOffset', 'y'], ['data-socket-scalez', 'socketScalez', 'scaleOffset', 'z'],
  ];
  for (const [attr, datasetKey, field, axis] of offsetFieldWiring) {
    listEl.querySelectorAll(`[${attr}]`).forEach((input) => {
      input.oninput = () => {
        const s = findSocket(input.dataset[datasetKey]);
        if (!s) return;
        const defVal = field === 'scaleOffset' ? 1 : 0;
        s[field] = s[field] || { x: defVal, y: defVal, z: defVal };
        const v = parseFloat(input.value);
        if (!Number.isNaN(v)) s[field][axis] = v;
      };
    });
  }
  const addBtn = document.getElementById('socket-add-btn');
  if (addBtn) {
    addBtn.onclick = () => {
      const nameInput = document.getElementById('socket-new-name');
      const boneSelect = document.getElementById('socket-new-bone');
      const name = nameInput.value.trim();
      if (!name) { showStatus('Name the socket first'); return; }
      if (asset.sockets.some((s) => s.name === name)) { showStatus(`A socket named "${name}" already exists`); return; }
      pushUndo();
      asset.sockets.push({ id: generateSocketId(), name, jointName: boneSelect.value, positionOffset: { x: 0, y: 0, z: 0 }, rotationOffset: { x: 0, y: 0, z: 0 }, scaleOffset: { x: 1, y: 1, z: 1 } });
      renderSocketList(item);
    };
  }
}
// Wave 7 (Priority D/Section 27): the AI State Machine editor -- a
// list/card editor (per the spec's own explicit preference over a node
// canvas for a first version), same "build the DOM in JS, wire handlers
// after" pattern every other Wave 7 list editor (Sockets, Animation
// Events, Equipment) already established. Each state card: Name, Movement
// (Type/Speed/Radius/Waypoints -- the same fields `applyAiMovementStep`
// already reads off `ai` itself, just scoped to this one state), Anim
// Role, an optional Attack sub-block (reusing the exact same
// Prefab/Radius/Cooldown/Damage fields the Simple-AI attack section
// already has), and its own ordered Transitions list (condition type +
// value + destination state -- authored order is transition PRIORITY,
// matching `tickAiStateMachine`'s own first-valid-wins evaluation) plus an
// Entry Actions list reusing the same curated ANIMATION_EVENT_ACTIONS set
// Priority B's event editor already established, for consistency.
// Wave 9 (Priority B/Sections 28-40): 'investigate' moves toward the last
// heard noise position (Section 36); 'canSeePlayer'/'cannotSeePlayer'
// (Sections 29-30, real FOV+distance+optional LOS) and 'heardNoiseRecently'
// (Sections 32-35) join the existing bounded condition set. Suspicion
// (Section 37-38) is deliberately NOT built -- Patrol/Investigate/Chase via
// these three conditions already covers the required dogfood (Section 40)
// without a second numeric awareness axis; see the Wave 9 report.
const AI_MOVEMENT_TYPES = ['', 'follow', 'flee', 'wander', 'patrolRoute', 'navigateToTarget', 'orbit', 'faceTarget', 'investigate'];
const AI_CONDITION_TYPES = ['distanceToPlayerAtMost', 'distanceToPlayerAtLeast', 'lineOfSightToPlayer', 'noLineOfSightToPlayer', 'healthAtMost', 'timeInStateAtLeast', 'canSeePlayer', 'cannotSeePlayer', 'heardNoiseRecently'];
// Wave 9 (Priority B/Section 29): Perception is a property of the
// CHARACTER's senses, not of any one State -- authored once per AI
// (`ai.perception`), read by every state's own canSeePlayer/
// cannotSeePlayer/heardNoiseRecently transitions. Unset (every pre-Wave-9
// State Machine) defaults to Vision Distance 15 / FOV 100 / Requires LOS
// true / Hearing Radius 12 the FIRST time a perception condition is
// actually evaluated (see evaluateAiTransitionCondition) -- so an old
// project with no perception UI ever opened just gets sane defaults rather
// than "always blind."
function defaultAiPerception() { return { visionDistance: 15, fovDegrees: 100, requiresLOS: true, hearingRadius: 12 }; }
function renderAiPerceptionFields(item) {
  const el = document.getElementById('ai-perception-fields');
  if (!el) return;
  const ai = item.entity.ai;
  const p = ai.perception = ai.perception || defaultAiPerception();
  el.innerHTML = `
    <div style="margin-top:6px;font-size:10px;color:#66759a">Perception (Wave 9 Priority B):</div>
    <div class="field-triple">
      <div><label style="font-size:10px;color:#66759a">Vision Distance</label><input type="number" id="f-ai-vision-distance" step="0.5" min="0" value="${p.visionDistance}"></div>
      <div><label style="font-size:10px;color:#66759a">FOV (degrees)</label><input type="number" id="f-ai-fov" step="1" min="1" max="360" value="${p.fovDegrees}"></div>
      <div><label style="font-size:10px;color:#66759a">Hearing Radius</label><input type="number" id="f-ai-hearing-radius" step="0.5" min="0" value="${p.hearingRadius}"></div>
    </div>
    <label style="display:flex;align-items:center;gap:6px;font-size:11px;color:#c7d3ea;margin-top:3px"><input type="checkbox" id="f-ai-requires-los"${p.requiresLOS ? ' checked' : ''}> Requires Line Of Sight</label>`;
  document.getElementById('f-ai-vision-distance').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= 0) p.visionDistance = v; };
  document.getElementById('f-ai-fov').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) p.fovDegrees = v; };
  document.getElementById('f-ai-hearing-radius').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= 0) p.hearingRadius = v; };
  document.getElementById('f-ai-requires-los').onchange = (e) => { p.requiresLOS = e.target.checked; };
}
function renderAiStateList(item) {
  renderAiPerceptionFields(item);
  const listEl = document.getElementById('ai-state-list');
  if (!listEl) return;
  const ai = item.entity.ai;
  ai.states = ai.states || [];
  const stateNames = ai.states.map((s) => s.name);
  listEl.innerHTML = ai.states.map((s, i) => {
    s.movement = s.movement || { type: '' };
    const isStart = ai.startState ? ai.startState === s.name : i === 0;
    const transitionsHtml = (s.transitions || []).map((tr, ti) => `
      <div class="field-triple" data-tr-index="${ti}" style="margin-top:3px">
        <select data-tr-cond="${i}:${ti}">${AI_CONDITION_TYPES.map((c) => `<option value="${c}"${tr.condition && tr.condition.type === c ? ' selected' : ''}>${c}</option>`).join('')}</select>
        <input type="number" step="0.5" data-tr-value="${i}:${ti}" value="${tr.condition && tr.condition.value != null ? tr.condition.value : 0}">
        <select data-tr-to="${i}:${ti}">${stateNames.map((n) => `<option value="${escapeHtml(n)}"${tr.to === n ? ' selected' : ''}>${escapeHtml(n)}</option>`).join('')}</select>
      </div>`).join('');
    const entryHtml = (s.entryActions || []).map((ea, ei) => `
      <div class="field-triple" style="margin-top:3px">
        <select data-entry-action="${i}:${ei}">${ANIMATION_EVENT_ACTIONS.map((a) => `<option value="${a}"${ea.action === a ? ' selected' : ''}>${escapeHtml(ACTION_TYPES[a].label)}</option>`).join('')}</select>
        <button data-entry-remove="${i}:${ei}" class="hud-remove-btn">✕</button>
      </div>`).join('');
    return `
    <div class="hud-element-row" data-state-index="${i}" style="border-color:${isStart ? '#4a8a5a' : ''}">
      <div class="hud-element-row-header">
        <span>${isStart ? '▶ ' : ''}${escapeHtml(s.name || '(unnamed)')}</span>
        <div style="display:flex;gap:4px">
          <button data-state-start="${i}" class="toolbar-btn" style="margin-bottom:0;padding:2px 8px" title="Set as start state">Start</button>
          <button data-state-remove="${i}" class="hud-remove-btn" title="Delete state">✕</button>
        </div>
      </div>
      <input type="text" data-state-name="${i}" value="${escapeHtml(s.name || '')}" placeholder="State name (e.g. patrol)">
      <div class="field-triple" style="margin-top:4px">
        <select data-state-movetype="${i}">${AI_MOVEMENT_TYPES.map((t) => `<option value="${t}"${s.movement.type === t ? ' selected' : ''}>${t || '(idle/none)'}</option>`).join('')}</select>
        <input type="number" step="0.1" data-state-speed="${i}" value="${s.movement.speed != null ? s.movement.speed : 3}" placeholder="Speed">
        <input type="number" step="0.5" data-state-radius="${i}" value="${s.movement.radius != null ? s.movement.radius : 5}" placeholder="Radius">
      </div>
      <input type="text" data-state-waypoints="${i}" value="${escapeHtml(s.movement.waypointNames || '')}" placeholder="Waypoint names (Patrol Route only)" style="margin-top:4px">
      <input type="text" data-state-animrole="${i}" value="${escapeHtml(s.animRole || '')}" placeholder="Anim role (idle/walk/run/attack/death)" style="margin-top:4px">
      <label style="display:flex;align-items:center;gap:6px;font-size:11px;color:#c7d3ea;margin-top:4px"><input type="checkbox" data-state-hasattack="${i}"${s.attack ? ' checked' : ''}> Attack in this state</label>
      ${s.attack ? `
      <div style="margin-top:2px">${prefabs.length === 0 ? '<p style="color:#8592a8;font-size:11px;margin:2px 0">No prefabs saved yet.</p>' : renderActionFieldInput({ key: 'prefabName', type: 'prefab' }, s.attack.attackPrefab, `state-attack-prefab-${i}`)}</div>
      <div class="field-triple">
        <input type="number" data-state-attack-radius="${i}" value="${s.attack.attackRadius || 5}" placeholder="Range">
        <input type="number" data-state-attack-cooldown="${i}" value="${s.attack.attackCooldown || 1}" placeholder="Cooldown">
        <input type="number" data-state-attack-damage="${i}" value="${s.attack.attackDamage || 10}" placeholder="Damage">
      </div>` : ''}
      <div style="margin-top:6px;font-size:10px;color:#66759a">Transitions (priority = order):</div>
      ${transitionsHtml}
      <button data-tr-add="${i}" class="toolbar-btn" style="margin-top:3px;padding:2px 8px">+ Transition</button>
      <div style="margin-top:6px;font-size:10px;color:#66759a">Entry actions:</div>
      ${entryHtml}
      <button data-entry-add="${i}" class="toolbar-btn" style="margin-top:3px;padding:2px 8px">+ Entry Action</button>
    </div>`;
  }).join('') || '<p style="color:#66759a;font-size:11px;margin:2px 0">No states yet -- add one below.</p>';

  listEl.querySelectorAll('[data-state-remove]').forEach((btn) => { btn.onclick = () => { pushUndo(); ai.states.splice(Number(btn.dataset.stateRemove), 1); renderAiStateList(item); }; });
  listEl.querySelectorAll('[data-state-start]').forEach((btn) => { btn.onclick = () => { pushUndo(); ai.startState = ai.states[Number(btn.dataset.stateStart)].name; renderAiStateList(item); }; });
  listEl.querySelectorAll('[data-state-name]').forEach((input) => { input.oninput = () => { ai.states[Number(input.dataset.stateName)].name = input.value; }; });
  listEl.querySelectorAll('[data-state-movetype]').forEach((sel) => { sel.onchange = () => { pushUndo(); ai.states[Number(sel.dataset.stateMovetype)].movement.type = sel.value; ai.states[Number(sel.dataset.stateMovetype)].movement.resolvedWaypointIds = undefined; }; });
  listEl.querySelectorAll('[data-state-speed]').forEach((input) => { input.oninput = () => { const v = parseFloat(input.value); if (!Number.isNaN(v)) ai.states[Number(input.dataset.stateSpeed)].movement.speed = v; }; });
  listEl.querySelectorAll('[data-state-radius]').forEach((input) => { input.oninput = () => { const v = parseFloat(input.value); if (!Number.isNaN(v)) ai.states[Number(input.dataset.stateRadius)].movement.radius = v; }; });
  listEl.querySelectorAll('[data-state-waypoints]').forEach((input) => { input.oninput = () => { const s = ai.states[Number(input.dataset.stateWaypoints)]; s.movement.waypointNames = input.value; s.movement.resolvedWaypointIds = undefined; }; });
  listEl.querySelectorAll('[data-state-animrole]').forEach((input) => { input.oninput = () => { ai.states[Number(input.dataset.stateAnimrole)].animRole = input.value; }; });
  listEl.querySelectorAll('[data-state-hasattack]').forEach((cb) => {
    cb.onchange = () => { pushUndo(); ai.states[Number(cb.dataset.stateHasattack)].attack = cb.checked ? { attackEnabled: true, attackPrefab: '', attackRadius: 5, attackCooldown: 1, attackDamage: 10 } : undefined; renderAiStateList(item); };
  });
  listEl.querySelectorAll('[data-state-attack-radius]').forEach((input) => { input.oninput = () => { const v = parseFloat(input.value); if (v > 0) ai.states[Number(input.dataset.stateAttackRadius)].attack.attackRadius = v; }; });
  listEl.querySelectorAll('[data-state-attack-cooldown]').forEach((input) => { input.oninput = () => { const v = parseFloat(input.value); if (v > 0) ai.states[Number(input.dataset.stateAttackCooldown)].attack.attackCooldown = v; }; });
  listEl.querySelectorAll('[data-state-attack-damage]').forEach((input) => { input.oninput = () => { const v = parseFloat(input.value); if (v >= 0) ai.states[Number(input.dataset.stateAttackDamage)].attack.attackDamage = v; }; });
  listEl.querySelectorAll(`[id^="state-attack-prefab-"]`).forEach((sel) => {
    sel.onchange = () => { const i = Number(sel.id.replace('state-attack-prefab-', '')); ai.states[i].attack.attackPrefab = sel.value; };
  });
  listEl.querySelectorAll('[data-tr-add]').forEach((btn) => {
    btn.onclick = () => { pushUndo(); const s = ai.states[Number(btn.dataset.trAdd)]; s.transitions = s.transitions || []; s.transitions.push({ condition: { type: 'distanceToPlayerAtMost', value: 10 }, to: stateNames[0] || '' }); renderAiStateList(item); };
  });
  listEl.querySelectorAll('[data-tr-cond]').forEach((sel) => {
    sel.onchange = () => { pushUndo(); const [si, ti] = sel.dataset.trCond.split(':').map(Number); ai.states[si].transitions[ti].condition.type = sel.value; };
  });
  listEl.querySelectorAll('[data-tr-value]').forEach((input) => {
    input.oninput = () => { const [si, ti] = input.dataset.trValue.split(':').map(Number); const v = parseFloat(input.value); if (!Number.isNaN(v)) ai.states[si].transitions[ti].condition.value = v; };
  });
  listEl.querySelectorAll('[data-tr-to]').forEach((sel) => {
    sel.onchange = () => { pushUndo(); const [si, ti] = sel.dataset.trTo.split(':').map(Number); ai.states[si].transitions[ti].to = sel.value; };
  });
  listEl.querySelectorAll('[data-entry-add]').forEach((btn) => {
    btn.onclick = () => { pushUndo(); const s = ai.states[Number(btn.dataset.entryAdd)]; s.entryActions = s.entryActions || []; s.entryActions.push({ action: 'message', params: {} }); renderAiStateList(item); };
  });
  listEl.querySelectorAll('[data-entry-action]').forEach((sel) => {
    sel.onchange = () => { pushUndo(); const [si, ei] = sel.dataset.entryAction.split(':').map(Number); ai.states[si].entryActions[ei].action = sel.value; ai.states[si].entryActions[ei].params = {}; };
  });
  listEl.querySelectorAll('[data-entry-remove]').forEach((btn) => {
    btn.onclick = () => { pushUndo(); const [si, ei] = btn.dataset.entryRemove.split(':').map(Number); ai.states[si].entryActions.splice(ei, 1); renderAiStateList(item); };
  });
  const addBtn = document.getElementById('ai-state-add-btn');
  if (addBtn) {
    addBtn.onclick = () => {
      pushUndo();
      ai.states.push({ name: `state${ai.states.length + 1}`, movement: { type: '', speed: 3, radius: 5 }, transitions: [] });
      if (!ai.startState) ai.startState = ai.states[0].name;
      renderAiStateList(item);
    };
  }
}
function itemDisplayName(item, index) {
  return item.name || itemLabel(item, index != null ? index : placed.indexOf(item));
}
// selectedItem: the "primary" selection -- the last item clicked or
// shift-toggled. Stays meaningful even with multiple selected: when
// selectedItems.size === 1, selectedItem is that one item, used for the
// full single-item inspector (property editing across a heterogeneous
// multi-selection isn't attempted -- see renderInspector's multi-select
// branch, which only offers Duplicate All / Delete All).
let selectedItem = null;
let selectedItems = new Set();
// Waypoint Graph connection lines (Wave 4) -- a thin stretched cube between
// each connected pair, reusing the existing cube mesh/entity pipeline
// rather than a new GL_LINES draw path (no line-rendering primitive existed
// in this renderer before this feature, and building one for exactly one
// consumer wasn't worth it). Keyed by a canonical "loId|hiId" string so
// each bidirectional pair gets exactly one line entity, not two overlapping
// ones. Editor-only furniture -- hidden during Play the same way every
// other marker (gizmo handles, selection markers, Camera/Spawner/Light
// placeholders) already is.
const waypointConnectionLines = new Map(); // "loId|hiId" -> line entity
function syncWaypointConnectionLines() {
  const seen = new Set();
  for (const item of placed) {
    if (!item.isWaypoint || !item.connections) continue;
    for (const otherId of item.connections) {
      const other = findItemById(otherId);
      if (!other) continue;
      const key = item.id < otherId ? `${item.id}|${otherId}` : `${otherId}|${item.id}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const a = item.entity.position, b = other.entity.position;
      const mid = a.add(b).scale(0.5);
      const dx = b.x - a.x, dz = b.z - a.z;
      const len = Math.hypot(dx, dz);
      const angle = Math.atan2(dx, dz);
      let line = waypointConnectionLines.get(key);
      if (!line) {
        line = app.addEntity({ mesh: cubeMesh, color: [0.3, 0.85, 0.5], position: mid, scale: new Opus.Vec3(0.08, 0.08, Math.max(0.01, len)) });
        waypointConnectionLines.set(key, line);
      }
      line.position.set(mid.x, mid.y, mid.z);
      line.rotationY = angle;
      line.scale.set(0.08, 0.08, Math.max(0.01, len));
      line.visible = !playMode;
    }
  }
  // Prune lines whose pair no longer exists (deleted waypoint or removed connection).
  for (const [key, line] of waypointConnectionLines) {
    if (!seen.has(key)) { app.scene.remove(line); waypointConnectionLines.delete(key); }
  }
}
app.onUpdate(() => { syncWaypointConnectionLines(); });

// --- Wave 8 (Priority I, Sections 54-60): Spline/Path Authoring ---
// A Path is its OWN lightweight container item (`kind: 'path'`) holding an
// ORDERED list of point-marker item ids (`pointIds`) -- deliberately NOT a
// second point-storage shape: each point is an ordinary small placed
// marker (`isPathPoint: true`, matching the exact same
// authoring-primitive-reuse pattern Waypoint/Trigger/Ramp already
// established), so "move a point in the viewport" is just moving an
// ordinary object -- the EXISTING Move gizmo/drag mechanics, free, no new
// interaction code. `pathId` on each point marker is how a deleted marker
// finds its own way out of the owning path's `pointIds` (see
// removeItemFromScene's own extension below).
function samplePathPositionLinear(pts, t) {
  if (pts.length === 0) return new Opus.Vec3();
  if (pts.length === 1) return pts[0].clone();
  const segCount = pts.length - 1;
  const scaled = Math.min(t, 1) * segCount;
  const i = Math.min(segCount - 1, Math.floor(scaled));
  const localT = scaled - i;
  return pts[i].add(pts[i + 1].sub(pts[i]).scale(localT));
}
// Catmull-Rom (Section 55's own "then Catmull-Rom... if straightforward")
// -- the standard uniform 4-point formula, clamping the two virtual
// "before-first"/"after-last" control points to the endpoints themselves
// (no wrap) rather than requiring a real loop; a looped path instead
// samples with real wrap-around neighbors, giving a genuinely closed curve.
function catmullRomPoint(p0, p1, p2, p3, t) {
  const t2 = t * t, t3 = t2 * t;
  const c = (a0, a1, a2, a3) => 0.5 * ((2 * a1) + (-a0 + a2) * t + (2 * a0 - 5 * a1 + 4 * a2 - a3) * t2 + (-a0 + 3 * a1 - 3 * a2 + a3) * t3);
  return new Opus.Vec3(c(p0.x, p1.x, p2.x, p3.x), c(p0.y, p1.y, p2.y, p3.y), c(p0.z, p1.z, p2.z, p3.z));
}
function samplePathPositionSmooth(pts, t, loop) {
  const n = pts.length;
  if (n < 2) return samplePathPositionLinear(pts, t);
  const segCount = loop ? n : n - 1;
  const scaled = Math.min(t, 1) * segCount;
  const i = Math.min(segCount - 1, Math.floor(scaled));
  const localT = scaled - i;
  const at = (idx) => loop ? pts[((idx % n) + n) % n] : pts[Math.max(0, Math.min(n - 1, idx))];
  return catmullRomPoint(at(i - 1), at(i), at(i + 1), at(i + 2), localT);
}
// The ONE entry point every consumer (Follow Path movement, Populate Along
// Path, Camera Path) samples through -- `t` normalized [0,1] across the
// WHOLE path regardless of point count/spacing.
function samplePathPosition(pathItem, t) {
  const pts = (pathItem.pointIds || []).map((id) => { const p = findItemById(id); return p ? p.entity.position : null; }).filter(Boolean);
  return pathItem.smooth ? samplePathPositionSmooth(pts, t, pathItem.loop) : samplePathPositionLinear(pts, t);
}
// Path visualization -- segment-by-segment thin stretched cubes between
// CONSECUTIVE points (not all-pairs the way Waypoint connections are),
// exactly the same reusable line-drawing technique `syncWaypointConnectionLines`
// above already established. Editor-only, hidden during Play.
const pathVisualizationLines = new Map(); // "pathId:segmentIndex" -> line entity
function syncPathVisualizationLines() {
  const seen = new Set();
  for (const item of placed) {
    if (item.kind !== 'path') continue;
    const pts = (item.pointIds || []).map((id) => findItemById(id)).filter(Boolean);
    const segCount = item.loop ? pts.length : pts.length - 1;
    for (let i = 0; i < segCount; i++) {
      const a = pts[i].entity.position, b = pts[(i + 1) % pts.length].entity.position;
      const key = `${item.id}:${i}`;
      seen.add(key);
      const mid = a.add(b).scale(0.5);
      const dx = b.x - a.x, dz = b.z - a.z, dy = b.y - a.y;
      const len = Math.hypot(dx, dy, dz);
      const angle = Math.atan2(dx, dz);
      let line = pathVisualizationLines.get(key);
      if (!line) { line = app.addEntity({ mesh: cubeMesh, color: [0.85, 0.6, 0.2], position: mid, scale: new Opus.Vec3(0.06, 0.06, Math.max(0.01, len)) }); pathVisualizationLines.set(key, line); }
      line.position.set(mid.x, mid.y, mid.z);
      line.rotationY = angle;
      line.scale.set(0.06, 0.06, Math.max(0.01, len));
      line.visible = !playMode;
    }
  }
  for (const [key, line] of pathVisualizationLines) {
    if (!seen.has(key)) { app.scene.remove(line); pathVisualizationLines.delete(key); }
  }
}
app.onUpdate(() => { syncPathVisualizationLines(); });
// Wave 8 (Priority I/Section 61, Road/Fence Tool utility gate -- built,
// clean enough not to defer): instantiates copies of a Prefab or Asset at
// even intervals along a Path -- fences, lamps, road markers, pipes.
// Reuses `scatterPlaceOne` (Wave 7 Scatter) wholesale for the actual
// placement primitive (same two-prefab-shape handling, same Asset
// fallback) -- Populate Along Path is really just Scatter with its
// candidate points sampled off a curve instead of a region, so it shares
// Scatter's own already-proven instantiation code rather than a second
// implementation. Output is ordinary placed objects (Section 61's own
// explicit requirement), wrapped in exactly ONE `pushUndo()`.
function populateAlongPath(pathItem, config) {
  pushUndo();
  const pts = (pathItem.pointIds || []).map((id) => { const p = findItemById(id); return p ? p.entity.position : null; }).filter(Boolean);
  if (pts.length < 2 || config.count < 1) return { placedCount: 0, items: [] };
  const spacing = config.spacing > 0 ? config.spacing : 2;
  // Total sampled length, same 40-sample approximation `followPath` already uses.
  let totalLen = 0;
  let prev = samplePathPosition(pathItem, 0);
  for (let s = 1; s <= 40; s++) { const cur = samplePathPosition(pathItem, s / 40); totalLen += cur.sub(prev).length(); prev = cur; }
  const count = config.count || Math.max(1, Math.floor(totalLen / spacing) + (pathItem.loop ? 0 : 1));
  const allItems = [];
  for (let i = 0; i < count; i++) {
    const t = pathItem.loop ? (i / count) : (count === 1 ? 0 : i / (count - 1));
    const pos = samplePathPosition(pathItem, t);
    // Align-to-path-direction (Section 61): a forward-difference tangent,
    // clamped at the very end of a non-looping path.
    let rotationY = 0;
    if (config.alignToPath) {
      const tNext = Math.min(1, t + 0.01);
      const ahead = samplePathPosition(pathItem, tNext);
      const dir = ahead.sub(pos);
      if (Math.hypot(dir.x, dir.z) > 1e-5) rotationY = Math.atan2(dir.x, dir.z);
    }
    const scale = config.scale || 1;
    const newItems = scatterPlaceOne(config, pos, rotationY, scale);
    allItems.push(...newItems);
  }
  return { placedCount: count, items: allItems };
}
function addPathPoint(pathItem, position) {
  const entity = app.addEntity({ mesh: cubeMesh, color: [0.85, 0.6, 0.2], position, scale: new Opus.Vec3(0.3, 0.3, 0.3) });
  const marker = { kind: 'cube', entity, behaviors: [], isPathPoint: true, pathId: pathItem.id };
  addPlaced(marker);
  pathItem.pointIds = pathItem.pointIds || [];
  pathItem.pointIds.push(marker.id);
  return marker;
}

// --- Collider visualization (Wave 6, Priority A/Section 10) -------------
// "Show Colliders" -- an editor-only toggle, off by default, that draws a
// translucent marker over every Solid/Trigger's REAL collision bounds
// (Box or Sphere, offset-adjusted, oriented) so an author can see exactly
// what will physically block/trigger, independent of what the rendered
// mesh looks like. Never serialized, never visible during Play (same
// "editor furniture" convention every other gizmo/marker here already
// follows). One marker entity per item, reused across syncs rather than
// destroyed/recreated -- the same pooling pattern selection markers and
// the rotate gizmo's rings already established.
let showColliders = false;
const colliderVizHandles = new Map(); // item -> marker entity
function syncColliderViz() {
  if (!showColliders || playMode) {
    for (const entity of colliderVizHandles.values()) app.scene.remove(entity);
    colliderVizHandles.clear();
    return;
  }
  const wanted = new Set();
  for (const item of placed) {
    if (item.kind !== 'cube' || !item.entity.visible) continue;
    const isSolidCollider = !!item.entity.solid;
    const isTriggerVolume = !!item.isTrigger;
    if (!isSolidCollider && !isTriggerVolume) continue;
    wanted.add(item.id);
    let center; let half; let quat; let color;
    if (isTriggerVolume) {
      color = [0.85, 0.35, 0.95];
      if (item.triggerShape === 'sphere') {
        const r = 1.5 * Math.max(item.entity.scale.x, item.entity.scale.z);
        center = item.entity.position; half = new Opus.Vec3(r, r, r); quat = null;
      } else {
        center = item.entity.position; half = item.entity.scale.scale(0.5); quat = item.entity.quaternion;
      }
    } else {
      color = [0.3, 1, 0.5];
      const cfg = itemColliderConfig(item);
      center = item.entity.position.add(cfg.offset);
      if (cfg.shape === 'sphere') { half = new Opus.Vec3(cfg.radius, cfg.radius, cfg.radius); quat = null; }
      else { half = cfg.half; quat = item.entity.quaternion; }
    }
    let marker = colliderVizHandles.get(item.id);
    if (!marker) {
      marker = app.addEntity({ mesh: cubeMesh, color, position: center, scale: half.scale(2), unlit: true, alpha: 0.22 });
      colliderVizHandles.set(item.id, marker);
    } else {
      marker.position.set(center.x, center.y, center.z);
      marker.scale.set(half.x * 2, half.y * 2, half.z * 2);
      marker.color = color;
    }
    marker.quaternion = quat || Opus.Quat.identity();
  }
  for (const [id, entity] of colliderVizHandles) {
    if (!wanted.has(id)) { app.scene.remove(entity); colliderVizHandles.delete(id); }
  }
}
app.onUpdate(() => { if (!playMode) syncColliderViz(); });

// Wave 6 (Priority I): given a desired WORLD-space forward direction,
// returns the quaternion that points an entity's local +Z at it -- the
// exact inverse of the forward-vector formula the First-Person controller's
// own look code already established (yawForward = (sin(yaw), 0, cos(yaw))
// at pitch 0; see applyFirstPersonLook), derived algebraically from that
// same fromEuler(pitch, yaw, 0) composition rather than a new look-rotation-
// from-vectors algorithm. Reused for every Billboard, not a second facing
// formula.
function quatFacingDirection(dir) {
  const d = dir.normalize();
  const yaw = Math.atan2(d.x, d.z);
  const pitch = -Math.asin(Math.max(-1, Math.min(1, d.y)));
  return Opus.Quat.fromEuler(pitch, yaw, 0);
}
// Reorients every placed Billboard to face the camera, every frame, in
// BOTH edit and Play (unconditional -- unlike collider visualization, a
// Billboard's facing IS part of what it looks like, not an editor-only
// aid, so WYSIWYG requires this to run continuously in the editor preview
// too). 'cylindrical' zeroes the direction's Y component first, keeping
// the billboard upright (grass/trees/signs) instead of tilting to stare
// straight up/down when the camera is far overhead/underneath.
function syncBillboards() {
  const eye = app.camera.eye;
  for (const item of placed) {
    if (!item.isBillboard || !item.entity.visible) continue;
    let dir = eye.sub(item.entity.position);
    if (item.billboardMode === 'cylindrical') dir = new Opus.Vec3(dir.x, 0, dir.z);
    if (dir.length() < 1e-6) continue; // camera exactly at the billboard's own position -- no well-defined facing, skip this frame
    item.entity.quaternion = quatFacingDirection(dir);
  }
}
app.onUpdate(() => syncBillboards());

const selectionMarkers = new Map(); // item -> its own marker entity

function itemPosition(item) {
  // Wave 8 (Priority I): a Path has neither `.entity` nor `.handle` -- its
  // own "position" (for selection markers/gizmo purposes only; a Path
  // itself is never moved as a unit, only its individual point markers
  // are) is its first point's real position, falling back to the origin
  // for a genuinely empty path (shouldn't normally happen -- placeItem
  // always creates one point immediately -- but never throws either way).
  if (item.kind === 'path') { const first = (item.pointIds || []).map(findItemById).find(Boolean); return first ? first.entity.position : new Opus.Vec3(); }
  return item.entity ? item.entity.position : item.handle.position;
}

function itemLabel(item, index) {
  if (item.kind === 'path') return `Path #${index + 1}`; // Wave 8 (Priority I) -- checked before the `item.entity.ai` fallback below, which assumes every OTHER kind has an `.entity`
  if (item.kind === 'terrain') return `Terrain #${index + 1}`;
  if (item.kind === 'water') return `Water #${index + 1}`;
  if (item.kind === 'emitter') return `Particle Emitter #${index + 1}`;
  if (item.kind === 'camera') return `Camera #${index + 1}`;
  if (item.kind === 'spawner') return `Spawner #${index + 1}`;
  if (item.kind === 'light') return item.options.lightType === 'spot' ? `Spot Light #${index + 1}` : `Point Light #${index + 1}`;
  if (item.isTrigger) return `Trigger Volume #${index + 1}`;
  if (item.isWaypoint) return `Waypoint #${index + 1}`;
  if (item.isPathPoint) return `Path Point #${index + 1}`;
  if (item.isSpawnPoint) return item.isDefaultSpawn ? `Spawn Point (Default) #${index + 1}` : `Spawn Point #${index + 1}`;
  if (item.entity.ai) return `Enemy #${index + 1}`;
  // Cubes all look the same in this list otherwise, even though a scene can
  // now mix crates/hazards/boost pads/plain cubes — name by role, not shape.
  const behaviors = item.behaviors || [];
  if (behaviors.some((b) => b.action === 'boost')) return `Boost Pad #${index + 1}`;
  if (behaviors.some((b) => b.action === 'lose')) return item.entity.patrol ? `Patrol Hazard #${index + 1}` : `Hazard #${index + 1}`;
  if (behaviors.some((b) => b.action === 'win')) return `Win Trigger #${index + 1}`;
  if (behaviors.some((b) => b.action === 'script')) return `Crate #${index + 1}`;
  if (behaviors.some((b) => b.action === 'graph')) return `Bonus Crate #${index + 1}`;
  if (![cubeMesh, mineMesh, boostMesh].includes(item.entity.mesh)) return `Model #${index + 1}`;
  return `Cube #${index + 1}`;
}

function screenToGroundPoint(clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  const ndcX = ((clientX - rect.left) / rect.width) * 2 - 1;
  const ndcY = -(((clientY - rect.top) / rect.height) * 2 - 1);
  const ray = app.camera.screenPointToRay(ndcX, ndcY, canvas.width / Math.max(canvas.height, 1));
  if (Math.abs(ray.direction.y) < 1e-6) return null;
  const t = -ray.origin.y / ray.direction.y;
  if (t < 0) return null;
  return ray.origin.add(ray.direction.scale(t));
}

// General ray/plane intersection (Wave 5) -- screenToGroundPoint above is
// the special case `planeOrigin=(0,0,0), planeNormal=(0,1,0)`, which is all
// the Y-only rotate gizmo ever needed. Full XYZ rotation needs the SAME
// operation against an arbitrary plane (the one perpendicular to whichever
// axis ring is being dragged), so this generalizes it rather than adding a
// second ray-casting implementation next to it.
function screenToPlanePoint(clientX, clientY, planeOrigin, planeNormal) {
  const rect = canvas.getBoundingClientRect();
  const ndcX = ((clientX - rect.left) / rect.width) * 2 - 1;
  const ndcY = -(((clientY - rect.top) / rect.height) * 2 - 1);
  const ray = app.camera.screenPointToRay(ndcX, ndcY, canvas.width / Math.max(canvas.height, 1));
  const denom = ray.direction.dot(planeNormal);
  if (Math.abs(denom) < 1e-6) return null;
  const t = planeOrigin.sub(ray.origin).dot(planeNormal) / denom;
  if (t < 0) return null;
  return ray.origin.add(ray.direction.scale(t));
}

// The inverse of screenPointToRay -- the engine only ever needed
// screen-to-world (for placement/picking), so world-to-screen doesn't exist
// in the public API. Built entirely from what Camera already exposes
// publicly (eye, getBasis(), fovY), not a matrix the engine hides: the
// same perspective-projection math screenPointToRay's ray direction implies,
// solved in the other direction. Returns null for a point behind the camera.
function worldToScreen(worldPos) {
  const cam = app.camera;
  const { forward, right, up } = cam.getBasis();
  const v = worldPos.sub(cam.eye);
  const viewZ = v.dot(forward);
  if (viewZ <= 0.01) return null;
  const tanHalfFov = Math.tan(cam.fovY / 2);
  const aspect = canvas.width / Math.max(canvas.height, 1);
  const ndcX = v.dot(right) / (viewZ * tanHalfFov * aspect);
  const ndcY = v.dot(up) / (viewZ * tanHalfFov);
  const rect = canvas.getBoundingClientRect();
  return {
    x: ((ndcX + 1) / 2) * rect.width + rect.left,
    y: ((1 - ndcY) / 2) * rect.height + rect.top,
  };
}

// Terrain footprint, for raycast picking -- approximated as an AABB over its
// square size (not the true circular island shape, same spirit as the cube's
// sphere approximation below: close enough for a click/drag hit-test).
function terrainAABB(item) {
  const opts = item.options;
  const half = (opts.size ?? 22) * 0.5;
  const pos = item.handle.position;
  return new Opus.Physics.AABB(
    new Opus.Vec3(pos.x - half, pos.y - 3, pos.z - half),
    new Opus.Vec3(pos.x + half, pos.y + 3, pos.z + half),
  );
}

function pickEntity(clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  const ndcX = ((clientX - rect.left) / rect.width) * 2 - 1;
  const ndcY = -(((clientY - rect.top) / rect.height) * 2 - 1);
  const ray = app.camera.screenPointToRay(ndcX, ndcY, canvas.width / Math.max(canvas.height, 1));

  // Water is deliberately excluded: it's a single large backdrop plane
  // spanning most of the map, so making it raycast-pickable would mean
  // almost every click lands on it -- including the "click empty space to
  // deselect" gesture, which would stop working almost everywhere. It
  // stays Scene-list-only, as before.
  //
  // Cubes are checked -- and always preferred -- ahead of terrain, not
  // merged into one closest-t comparison. An object resting on an island
  // sits INSIDE that terrain's own AABB (which spans a generous +-3 in y to
  // approximate the whole heightfield), so its near face is almost always
  // closer to the camera than anything resting inside it. A raw
  // closest-hit comparison would make the terrain win nearly every time a
  // crate/hazard/boost pad sits on land -- exactly backwards from what
  // clicking or dragging a crate should do. Found by dragging a crate that
  // sits on an island and grabbing the whole island instead.
  let closestCubeT = Infinity;
  let cubeHit = null;
  for (const item of placed) {
    if (item.kind !== 'cube') continue;
    const radius = 0.6 * Math.max(item.entity.scale.x, item.entity.scale.y, item.entity.scale.z);
    const t = Opus.Physics.raySphere(ray.origin, ray.direction, item.entity.position, radius);
    if (t !== null && t < closestCubeT) {
      closestCubeT = t;
      cubeHit = item;
    }
  }
  if (cubeHit) return cubeHit;

  let closestTerrainT = Infinity;
  let terrainHit = null;
  for (const item of placed) {
    if (item.kind !== 'terrain') continue;
    const t = Opus.Physics.rayAABB(ray.origin, ray.direction, terrainAABB(item));
    if (t !== null && t < closestTerrainT) {
      closestTerrainT = t;
      terrainHit = item;
    }
  }
  return terrainHit;
}

// --- Drag and drop placement ---
// Built on Pointer Events end to end, not HTML5 Drag-and-Drop -- the
// `draggable` attribute's native drag simply doesn't fire on touch in most
// mobile browsers (it's a desktop-only affordance in practice), so a
// palette a touch user can't drag from isn't really no-code on a tablet at
// all. One pointer-based implementation replaces it for every input type,
// mouse and touch alike, rather than running two separate systems.

// Particle presets -- one-click starting points for the Emitter inspector's
// Preset dropdown (below), tuned by eye against the existing hovercraft
// exhaust/spray/foam emitters' own values rather than invented from
// scratch. Applying one overwrites rate/life/riseSpeed/spread/size/color/
// gravity on the live emitter directly -- position and maxParticles are
// deliberately left alone, since those are placement/perf choices the
// preset shouldn't override.
const PARTICLE_PRESETS = {
  Smoke: { rate: 12, life: [1.5, 3], riseSpeed: [0.3, 0.7], spread: 0.5, size: [0.15, 0.35], color: [0.5, 0.5, 0.5], gravity: 0.05 },
  Sparks: { rate: 30, life: [0.3, 0.7], riseSpeed: [1.5, 3], spread: 0.3, size: [0.03, 0.07], color: [1, 0.8, 0.3], gravity: -1.2 },
  Fire: { rate: 25, life: [0.4, 0.9], riseSpeed: [0.8, 1.6], spread: 0.25, size: [0.1, 0.22], color: [1, 0.45, 0.1], gravity: 0.3 },
  Magic: { rate: 18, life: [1, 2], riseSpeed: [0.2, 0.6], spread: 0.7, size: [0.06, 0.14], color: [0.6, 0.3, 1], gravity: -0.05 },
  Dust: { rate: 6, life: [2, 4], riseSpeed: [0.05, 0.2], spread: 1.2, size: [0.08, 0.16], color: [0.7, 0.65, 0.5], gravity: 0.02 },
  'Water Spray': { rate: 40, life: [0.35, 0.75], riseSpeed: [0.6, 1.3], spread: 0.8, size: [0.08, 0.2], color: [0.8, 0.95, 1], gravity: -0.7 },
  Burst: { rate: 0, life: [0.4, 1], riseSpeed: [1, 2.5], spread: 0.6, size: [0.08, 0.18], color: [1, 0.9, 0.6], gravity: -0.5 },
};

function placeItem(type, point) {
  pushUndo();
  if (type === 'cube') {
    point.y = 0.5;
    const entity = app.addEntity({ mesh: cubeMesh, color: [0.55, 0.65, 0.95], position: point, scale: new Opus.Vec3(1, 1, 1) });
    const item = { kind: 'cube', entity, behaviors: [] };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'ramp') {
    // Wave 6 (Priority B/Section 14): the same isWaypoint-style pattern --
    // a plain kind:'cube' item with an `isRamp` marker flag, gaining every
    // existing cube capability (solid, hierarchy, behaviors, Duplicate,
    // Save/Load) for free, distinguished only by its render mesh and by
    // which collision function the four Player Controllers call for it.
    point.y = 0.5;
    const entity = app.addEntity({ mesh: wedgeMesh, color: [0.6, 0.55, 0.45], position: point, scale: new Opus.Vec3(2, 1, 2) });
    entity.solid = true;
    const item = { kind: 'cube', entity, behaviors: [], isRamp: true };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'billboard') {
    // Wave 6 (Priority I): same plain kind:'cube' + marker-flag pattern as
    // Ramp/Waypoint/Trigger above -- a Billboard gets every existing cube
    // capability (Materials 2.0 texture/alpha/unlit, hierarchy, behaviors,
    // Duplicate, Save/Load) for free, distinguished only by its render mesh
    // (billboardMesh, a vertical quad) and by syncBillboards continuously
    // reorienting it to face the camera every frame.
    point.y = 1;
    const entity = app.addEntity({ mesh: billboardMesh, color: [1, 1, 1], position: point, scale: new Opus.Vec3(1.5, 1.5, 1.5) });
    const item = { kind: 'cube', entity, behaviors: [], isBillboard: true, billboardMode: 'full' };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'terrain') {
    const options = { seed: Math.floor(Math.random() * 10000), size: 20, segments: 48, radius: 8, position: new Opus.Vec3(point.x, 0, point.z) };
    const handle = app.createTerrain(options);
    const item = { kind: 'terrain', handle, options };
    syncTerrainLayerTextures(item);
    addPlaced(item);
    selectItem(item);
  } else if (type === 'water') {
    const options = { size: 24, segments: 48, position: new Opus.Vec3(point.x, -1.6, point.z) };
    const handle = app.createWater(options);
    const item = { kind: 'water', handle, options };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'emitter') {
    // A live, continuously-animating particle effect (torch flame,
    // waterfall mist, sparkle) -- Opus.App.createEmitter already existed
    // and is already used internally for the craft's own exhaust/spray/
    // foam trails, just never reachable as a placeable, no-code-authored
    // object in its own right. Runs (and is visible) in both edit and Play
    // -- the engine's own update loop drives it unconditionally, the same
    // way the craft's own trail emitters already animate continuously, so
    // it's true WYSIWYG with no special-casing needed for preview.
    point.y = 0.5;
    const options = { position: point, rate: 20, life: [1, 2], riseSpeed: [0.4, 1.0], spread: 0.6, size: [0.05, 0.12], color: [1, 0.85, 0.5], gravity: -0.15, maxParticles: 200 };
    const handle = app.createEmitter(options);
    const item = { kind: 'emitter', handle, options };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'waypoint') {
    // Deliberately a plain kind:'cube' item with an `isWaypoint` marker
    // flag, the exact same pattern isTrigger already established -- gets
    // free-drag AND Move-gizmo draggability, Duplicate, stable id, and
    // Save/Load for free from the existing cube machinery, instead of
    // becoming a whole new item kind with its own copy of all of that.
    point.y = 0.5;
    const entity = app.addEntity({ mesh: cubeMesh, color: [0.3, 0.85, 0.5], position: point, scale: new Opus.Vec3(0.4, 0.4, 0.4) });
    const item = { kind: 'cube', entity, behaviors: [], isWaypoint: true };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'pointLight' || type === 'spotLight') {
    // A small marker entity (this editor's established pattern for anything
    // that isn't itself a visible gameplay mesh -- Camera/Spawner use the
    // exact same shape) PLUS a real `app.createLight` handle that actually
    // illuminates the scene. Kept as two separate objects deliberately: the
    // marker is what hierarchy/gizmo/drag/Undo already know how to move: a
    // per-frame sync (see the always-on hierarchy onUpdate hook) copies the
    // marker's resolved WORLD position into the light handle every frame, so
    // a parented/animated light stays correctly lit with zero light-specific
    // hierarchy code.
    point.y = 2;
    const isSpot = type === 'spotLight';
    const entity = app.addEntity({ mesh: cubeMesh, color: isSpot ? [1, 0.85, 0.3] : [1, 0.95, 0.6], position: point, scale: new Opus.Vec3(0.35, 0.35, 0.35) });
    const options = { lightType: isSpot ? 'spot' : 'point', position: point.clone(), color: [1, 0.92, 0.75], intensity: 1.5, range: 8, angle: isSpot ? 0.4 : undefined, direction: isSpot ? new Opus.Vec3(0, -1, 0) : undefined };
    const lightHandle = app.createLight({ type: options.lightType, position: point.clone(), color: options.color, intensity: options.intensity, range: options.range, angle: options.angle, direction: options.direction });
    const item = { kind: 'light', entity, options, lightHandle };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'spawnPoint') {
    // Same plain kind:'cube'+marker-flag pattern as Waypoint/Trigger above --
    // free drag, Move gizmo, Duplicate, stable id, Save/Load, prefab-capable,
    // for zero extra machinery. `isDefaultSpawn` designates the one spawn a
    // fresh Play session actually boots from; computeSpawnPoint() (see Wave 4
    // spawn-resolution fix) reads it first, ahead of every other fallback.
    // The first Spawn Point placed in a level is auto-designated default so a
    // level is never left with zero default spawn just because nobody
    // explicitly clicked "Set as Default".
    point.y = 0.5;
    const entity = app.addEntity({ mesh: cubeMesh, color: [0.3, 0.9, 0.95], position: point, scale: new Opus.Vec3(0.5, 0.9, 0.5) });
    const hasDefaultAlready = placed.some((p) => p.isSpawnPoint && p.isDefaultSpawn);
    const item = { kind: 'cube', entity, behaviors: [], isSpawnPoint: true, isDefaultSpawn: !hasDefaultAlready };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'path') {
    // Wave 8 (Priority I): a Path's own container item carries no visible
    // mesh itself (it's pure authoring metadata -- `pointIds` -- plus the
    // line visualization above); the FIRST point marker is created here so
    // a freshly-placed Path is never empty.
    const item = { kind: 'path', name: '', pointIds: [], loop: false, smooth: false };
    addPlaced(item);
    addPathPoint(item, point.clone());
    selectItem(item);
  } else if (type === 'mine') {
    point.y = 0.5;
    const entity = app.addEntity({ mesh: mineMesh, color: [0.85, 0.2, 0.2], position: point, scale: new Opus.Vec3(1.1, 1.1, 1.1) });
    const item = { kind: 'cube', entity, behaviors: [{ trigger: 'enter', action: 'lose', param: '' }] };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'boost') {
    point.y = 0.5;
    const entity = app.addEntity({ mesh: boostMesh, color: [0.3, 0.85, 1], position: point, scale: new Opus.Vec3(1.3, 0.7, 1.3) });
    entity.spin = 1.5;
    const item = { kind: 'cube', entity, behaviors: [{ trigger: 'enter', action: 'boost', param: '11' }] };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'trigger') {
    // A trigger volume is a placed cube like any other (reuses picking,
    // dragging, duplicate/delete, Save/Load, Undo/Redo unchanged) with one
    // difference: `isTrigger` hides its marker once Play starts (see
    // enterPlayMode) -- in-game it's an invisible volume, not an object.
    // Its radius reuses the exact same scale-derived formula every 'enter'
    // cube already gets (1.5x horizontal scale), so resizing it with the
    // existing Scale field just works, no new field needed for that part.
    point.y = 0.5;
    const entity = app.addEntity({ mesh: cubeMesh, color: [0.85, 0.35, 0.95], position: point, scale: new Opus.Vec3(1.5, 1.5, 1.5) });
    const item = { kind: 'cube', entity, behaviors: [], isTrigger: true, triggerRepeat: true };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'camera') {
    // An authored camera preset -- an editor-only marker (hidden in Play,
    // same as a Trigger Volume) whose position/settings the Change Camera
    // action reads and applies to the real app.camera. Placing one doesn't
    // change what's currently rendering; only firing Change Camera does.
    point.y = 1.6;
    const entity = app.addEntity({ mesh: cubeMesh, color: [0.95, 0.75, 0.15], position: point, scale: new Opus.Vec3(0.45, 0.45, 0.7) });
    const options = { position: point.clone(), mode: 'chase', fovDegrees: 45, chase: { distance: 8, height: 3, pitch: 0.2, lerpSpeed: 6, rotationLerpSpeed: 8, lookAhead: 0.5 }, lookAtTargetId: null };
    const item = { kind: 'camera', entity, options };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'spawner') {
    // An editor-only marker (hidden in Play, same as Trigger Volume/Camera)
    // that spawns real Spawn-Prefab-style instances of a chosen prefab on
    // its own interval at runtime -- generalizes the "wave" pattern (Survival
    // Arena 2.0's Node Graph Delay chain) into a reusable placed object
    // instead of hand-wiring a graph every time.
    point.y = 1;
    const entity = app.addEntity({ mesh: cubeMesh, color: [0.95, 0.5, 0.2], position: point, scale: new Opus.Vec3(0.5, 1.2, 0.5) });
    const options = { position: point.clone(), prefabName: '', interval: 3, initialDelay: 0, maxActive: 5, totalCount: 0, radius: 3, startEnabled: true, tag: '' };
    const item = { kind: 'spawner', entity, options };
    addPlaced(item);
    selectItem(item);
  // --- Reusable Gameplay Component Presets (Wave 5, Priority K) -------
  // Every preset below is a curated combination of primitives that already
  // existed and were already independently dogfooded (Trigger Volume,
  // Behaviors/Action Types, Object Health's auto-init-on-first-hit via
  // tags, AI Follow, Property Animation, the Solid flag's own documented
  // "hidden = passable" rule) -- no new engine or editor mechanism was
  // added to build this list, matching the spec's own "package, don't
  // invent" framing for this priority. Every field written below is one a
  // user could set by hand through the existing Inspector; a preset just
  // saves them the trip.
  } else if (type === 'collectible') {
    point.y = 0.6;
    const entity = app.addEntity({ mesh: cubeMesh, color: [1, 0.85, 0.2], position: point, scale: new Opus.Vec3(0.4, 0.4, 0.4), unlit: true });
    entity.spin = 2;
    const item = {
      kind: 'cube', entity, behaviors: [
        { trigger: 'enter', action: 'incrementCounter', params: { counter: 'score' } },
        { trigger: 'enter', action: 'destroyObject' }, // no params -- resolveTarget defaults to self
      ],
      // Dogfood-02 fix: this preset used to also set `isTrigger: true,
      // triggerRepeat: false` -- but `isTrigger` is an opt-in for an
      // authored INVISIBLE proximity marker (preparePlacedForPlay
      // unconditionally hides any isTrigger cube), which a spinning gold
      // collectible star obviously isn't meant to be. The enter/exit/stay
      // overlap system itself never required isTrigger at all (see
      // wireItemTrigger's own comment: an ordinary pickup keeps its normal
      // 1.5x-scale sphere touch radius with isTrigger simply absent) --
      // `destroyObject` already makes this fire exactly once regardless,
      // so dropping isTrigger changes nothing about the pickup's behavior,
      // only whether it was ever visible to walk into in the first place.
    };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'healthPickup') {
    point.y = 0.6;
    const entity = app.addEntity({ mesh: cubeMesh, color: [0.3, 0.9, 0.4], position: point, scale: new Opus.Vec3(0.4, 0.4, 0.4), unlit: true });
    entity.spin = 2;
    const item = {
      kind: 'cube', entity, behaviors: [
        { trigger: 'enter', action: 'healPlayer', params: { amount: 25 } },
        { trigger: 'enter', action: 'destroyObject' },
      ],
      // Dogfood-02 fix: same invisible-pickup bug as Collectible above --
      // isTrigger dropped, no behavior change (destroyObject already makes
      // this one-shot).
    };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'damageHazard') {
    // Deliberately reuses the Mine mesh (a familiar hazard silhouette) but,
    // unlike the plain Mine palette item (an instant Lose Game), fires the
    // configurable Damage Player action with a cooldown -- a repeatable
    // "stand in the lava" hazard rather than a one-shot game-over trap.
    point.y = 0.5;
    const entity = app.addEntity({ mesh: mineMesh, color: [0.9, 0.35, 0.1], position: point, scale: new Opus.Vec3(1.1, 1.1, 1.1) });
    // Dogfood-02 fix: same invisible-hazard bug -- isTrigger dropped
    // (Damage Player's own `cooldown` param already makes this correctly
    // repeatable without triggerRepeat/isTrigger doing anything for it).
    const item = { kind: 'cube', entity, behaviors: [{ trigger: 'enter', action: 'damagePlayer', params: { amount: 15, cooldown: 1 } }] };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'checkpointPreset') {
    point.y = 0.5;
    const entity = app.addEntity({ mesh: cubeMesh, color: [0.3, 0.9, 0.95], position: point, scale: new Opus.Vec3(1.2, 0.15, 1.2), unlit: true });
    // Dogfood-02 fix: same invisible-marker bug -- isTrigger dropped (a
    // Checkpoint is meant to be a visible pad you can see and return to,
    // not an invisible volume).
    const item = { kind: 'cube', entity, behaviors: [{ trigger: 'enter', action: 'setCheckpoint' }] };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'door') {
    // Two objects, not one: the door panel itself (Solid, so it blocks
    // movement until opened -- reuses the existing Solid flag's own
    // documented "hidden = passable" rule from the Player Controller
    // collision loops, no new collision concept) and a small proximity
    // Trigger Volume in front of it wired to Show/Hide Object on the
    // panel. A one-shot open (triggerRepeat:false) -- the common "walk up,
    // door opens and stays open" case; a closing door is a second,
    // separate authored trigger, not assumed here.
    point.y = 1.25;
    const panelEntity = app.addEntity({ mesh: cubeMesh, color: [0.5, 0.4, 0.3], position: point.clone(), scale: new Opus.Vec3(1.2, 2.5, 0.3) });
    panelEntity.solid = true;
    const panelItem = { kind: 'cube', entity: panelEntity, behaviors: [] };
    addPlaced(panelItem);
    const triggerPoint = new Opus.Vec3(point.x, 0.5, point.z + 1.5);
    const triggerEntity = app.addEntity({ mesh: cubeMesh, color: [0.85, 0.35, 0.95], position: triggerPoint, scale: new Opus.Vec3(1.5, 1.5, 1.5) });
    const triggerItem = {
      kind: 'cube', entity: triggerEntity,
      behaviors: [{ trigger: 'enter', action: 'setVisibility', params: { targetId: panelItem.id, visible: false } }],
      isTrigger: true, triggerRepeat: false,
    };
    addPlaced(triggerItem);
    selectItem(panelItem);
  } else if (type === 'enemy') {
    // Object Health needs no explicit "damageable" flag -- ensureObjectHealthInit
    // auto-inits {current:100,max:100} on first hit for ANY tagged object
    // (see applyHitDamage), so the one thing this preset must set is the
    // tag. AI Follow + a Trigger Volume/Damage Player pair on the SAME cube
    // gives it contact damage, the exact combination Priority B's own
    // dogfood Robot already proved works (there as one piece of a bigger
    // assembly; here as a single self-contained preset).
    point.y = 0.5;
    const entity = app.addEntity({ mesh: cubeMesh, color: [0.75, 0.15, 0.15], position: point, scale: new Opus.Vec3(0.9, 0.9, 0.9) });
    entity.ai = { type: 'follow', speed: 3, radius: 10, targetId: null, base: entity.position.clone() };
    // Dogfood-02 fix: same invisible-object bug as the pickup presets above
    // -- isTrigger dropped, so the enemy this preset places is actually
    // visible in Play (found live: a placed Enemy preset was confirmed
    // genuinely invisible -- `entity.visible === false` -- the instant Play
    // started, with no error). Damage Player's own `cooldown` param already
    // makes contact damage correctly repeatable without triggerRepeat.
    const item = {
      kind: 'cube', entity, tags: ['enemy'],
      behaviors: [{ trigger: 'enter', action: 'damagePlayer', params: { amount: 10, cooldown: 1 } }],
    };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'movingPlatform') {
    // A ready-to-go 2-second ping-pong Property Animation clip (4 units
    // along local X) plus an On Start -> Play Animation behavior so it's
    // moving the instant Play begins, with zero extra authoring -- the
    // clip and its keyframes are ordinary `item.animationClips` data, the
    // same shape the Animation Editor itself produces, so it's fully
    // editable afterward (retime it, change the axis/distance, add a
    // rotation) rather than being special hardcoded platform logic.
    point.y = 0.5;
    const entity = app.addEntity({ mesh: cubeMesh, color: [0.55, 0.6, 0.7], position: point, scale: new Opus.Vec3(3, 0.4, 3) });
    entity.solid = true;
    const clip = {
      name: 'Patrol', duration: 2, loop: 'pingpong',
      tracks: {
        position: [
          { t: 0, value: [point.x, point.y, point.z], easing: 'linear' },
          { t: 2, value: [point.x + 4, point.y, point.z], easing: 'linear' },
        ],
        rotationY: [], scale: [], visible: [],
      },
    };
    const item = { kind: 'cube', entity, behaviors: [{ trigger: 'start', action: 'playAnimation', params: { clipName: 'Patrol' } }], animationClips: [clip] };
    addPlaced(item);
    selectItem(item);
  } else if (type === 'projectilePreset') {
    // Not placed as a level hazard itself -- a ready-sized, ready-colored
    // starting point meant to be Saved As Prefab and assigned to a Weapon's
    // Prefab field or an AI's Ranged Attack Projectile Prefab, both of
    // which already expect exactly this: a small free-standing object.
    point.y = 1;
    const entity = app.addEntity({ mesh: cubeMesh, color: [1, 0.9, 0.3], position: point, scale: new Opus.Vec3(0.25, 0.25, 0.25), unlit: true, emissiveColor: [1, 0.9, 0.3], emissiveIntensity: 1.5 });
    const item = { kind: 'cube', entity, behaviors: [] };
    addPlaced(item);
    selectItem(item);
  } else if (type.startsWith('prefab:')) {
    const prefab = prefabs[Number(type.slice('prefab:'.length))];
    if (!prefab) return;
    if (prefab.records && prefab.records.length > 0) {
      const newItems = instantiatePrefabAssembly(prefab, point);
      for (const it of newItems) addPlaced(it);
      hierarchyTickToken++;
      updateHierarchyTransforms();
      selectedItems.clear();
      for (const it of newItems) selectedItems.add(it);
      selectedItem = newItems.find((it) => it.id === newItems._newRootId) || newItems[0];
      // Wave 6 (Priority K): linked-prefab tracking, root-only -- the same
      // "one id per logical spawn" scoping Spawner 2.0 already established
      // for its own activeIds. `sourcePrefabName` is what "Update From
      // Prefab"/"Update Prefab From This" (Inspector) read to find their way
      // back to this prefab -- a manual, on-demand link only (no automatic
      // propagation, no per-field override tracking), per this priority's
      // own explicit bounded scope.
      if (selectedItem) selectedItem.sourcePrefabName = prefab.name;
      applyPrefabParameters(prefab, selectedItem);
      syncSelectionMarkers();
    } else {
      // Preserve the prefab's original height-above-ground (its saved Y) at
      // the new X/Z the user dropped it at, rather than hardcoding a height
      // -- a prefab built from a tall model shouldn't sink into the ground.
      point.y = prefab.record.position[1];
      const item = instantiateCubeRecord(prefab.record, point);
      item.sourcePrefabName = prefab.name;
      addPlaced(item);
      applyPrefabParameters(prefab, item);
      selectItem(item);
    }
  }
  renderSceneList();
}

// --- Wave 8 (Priority C, Sections 15-24): Prefab Parameters ---
// The biggest reusable-authoring feature of this Wave: a prefab author
// exposes selected configuration as named `parameters` (Section 16 bound
// to Number/Boolean/String/Color/Prefab-Reference; Object/Mesh/Texture/
// Audio Asset references use the same `renderActionFieldInput` field
// types every other reference-picker in this editor already reuses),
// each with a stable `id` (separate from its display `label`, so renaming
// the label never breaks an instance's own override keyed by `id`) and a
// declarative BOUNDED binding (Section 19's own explicit "avoid a
// JavaScript expression system") to one of a small curated set of
// well-known prefab fields -- not an arbitrary JSON path a user could
// mistype into something silently inert.
const PREFAB_PARAM_BINDINGS = {
  color: { label: 'Color', valueType: 'color' },
  scale: { label: 'Scale (uniform)', valueType: 'number' },
  aiSpeed: { label: 'AI -> Speed', valueType: 'number' },
  healthMax: { label: 'Health -> Max', valueType: 'number' },
  attackDamage: { label: 'AI -> Attack Damage', valueType: 'number' },
  attackCooldown: { label: 'AI -> Attack Cooldown', valueType: 'number' },
  attackPrefab: { label: 'AI -> Attack Prefab', valueType: 'prefab' },
  animationSpeed: { label: 'Animation -> Speed', valueType: 'number' },
  soundAsset: { label: 'Play Sound -> Asset (first matching behavior)', valueType: 'audioAsset' },
  variable: { label: 'Object Variable starting value', valueType: 'dynamic' }, // valueType comes from the parameter's own declared `type` instead
  // Wave 9D (Priority A, Sections 3-6): the two new live-swap bindings --
  // reuse the exact SAME asset-resolution/application machinery every
  // other mesh/texture consumer in this editor already uses
  // (`getAssetMeshHandle`/`applyTextureToEntity`), just centralized here
  // (`applyMeshAssetToItem`/`applyTextureAssetToItem`, below) so both the
  // initial prefab-instantiate path AND a later Update-From-Prefab/
  // override-edit path apply a swap identically, never two.
  meshAssetSwap: { label: 'Visual -> Mesh Asset', valueType: 'meshAsset' },
  textureAssetSwap: { label: 'Material -> Texture Asset', valueType: 'textureAsset' },
};
// Wave 9D (Priority A, Section 4): the ONE centralized "assign this Mesh
// Asset to this placed object's live visual" helper. Refuses cleanly
// (Section 4's own explicit requirement) rather than corrupting state when
// the swap isn't safe: a skinned asset onto a skinned entity has its own
// separate clip-mapping/joint machinery this bounded parameter system was
// never meant to reconfigure, so both directions are refused, not
// partially applied. `getAssetMeshHandle` is asset-level cached (Wave 6),
// so repeated swaps between the same few variants never duplicate GPU
// mesh resources -- only ever creates one buffer per DISTINCT asset,
// however many instances/swaps reference it.
function applyMeshAssetToItem(item, assetId) {
  if (!item || item.kind !== 'cube' || !item.entity) return false;
  const asset = findAssetById(assetId);
  if (!asset) return false;
  if (asset.type === 'skinnedMesh' || item.entity.skin) return false; // refuse rather than corrupt a skinned rig's own animation state
  item.entity.mesh = getAssetMeshHandle(asset);
  item.assetId = assetId; // persisted id -- serializeCubeRecord's own `tag = item.assetId ? 'asset' : ...` picks this up on the next save with no further change needed
  return true;
}
// The Texture Asset counterpart -- reuses `applyTextureToEntity` (Wave 6's
// own existing texture-resolution path) directly, so "immediate live
// update, no duplicate texture loading" (Section 5) is inherited for free
// rather than reimplemented.
function applyTextureAssetToItem(item, assetId) {
  if (!item || item.kind !== 'cube' || !item.entity) return false;
  const asset = findTextureAssetById(assetId);
  if (!asset) return false;
  applyTextureToEntity(item.entity, asset);
  item.textureAssetId = assetId;
  return true;
}
function generatePrefabParamId() { return `param${nextItemId++}`; }
// Applies ONE parameter's effective value (instance override, else the
// prefab's own default) onto the actual live field it's bound to, on the
// prefab's ROOT item only (Section 15's own worked examples -- Health/
// Speed/Weapon/Color/Aggressive -- are all root-level character/object
// properties; per-child-record binding was not something any real dogfood
// asked for, a genuine bounded scope choice, not an oversight).
function resolveEffectivePrefabParamValue(rootItem, param) {
  const override = rootItem.prefabParams && rootItem.prefabParams[param.id];
  return override !== undefined ? override : param.default;
}
function applyPrefabParamBinding(item, param, value) {
  if (!param.bindingField || value == null) return;
  switch (param.bindingField) {
    case 'color': { const [r, g, b] = hexToRgb(value); item.entity.color[0] = r; item.entity.color[1] = g; item.entity.color[2] = b; break; }
    case 'scale': item.entity.scale = new Opus.Vec3(value, value, value); break;
    case 'aiSpeed': if (item.entity.ai) item.entity.ai.speed = value; break;
    case 'healthMax': ensureObjectHealthInit(item); item.health.max = value; item.health.current = value; break;
    case 'attackDamage': if (item.entity.ai) item.entity.ai.attackDamage = value; break;
    case 'attackCooldown': if (item.entity.ai) item.entity.ai.attackCooldown = value; break;
    case 'attackPrefab': if (item.entity.ai) item.entity.ai.attackPrefab = value; break;
    case 'animationSpeed': if (item.entity.animationSpeed !== undefined || item.entity.skin) item.entity.animationSpeed = value; break;
    case 'soundAsset': { const b = (item.behaviors || []).find((bh) => bh.action === 'sound'); if (b) { b.params = b.params || {}; b.params.mode = 'asset'; b.params.audioAssetId = value; } break; }
    case 'variable': item.variables = item.variables || {}; item.variables[param.variableName] = value; break;
    case 'meshAssetSwap': applyMeshAssetToItem(item, value); break;
    case 'textureAssetSwap': applyTextureAssetToItem(item, value); break;
    default: break;
  }
}
// The ONE place a prefab's parameters (defaults, or an instance's own
// overrides layered on top) get applied to a live instance's real fields
// -- called right after instantiation (palette placement, Spawner,
// runtime Spawn Prefab) AND after "Update From Prefab" (Section 21: an
// instance with NO override for a given parameter picks up the prefab's
// new default; an instance WITH an explicit override keeps it -- parameter-
// only override tracking, deliberately not full Unity-style per-field
// tracking).
function applyPrefabParameters(prefab, rootItem) {
  if (!prefab.parameters || prefab.parameters.length === 0 || !rootItem) return;
  for (const param of prefab.parameters) {
    applyPrefabParamBinding(rootItem, param, resolveEffectivePrefabParamValue(rootItem, param));
  }
}

// Prefabs 2.0: instantiates a whole saved multi-object assembly at `point`
// (the root object's new position; every other record in the assembly is
// rigidly translated by the same delta, so relative offsets/hierarchy are
// preserved exactly). Returns the new items, NOT yet added to `placed`.
//
// ID remapping reuses `remapObjectIds()` -- the exact same whole-JSON
// quoted-string-substitution mechanism Duplicate Level already built for
// its own "every object gets a fresh id, every internal reference
// (targetId/aiTargetId/lookAtTargetId/groupId/parentId/...) follows it"
// requirement. One mechanism for both call sites, per the Wave 4 spec's own
// "do not write independent ad-hoc remapping logic for every subsystem" --
// this covers parentId, AI targetId, and every ACTION_TYPES/GRAPH_NODE_TYPES
// field type:'target'/'cameraPreset' automatically, with no per-field-type
// code here at all, since none of those references care HOW an id string
// got into that JSON, only that it matches something in the id map.
function instantiatePrefabAssembly(prefab, point) {
  const rootRecord = prefab.records.find((r) => r.id === prefab.rootId) || prefab.records[0];
  const rootPos = rootRecord.position || (rootRecord.options && rootRecord.options.position);
  const delta = new Opus.Vec3(point.x - rootPos[0], point.y - rootPos[1], point.z - rootPos[2]);
  const remapped = remapObjectIds(prefab.records); // fresh ids + every internal reference rewritten to match
  const idBefore = prefab.records.map((r) => r.id);
  const idAfter = remapped.map((r) => r.id);
  const newRootId = idAfter[idBefore.indexOf(prefab.rootId)];
  const newItems = [];
  for (const record of remapped) {
    const pos = record.position || (record.options && record.options.position);
    if (pos) { pos[0] += delta.x; pos[1] += delta.y; pos[2] += delta.z; }
    let item;
    if (record.kind === 'cube') item = instantiateCubeRecord(record, new Opus.Vec3(...record.position));
    else item = instantiateItemFromRecord(record);
    item.id = record.id;
    item.name = record.name;
    item.groupId = record.groupId;
    newItems.push(item);
  }
  newItems._newRootId = newRootId;
  return newItems;
}

// --- Wave 7 (Priority G, Sections 47-54): Scatter Placement ---
// Deterministic seeded RNG (mulberry32) -- the SAME seed always produces
// the SAME scatter, matching the spec's own "deterministic seeded
// placement" requirement, and reused by Array/Duplicate below for nothing
// (Array is fully deterministic already, no RNG needed there).
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
// Places ONE instance (Prefab or single Asset -- Prefab takes priority when
// both happen to be configured, matching the spec's own stated priority)
// at `point`, returning the new item(s) so the caller can fold them into
// the scatter's own single Undo step. Reuses `instantiatePrefabAssembly`
// (already generic over single- or multi-member prefabs) and ordinary
// `app.addEntity`/`getAssetMeshHandle` for a plain Asset -- no second
// placement code path.
function scatterPlaceOne(config, point, rotationY, scale) {
  if (config.prefabName) {
    const prefab = prefabs.find((pf) => pf.name === config.prefabName);
    if (!prefab) return [];
    // Two prefab shapes (Wave 6 Priority K): a multi-member assembly has
    // `prefab.records`/`rootId`; a single-object prefab has only
    // `prefab.record` -- the same branch `swapItemForPrefabInstance`
    // already uses to tell them apart, reused here rather than assuming
    // every prefab is multi-member.
    let items, root;
    if (prefab.records && prefab.records.length > 0) {
      items = instantiatePrefabAssembly(prefab, point);
      for (const it of items) addPlaced(it);
      root = items.find((it) => it.id === items._newRootId) || items[0];
    } else {
      root = instantiateCubeRecord(prefab.record, point);
      addPlaced(root);
      items = [root];
    }
    if (root && root.entity) { root.entity.rotationY = rotationY; root.entity.scale = new Opus.Vec3(scale, scale, scale); }
    return items;
  }
  if (config.assetId) {
    const asset = findAssetById(config.assetId);
    if (!asset) return [];
    const entity = app.addEntity({ mesh: getAssetMeshHandle(asset), color: [1, 1, 1], position: point, rotationY, scale: new Opus.Vec3(scale, scale, scale) });
    const item = { kind: 'cube', entity, behaviors: [], assetId: config.assetId };
    addPlaced(item);
    return [item];
  }
  return [];
}
// The one Scatter entry point -- config: `{prefabName|assetId, region:
// 'circle'|'box', centerX, centerZ, radius, width, depth, count,
// minSpacing, randomYRotation, scaleMin, scaleMax, seed, terrainConform,
// terrainItemId, maxSlopeDegrees}`. Naive rejection-sampling for min-
// spacing (bounded attempts per point, not a true Poisson-disc solver --
// accepted per the spec's own "at minimum a Scatter button" bar). Output
// is ordinary placed objects with zero second scene representation --
// movable/deletable/editable/prefab-able/groupable for free, exactly the
// spec's own explicit requirement. Wrapped in exactly ONE pushUndo() for
// the whole operation, never one per placement.
// Wave 8 (Priority J/Section 65): weighted deterministic source pick --
// the SAME `rng` instance `performScatter` already draws position/
// rotation/scale from (never a second RNG stream), so a "Forest" layer's
// 50/30/20 Oak/Pine/Rock split is fully reproducible from one seed, not
// just each individual placement's own position.
function pickWeightedScatterSource(sources, rng) {
  const total = sources.reduce((s, e) => s + (e.weight > 0 ? e.weight : 1), 0);
  let r = rng() * total;
  for (const e of sources) { r -= (e.weight > 0 ? e.weight : 1); if (r <= 0) return e; }
  return sources[sources.length - 1];
}
// Wave 9C: the pushUndo-free core, split out of performScatter (below) so
// the Scatter Brush (Section 10-11) can call it once per pointer-move
// sample WITHOUT pushing a separate Undo step each time -- "one drag
// gesture = one Undo step" needs the brush's own caller to wrap ONE
// pushUndo() around potentially many of these calls, which performScatter
// itself (still pushing its own undo, unchanged for the existing one-shot
// Scatter tool) can't do on the brush's behalf.
function scatterFillRegion(config) {
  const rng = mulberry32(config.seed >>> 0 || 1);
  const placedPoints = [];
  const terrainItem = config.terrainConform ? (config.terrainItemId ? findItemById(config.terrainItemId) : placed.find((p) => p.kind === 'terrain')) : null;
  const maxAttempts = Math.max(20, config.count * 20);
  let placedCount = 0;
  let attempts = 0;
  const allNewItems = [];
  while (placedCount < config.count && attempts < maxAttempts) {
    attempts++;
    let x, z;
    if (config.region === 'box') {
      x = config.centerX + (rng() - 0.5) * config.width;
      z = config.centerZ + (rng() - 0.5) * config.depth;
    } else {
      const angle = rng() * Math.PI * 2;
      const r = Math.sqrt(rng()) * config.radius; // sqrt for uniform AREA density, not center-biased
      x = config.centerX + Math.cos(angle) * r;
      z = config.centerZ + Math.sin(angle) * r;
    }
    if (config.minSpacing > 0 && placedPoints.some((p) => Math.hypot(p[0] - x, p[1] - z) < config.minSpacing)) continue;
    let y = 0;
    if (terrainItem && terrainItem.handle) {
      y = terrainItem.handle.sampleHeight(x, z);
      if (config.maxSlopeDegrees != null) {
        const normal = terrainItem.handle.sampleNormal(x, z);
        const slopeDeg = Math.acos(Math.min(1, Math.max(-1, normal.y))) * 180 / Math.PI;
        if (slopeDeg > config.maxSlopeDegrees) continue; // too steep -- skip this candidate point entirely, don't place a mislabeled "flat" instance on it
      }
    }
    const rotationY = config.randomYRotation ? rng() * Math.PI * 2 : 0;
    const scale = config.scaleMin != null ? config.scaleMin + rng() * (config.scaleMax - config.scaleMin) : 1;
    // Wave 8 (Priority J): a Scatter Layer's own weighted multi-prefab list
    // (`config.sources = [{type:'prefab'|'asset', ref, weight}]`) picks ONE
    // source per candidate point deterministically -- everything else
    // (single prefabName/assetId, the pre-Wave-8 shape) is unaffected.
    let pointConfig = config;
    if (config.sources && config.sources.length > 0) {
      const picked = pickWeightedScatterSource(config.sources, rng); // exactly ONE rng draw per point -- calling this twice would both break determinism and pick two DIFFERENT sources for type vs ref
      pointConfig = { ...config, prefabName: picked.type === 'asset' ? undefined : picked.ref, assetId: picked.type === 'asset' ? picked.ref : undefined };
    }
    const newItems = scatterPlaceOne(pointConfig, new Opus.Vec3(x, y, z), rotationY, scale);
    if (newItems.length === 0) break; // nothing placeable configured -- stop immediately rather than looping to maxAttempts uselessly
    // Wave 8 (Priority J/Section 67): Scatter ownership -- every object a
    // Layer creates records which layer made it, so Erase Scatter can
    // target only that layer's own generated instances. Otherwise ordinary
    // placed objects (movable/deletable/prefab-able) in every other respect.
    if (config.layerId) for (const it of newItems) it.scatterLayerId = config.layerId;
    allNewItems.push(...newItems);
    placedPoints.push([x, z]);
    placedCount++;
  }
  return { placedCount, attempts, items: allNewItems };
}
// The original one-shot entry point (the existing "Scatter" tool button
// above still calls this, unchanged) -- ONE pushUndo() per whole
// region-fill operation, then the exact same core loop.
function performScatter(config) {
  pushUndo();
  return scatterFillRegion(config);
}
// Wave 8 (Priority J/Section 67): removes only the objects a given Scatter
// Layer actually created (`item.scatterLayerId`), never hand-placed/other-
// layer objects that merely happen to sit nearby -- the whole point of
// tagging ownership at creation time above.
function eraseScatterLayer(layerId) {
  const toRemove = placed.filter((p) => p.scatterLayerId === layerId);
  if (toRemove.length === 0) return 0;
  pushUndo();
  for (const it of toRemove) removeItemFromScene(it);
  return toRemove.length;
}

// --- Wave 7 (Priority H, Sections 55-56): Array/Duplicate Pattern Tool ---
// `Duplicate Array` -- Linear (count/spacing along one axis) or Grid
// (countX/countZ/spacingX/spacingZ) -- reuses the SAME per-source-item
// duplication primitive Duplicate Selected already has for a single copy,
// just looped, wrapped in exactly ONE pushUndo() for the whole operation.
// Circular deliberately NOT built -- Linear/Grid alone already covered the
// two dogfood cases (a fence line, a wall of platforms/columns) with zero
// friction; adding a third mode with no concrete use case yet would be
// complexity ahead of a real need, the same bounded discipline this
// project applies everywhere else.
// Builds one independent copy of `sourceItem` at `point`, via the exact
// same serialize/instantiate round-trip Save/Load already trusts to
// faithfully carry every field (materials, behaviors, tags, collider,
// sockets, ...) -- reused here instead of hand-copying fields the way
// `duplicateSelected` does inline, so Array/Scatter output can never
// silently diverge from what a real save/load already proves correct.
// Scoped to ordinary cube-kind objects (fences/platforms/walls/columns,
// the spec's own worked examples for Array; Scatter's own foliage/props
// dogfood is cube-kind too) -- not every placeable kind.
function duplicateOneItemAt(sourceItem, point) {
  if (sourceItem.kind !== 'cube') return null;
  const record = serializeCubeRecord(sourceItem);
  record.parentId = undefined; // an array/scatter copy is independent, never chained under the source
  record.socketName = undefined;
  const item = instantiateCubeRecord(record, point);
  item.id = generateItemId(); // fresh, not the source's own id
  addPlaced(item);
  return item;
}
function performArrayDuplicate(sourceItem, config) {
  pushUndo();
  const newItems = [];
  const basePos = itemPosition(sourceItem);
  if (config.mode === 'grid') {
    for (let ix = 0; ix < config.countX; ix++) {
      for (let iz = 0; iz < config.countZ; iz++) {
        if (ix === 0 && iz === 0) continue; // the original stays where it is -- Array adds COPIES, it doesn't move the source
        const point = new Opus.Vec3(basePos.x + ix * config.spacingX, basePos.y, basePos.z + iz * config.spacingZ);
        const copy = duplicateOneItemAt(sourceItem, point);
        if (copy) newItems.push(copy);
      }
    }
  } else {
    for (let i = 1; i < config.count; i++) {
      const point = config.axis === 'z'
        ? new Opus.Vec3(basePos.x, basePos.y, basePos.z + i * config.spacing)
        : new Opus.Vec3(basePos.x + i * config.spacing, basePos.y, basePos.z);
      const copy = duplicateOneItemAt(sourceItem, point);
      if (copy) newItems.push(copy);
    }
  }
  return newItems;
}

// Wave 6 (Priority K): Prefab Workflow 3.0 -- three small functions built
// entirely on primitives that already existed (collectDescendants,
// serializeCubeRecord/serializeItemRecord, instantiateCubeRecord/
// instantiatePrefabAssembly, removeItemFromScene), not new prefab math.

// The ONE place that turns a live root item (+ its descendants, if any)
// into a prefab payload -- shared by Save-as-Prefab and "Update Prefab
// From This" so the two can never build a differently-shaped prefab
// record for the same kind of selection.
function buildPrefabPayload(rootItem, name) {
  // Wave 8 (Priority C): carries an EXISTING prefab's own `parameters`
  // definition forward across a re-Save/Update -- otherwise `prefabs[i] =
  // payload` (both call sites) would silently WIPE a prefab's authored
  // Parameter list the moment an author re-saved or "Update Prefab From
  // This"'d it, since `buildPrefabPayload` itself has no other way to know
  // parameters exist at all (they're prefab-level authoring data, not
  // derived from any one live instance's own fields).
  const existing = prefabs.find((p) => p.name === name);
  const parameters = existing ? existing.parameters : undefined;
  const descendants = collectDescendants(rootItem);
  if (descendants.length === 0) {
    return { payload: { name, record: serializeCubeRecord(rootItem), parameters }, memberCount: 1 };
  }
  const allItems = [rootItem, ...descendants];
  const records = allItems.map(serializeItemRecord);
  return { payload: { name, records, record: records.find((r) => r.id === rootItem.id), rootId: rootItem.id, parameters }, memberCount: allItems.length };
}
// Destroys a root item AND every object transitively parented under it --
// removeItemFromScene alone only ever removes the one item it's given
// (orphaning, not deleting, its children), which is correct for Delete
// Object but wrong here: swapping an instance for a fresh prefab copy must
// not leave the OLD assembly's other pieces behind as orphaned leftovers.
function removeItemAndDescendants(item) {
  for (const it of [item, ...collectDescendants(item)]) removeItemFromScene(it);
}
// Shared by "Update From Prefab" (re-sync to the CURRENT prefab definition)
// and "Replace With Prefab" (swap for a DIFFERENT prefab entirely) -- both
// are, mechanically, the exact same operation: destroy the old instance,
// instantiate a fresh one from the given prefab at the same position, link
// the new instance back to that prefab. Deliberately NOT a field-by-field
// diff/merge -- a full destroy-and-reinstantiate is the honest, bounded
// implementation of "no override tracking" (this priority's own explicit
// constraint): whatever the author had customized on the old instance
// beyond the prefab's own definition is not preserved, because tracking
// which fields were "overridden" vs "from the prefab" is exactly the
// Unity-style bookkeeping this priority was told not to build.
function swapItemForPrefabInstance(item, prefab, statusVerb) {
  const position = itemPosition(item).clone();
  // Wave 8 (Priority C/Section 21): "Update From Prefab" (same source
  // prefab) carries the OLD instance's own parameter overrides forward --
  // an instance with an explicit override keeps it; a parameter with NO
  // override picks up the prefab's new default automatically, because
  // `applyPrefabParameters` below always resolves through
  // `resolveEffectivePrefabParamValue` (override-else-default), never a
  // frozen snapshot. "Replace With Prefab" (a DIFFERENT prefab) does NOT
  // carry params forward -- a different prefab's own parameter schema may
  // not even share the same ids, so starting from ITS OWN defaults is the
  // only value that would ever make sense.
  const carryForwardParams = item.sourcePrefabName === prefab.name ? item.prefabParams : undefined;
  pushUndo();
  removeItemAndDescendants(item);
  let newRoot;
  if (prefab.records && prefab.records.length > 0) {
    const newItems = instantiatePrefabAssembly(prefab, position);
    for (const it of newItems) addPlaced(it);
    hierarchyTickToken++;
    updateHierarchyTransforms();
    newRoot = newItems.find((it) => it.id === newItems._newRootId) || newItems[0];
  } else {
    newRoot = instantiateCubeRecord(prefab.record, position);
    addPlaced(newRoot);
  }
  if (newRoot) {
    newRoot.sourcePrefabName = prefab.name;
    // Post-Wave-9 dogfood -- REAL BUG found live building Signal Relay:
    // "Update From Prefab" silently discarded the instance's own custom
    // Name (and tags/variables), since `instantiateCubeRecord` builds a
    // fresh item from the PREFAB's own template record, which has no idea
    // "ConsoleAlpha" was this particular instance's own identifying label
    // -- a game creator naming their three consoles Alpha/Beta/Gamma, then
    // syncing one to pick up a Color Parameter default change, lost that
    // name back to blank the instant they clicked the button. Name/tags/
    // variables are per-INSTANCE authored data, not defined by the prefab
    // template, so they carry forward here exactly like `prefabParams`
    // already does just above -- everything else (mesh/behaviors/color-if-
    // unoverridden) still comes from the current prefab definition, which
    // is the whole point of this action.
    if (item.name) newRoot.name = item.name;
    if (item.tags && item.tags.length) newRoot.tags = item.tags.slice();
    if (item.variables && Object.keys(item.variables).length) newRoot.variables = { ...item.variables };
    if (carryForwardParams) newRoot.prefabParams = { ...carryForwardParams };
    applyPrefabParameters(prefab, newRoot);
    selectItem(newRoot);
  }
  renderSceneList();
  showStatus(`${statusVerb} "${prefab.name}"`);
}
function updateInstanceFromPrefab(item) {
  const prefab = prefabs.find((p) => p.name === item.sourcePrefabName);
  if (!prefab) { showStatus('Source prefab no longer exists'); return; }
  swapItemForPrefabInstance(item, prefab, 'Updated instance from prefab');
}
function replaceItemWithPrefab(item, prefab) {
  if (!item || !prefab) return;
  swapItemForPrefabInstance(item, prefab, 'Replaced with prefab');
}

const PALETTE_LABELS = { cube: '▢ Cube', ramp: '◺ Ramp', billboard: '🌿 Billboard', terrain: '⛰ Terrain', water: '〜 Water', mine: '✹ Mine', boost: '▲ Boost Pad', trigger: '◈ Trigger Volume', emitter: '✨ Particle Emitter', camera: '🎥 Camera', spawner: '💠 Spawner', waypoint: '📍 Waypoint', path: '🛤 Path', spawnPoint: '🚩 Spawn Point', pointLight: '💡 Point Light', spotLight: '🔦 Spot Light', collectible: '⭐ Collectible', healthPickup: '➕ Health Pickup', damageHazard: '☠ Damage Hazard', checkpointPreset: '🏁 Checkpoint', door: '🚪 Door', enemy: '👾 Enemy', movingPlatform: '🟫 Moving Platform', projectilePreset: '● Projectile' };
// The base placeable kinds plus the Wave 5 (Priority K) component presets --
// one shared list so the palette drag-sources and the Command Palette
// (Ctrl+K) can never drift apart on which types exist.
const PLACEABLE_TYPES = ['cube', 'ramp', 'billboard', 'terrain', 'water', 'mine', 'boost', 'trigger', 'emitter', 'camera', 'spawner', 'waypoint', 'path', 'spawnPoint', 'pointLight', 'spotLight', 'collectible', 'healthPickup', 'damageHazard', 'checkpointPreset', 'door', 'enemy', 'movingPlatform', 'projectilePreset'];

// --- Prefabs ---
// A prefab is one cube's serialized record (serializeCubeRecord), persisted
// independently of any one project -- a template built once (a decorated
// hazard, a specific enemy setup) can be reused across scenes, not just
// duplicated within the scene it was built in. Placing one goes through
// instantiateCubeRecord, the exact same reconstruction loadScene uses, so a
// prefab and a Save/Load round trip can never reconstruct an item
// differently from each other.
let prefabs = [];
try { prefabs = JSON.parse(localStorage.getItem('opus-prefabs') || '[]'); } catch (err) { prefabs = []; }
function savePrefabs() { localStorage.setItem('opus-prefabs', JSON.stringify(prefabs)); }

function renderPrefabPalette() {
  const section = document.getElementById('palette-prefabs');
  if (prefabs.length === 0) {
    section.innerHTML = '<p style="color:#66759a;font-size:11px;margin:4px 0">Select an object and use Save as Prefab in the Inspector.</p>';
    return;
  }
  section.innerHTML = prefabs.map((p, i) => `
    <div class="palette-item" id="palette-prefab-${i}" style="display:flex;justify-content:space-between;align-items:center;gap:6px">
      <span>◆ ${escapeHtml(p.name)}${p.records && p.records.length > 1 ? ` <span style="color:#66759a;font-size:10px">(${p.records.length})</span>` : ''}</span>
      <button data-delete-prefab="${i}" style="padding:1px 6px" title="Delete prefab">✕</button>
    </div>
  `).join('');
  prefabs.forEach((p, i) => wirePaletteDragSource(`palette-prefab-${i}`, `prefab:${i}`, `◆ ${p.name}`));
  section.querySelectorAll('[data-delete-prefab]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      prefabs.splice(Number(btn.dataset.deletePrefab), 1);
      savePrefabs();
      renderPrefabPalette();
    });
  });
}

let paletteDragState = null;
const paletteGhost = (() => {
  const g = document.createElement('div');
  g.id = 'palette-ghost';
  Object.assign(g.style, {
    position: 'fixed', zIndex: '1000', padding: '8px 14px', borderRadius: '4px',
    background: '#182338', border: '1px solid rgba(255,255,255,0.25)', color: '#dce6f5',
    font: '13px system-ui, sans-serif', pointerEvents: 'none', display: 'none', transform: 'translate(-50%, -50%)',
  });
  document.body.appendChild(g);
  return g;
})();

// Shared by the fixed palette entries and the dynamically-rendered prefab
// list -- one pointer-based drag-start wiring for both, so a prefab drags
// exactly like a built-in palette item instead of needing its own path.
function wirePaletteDragSource(elId, type, label) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.style.touchAction = 'none';
  el.addEventListener('pointerdown', (e) => {
    if (playMode || e.target.closest('[data-delete-prefab]')) return;
    paletteDragState = { type, pointerId: e.pointerId };
    paletteGhost.textContent = label;
    paletteGhost.style.left = `${e.clientX}px`;
    paletteGhost.style.top = `${e.clientY}px`;
    paletteGhost.style.display = 'block';
    e.preventDefault();
  });
}

for (const type of PLACEABLE_TYPES) {
  wirePaletteDragSource(`palette-${type}`, type, PALETTE_LABELS[type]);
}
renderPrefabPalette();

// --- Games / Samples catalog ---
// Turns the games/*.json backlog into a one-click surface: Games -> card ->
// Play (loads the bundled sample and enters Play) or Open in Editor (loads
// it and stays in Edit mode) -- zero file-picker interaction, per the
// game-catalog pass's own explicit success criterion. Renders from the
// SAME games/catalog.json the build-time playable-HTML generator
// (build/build-games.js) and the static launcher (dist/games/index.html)
// also read -- one metadata source, not three hand-maintained lists.
let gamesCatalogData = null;
let gamesCatalogFilter = 'all';
async function loadGamesCatalog() {
  const statusEl = document.getElementById('games-status');
  try {
    const res = await fetch('../games/catalog.json', { cache: 'reload' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    gamesCatalogData = await res.json();
    renderGamesCatalog();
    openGameFromURLParam();
  } catch (err) {
    // Editor catalog gracefully degrades if the metadata file itself can't
    // be fetched (e.g. a packaged/offline layout missing games/) -- never
    // crashes the rest of the editor over one missing file.
    if (statusEl) statusEl.textContent = `Games catalog unavailable: ${err.message}`;
  }
}
// Undo history is the one existing "has this project been touched since it
// was last a clean document" signal already in the editor (pushUndo() is
// already called before essentially every meaningful edit) -- reused here
// rather than building a second, parallel dirty-tracking mechanism. Reset
// alongside every catalog load below, the same way a level switch already
// treats itself as a fresh document boundary (see switchToLevel's own
// undoStack.length = 0).
function hasUnsavedEditorWork() { return undoStack.length > 0; }
function renderGamesCatalog() {
  const listEl = document.getElementById('games-card-list');
  const statusEl = document.getElementById('games-status');
  if (!gamesCatalogData) return;
  const games = gamesCatalogData.games.filter((g) => gamesCatalogFilter === 'all' || g.category === gamesCatalogFilter);
  statusEl.textContent = `${games.length} game${games.length === 1 ? '' : 's'}`;
  if (games.length === 0) {
    listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:4px 0">No games in this category.</p>';
    return;
  }
  listEl.innerHTML = games.map((g) => `
    <div class="game-card" data-game-id="${escapeHtml(g.id)}">
      <div class="game-card-title-row">
        <span class="game-card-title">${escapeHtml(g.title)}</span>
        ${g.featured ? '<span class="game-card-badge">Featured</span>' : ''}
      </div>
      <div class="game-card-genre">${escapeHtml(g.genre)}${(g.controller && g.controller !== 'n/a') ? ` · ${escapeHtml(g.controller)}` : ''}</div>
      <div class="game-card-desc">${escapeHtml(g.description)}</div>
      <div class="game-card-meta">${g.estimatedMinutes ? `~${g.estimatedMinutes} min` : ''}</div>
      <div class="game-card-actions">
        <button type="button" data-game-play="${escapeHtml(g.id)}" aria-label="Play ${escapeHtml(g.title)}">▶ Play</button>
        <button type="button" class="toolbar-btn" data-game-open="${escapeHtml(g.id)}" aria-label="Open ${escapeHtml(g.title)} in editor">Open in Editor</button>
      </div>
    </div>
  `).join('');
  listEl.querySelectorAll('[data-game-play]').forEach((btn) => {
    btn.addEventListener('click', () => openCatalogGame(btn.dataset.gamePlay, true));
  });
  listEl.querySelectorAll('[data-game-open]').forEach((btn) => {
    btn.addEventListener('click', () => openCatalogGame(btn.dataset.gameOpen, false));
  });
}
// The one loader both Play and Open in Editor share -- always a FRESH
// fetch + fresh loadProjectFull, never a cached/reused parsed object, so
// opening the same bundled sample twice (or switching away and back) can
// never hand back a previous session's own in-memory mutations. See this
// pass's own report for the exact live repro this guards against (move an
// object in Foglight, open Signal Relay, reopen Foglight -- the gate must
// NOT still be moved).
async function openCatalogGame(id, enterPlay) {
  const entry = gamesCatalogData && gamesCatalogData.games.find((g) => g.id === id);
  if (!entry) return;
  if (hasUnsavedEditorWork() && !window.confirm(`Open ${entry.title}?\n\nUnsaved changes in the current project may be lost.`)) return;
  if (playMode) exitPlayMode();
  const statusEl = document.getElementById('games-status');
  if (statusEl) statusEl.textContent = `Loading ${entry.title}…`;
  try {
    // Engine Public Home pass: fetches `<id>.json` -- built from the
    // catalog's own stable id, NOT `entry.file` -- because `../games/
    // catalog.json` can resolve to two differently-shaped files depending
    // on context: the dev-source `games/catalog.json` (`file` points to
    // the raw `<id>.json` project, which is what this function actually
    // needs), or the PUBLIC catalog.json a packaged games hub generates
    // alongside the editor (`file` points to the compiled `<id>.html`
    // standalone build, for that hub's own card links -- useless here,
    // since this function needs to LOAD project data via loadProjectFull,
    // not navigate to a compiled export). Found live: packaging the editor
    // into dist/engine-site/ put the PUBLIC-shaped catalog.json at the
    // exact path the editor's own Games tab fetches, and "Open in Editor"
    // failed with "Unexpected token '<'" -- the fetch had silently
    // received the 404 HTML page for a nonexistent `foglight.html.json`-
    // shaped guess, because `entry.file` was `"foglight.html"` in that
    // catalog variant. The id-based filename is stable in both shapes
    // (every source project is deliberately named `<id>.json`), so this
    // works correctly regardless of which catalog.json variant answered.
    const res = await fetch(`../games/${id}.json`, { cache: 'reload' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const parsed = await res.json();
    loadProjectFull(parsed, `Games catalog: ${entry.title}`);
    // Fresh document boundary, same reasoning as switchToLevel's own reset --
    // undo history from whatever was open before must not follow a
    // catalog sample in (and must not make THIS load itself look dirty).
    undoStack.length = 0;
    redoStack.length = 0;
    updateUndoRedoButtons();
    if (statusEl) statusEl.textContent = `Loaded ${entry.title}`;
    if (enterPlay) enterPlayMode();
  } catch (err) {
    if (statusEl) statusEl.textContent = `Could not open ${entry.title}: ${err.message}`;
  }
}
// Public-site deep-link (Engine Public Home pass): "Open in Editor" from
// the Engine's own Featured Examples cards can link straight to
// `editor/?game=<id>` instead of dumping a visitor into a blank editor
// they'd then have to find the Games tab in themselves. Deliberately NOT
// a router or a new project-loading path -- it's a single `URLSearchParams`
// read, reusing the exact same `openCatalogGame` every Games-tab card
// already calls. Runs once, right after the catalog is available; a
// missing/unknown `game` id is a silent no-op (the editor still opens
// normally, just without the deep-linked sample).
function openGameFromURLParam() {
  const gameId = new URLSearchParams(location.search).get('game');
  if (!gameId || !gamesCatalogData) return;
  const entry = gamesCatalogData.games.find((g) => g.id === gameId);
  if (!entry) return;
  openCatalogGame(gameId, false);
}
document.getElementById('games-category-filter').addEventListener('change', (e) => {
  gamesCatalogFilter = e.target.value;
  renderGamesCatalog();
});
// The Games panel is a genuine DEV-EDITOR-ONLY feature -- games/catalog.json
// lives next to the editable source projects, not inside a build artifact,
// so a relative fetch for it only ever makes sense from editor/index.html
// itself. `window.__OPUS_EMBEDDED_PROJECT__` is the exact flag every
// Playable/Editable Export already sets before this script even runs (see
// this file's own tail), so it's the correct, already-established signal
// for "this is a played/opened export, not the real dev editor" -- reused
// here rather than inventing a second one. Found live: without this guard,
// every exported/played game's embedded copy of this entire script (the
// export inlines editor/src/01-editor.js wholesale, same as it always has)
// still ran this init call, making an unexpected `../games/catalog.json`
// network request the instant ANY exported game loaded -- harmless only by
// coincidence in this dev layout (it happened to resolve to the real
// dist/games/catalog.json this same build produces), but a genuine "no
// unexpected network dependency" violation for the single-file-portability
// case the catalog build's own clean-room test specifically checks for.
if (!window.__OPUS_EMBEDDED_PROJECT__) {
  loadGamesCatalog();
} else {
  const gamesTabBtn = document.querySelector('[data-left-tab="games"]');
  if (gamesTabBtn) gamesTabBtn.style.display = 'none';
}

window.addEventListener('pointermove', (e) => {
  if (!paletteDragState || e.pointerId !== paletteDragState.pointerId) return;
  paletteGhost.style.left = `${e.clientX}px`;
  paletteGhost.style.top = `${e.clientY}px`;
});

window.addEventListener('pointerup', (e) => {
  if (!paletteDragState || e.pointerId !== paletteDragState.pointerId) return;
  const { type } = paletteDragState;
  paletteDragState = null;
  paletteGhost.style.display = 'none';
  const rect = canvas.getBoundingClientRect();
  const overCanvas = e.clientX >= rect.left && e.clientX <= rect.right && e.clientY >= rect.top && e.clientY <= rect.bottom;
  if (!overCanvas) return;
  const point = screenToGroundPoint(e.clientX, e.clientY);
  if (!point) return;
  placeItem(type, point);
});

// --- Selection ---

let justDragged = false;

canvas.addEventListener('click', (e) => {
  if (justDragged) { justDragged = false; return; }
  const hit = pickEntity(e.clientX, e.clientY);
  if (playMode) {
    if (hit) runBehaviors(hit, 'click');
    return;
  }
  if (hit) selectItem(hit, e.shiftKey);
  else if (!e.shiftKey) deselectAll();
});
// 'click' itself is left as-is: it already fires for a tap the same way it
// fires for a mouse click (browsers synthesize it from either), so nothing
// here needed to change for touch.

// --- Drag to move (viewport reposition) ---
// The inspector's number fields cover precise editing, but nudging a crate
// (or an island) a few units over meant typing three values instead of just
// dragging it -- the actual reason editing "still felt number-field-based".
// Cubes and terrain both support it; water stays number-field-only since
// it's excluded from raycast picking entirely (see pickEntity above).
//
// Terrain is cheaper to drag than it looks: the renderer applies a
// terrain's `position` as a draw-time translation (Mat4.translation) over
// mesh geometry that's already in local coordinates -- see
// engine/src/09-renderer.js's renderTerrain -- so moving it needs no mesh
// regeneration, just like a cube's position.x/z. The one thing that isn't
// free: `item.handle.position` (what rendering/sampleHeight/sampleNormal
// read) and `item.options.position` (what Physics.resolveTerrainCollision
// and the inspector's Seed/Size/Radius regenerate-on-edit read) are two
// separate Vec3 objects, not one -- both must be kept in sync or dragging
// would silently desync collision from what's rendered (the exact class of
// bug friction #15 was about), or a later Size/Radius edit would snap the
// terrain back to its pre-drag spot.
let dragState = null;
let gizmoDragState = null;

// Gizmos 2.0: which transform the on-screen gizmo currently manipulates,
// plus optional snapping (off by default, only the on/off flag persists --
// the increments are fixed, reasonable defaults, not something worth a
// whole settings UI for a first cut).
let gizmoMode = 'move'; // 'move' | 'rotate' | 'scale'
// Wave 6 (Priority J): Local/World gizmo mode -- scoped to the MOVE gizmo
// only, per its own named case. Scale is deliberately left untouched:
// `entity.scale` is inherently a LOCAL-space field in this engine's
// TRS composition (Mat4.compose applies scale before rotation), so
// "world-space non-uniform scale" has no clean, safe meaning to add a
// second mode for without risking a real behavior change to the Scale
// gizmo's existing (pre-Wave-6) drag math -- out of this priority's own
// bounded scope. Rotate is also left untouched (always rotates around
// world X/Y/Z) for the same "don't touch what isn't the named case"
// reasoning.
let gizmoSpace = 'world'; // 'world' | 'local'
const gizmoSnap = { enabled: false, position: 1, rotationDegrees: 15, scale: 0.25 };
try {
  const savedSnap = JSON.parse(localStorage.getItem('opus-gizmo-snap') || 'null');
  if (savedSnap && typeof savedSnap.enabled === 'boolean') gizmoSnap.enabled = savedSnap.enabled;
} catch (err) { /* ignore corrupt value, keep default */ }
function saveGizmoSnapSetting() { localStorage.setItem('opus-gizmo-snap', JSON.stringify({ enabled: gizmoSnap.enabled })); }
function snapValue(v, increment) { return increment > 0 ? Math.round(v / increment) * increment : v; }

// --- Marquee (rectangle) select ---
// A mousedown that starts on empty space -- nothing for the object-drag
// above to grab -- becomes a marquee instead of doing nothing. Needs
// worldToScreen (defined above) to test which items' positions fall inside
// the screen-space rectangle once the drag ends; terrain/cubes only, same
// set pickEntity itself considers (water excluded for the same reason).
let marqueeState = null;
const marqueeBox = document.getElementById('marquee-box');

function marqueeableItems() {
  return placed.filter((item) => item.kind === 'cube' || item.kind === 'terrain');
}

// Built on Pointer Events (not mouse events) so the exact same code drives
// object-drag and marquee-select from touch, not just a mouse -- and
// `activePointerId` makes sure a second finger touching down mid-gesture
// (or a second simultaneous pointer of any kind) can't hijack or corrupt an
// already-running drag/marquee.
let activePointerId = null;

// The engine's own camera-orbit-drag listens on the same canvas via
// Pointer Events too (Input, engine/src/04-input.js), and a real pointer
// click/touch fires those events regardless of what else is also
// listening. Left alone, every drag/marquee gesture here also accumulates
// into Input's pending orbit-drag delta, which would jump the camera the
// next time it's consumed -- draining it every tick an editor-owned
// gesture is in progress keeps that delta at zero for the whole gesture.
function suppressCameraDrag() { app.input.consumeDrag(); }

canvas.addEventListener('pointerdown', (e) => {
  if (playMode || activePointerId !== null) return;
  // Wave 9C: Scatter Brush takes over the canvas entirely while a mode is
  // selected (checked first, same "one brush mode at a time" precedent
  // Sculpt/Terrain-Paint below already established).
  if (scatterBrushMode) {
    const layer = findScatterLayerById(selectedScatterLayerId);
    if (!layer) { showStatus('Select or create a Scatter Layer first'); return; }
    const point = screenToGroundPoint(e.clientX, e.clientY);
    if (!point) return;
    activePointerId = e.pointerId;
    scatterBrushDragState = { layer, dabIndex: 0, lastPoint: point, placedCount: 0, removedCount: 0 };
    suppressCameraDrag();
    pushUndo(); // ONE snapshot for the whole drag gesture, not one per dab (Section 10's own explicit requirement)
    if (scatterBrushMode === 'paint') scatterBrushDragState.placedCount += applyScatterBrushPaint(layer, point);
    else scatterBrushDragState.removedCount += applyScatterBrushErase(layer, point);
    renderSceneList();
    e.preventDefault();
    return;
  }
  // Sculpt mode takes over the canvas entirely while active (checked before
  // gizmo/pick/drag/marquee) -- Pointer Events, so mouse/pen/touch all drive
  // the identical code path, same architecture as every other viewport
  // gesture in this editor.
  if (sculptMode && selectedItem && selectedItem.kind === 'terrain') {
    const point = screenToGroundPoint(e.clientX, e.clientY);
    if (!point) return;
    activePointerId = e.pointerId;
    sculptDragState = { item: selectedItem, strokeStarted: false };
    suppressCameraDrag();
    pushUndo(); // ONE snapshot for the whole stroke, not one per dab -- gesture-level undo
    sculptDragState.strokeStarted = true;
    applySculptBrush(selectedItem, point, true);
    e.preventDefault();
    return;
  }
  // Terrain Painting (Priority G) -- the exact same gesture shape as
  // sculpt mode above, mutually exclusive with it (only one brush mode is
  // ever active at a time).
  if (paintMode && selectedItem && selectedItem.kind === 'terrain') {
    const point = screenToGroundPoint(e.clientX, e.clientY);
    if (!point) return;
    activePointerId = e.pointerId;
    paintDragState = { item: selectedItem };
    suppressCameraDrag();
    pushUndo();
    applyPaintBrush(selectedItem, point);
    e.preventDefault();
    return;
  }
  // Checked before pickEntity/marquee -- a gizmo handle sits in front of
  // (or extends past) whatever's selected, so it must win the hit-test
  // first or clicking it would just re-select/drag the object underneath.
  const gizmoAxis = pickGizmoHandle(e.clientX, e.clientY);
  if (gizmoAxis === 'rx' || gizmoAxis === 'ry' || gizmoAxis === 'rz') {
    const axisInfo = GIZMO_ROTATE_AXES.find((a) => a.axis === gizmoAxis);
    // Wave 6B (Priority L): multi-select Rotate -- `items` covers every
    // selection ROOT (selectionRoots filters out a child whose parent is
    // also selected, see that function's own comment). Pivot defaults to
    // the roots' own position average ("Selection Center"). For a single
    // selected object this reduces to exactly the old single-object
    // behavior: pivot === that object's own position, so "orbit around the
    // pivot" is a no-op and only its own orientation rotates in place --
    // one shared code path serves both cases, not two.
    const rootItems = selectionRoots(selectedItems).filter((item) => item.kind === 'cube');
    const items = rootItems.map((item) => ({ item, startPos: itemPosition(item).clone(), startQuat: item.entity.quaternion.clone() }));
    const pivot = items.reduce((sum, r) => sum.add(r.startPos), new Opus.Vec3()).scale(1 / Math.max(1, items.length));
    // The grab-time angle is established HERE, from the actual pointerdown
    // position, not lazily on the first pointermove -- doing it lazily
    // silently dropped the very first move's angular delta (its "before"
    // sample would have been null), found by dragging a ring end-to-end and
    // measuring a smaller total rotation than the mouse actually swept.
    const grabPoint = screenToPlanePoint(e.clientX, e.clientY, pivot, axisInfo.dir);
    activePointerId = e.pointerId;
    gizmoDragState = {
      type: 'rotate',
      items,
      axisInfo,
      pivot,
      lastAngle: grabPoint ? Math.atan2(grabPoint.sub(pivot).dot(axisInfo.v), grabPoint.sub(pivot).dot(axisInfo.u)) : null,
      totalAngle: 0,
      moved: false,
    };
    suppressCameraDrag();
    canvas.style.cursor = 'grabbing';
    return;
  }
  if (gizmoAxis === 'uniform') {
    // Wave 6B (Priority L): multi-select Uniform Scale -- same
    // selectionRoots parent/child correctness filter Rotate above uses.
    // Each root's own scale multiplies by the drag ratio (identical to the
    // pre-Priority-L single-object math) AND its position is pulled toward/
    // pushed away from the group pivot by that SAME ratio, so the group
    // visibly scales as one coherent whole rather than every object just
    // growing in place independently. A single-object selection has
    // pivot === that object's own position, so the position term is
    // mathematically zero -- bit-exact with the old single-object behavior.
    const rootItems = selectionRoots(selectedItems).filter((item) => item.kind === 'cube');
    const items = rootItems.map((item) => ({ item, startPos: itemPosition(item).clone(), startScale: item.entity.scale.clone() }));
    const pivot = items.reduce((sum, r) => sum.add(r.startPos), new Opus.Vec3()).scale(1 / Math.max(1, items.length));
    activePointerId = e.pointerId;
    gizmoDragState = {
      type: 'scaleUniform',
      items,
      pivot,
      grabClientX: e.clientX,
      grabClientY: e.clientY,
      moved: false,
    };
    suppressCameraDrag();
    canvas.style.cursor = 'grabbing';
    return;
  }
  if (gizmoAxis === 'sx' || gizmoAxis === 'sy' || gizmoAxis === 'sz') {
    const axisInfo = GIZMO_SCALE_AXES.find((a) => a.axis === gizmoAxis);
    // Wave 6B (Priority L): multi-select per-axis Scale -- same
    // selectionRoots filter, but deliberately bounded to just each root's
    // OWN scale component (an additive delta, matching the pre-Priority-L
    // single-object math exactly): positions are left unchanged. Scaling
    // group POSITIONS apart along a single world axis (as opposed to
    // uniformly, which the pivot-relative math above already covers) is a
    // real but genuinely separate feature with its own ambiguous "what
    // should this look like" design questions -- not built this pass to
    // avoid scope creep past what the spec actually asked for.
    const rootItems = selectionRoots(selectedItems).filter((item) => item.kind === 'cube');
    activePointerId = e.pointerId;
    gizmoDragState = {
      type: 'scaleAxis',
      axisVec: axisInfo.dir,
      axisComponent: gizmoAxis.slice(1), // 'x' | 'y' | 'z'
      items: rootItems.map((item) => ({ item, startScale: item.entity.scale.clone() })),
      itemPos: itemPosition(selectedItem).clone(),
      grabClientX: e.clientX,
      grabClientY: e.clientY,
      moved: false,
    };
    suppressCameraDrag();
    canvas.style.cursor = 'grabbing';
    return;
  }
  if (gizmoAxis) {
    activePointerId = e.pointerId;
    gizmoDragState = {
      type: 'move',
      axisVec: moveAxisWorldDir(gizmoAxis),
      items: [...selectedItems].filter((item) => item.kind === 'cube' || item.kind === 'terrain').map((item) => ({ item, startPos: itemPosition(item).clone() })),
      grabClientX: e.clientX,
      grabClientY: e.clientY,
      moved: false,
    };
    suppressCameraDrag();
    canvas.style.cursor = 'grabbing';
    return;
  }
  const hit = pickEntity(e.clientX, e.clientY);
  if (!hit) {
    activePointerId = e.pointerId;
    marqueeState = { startX: e.clientX, startY: e.clientY, additive: e.shiftKey, moved: false };
    suppressCameraDrag();
    return;
  }
  const point = screenToGroundPoint(e.clientX, e.clientY);
  if (!point) return;

  if (e.shiftKey) {
    selectItem(hit, true); // shift-click only toggles selection, it doesn't start a drag
    return;
  }
  // Dragging an item that's already part of the current multi-selection
  // moves the whole group, keeping the rest of the selection intact.
  // Dragging anything else collapses the selection down to just that item
  // first, matching plain-click's replace behavior.
  if (!selectedItems.has(hit)) selectItem(hit);

  activePointerId = e.pointerId;
  dragState = {
    items: [...selectedItems].map((item) => {
      const pos = itemPosition(item);
      return { item, startX: pos.x, startZ: pos.z };
    }),
    grabStartX: point.x,
    grabStartZ: point.z,
    moved: false,
  };
  suppressCameraDrag();
  canvas.style.cursor = 'grabbing';
});

// Cursor feedback doubles as the only hint that an object *can* be dragged
// at all -- nothing else in the viewport signals it. 'grab' over a
// draggable item, 'grabbing' while actually dragging, default otherwise.
// (Touch has no hover state to show it in, but the cost of computing it is
// the same either way, so this doesn't need a touch-specific branch.)
canvas.addEventListener('pointermove', (e) => {
  if (scatterBrushDragState) {
    if (e.pointerId !== activePointerId) return;
    suppressCameraDrag();
    const point = screenToGroundPoint(e.clientX, e.clientY);
    if (point) {
      const { layer, lastPoint } = scatterBrushDragState;
      // Bounded step cadence (Section 11's "one drag = one Undo," and this
      // project's standing "no once-per-frame flood" rule) -- a new dab
      // only fires once the pointer has moved a meaningful fraction of the
      // brush's own radius since the last one, not on every single
      // pointermove event a fast mouse can fire dozens of per second.
      if (Math.hypot(point.x - lastPoint.x, point.z - lastPoint.z) >= layer.brushRadius * 0.4) {
        scatterBrushDragState.lastPoint = point;
        if (scatterBrushMode === 'paint') scatterBrushDragState.placedCount += applyScatterBrushPaint(layer, point);
        else scatterBrushDragState.removedCount += applyScatterBrushErase(layer, point);
        renderSceneList();
      }
      syncScatterBrushMarker(point, layer.brushRadius, true);
    }
    e.preventDefault();
    return;
  }
  if (sculptDragState) {
    if (e.pointerId !== activePointerId) return;
    suppressCameraDrag();
    const point = screenToGroundPoint(e.clientX, e.clientY);
    if (point) applySculptBrush(sculptDragState.item, point, false);
    e.preventDefault();
    return;
  }
  if (paintDragState) {
    if (e.pointerId !== activePointerId) return;
    suppressCameraDrag();
    const point = screenToGroundPoint(e.clientX, e.clientY);
    if (point) applyPaintBrush(paintDragState.item, point);
    e.preventDefault();
    return;
  }
  if (gizmoDragState) {
    if (e.pointerId !== activePointerId) return;
    if (!gizmoDragState.moved) {
      pushUndo();
      gizmoDragState.moved = true;
    }
    suppressCameraDrag();
    if (gizmoDragState.type === 'rotate') {
      // Angle within the ring's OWN plane (perpendicular to its axis, not
      // always the ground plane the way the old Y-only gizmo assumed) --
      // screenToPlanePoint generalizes screenToGroundPoint to an arbitrary
      // plane. u/v are the same right-handed basis pickGizmoHandle/syncGizmo
      // already use to draw and pick the ring, so the drag direction always
      // agrees with what's on screen for all three axes, not just Y.
      const { dir, u, v } = gizmoDragState.axisInfo;
      const point = screenToPlanePoint(e.clientX, e.clientY, gizmoDragState.pivot, dir);
      if (point) {
        const delta = point.sub(gizmoDragState.pivot);
        if (delta.length() > 0.05) {
          const angle = Math.atan2(delta.dot(v), delta.dot(u));
          if (gizmoDragState.lastAngle !== null) {
            // Shortest-path delta between successive angles (handles the
            // -PI/+PI wraparound as the cursor sweeps past the seam) --
            // accumulated into totalAngle rather than re-deriving a single
            // absolute angle each move, since "absolute angle around this
            // ring" isn't well-defined once you've gone around more than once.
            let step = angle - gizmoDragState.lastAngle;
            if (step > Math.PI) step -= Math.PI * 2;
            if (step < -Math.PI) step += Math.PI * 2;
            gizmoDragState.totalAngle += step;
          }
          gizmoDragState.lastAngle = angle;
          let applied = gizmoDragState.totalAngle;
          if (gizmoSnap.enabled) {
            const stepRad = gizmoSnap.rotationDegrees * Math.PI / 180;
            applied = snapValue(applied, stepRad);
          }
          // World-space rotation: the new orientation is "rotate by `applied`
          // around this axis in WORLD space, THEN apply whatever the object's
          // orientation already was at grab time" -- composed on the LEFT of
          // the starting quaternion, matching how worldMatrix = parent*local
          // already composes (the axis ring itself is drawn in world axes,
          // not the object's own local axes, so this is the reading that
          // matches what the user sees on screen).
          // Wave 6B (Priority L): each selection root's OWN orientation
          // rotates (same math as before) AND its position orbits the
          // group's pivot by the same angle -- for a single-object selection
          // (pivot === that object's own startPos) the orbit term is
          // mathematically zero, so this is bit-exact with the pre-Priority-L
          // single-object behavior in that case.
          const rot = Opus.Quat.fromAxisAngle(dir, applied);
          for (const { item, startPos, startQuat } of gizmoDragState.items) {
            item.entity.quaternion = rot.multiply(startQuat);
            const newPos = gizmoDragState.pivot.add(rot.rotateVec3(startPos.sub(gizmoDragState.pivot)));
            item.entity.position.set(newPos.x, newPos.y, newPos.z);
          }
        }
      }
      syncGizmo();
      return;
    }
    // Same screen-space axis projection as Move below, applied to one scale
    // component instead of one position component -- floored so an object
    // can't be dragged to zero/negative scale (which would collapse it and
    // make it unpickable to drag back out).
    if (gizmoDragState.type === 'scaleAxis' || gizmoDragState.type === 'scaleUniform') {
      const projectDir = gizmoDragState.type === 'scaleUniform' ? GIZMO_UNIFORM_OFFSET.normalize() : gizmoDragState.axisVec;
      const projectOrigin = gizmoDragState.type === 'scaleUniform' ? gizmoDragState.pivot : gizmoDragState.itemPos;
      const originScreen = worldToScreen(projectOrigin);
      const axisScreen = worldToScreen(projectOrigin.add(projectDir));
      if (originScreen && axisScreen) {
        const sdx = axisScreen.x - originScreen.x;
        const sdy = axisScreen.y - originScreen.y;
        const denom = sdx * sdx + sdy * sdy;
        if (denom > 1e-6) {
          const mdx = e.clientX - gizmoDragState.grabClientX;
          const mdy = e.clientY - gizmoDragState.grabClientY;
          const worldDelta = (mdx * sdx + mdy * sdy) / denom;
          const MIN_SCALE = 0.05;
          if (gizmoDragState.type === 'scaleUniform') {
            // Wave 6B (Priority L): ratio is computed once off the FIRST
            // root (matching the pre-Priority-L single-object read of
            // `startScale.x`) then applied identically to every root's own
            // scale AND to its position offset from the pivot -- see this
            // drag state's own mousedown comment for why that's bit-exact
            // with the old single-object behavior when there's only one root.
            const first = gizmoDragState.items[0];
            if (!first) { syncGizmo(); return; }
            const s = gizmoSnap.enabled
              ? snapValue(Math.max(MIN_SCALE, first.startScale.x + worldDelta), gizmoSnap.scale)
              : Math.max(MIN_SCALE, first.startScale.x + worldDelta);
            const ratio = s / Math.max(MIN_SCALE, first.startScale.x);
            for (const { item, startPos, startScale } of gizmoDragState.items) {
              item.entity.scale.set(
                Math.max(MIN_SCALE, startScale.x * ratio),
                Math.max(MIN_SCALE, startScale.y * ratio),
                Math.max(MIN_SCALE, startScale.z * ratio),
              );
              const newPos = gizmoDragState.pivot.add(startPos.sub(gizmoDragState.pivot).scale(ratio));
              item.entity.position.set(newPos.x, newPos.y, newPos.z);
            }
          } else {
            const key = gizmoDragState.axisComponent;
            for (const { item, startScale } of gizmoDragState.items) {
              let v = Math.max(MIN_SCALE, startScale[key] + worldDelta);
              if (gizmoSnap.enabled) v = Math.max(MIN_SCALE, snapValue(v, gizmoSnap.scale));
              const next = item.entity.scale.clone();
              next[key] = v;
              item.entity.scale.set(next.x, next.y, next.z);
            }
          }
        }
      }
      syncGizmo();
      return;
    }
    // Classic screen-space axis projection: two world points one axis-unit
    // apart, projected to screen, give both the 2D drag direction AND (via
    // that projected segment's own pixel length) how many screen pixels
    // correspond to one world unit at the primary item's depth -- from
    // there, projecting the mouse's own screen delta onto that same
    // direction and dividing out the pixels-per-unit converts back to a
    // world-space distance along the axis. Computed fresh from the FIXED
    // grab-start position (not live current position) so a used camera
    // orbit mid-drag couldn't ever feed back into itself.
    const primary = gizmoDragState.items.find((i) => i.item === selectedItem) || gizmoDragState.items[0];
    if (primary) {
      const originScreen = worldToScreen(primary.startPos);
      const axisScreen = worldToScreen(primary.startPos.add(gizmoDragState.axisVec));
      if (originScreen && axisScreen) {
        const sdx = axisScreen.x - originScreen.x;
        const sdy = axisScreen.y - originScreen.y;
        const denom = sdx * sdx + sdy * sdy;
        if (denom > 1e-6) {
          const mdx = e.clientX - gizmoDragState.grabClientX;
          const mdy = e.clientY - gizmoDragState.grabClientY;
          let worldDelta = (mdx * sdx + mdy * sdy) / denom;
          if (gizmoSnap.enabled) worldDelta = snapValue(worldDelta, gizmoSnap.position);
          for (const { item, startPos } of gizmoDragState.items) {
            const newPos = startPos.add(gizmoDragState.axisVec.scale(worldDelta));
            if (item.kind === 'cube') item.entity.position.set(newPos.x, newPos.y, newPos.z);
            else if (item.kind === 'terrain') { item.handle.position.set(newPos.x, newPos.y, newPos.z); item.options.position.set(newPos.x, newPos.y, newPos.z); }
          }
        }
      }
    }
    syncGizmo();
    return;
  }
  if (marqueeState) {
    if (e.pointerId !== activePointerId) return;
    suppressCameraDrag();
    const dx = e.clientX - marqueeState.startX;
    const dy = e.clientY - marqueeState.startY;
    if (!marqueeState.moved && Math.hypot(dx, dy) > 4) marqueeState.moved = true;
    if (marqueeState.moved) {
      const wrapRect = marqueeBox.parentElement.getBoundingClientRect();
      const left = Math.min(marqueeState.startX, e.clientX) - wrapRect.left;
      const top = Math.min(marqueeState.startY, e.clientY) - wrapRect.top;
      marqueeBox.style.left = `${left}px`;
      marqueeBox.style.top = `${top}px`;
      marqueeBox.style.width = `${Math.abs(dx)}px`;
      marqueeBox.style.height = `${Math.abs(dy)}px`;
      marqueeBox.classList.add('active');
    }
    return;
  }
  if (!dragState) {
    if (playMode) return;
    canvas.style.cursor = pickEntity(e.clientX, e.clientY) ? 'grab' : '';
    return;
  }
  if (e.pointerId !== activePointerId) return;
  const point = screenToGroundPoint(e.clientX, e.clientY);
  if (!point) return;
  if (!dragState.moved) {
    pushUndo();
    dragState.moved = true;
  }
  suppressCameraDrag();
  // A single shared delta (from the grab point) applied to each item's own
  // start position -- not a per-item grab offset -- so a group of several
  // objects moves as one rigid formation instead of all snapping to the
  // same spot. For a single selected item this reduces to exactly the same
  // math the original single-item drag used.
  const dx = point.x - dragState.grabStartX;
  const dz = point.z - dragState.grabStartZ;
  for (const { item, startX, startZ } of dragState.items) {
    const newX = startX + dx;
    const newZ = startZ + dz;
    if (item.kind === 'cube') {
      item.entity.position.x = newX;
      item.entity.position.z = newZ;
    } else if (item.kind === 'terrain') {
      item.handle.position.set(newX, item.handle.position.y, newZ);
      item.options.position.set(newX, item.options.position.y, newZ);
    }
  }
});

window.addEventListener('pointerup', (e) => {
  if (e.pointerId !== activePointerId) return;
  activePointerId = null;
  suppressCameraDrag();
  if (sculptDragState) { sculptDragState = null; renderInspector(); }
  if (paintDragState) { paintDragState = null; renderInspector(); }
  if (scatterBrushDragState) {
    const { placedCount, removedCount } = scatterBrushDragState;
    scatterBrushDragState = null;
    if (scatterBrushMarker) scatterBrushMarker.visible = false;
    renderScatterLayerPanel();
    showStatus(placedCount ? `Painted ${placedCount} objects` : removedCount ? `Erased ${removedCount} objects` : 'Scatter Brush: nothing changed');
  }
  if (marqueeState) {
    if (marqueeState.moved) {
      const x0 = Math.min(marqueeState.startX, e.clientX);
      const x1 = Math.max(marqueeState.startX, e.clientX);
      const y0 = Math.min(marqueeState.startY, e.clientY);
      const y1 = Math.max(marqueeState.startY, e.clientY);
      const hits = marqueeableItems().filter((item) => {
        const screen = worldToScreen(itemPosition(item));
        return screen && screen.x >= x0 && screen.x <= x1 && screen.y >= y0 && screen.y <= y1;
      });
      if (!marqueeState.additive) { selectedItems.clear(); }
      for (const item of hits) selectedItems.add(item);
      selectedItem = hits.length ? hits[hits.length - 1] : (selectedItems.size ? [...selectedItems].pop() : null);
      syncSelectionMarkers();
      renderInspector();
      renderSceneList();
      justDragged = true;
    }
    marqueeBox.classList.remove('active');
    marqueeState = null;
  }
  if (dragState && dragState.moved) {
    justDragged = true;
    renderInspector();
    renderSceneList();
  }
  dragState = null;
  if (gizmoDragState && gizmoDragState.moved) {
    justDragged = true;
    renderInspector();
    renderSceneList();
  }
  gizmoDragState = null;
  if (!playMode) canvas.style.cursor = pickEntity(e.clientX, e.clientY) ? 'grab' : '';
});

// additive=true (shift-click) toggles `item` in/out of the selection
// instead of replacing it. selectedItem always tracks the last item
// clicked/toggled -- null only once selectedItems is empty.
function selectItem(item, additive = false) {
  if (additive) {
    if (selectedItems.has(item)) {
      selectedItems.delete(item);
      selectedItem = selectedItems.size ? [...selectedItems].pop() : null;
    } else {
      selectedItems.add(item);
      selectedItem = item;
    }
  } else {
    selectedItems.clear();
    // Clicking (or drag-grabbing) any one grouped member selects the whole
    // group -- this, not anything about how dragging itself works, is what
    // makes Group meaningfully different from just multi-selecting the same
    // items again by hand every time.
    if (item.groupId) {
      for (const p of placed) if (p.groupId === item.groupId) selectedItems.add(p);
    } else {
      selectedItems.add(item);
    }
    selectedItem = item;
  }
  syncSelectionMarkers();
  renderInspector();
  renderSceneList();
  // Selecting something should surface its controls immediately, not leave
  // the user on whatever right-side tab they happened to be looking at --
  // but only jump TO Inspector, never fight a deliberate switch away from it
  // while nothing is selected (deselectAll doesn't call this).
  if (typeof activateTab === 'function') activateTab('right-tab', 'inspector');
  // On a narrow/tablet screen the right panel is an off-canvas drawer (see
  // the @media rule) -- tapping an object in the viewport should reveal the
  // Inspector automatically, the same as it does inline at desktop widths,
  // instead of silently updating a drawer the user can't currently see.
  if (typeof setNarrowPanel === 'function') setNarrowPanel('right-panel', true);
}

function deselectAll() {
  selectedItem = null;
  selectedItems.clear();
  syncSelectionMarkers();
  renderInspector();
  renderSceneList();
}

// One marker entity per selected item, reused across renders rather than
// destroyed/recreated -- pooled the same way the original single marker was.
function syncSelectionMarkers() {
  for (const [item, marker] of selectionMarkers) {
    if (!selectedItems.has(item)) {
      app.scene.remove(marker);
      selectionMarkers.delete(item);
    }
  }
  for (const item of selectedItems) {
    if (selectionMarkers.has(item)) continue;
    const pos = itemPosition(item);
    const marker = app.addEntity({ mesh: cubeMesh, color: [0.3, 1, 0.5], position: pos.clone(), scale: new Opus.Vec3(1, 0.05, 1) });
    selectionMarkers.set(item, marker);
  }
  syncGizmo();
  syncLightConeViz();
}

// --- Transform gizmo (Move / Rotate / Scale) ---
// Three colored handles (X red, Y green, Z blue) at the primary selection's
// position, built from cubeMesh scaled thin+long along one axis -- no
// custom geometry needed, the same "reuse what already exists" approach as
// the earlier hazard/boost meshes. Only ONE mode's handles exist in the
// scene at a time (gizmoMode selects which) -- Move and Scale reuse the
// exact same axis geometry/pick math, just interpreted as a different
// transform and drawn in a dimmer shade for Scale so they're visually
// distinct even though they occupy the same screen position.
const GIZMO_LENGTH = 2.2;
const GIZMO_THICKNESS = 0.16;
const GIZMO_GAP = 0.5;
const GIZMO_MOVE_AXES = [
  { axis: 'x', dir: new Opus.Vec3(1, 0, 0), color: [0.95, 0.25, 0.25] },
  { axis: 'y', dir: new Opus.Vec3(0, 1, 0), color: [0.3, 0.9, 0.35] },
  { axis: 'z', dir: new Opus.Vec3(0, 0, 1), color: [0.3, 0.55, 0.95] },
];
// Wave 6 (Priority J): the ONE place that resolves a Move axis entry's
// WORLD-space direction, reading `gizmoSpace` -- every render/pick/drag-init
// call site below calls this instead of reading `.dir` directly, so all
// three stay trivially in sync with the toggle. In 'world' mode (the
// default, and the only mode any project saved before this priority ever
// used) this returns the exact same fixed unit vector `.dir` already was --
// bit-identical behavior. In 'local' mode it returns the SELECTED item's
// own current rotated axis (`entity.right`/`.up`/`.forward`, all public
// since Wave 5's full-XYZ orientation work) -- an object with no
// orientation change (identity quaternion) still gets the exact same
// world-aligned handles either way, so a never-rotated object's Move gizmo
// is unaffected by which mode is active.
function moveAxisWorldDir(axisLetter) {
  if (gizmoSpace === 'local' && selectedItem && selectedItem.entity) {
    const e = selectedItem.entity;
    return axisLetter === 'x' ? e.right : axisLetter === 'y' ? e.up : e.forward;
  }
  const entry = GIZMO_MOVE_AXES.find((a) => a.axis === axisLetter);
  return entry.dir;
}
// Full XYZ Rotate gizmo (Wave 5) -- one ring per axis, conventional colors
// (X=red, Y=green, Z=blue, matching the Move/Scale axis colors already
// established). Each ring lives in the plane perpendicular to its axis;
// `u`/`v` are two basis vectors of that plane chosen so `u × v = dir`
// (right-handed) -- dragging sweeps `u` toward `v` as the angle increases,
// which is what makes `Quat.fromAxisAngle(dir, angle)` and the drag's own
// atan2(delta·v, delta·u) agree on which way is "positive" for every axis,
// not just Y. The Y entry's own (u,v) = (Z,X) is deliberately the exact
// pair that reproduces the pre-Wave-5 single Y-ring's atan2(dx,dz) angle
// convention bit-for-bit, so an old project's authored Y rotation feels
// identical to drag, not just identical to load.
const GIZMO_ROTATE_AXES = [
  { axis: 'rx', dir: new Opus.Vec3(1, 0, 0), color: [0.95, 0.25, 0.25], u: new Opus.Vec3(0, 1, 0), v: new Opus.Vec3(0, 0, 1) },
  { axis: 'ry', dir: new Opus.Vec3(0, 1, 0), color: [0.3, 0.9, 0.35], u: new Opus.Vec3(0, 0, 1), v: new Opus.Vec3(1, 0, 0) },
  { axis: 'rz', dir: new Opus.Vec3(0, 0, 1), color: [0.3, 0.55, 0.95], u: new Opus.Vec3(1, 0, 0), v: new Opus.Vec3(0, 1, 0) },
];
const GIZMO_RING_SEGMENTS = 16;
const GIZMO_SCALE_AXES = [
  { axis: 'sx', dir: new Opus.Vec3(1, 0, 0), color: [0.75, 0.4, 0.4] },
  { axis: 'sy', dir: new Opus.Vec3(0, 1, 0), color: [0.4, 0.7, 0.45] },
  { axis: 'sz', dir: new Opus.Vec3(0, 0, 1), color: [0.4, 0.5, 0.75] },
];
// One extra point handle (not an axis) near the origin for uniform scale --
// deliberately off all three axes so it never overlaps their pick regions.
const GIZMO_UNIFORM_OFFSET = new Opus.Vec3(0.5, 0.5, 0.5);
// Deliberately clear of the three move/scale handles' own reach
// ([GAP, GAP+LENGTH] along their axis) so the rotate handle doesn't
// visually or pick-wise collide with them regardless of rotation angle.
const GIZMO_ROTATE_RADIUS = GIZMO_GAP + GIZMO_LENGTH + 0.5;
const gizmoHandles = new Map(); // handle id -> entity ('x'/'y'/'z'/'rotate'/'sx'/'sy'/'sz'/'uniform')

// Wave 5 (Priority I): a spot light's cone has no visual representation at
// all otherwise -- angle/range are just numbers in the Inspector, with no
// way to see what they actually illuminate without entering Play mode. A
// bounded, editor-only marker set (never saved, never lit, unpickable --
// same non-interactive convention as the selection marker), rebuilt
// whenever the selected light's own relevant fields change.
const LIGHT_CONE_RING_SEGMENTS = 12;
const lightConeHandles = new Map(); // id -> marker entity, id is 'apex', 'axis-N', or 'ring-N'

function syncLightConeViz() {
  const isSelectedSpot = selectedItem && selectedItem.kind === 'light' && selectedItem.options.lightType === 'spot';
  if (!isSelectedSpot) {
    for (const entity of lightConeHandles.values()) app.scene.remove(entity);
    lightConeHandles.clear();
    return;
  }
  const apex = selectedItem.entity.position;
  // The light handle's own `.direction` is kept in sync with the entity's
  // WORLD orientation every frame (see the light per-frame sync near
  // instantiateCubeRecord) -- using it here, rather than the raw local
  // `options.direction`, means the cone preview correctly follows a
  // parented light's inherited rotation, not just its own local aim.
  const dir = selectedItem.lightHandle.direction.length() > 0.0001 ? selectedItem.lightHandle.direction.clone().normalize() : new Opus.Vec3(0, -1, 0);
  const range = selectedItem.options.range;
  const radius = range * Math.tan(selectedItem.options.angle);
  const baseCenter = apex.add(dir.scale(range));
  const ref = Math.abs(dir.dot(new Opus.Vec3(0, 1, 0))) > 0.99 ? new Opus.Vec3(1, 0, 0) : new Opus.Vec3(0, 1, 0);
  const u = dir.cross(ref).normalize();
  const v = dir.cross(u).normalize();

  const wanted = new Set(['apex']);
  const place = (id, pos, color, size) => {
    wanted.add(id);
    let entity = lightConeHandles.get(id);
    if (!entity) { entity = app.addEntity({ mesh: cubeMesh, color, position: pos, scale: new Opus.Vec3(size, size, size), unlit: true }); lightConeHandles.set(id, entity); }
    else entity.position.set(pos.x, pos.y, pos.z);
  };
  place('apex', apex, [1, 1, 0.6], 0.12);
  for (let i = 0; i < LIGHT_CONE_RING_SEGMENTS; i++) {
    const theta = (i / LIGHT_CONE_RING_SEGMENTS) * Math.PI * 2;
    const pos = baseCenter.add(u.scale(Math.cos(theta) * radius)).add(v.scale(Math.sin(theta) * radius));
    place(`ring-${i}`, pos, [1, 1, 0.4], 0.1);
  }
  const AXIS_DOTS = 4;
  for (let i = 1; i <= AXIS_DOTS; i++) {
    place(`axis-${i}`, apex.add(dir.scale(range * (i / (AXIS_DOTS + 1)))), [1, 1, 0.4], 0.07);
  }
  for (const [id, entity] of lightConeHandles) {
    if (!wanted.has(id)) { app.scene.remove(entity); lightConeHandles.delete(id); }
  }
}

function gizmoEligible() {
  if (playMode || !selectedItem) return false;
  // Move-gizmo-able kinds match exactly what free-drag already supports
  // (cube, terrain) -- water was never draggable either, no reason for the
  // gizmo to support it first. Rotate/Scale are cube-only: terrain has no
  // rotationY or per-axis scale in this engine (Seed/Size/Radius instead).
  if (gizmoMode === 'move') return selectedItem.kind === 'cube' || selectedItem.kind === 'terrain';
  return selectedItem.kind === 'cube';
}

function syncGizmo() {
  if (!gizmoEligible()) {
    for (const entity of gizmoHandles.values()) app.scene.remove(entity);
    gizmoHandles.clear();
    return;
  }
  // Mode switches reuse nothing across modes -- a leftover Rotate handle
  // while in Scale mode (or vice versa) would still be pickable even though
  // it's the wrong tool, so every handle not valid for the CURRENT mode is
  // torn down first. Rotate ring segments use composite ids ('rx-0', 'ry-3',
  // ...), matched by prefix rather than listed individually.
  const keep = (id) => (gizmoMode === 'move' ? ['x', 'y', 'z'].includes(id)
    : gizmoMode === 'rotate' ? /^r[xyz]-/.test(id)
    : ['sx', 'sy', 'sz', 'uniform'].includes(id));
  for (const [id, entity] of gizmoHandles) {
    if (!keep(id)) { app.scene.remove(entity); gizmoHandles.delete(id); }
  }
  const origin = itemPosition(selectedItem);
  if (gizmoMode === 'move') {
    // Wave 6 (Priority J): in 'local' mode every handle gets the SELECTED
    // item's own current quaternion -- a box scaled long along its local X
    // (the 'x' handle), given the object's own orientation, points its long
    // axis exactly along entity.right, matching moveAxisWorldDir('x')
    // exactly -- one shared rotation, not three separately-computed
    // per-axis alignments. Identity in 'world' mode (the default), so an
    // unrotated object's handles are visually unaffected by which mode is
    // active, and every project saved before this priority renders
    // bit-identical Move handles.
    const handleQuat = (gizmoSpace === 'local' && selectedItem.entity) ? selectedItem.entity.quaternion : Opus.Quat.identity();
    for (const { axis, color } of GIZMO_MOVE_AXES) {
      const dir = moveAxisWorldDir(axis);
      const center = origin.add(dir.scale(GIZMO_GAP + GIZMO_LENGTH / 2));
      const scale = axis === 'x' ? new Opus.Vec3(GIZMO_LENGTH, GIZMO_THICKNESS, GIZMO_THICKNESS)
        : axis === 'y' ? new Opus.Vec3(GIZMO_THICKNESS, GIZMO_LENGTH, GIZMO_THICKNESS)
        : new Opus.Vec3(GIZMO_THICKNESS, GIZMO_THICKNESS, GIZMO_LENGTH);
      let entity = gizmoHandles.get(axis);
      if (!entity) { entity = app.addEntity({ mesh: cubeMesh, color, position: center, scale }); gizmoHandles.set(axis, entity); }
      else entity.position.set(center.x, center.y, center.z);
      entity.quaternion = handleQuat;
    }
  } else if (gizmoMode === 'rotate') {
    // Each ring is drawn as GIZMO_RING_SEGMENTS small markers around a
    // fixed circle in that axis's own plane (no continuous-curve mesh
    // exists in this engine -- the same "approximate with arranged cubes"
    // precedent the Waypoint Graph's connection LINES already established
    // for a missing primitive). Positions are fixed relative to the
    // object's origin (not re-oriented by the object's current rotation),
    // matching how Move/Scale handles are also fixed local offsets, not a
    // reflection of some current value -- simpler and just as grabbable.
    for (const { axis, dir, color, u, v } of GIZMO_ROTATE_AXES) {
      for (let i = 0; i < GIZMO_RING_SEGMENTS; i++) {
        const theta = (i / GIZMO_RING_SEGMENTS) * Math.PI * 2;
        const offset = u.scale(Math.cos(theta)).add(v.scale(Math.sin(theta))).scale(GIZMO_ROTATE_RADIUS);
        const center = origin.add(offset);
        const id = `${axis}-${i}`;
        let entity = gizmoHandles.get(id);
        if (!entity) { entity = app.addEntity({ mesh: cubeMesh, color, position: center, scale: new Opus.Vec3(0.14, 0.14, 0.14) }); gizmoHandles.set(id, entity); }
        else entity.position.set(center.x, center.y, center.z);
      }
    }
  } else if (gizmoMode === 'scale') {
    for (const { axis, dir, color } of GIZMO_SCALE_AXES) {
      const center = origin.add(dir.scale(GIZMO_GAP + GIZMO_LENGTH / 2));
      const scale = axis === 'sx' ? new Opus.Vec3(GIZMO_LENGTH, GIZMO_THICKNESS, GIZMO_THICKNESS)
        : axis === 'sy' ? new Opus.Vec3(GIZMO_THICKNESS, GIZMO_LENGTH, GIZMO_THICKNESS)
        : new Opus.Vec3(GIZMO_THICKNESS, GIZMO_THICKNESS, GIZMO_LENGTH);
      let entity = gizmoHandles.get(axis);
      if (!entity) { entity = app.addEntity({ mesh: cubeMesh, color, position: center, scale }); gizmoHandles.set(axis, entity); }
      else entity.position.set(center.x, center.y, center.z);
    }
    const uCenter = origin.add(GIZMO_UNIFORM_OFFSET);
    let uEntity = gizmoHandles.get('uniform');
    if (!uEntity) { uEntity = app.addEntity({ mesh: cubeMesh, color: [0.9, 0.85, 0.9], position: uCenter, scale: new Opus.Vec3(0.28, 0.28, 0.28) }); gizmoHandles.set('uniform', uEntity); }
    else uEntity.position.set(uCenter.x, uCenter.y, uCenter.z);
  }
}

// Closest approach between the pick ray and each handle's own line segment
// (origin+dir*GIZMO_GAP to origin+dir*(GIZMO_GAP+GIZMO_LENGTH)) -- NOT a
// sphere around each handle's center. First attempt used a generous sphere
// per handle (the same approximation pickEntity already uses for
// free-standing cube selection), but all three handles share one origin
// close enough together that their spheres overlap heavily: clicking
// exactly on the X handle's screen position picked Y instead, because Y's
// sphere happened to be closer along the ray at that pixel. Caught by
// dispatching a real PointerEvent at the X handle's own projected screen
// position and finding the object moved along Y, not X.
function closestPointsRayLine(rayOrigin, rayDir, lineOrigin, lineDir) {
  const w0 = rayOrigin.sub(lineOrigin);
  const b = rayDir.dot(lineDir);
  const d = rayDir.dot(w0);
  const e = lineDir.dot(w0);
  const denom = 1 - b * b;
  if (Math.abs(denom) < 1e-6) return { rayT: Math.max(0, -d), lineU: 0 };
  return { rayT: Math.max(0, (b * e - d) / denom), lineU: (e - b * d) / denom };
}

function pickGizmoHandle(clientX, clientY) {
  if (gizmoHandles.size === 0 || !selectedItem) return null;
  const rect = canvas.getBoundingClientRect();
  const ndcX = ((clientX - rect.left) / rect.width) * 2 - 1;
  const ndcY = -(((clientY - rect.top) / rect.height) * 2 - 1);
  const ray = app.camera.screenPointToRay(ndcX, ndcY, canvas.width / Math.max(canvas.height, 1));
  const origin = itemPosition(selectedItem);
  const pickThreshold = GIZMO_THICKNESS * 4;
  let closestId = null;
  let closestDist = pickThreshold;
  const axisSet = gizmoMode === 'move' ? GIZMO_MOVE_AXES : gizmoMode === 'scale' ? GIZMO_SCALE_AXES : [];
  for (const { axis } of axisSet) {
    const dir = gizmoMode === 'move' ? moveAxisWorldDir(axis) : GIZMO_SCALE_AXES.find((a) => a.axis === axis).dir;
    const { lineU } = closestPointsRayLine(ray.origin, ray.direction, origin, dir);
    const clampedU = Math.max(GIZMO_GAP, Math.min(GIZMO_GAP + GIZMO_LENGTH, lineU));
    const handlePoint = origin.add(dir.scale(clampedU));
    const rayT = Math.max(0, handlePoint.sub(ray.origin).dot(ray.direction));
    const rayPoint = ray.origin.add(ray.direction.scale(rayT));
    const dist = rayPoint.sub(handlePoint).length();
    if (dist < closestDist) { closestDist = dist; closestId = axis; }
  }
  // The uniform-scale handle is a single point -- plain closest-point-on-
  // ray-to-a-point, the degenerate case of the same math.
  const uniformHandle = gizmoHandles.get('uniform');
  if (uniformHandle) {
    const rayT = Math.max(0, uniformHandle.position.sub(ray.origin).dot(ray.direction));
    const rayPoint = ray.origin.add(ray.direction.scale(rayT));
    const dist = rayPoint.sub(uniformHandle.position).length();
    if (dist < closestDist) { closestDist = dist; closestId = 'uniform'; }
  }
  // Rotate rings (Wave 5): picked against each ring's actual rendered
  // segment markers (closest-point-on-ray-to-a-point, same math as the
  // uniform handle above), NOT a generic "ray hits my plane near my
  // radius" test. The plane/radius test was tried first and found broken
  // by dogfooding: at theta=0/90/180/270 a ring's own reference point sits
  // exactly on the shared seam where TWO rings' planes intersect (e.g.
  // (R,0,0) lies in both the rz ring's z=0 plane AND the ry ring's y=0
  // plane, at exactly radius R from origin in both), so the generic test
  // picked the wrong ring there -- reproduced by dragging the Z ring and
  // measuring the resulting rotation land on Y instead of Z. Testing
  // against real marker positions has no such seam ambiguity: two
  // different rings' segments are never at the same point in space.
  if (gizmoMode === 'rotate') {
    const ringPickThreshold = GIZMO_THICKNESS * 5;
    for (const { axis } of GIZMO_ROTATE_AXES) {
      for (let i = 0; i < GIZMO_RING_SEGMENTS; i++) {
        const seg = gizmoHandles.get(`${axis}-${i}`);
        if (!seg) continue;
        const rayT = Math.max(0, seg.position.sub(ray.origin).dot(ray.direction));
        const rayPoint = ray.origin.add(ray.direction.scale(rayT));
        const dist = rayPoint.sub(seg.position).length();
        if (dist < ringPickThreshold && dist < closestDist) { closestDist = dist; closestId = axis; }
      }
    }
  }
  return closestId;
}

// Unconditional (runs in edit mode too, unlike the gameplay-only onUpdate
// below gated behind `playMode`) -- so dragging/gizmo-editing a parent in
// the editor itself moves its children live, WYSIWYG, not just once Play
// starts. Registered before the selection-marker sync below so a selected
// CHILD's marker reads its already-resolved (not stale) world position.
app.onUpdate(() => { updateHierarchyTransforms(); });

// Unconditional too, same reasoning as hierarchy above -- this is what makes
// Preview work in the editor itself, not just once Play starts. The
// engine's own update loop already gates EVERY registered onUpdate callback
// (this one included) behind `!app.paused` (see API-FRICTION.md #54), so
// "respect pause" and "use simulation time" both come for free here with no
// animation-specific pause-checking code -- the same property Tweens/Timers
// already got by living inside the gameplay-gated callback, just reached a
// different way since this one also needs to run in edit mode for Preview.
app.onUpdate((dt) => { updateAnimations(dt); });

// A light's marker `entity` is what hierarchy/gizmo/drag/Undo all already
// know how to move; the actual `app.createLight` handle the renderer reads
// is a SEPARATE object (createLight's own return value, not an Entity --
// lights have no mesh). This is the one sync point between them: copy the
// marker's now-hierarchy-resolved world position into the light handle
// every frame, so a parented or Tween-animated light stays correctly lit
// with zero light-specific code anywhere else. Direction is NOT re-derived
// from the marker's rotationY -- true when this was written (a cube had no
// pitch/tilt to drive a cone direction from), no longer true now that Wave
// 5 gives every entity a real quaternion. `options.direction` is now
// interpreted as the LOCAL aim direction (relative to the light's own
// orientation), and the light handle's actual world-space direction is
// `entity.quaternion.rotateVec3(localDirection)` every frame -- for an
// unparented light `entity.quaternion` is always identity (nothing else
// ever sets it), so `identity.rotateVec3(d) === d` and behavior for every
// pre-Wave-5 standalone light is completely unchanged; a PARENTED spot
// light's cone now correctly follows its parent's full rotation, closing
// the bound this comment used to document.
app.onUpdate(() => {
  for (const item of placed) {
    if (item.kind !== 'light') continue;
    item.lightHandle.position.set(item.entity.position.x, item.entity.position.y, item.entity.position.z);
    item.options.position.set(item.entity.position.x, item.entity.position.y, item.entity.position.z);
    if (item.options.lightType === 'spot' && item.options.direction) {
      const worldDir = item.entity.quaternion.rotateVec3(item.options.direction);
      item.lightHandle.direction.set(worldDir.x, worldDir.y, worldDir.z);
    }
  }
});

app.onUpdate(() => {
  for (const [item, marker] of selectionMarkers) {
    const pos = itemPosition(item);
    if (item.kind === 'cube') {
      marker.position.set(pos.x, pos.y - item.entity.scale.y * 0.4, pos.z);
      marker.scale.set(item.entity.scale.x * 1.15, 0.05, item.entity.scale.z * 1.15);
    } else {
      marker.position.set(pos.x, pos.y + 0.02, pos.z);
      marker.scale.set(1.5, 0.05, 1.5);
    }
  }
  // Keeps the gizmo glued to its item across every OTHER way position can
  // change -- inspector field edits, AI/patrol movement, Undo/Redo -- not
  // just its own drag gesture.
  if (gizmoHandles.size > 0 && selectedItem) {
    const origin = itemPosition(selectedItem);
    const axisSet = gizmoMode === 'move' ? GIZMO_MOVE_AXES : gizmoMode === 'scale' ? GIZMO_SCALE_AXES : [];
    const moveHandleQuat = (gizmoMode === 'move' && gizmoSpace === 'local' && selectedItem.entity) ? selectedItem.entity.quaternion : Opus.Quat.identity();
    for (const { axis } of axisSet) {
      const entity = gizmoHandles.get(axis);
      if (!entity) continue;
      const dir = gizmoMode === 'move' ? moveAxisWorldDir(axis) : GIZMO_SCALE_AXES.find((a) => a.axis === axis).dir;
      const center = origin.add(dir.scale(GIZMO_GAP + GIZMO_LENGTH / 2));
      entity.position.set(center.x, center.y, center.z);
      if (gizmoMode === 'move') entity.quaternion = moveHandleQuat;
    }
    if (gizmoMode === 'rotate' && selectedItem.kind === 'cube') {
      for (const { axis, u, v } of GIZMO_ROTATE_AXES) {
        for (let i = 0; i < GIZMO_RING_SEGMENTS; i++) {
          const entity = gizmoHandles.get(`${axis}-${i}`);
          if (!entity) continue;
          const theta = (i / GIZMO_RING_SEGMENTS) * Math.PI * 2;
          const offset = u.scale(Math.cos(theta)).add(v.scale(Math.sin(theta))).scale(GIZMO_ROTATE_RADIUS);
          const center = origin.add(offset);
          entity.position.set(center.x, center.y, center.z);
        }
      }
    }
    const uniformHandle = gizmoHandles.get('uniform');
    if (uniformHandle) {
      const center = origin.add(GIZMO_UNIFORM_OFFSET);
      uniformHandle.position.set(center.x, center.y, center.z);
    }
  }
});

function setGizmoMode(mode) {
  if (gizmoMode === mode) return;
  gizmoMode = mode;
  for (const m of ['move', 'rotate', 'scale']) {
    document.getElementById(`gizmo-mode-${m}`).classList.toggle('active', m === mode);
  }
  syncGizmo();
}
document.getElementById('gizmo-mode-move').addEventListener('click', () => setGizmoMode('move'));
document.getElementById('gizmo-mode-rotate').addEventListener('click', () => setGizmoMode('rotate'));
document.getElementById('gizmo-mode-scale').addEventListener('click', () => setGizmoMode('scale'));
document.getElementById('gizmo-mode-move').classList.add('active'); // matches the default gizmoMode = 'move'

const gizmoSnapToggleEl = document.getElementById('gizmo-snap-toggle');
gizmoSnapToggleEl.checked = gizmoSnap.enabled;
gizmoSnapToggleEl.addEventListener('change', (e) => {
  gizmoSnap.enabled = e.target.checked;
  saveGizmoSnapSetting();
});

document.getElementById('show-colliders-toggle').addEventListener('change', (e) => {
  showColliders = e.target.checked;
  syncColliderViz();
});

// Wave 6 (Priority J): Local/World gizmo mode toggle -- a plain session
// preference (like gizmoMode itself), not persisted per-project, since
// which frame an author wants to move objects in is a moment-to-moment
// authoring choice, not something a saved game needs to remember.
document.getElementById('gizmo-space-toggle').addEventListener('click', () => {
  gizmoSpace = gizmoSpace === 'world' ? 'local' : 'world';
  const btn = document.getElementById('gizmo-space-toggle');
  btn.textContent = gizmoSpace === 'world' ? '🌐 World' : '📐 Local';
  syncGizmo(); // the same "keep matching-mode handles, just update position/quaternion" refresh setGizmoMode already uses
});

// W/E/R gizmo-mode shortcuts -- only in edit mode (never during Play, where
// WASD/Space already drive the player), and only when focus isn't inside a
// text input/textarea/select (otherwise typing a level name starting with
// "r" would yank the gizmo into Rotate mode out from under the user).
window.addEventListener('keydown', (e) => {
  if (playMode) return;
  const tag = document.activeElement && document.activeElement.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
  if (e.key === 'w' || e.key === 'W') setGizmoMode('move');
  else if (e.key === 'e' || e.key === 'E') setGizmoMode('rotate');
  else if (e.key === 'r' || e.key === 'R') setGizmoMode('scale');
});

// --- Scene list ---

const sceneListEl = document.getElementById('scene-list');

let sceneListFilter = '';
// Depth-first parent-before-children ordering for the Scene tree. Dangling
// parentId (parent no longer in `placed`) is treated as a root rather than
// dropped -- shouldn't happen given removeItemFromScene's unparent-on-delete
// step, but a tree view fails safe by still showing the item, not hiding it.
function buildHierarchyOrder(items) {
  const childrenByParent = new Map();
  for (const item of items) {
    if (!item.parentId) continue;
    if (!childrenByParent.has(item.parentId)) childrenByParent.set(item.parentId, []);
    childrenByParent.get(item.parentId).push(item);
  }
  const result = [];
  const visited = new Set();
  function visit(item, depth) {
    if (visited.has(item)) return;
    visited.add(item);
    result.push({ item, depth });
    for (const kid of childrenByParent.get(item.id) || []) visit(kid, depth + 1);
  }
  for (const item of items) {
    const parent = item.parentId ? findItemById(item.parentId) : null;
    if (!parent || !items.includes(parent)) visit(item, 0);
  }
  return result;
}
const sceneTreeCollapsed = new Set(); // item ids currently collapsed (children hidden)
function renderSceneList() {
  if (placed.length === 0) {
    sceneListEl.innerHTML = '<p id="scene-list-empty">Nothing placed yet.</p>';
    return;
  }
  const q = sceneListFilter.trim().toLowerCase();
  const childrenByParent = new Map();
  for (const item of placed) {
    if (item.parentId) { if (!childrenByParent.has(item.parentId)) childrenByParent.set(item.parentId, []); childrenByParent.get(item.parentId).push(item); }
  }
  let rows;
  if (q) {
    // Searching flattens to a plain matched list (still findable by name
    // regardless of nesting depth) rather than trying to show ancestor
    // chains above each match -- simpler and still sensible: a search hit
    // is never hidden just because it's nested.
    rows = placed.map((item, i) => ({ item, i, depth: 0, label: itemDisplayName(item, i) })).filter(({ label }) => label.toLowerCase().includes(q));
  } else {
    rows = buildHierarchyOrder(placed)
      .map(({ item, depth }) => ({ item, i: placed.indexOf(item), depth, label: itemDisplayName(item, placed.indexOf(item)) }));
  }
  if (rows.length === 0) {
    sceneListEl.innerHTML = '<p id="scene-list-empty">No objects match the filter.</p>';
    return;
  }
  // Visibility toggle only applies to real entities (cube/camera) -- terrain/
  // water/emitter don't have an on/off visual state the way an entity does.
  const visibleRows = q ? rows : rows.filter(({ item }) => {
    // Hide a row if any ancestor (walking up parentId) is currently collapsed.
    let p = item.parentId ? findItemById(item.parentId) : null;
    while (p) { if (sceneTreeCollapsed.has(p.id)) return false; p = p.parentId ? findItemById(p.parentId) : null; }
    return true;
  });
  sceneListEl.innerHTML = visibleRows.map(({ item, i, depth, label }) => {
    const canToggle = !!item.entity;
    const visible = canToggle ? item.entity.visible : true;
    const eyeBtn = canToggle ? `<button class="scene-list-visibility-btn${visible ? '' : ' hidden-item'}" data-toggle-index="${i}" title="${visible ? 'Hide' : 'Show'}">${visible ? '👁' : '🚫'}</button>` : '';
    const hasChildren = (childrenByParent.get(item.id) || []).length > 0;
    const collapsed = sceneTreeCollapsed.has(item.id);
    const caret = hasChildren ? `<button class="scene-list-caret-btn" data-caret-index="${i}" title="${collapsed ? 'Expand' : 'Collapse'}">${collapsed ? '▸' : '▾'}</button>` : `<span class="scene-list-caret-spacer"></span>`;
    const indent = q ? 0 : depth * 14;
    // Wave 6 (Priority J): only a hierarchy-capable item can be dragged OR
    // accept a drop (terrain/water were always excluded from hierarchy --
    // see hierarchyCapable's own comment -- dragging one here would silently
    // no-op reparentItem, confusing rather than useful, so it's simply not
    // draggable at all).
    const draggable = hierarchyCapable(item) ? ' draggable="true"' : '';
    return `<div class="scene-list-item${selectedItems.has(item) ? ' selected' : ''}" data-index="${i}"${draggable} style="padding-left:${indent}px">${caret}<span class="scene-list-item-name">${escapeHtml(label)}</span>${eyeBtn}</div>`;
  }).join('');
  sceneListEl.querySelectorAll('.scene-list-item').forEach((el) => {
    el.onclick = (e) => {
      if (playMode || e.target.closest('[data-toggle-index]') || e.target.closest('[data-caret-index]')) return;
      selectItem(placed[Number(el.dataset.index)], e.shiftKey);
    };
  });
  sceneListEl.querySelectorAll('[data-toggle-index]').forEach((btn) => {
    btn.onclick = (e) => {
      e.stopPropagation();
      if (playMode) return;
      const item = placed[Number(btn.dataset.toggleIndex)];
      if (!item.entity) return;
      pushUndo();
      item.entity.visible = !item.entity.visible;
      renderSceneList();
    };
  });
  sceneListEl.querySelectorAll('[data-caret-index]').forEach((btn) => {
    btn.onclick = (e) => {
      e.stopPropagation();
      const item = placed[Number(btn.dataset.caretIndex)];
      if (sceneTreeCollapsed.has(item.id)) sceneTreeCollapsed.delete(item.id); else sceneTreeCollapsed.add(item.id);
      renderSceneList();
    };
  });
  wireSceneListDragReparenting();
}
// Wave 6 (Priority J): drag-and-drop reparenting directly in the Scene
// tree -- the ONE existing way to reparent before this (an Inspector
// "Parent To" dropdown) is precise but slow for restructuring several
// objects at once; dragging one row onto another is the standard hierarchy-
// panel gesture every scene editor already trains users to expect. Reuses
// `reparentItem`/`unparentItem` wholesale (Wave 4/5) -- no new reparenting
// math, just a new gesture that calls the same functions the Inspector
// dropdown already does.
let sceneDragItemId = null;
function wireSceneListDragReparenting() {
  sceneListEl.querySelectorAll('.scene-list-item[draggable]').forEach((el) => {
    el.addEventListener('dragstart', (e) => {
      if (playMode) { e.preventDefault(); return; }
      sceneDragItemId = placed[Number(el.dataset.index)].id;
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', sceneDragItemId); // Firefox requires real data to be set for a drag to start at all
    });
    el.addEventListener('dragover', (e) => {
      if (!sceneDragItemId) return;
      e.preventDefault(); // required for 'drop' to fire at all -- native HTML5 DnD default is "reject"
      e.dataTransfer.dropEffect = 'move';
      el.classList.add('scene-list-drop-target');
    });
    el.addEventListener('dragleave', () => el.classList.remove('scene-list-drop-target'));
    el.addEventListener('drop', (e) => {
      e.preventDefault();
      el.classList.remove('scene-list-drop-target');
      const draggedItem = findItemById(sceneDragItemId);
      const targetItem = placed[Number(el.dataset.index)];
      sceneDragItemId = null;
      if (!draggedItem || !targetItem || draggedItem === targetItem) return;
      pushUndo();
      if (reparentItem(draggedItem, targetItem)) {
        showStatus(`Parented "${itemDisplayName(draggedItem, placed.indexOf(draggedItem))}" to "${itemDisplayName(targetItem, placed.indexOf(targetItem))}"`);
        renderSceneList();
        renderInspector();
      }
    });
  });
  // Dropping onto the list's own empty background (not any row) unparents
  // back to root -- the drag-and-drop equivalent of the Inspector's own
  // "Parent To: (none)" option.
  sceneListEl.ondragover = (e) => { if (sceneDragItemId) e.preventDefault(); };
  sceneListEl.ondrop = (e) => {
    if (e.target !== sceneListEl || !sceneDragItemId) return; // a row's own drop handler already ran and stopped nothing, so guard on the exact target instead
    e.preventDefault();
    const draggedItem = findItemById(sceneDragItemId);
    sceneDragItemId = null;
    if (!draggedItem || !draggedItem.parentId) return;
    pushUndo();
    if (unparentItem(draggedItem)) {
      showStatus(`Unparented "${itemDisplayName(draggedItem, placed.indexOf(draggedItem))}"`);
      renderSceneList();
      renderInspector();
    }
  };
}
document.getElementById('scene-search').addEventListener('input', (e) => {
  sceneListFilter = e.target.value;
  renderSceneList();
});

// --- Hovercraft player controller ---
// Ported from the earlier standalone Delivery Run demo: one game, not two
// disconnected demos. Driving to a crate is a much more compelling proof
// of "built with this editor" than clicking a static cube with a mouse.
// Movement/collision/hover math is unchanged from the proven original;
// only the terrain/water source (looked up from `placed`, not a fixed
// module-level const) and emitter lifecycle (spawned/removed per play
// session via the new removeEmitter API) are new.

const MAP_BOUNDARY = 40; // must clear all five islands (farthest: (20,20) center + radius 9 ≈ 37.3)

// Touch devices have no physical keyboard, so WASD/Space have nothing to
// read -- on-screen buttons drive the exact same key state via the new
// Input.simulateKeyDown/Up, so updateCraftPhysics below needs zero changes.
const isTouchDevice = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
// `codeOrGetter` accepts a fixed key code (unrebindable buttons -- none of
// these five actually are anymore, kept for generality) OR a function
// returning the CURRENT code (Wave 5: Move/Jump/Boost are all rebindable
// via inputActionMap, and this touch button must invoke the same LOGICAL
// action, not whatever key happened to be bound when the page first
// loaded). The code is resolved once at press time and reused for the
// matching release, so a rebind mid-press can't release the wrong key.
function wireTouchButton(id, codeOrGetter) {
  const btn = document.getElementById(id);
  const resolveCode = () => (typeof codeOrGetter === 'function' ? codeOrGetter() : codeOrGetter);
  let heldCode = null;
  const press = (e) => { e.preventDefault(); heldCode = resolveCode(); app.input.simulateKeyDown(heldCode); };
  const release = (e) => { e.preventDefault(); if (heldCode) app.input.simulateKeyUp(heldCode); heldCode = null; };
  btn.addEventListener('pointerdown', press);
  btn.addEventListener('pointerup', release);
  btn.addEventListener('pointerleave', release);
  btn.addEventListener('pointercancel', release);
  btn.addEventListener('contextmenu', (e) => e.preventDefault());
}
wireTouchButton('touch-up', () => effectiveInputMap.moveForward);
wireTouchButton('touch-down', () => effectiveInputMap.moveBack);
wireTouchButton('touch-left', () => effectiveInputMap.moveLeft);
wireTouchButton('touch-right', () => effectiveInputMap.moveRight);
wireTouchButton('touch-boost', () => effectiveInputMap.jump);

let craft = null;
let craftParts = [];
let craftVelocity = null;
let craftSteering = 0;
let craftBoostActive = 0;
let craftBoostCooldown = 0;
let craftExhaust = null;
let craftSpray = null;
let craftFoam = null;

// Generic player accessor -- every controller (hovercraft today, more to
// come) populates this on spawn so consumer code (camera, AI follow,
// triggers, checkpoints, the boost action) never needs to know which
// controller is active. `entity`/`radius`/`controllerType` are set once at
// spawn; `velocity` is a getter/setter delegating to the controller's own
// state variable (which gets *reassigned*, not mutated, every frame) so it
// always reflects the live value without the hovercraft's proven physics
// code having to change how it stores that state.
let player = null;
// Logic-check pass: no jump-enabled controller (topdown-with-jump,
// third-person, first-person) had ANY recovery from walking/jumping off the
// edge of placed floor geometry into open space -- none of the 28 catalog
// games place explicit `terrain` objects, so `currentTerrainItem()` returns
// null and there is no fallback ground height once you clear the last box
// collider; `applyMapBoundary` only ever nudges XZ, never Y. The result,
// confirmed live: fall off any ledge and free-fall forever with the level
// receding above you -- exactly the "jump off map and get stuck" report.
// Fixed once, at the single per-frame choke point every controller already
// funnels through (`updatePlayerController`), reusing the exact same
// recovery the `respawnAtCheckpoint` behavior-graph action already used for
// hazards: checkpoint if one's been set, else `computeSpawnPoint()`. Not a
// per-level authoring fix (which would need retrofitting 23 existing
// projects with a manual void-trigger volume each) -- this is unconditional
// for every controller, so it can never be missed on a level.
const VOID_FALL_MARGIN = 30; // generous: real jumps/falls off a platform are a few units, not 30
let voidFallY = -Infinity;

const PLAYER_CONTROLLERS = {
  hovercraft: { spawn: spawnHovercraftController, despawn: despawnHovercraftController, update: updateHovercraftController },
  topdown: { spawn: spawnTopDownController, despawn: despawnTopDownController, update: updateTopDownController },
  thirdperson: { spawn: spawnThirdPersonController, despawn: despawnThirdPersonController, update: updateThirdPersonController },
  firstperson: { spawn: spawnFirstPersonController, despawn: despawnFirstPersonController, update: updateFirstPersonController },
};

// Always spawns using `currentPlayerSettings` (set by applyLevelPlayerSettings
// before Play starts / a level switches), so it never needs its own type
// argument -- one fewer place that could disagree with the Player panel.
// --- Waypoint Graph pathfinding (Wave 4) ---
// A bounded navigation layer on top of Waypoint objects -- real A* over
// author-connected waypoints, NOT a navmesh (no dynamic obstacle avoidance
// beyond "the graph already routes around static walls because that's how
// the author connected it"). Deliberately separate from the existing Patrol
// Route AI type: Patrol Route visits an ORDERED list directly with no graph/
// pathfinding at all (unchanged); Navigate To Target (below) computes the
// shortest CONNECTED route to wherever a target currently is, recomputing
// periodically since the target moves -- the actual point of a real
// pathfinder rather than a fixed route.
function nearestWaypointTo(position) {
  let best = null, bestDist = Infinity;
  for (const item of placed) {
    if (!item.isWaypoint) continue;
    const d = item.entity.position.sub(position).length();
    if (d < bestDist) { bestDist = d; best = item; }
  }
  return best;
}
// Standard A* over the waypoint graph -- straight-line distance heuristic
// (admissible: never overestimates the true connected-path cost). Returns
// an array of waypoint ids from start to goal (inclusive), or null if the
// graph has no connected route between them.
function findWaypointPath(startId, goalId) {
  if (startId === goalId) return [startId];
  const dist = (a, b) => { const wa = findItemById(a), wb = findItemById(b); return wa && wb ? wa.entity.position.sub(wb.entity.position).length() : Infinity; };
  const open = new Set([startId]);
  const cameFrom = new Map();
  const gScore = new Map([[startId, 0]]);
  const fScore = new Map([[startId, dist(startId, goalId)]]);
  const guard = placed.length + 10; // cycle/runaway safety, not a real graph-size limit
  for (let step = 0; step < guard && open.size > 0; step++) {
    let current = null, currentF = Infinity;
    for (const id of open) { const f = fScore.get(id) ?? Infinity; if (f < currentF) { currentF = f; current = id; } }
    if (current === goalId) {
      const path = [current];
      while (cameFrom.has(current)) { current = cameFrom.get(current); path.unshift(current); }
      return path;
    }
    open.delete(current);
    const currentItem = findItemById(current);
    if (!currentItem) continue;
    for (const neighborId of (currentItem.connections || [])) {
      if (!findItemById(neighborId)) continue;
      const tentativeG = (gScore.get(current) ?? Infinity) + dist(current, neighborId);
      if (tentativeG < (gScore.get(neighborId) ?? Infinity)) {
        cameFrom.set(neighborId, current);
        gScore.set(neighborId, tentativeG);
        fScore.set(neighborId, tentativeG + dist(neighborId, goalId));
        open.add(neighborId);
      }
    }
  }
  return null; // no connected route
}
// Recomputes at most every `recomputeInterval` seconds, or immediately if
// there's no path yet -- not every frame, since A* over a real graph isn't
// free and the target rarely needs sub-second path updates to look correct.
function navigateToTargetTick(item, ai, pos, targetEntity, dt) {
  // Once the route through the graph is fully walked (navPathIndex reaches
  // the end), the AI is deliberately off-graph and steering straight for
  // the target's live position for the final stretch -- recomputing on the
  // usual timer in that state would find "the nearest waypoint to HERE"
  // (now off-graph, near wherever it currently is) and briefly steer back
  // toward it before continuing, a visible back-and-forth wobble with no
  // actual benefit. finishedRoute suppresses recompute for as long as the
  // AI stays off-graph; a genuinely new chase (new target, or called again
  // after losing/regaining a path) still recomputes normally via the
  // `!ai.navPath` branch below.
  const offGraph = ai.navPath && ai.navPathIndex >= ai.navPath.length;
  if (!offGraph) {
    ai.navRecomputeTimer = (ai.navRecomputeTimer || 0) - dt;
    if (!ai.navPath || ai.navRecomputeTimer <= 0) {
      ai.navRecomputeTimer = 0.75;
      // Seed the recompute from the waypoint the AI is CURRENTLY heading to,
      // not from nearestWaypointTo(pos) -- found by dogfooding Sentinel Maze:
      // when the AI is near the midpoint between two waypoints in its route,
      // "nearest to raw position" flip-flops between them every recompute,
      // resetting navPathIndex to 0 each time and making the AI oscillate
      // back and forth forever instead of progressing (it would re-walk
      // toward a waypoint it had already just passed). Continuing from the
      // in-progress target waypoint is stable under that flip-flop and still
      // correctly re-routes if the connected graph changed; nearestWaypointTo
      // is still used to seed a BRAND NEW chase (no path yet).
      const currentTargetWp = (ai.navPath && ai.navPathIndex < ai.navPath.length) ? findItemById(ai.navPath[ai.navPathIndex]) : null;
      const startWp = currentTargetWp || nearestWaypointTo(pos);
      const goalWp = nearestWaypointTo(targetEntity.position);
      ai.navPath = (startWp && goalWp) ? findWaypointPath(startWp.id, goalWp.id) : null;
      ai.navPathIndex = 0;
    }
  }
  // Follow the computed route through the graph, then the final unguided
  // stretch from the last waypoint to the target's actual live position --
  // matching how Patrol Route/Follow already move (direct steering, no
  // avoidance), just chained after a real connected route instead of one
  // straight line through a wall.
  let aimPos = targetEntity.position;
  if (ai.navPath && ai.navPathIndex < ai.navPath.length) {
    const wp = findItemById(ai.navPath[ai.navPathIndex]);
    if (wp) {
      aimPos = wp.entity.position;
      if (pos.sub(wp.entity.position).length() < 0.4) ai.navPathIndex += 1;
    } else {
      ai.navPath = null; // a waypoint in the route vanished -- force a clean recompute next tick
    }
  }
  const toAim = aimPos.sub(pos);
  toAim.y = 0;
  const d = toAim.length();
  if (d > 0.1) {
    const step = toAim.scale(Math.min(1, (ai.speed * dt) / d));
    pos.set(pos.x + step.x, pos.y, pos.z + step.z);
  }
}
// Wave 7 (Priority D): the entire pre-Wave-7 movement dispatch, pulled into
// its own function so BOTH the existing "Simple" single-type AI (unchanged
// call site, `ai` itself) and the new State Machine (a state's own
// `movement` sub-object, shaped identically to `ai`) drive movement through
// the exact same code -- a state's `movement` is not a second movement
// language, just the same fields on a different, per-state object (so
// `resolvedWaypointIds`/`wanderTarget`/`navPath`-style per-run caches stay
// correctly scoped to whichever state actually owns them).
function applyAiMovementStep(item, ai, pos, dt, elapsed) {
  const followTargetEntity = ai.targetId ? targetEntity(findItemById(ai.targetId)) : (player ? player.entity : null);
  if (ai.type === 'follow' && followTargetEntity) {
    const toTarget = followTargetEntity.position.sub(pos);
    toTarget.y = 0;
    const dist = toTarget.length();
    if (dist > 0.1) {
      const step = toTarget.scale(Math.min(1, (ai.speed * dt) / dist));
      pos.set(pos.x + step.x, pos.y, pos.z + step.z);
    }
  } else if (ai.type === 'followPath' && ai.pathId) {
    // Wave 8 (Priority I, Sections 58-59): Follow Path -- reusing the SAME
    // shared movement dispatch every other AI/State-Machine movement type
    // already funnels through (so a moving platform, an ordinary AI
    // character, AND a State Machine state's own `movement.type` can all
    // use it for free, zero special-casing per consumer). `ai._pathT`
    // (normalized [0,1] progress) advances by real speed-in-units/second
    // divided by the path's own real sampled length (cached, recomputed
    // if the path reference changes), not a fixed per-tick t-step -- so
    // Speed genuinely means "units per second" regardless of how many/how
    // far apart a path's own control points are.
    const pathItem = findItemById(ai.pathId);
    if (pathItem && pathItem.kind === 'path' && pathItem.pointIds && pathItem.pointIds.length > 1) {
      if (ai._pathLengthFor !== ai.pathId) {
        let len = 0;
        const SAMPLES = 40;
        let prev = samplePathPosition(pathItem, 0);
        for (let s = 1; s <= SAMPLES; s++) { const cur = samplePathPosition(pathItem, s / SAMPLES); len += cur.sub(prev).length(); prev = cur; }
        ai._pathLength = Math.max(0.01, len);
        ai._pathLengthFor = ai.pathId;
        ai._pathT = ai._pathT || 0;
        ai._pathDir = ai._pathDir || 1;
      }
      const dt_t = ((ai.speed || 2) * dt) / ai._pathLength;
      if (pathItem.loop) {
        ai._pathT = (ai._pathT + dt_t) % 1;
        if (ai._pathT < 0) ai._pathT += 1;
      } else if (ai.pingpong) {
        ai._pathT += dt_t * ai._pathDir;
        if (ai._pathT >= 1) { ai._pathT = 1; ai._pathDir = -1; }
        else if (ai._pathT <= 0) { ai._pathT = 0; ai._pathDir = 1; }
      } else {
        ai._pathT = Math.min(1, ai._pathT + dt_t);
      }
      const target = samplePathPosition(pathItem, ai._pathT);
      pos.set(target.x, target.y, target.z);
    }
  } else if (ai.type === 'flee' && player) {
    const away = pos.sub(player.entity.position);
    away.y = 0;
    const dist = away.length();
    if (dist > 0.1 && dist < ai.radius) {
      const step = away.normalize().scale(Math.min(dist, ai.speed * dt));
      pos.set(pos.x + step.x, pos.y, pos.z + step.z);
    }
  } else if (ai.type === 'faceTarget' && followTargetEntity) {
    const toTarget = followTargetEntity.position.sub(pos);
    if (Math.hypot(toTarget.x, toTarget.z) > 0.05) item.entity.rotationY = Math.atan2(toTarget.x, toTarget.z);
  } else if (ai.type === 'patrolRoute') {
    if (!ai.resolvedWaypointIds) {
      const names = (ai.waypointNames || '').split(',').map((s) => s.trim()).filter(Boolean);
      ai.resolvedWaypointIds = names
        .map((name) => placed.find((p) => p.isWaypoint && p.name === name))
        .filter(Boolean)
        .map((p) => p.id);
      ai.currentWaypointIndex = 0;
      ai.direction = 1;
    }
    const routeIds = ai.resolvedWaypointIds;
    if (routeIds.length > 0) {
      const target = findItemById(routeIds[ai.currentWaypointIndex]);
      if (target) {
        const toTarget = target.entity.position.sub(pos);
        toTarget.y = 0;
        const dist = toTarget.length();
        if (dist > 0.15) {
          const step = toTarget.scale(Math.min(1, (ai.speed * dt) / dist));
          pos.set(pos.x + step.x, pos.y, pos.z + step.z);
        } else if (ai.pingpong) {
          const next = ai.currentWaypointIndex + ai.direction;
          if (next < 0 || next >= routeIds.length) { ai.direction *= -1; ai.currentWaypointIndex += ai.direction; }
          else ai.currentWaypointIndex = next;
        } else {
          ai.currentWaypointIndex += 1;
          if (ai.currentWaypointIndex >= routeIds.length) ai.currentWaypointIndex = ai.loop ? 0 : routeIds.length - 1;
        }
      }
    }
  } else if (ai.type === 'navigateToTarget' && followTargetEntity) {
    navigateToTargetTick(item, ai, pos, followTargetEntity, dt);
  } else if (ai.type === 'orbit') {
    // Wave 7 (Priority D/M): a State Machine state's own `movement` object
    // has no author-facing "base" field in the v1 card UI (unlike ordinary
    // Simple-AI, whose `ai.base` is always set when Orbit/Wander is first
    // chosen via placeItem/Create Animated Enemy) -- lazily anchor to
    // wherever this AI actually is the first time Orbit/Wander runs on it,
    // rather than crashing on a real, found-via-dogfood gap. Harmless no-op
    // for the ordinary Simple-AI path, which already always has `ai.base`.
    if (!ai.base) ai.base = pos.clone();
    ai.angle = (ai.angle || 0) + (ai.speed * dt) / Math.max(0.5, ai.radius);
    pos.set(ai.base.x + Math.cos(ai.angle) * ai.radius, pos.y, ai.base.z + Math.sin(ai.angle) * ai.radius);
  } else if (ai.type === 'investigate') {
    // Wave 9 (Priority B, Sections 35-36): move toward the last heard noise
    // position via direct movement (no new pathfinder, per Section 36) --
    // stops once within 0.5 units, leaving the character facing where the
    // noise came from until a transition (e.g. `timeInStateAtLeast`) moves
    // it on to Search/Patrol. No noise heard yet at all is a harmless no-op
    // (stands still) rather than a crash.
    const target = item._lastHeardNoisePos;
    if (target) {
      const toTarget = target.sub(pos);
      toTarget.y = 0;
      const dist = toTarget.length();
      if (dist > 0.5) {
        const step = toTarget.scale(Math.min(1, (ai.speed * dt) / dist));
        pos.set(pos.x + step.x, pos.y, pos.z + step.z);
        item.entity.rotationY = Math.atan2(toTarget.x, toTarget.z);
      }
    }
  } else if (ai.type === 'wander') {
    if (!ai.base) ai.base = pos.clone();
    ai.wanderTimer = (ai.wanderTimer || 0) - dt;
    if (!ai.wanderTarget || ai.wanderTimer <= 0) {
      const angle = Math.random() * Math.PI * 2;
      const r = Math.random() * ai.radius;
      ai.wanderTarget = new Opus.Vec3(ai.base.x + Math.cos(angle) * r, pos.y, ai.base.z + Math.sin(angle) * r);
      ai.wanderTimer = 1.5 + Math.random() * 2;
    }
    const toTarget = ai.wanderTarget.sub(pos);
    toTarget.y = 0;
    const dist = toTarget.length();
    if (dist > 0.1) {
      const step = toTarget.scale(Math.min(1, (ai.speed * dt) / dist));
      pos.set(pos.x + step.x, pos.y, pos.z + step.z);
    }
  }
  return followTargetEntity;
}
// Enemy ranged attack (Wave 4) -- likewise pulled into its own function so
// a State Machine state's own `attack` sub-object (same field names:
// attackEnabled/attackPrefab/attackRadius/attackCooldown/attackDamage/
// attackSpeed) drives it identically to `ai` itself.
function applyAiAttackStep(item, ai, pos, followTargetEntity, elapsed) {
  if (ai.attackEnabled && ai.attackPrefab && followTargetEntity) {
    const distToTarget = followTargetEntity.position.sub(pos).length();
    if (distToTarget <= (ai.attackRadius || 8)) {
      ai._attackCooldownUntil = ai._attackCooldownUntil || 0;
      if (elapsed >= ai._attackCooldownUntil) {
        ai._attackCooldownUntil = elapsed + (ai.attackCooldown || 1.5);
        const dir = followTargetEntity.position.sub(pos);
        fireProjectile(ai.attackPrefab, pos.clone(), dir, ai.attackSpeed || 12, ai.attackDamage || 10, item.tags && item.tags[0], 3, 0.3, 0, '');
        triggerCharacterAttackAnim(item);
      }
    }
  }
}
// --- AI State Machine (Wave 7, Priority D, Sections 24-32) ---
// Bounded, much smaller than a generic Behavior Tree: `ai.states = [{name,
// movement, attack, animRole, entryActions, transitions: [{condition, to}]}]`,
// `ai.startState`. Transition priority is authored order -- the FIRST valid
// transition in a state's own array wins, checked once per tick before that
// tick's movement/attack run (so a same-tick transition immediately drives
// the NEW state's own movement, not a one-frame-stale old one).
function distanceToPlayerXZ(pos) {
  if (!player) return Infinity;
  const d = pos.sub(player.entity.position);
  d.y = 0;
  return d.length();
}
// Bounded Line Of Sight: a straight ray from `fromPos` to the Player's own
// position, blocked by any SOLID box collider crossing it before the
// Player is reached -- boolean only, no vision cones/perception simulation,
// reusing the exact same `Opus.Physics.rayAABB` primitive `fireHitscan`
// already uses against solids, not a second raycast implementation.
function hasLineOfSightToPlayer(fromPos) {
  if (!player) return false;
  const toTarget = player.entity.position.sub(fromPos);
  const dist = toTarget.length();
  if (dist < 1e-6) return true;
  const dir = toTarget.scale(1 / dist);
  for (const other of placed) {
    if (other.kind !== 'cube' || !other.entity.solid) continue;
    const half = other.entity.scale.scale(0.5);
    const box = new Opus.Physics.AABB(other.entity.position.sub(half), other.entity.position.add(half));
    const t = Opus.Physics.rayAABB(fromPos, dir, box);
    if (t !== null && t < dist) return false;
  }
  return true;
}
// Wave 9 (Priority B, Sections 29-31): real Vision Field -- distance, THEN
// angle inside the authored FOV cone, THEN (if required) LOS, all three in
// order (cheapest check first). Uses `item.entity.forward` -- the entity's
// REAL current orientation (Section 30's own "do not derive a second
// heading model"); for ground AI (no pitch/roll) this is yaw, exactly as
// the spec anticipates.
function aiCanSeePlayer(item, pos) {
  if (!player) return false;
  const perception = (item.entity.ai && item.entity.ai.perception) || defaultAiPerception();
  const toPlayer = player.entity.position.sub(pos);
  toPlayer.y = 0;
  const dist = toPlayer.length();
  if (dist > (perception.visionDistance != null ? perception.visionDistance : 15)) return false;
  if (dist < 1e-6) return true;
  const forward = item.entity.forward;
  const fwdFlat = new Opus.Vec3(forward.x, 0, forward.z);
  const fwdLen = fwdFlat.length();
  if (fwdLen > 1e-6) {
    const cosAngle = fwdFlat.scale(1 / fwdLen).dot(toPlayer.scale(1 / dist));
    const halfFovCos = Math.cos(((perception.fovDegrees != null ? perception.fovDegrees : 100) / 2) * Math.PI / 180);
    if (cosAngle < halfFovCos) return false;
  }
  if (perception.requiresLOS !== false && !hasLineOfSightToPlayer(pos)) return false;
  return true;
}
// Wave 9 (Priority B, Sections 32-35): Noise Events -- pure authored
// gameplay data (position/radius/timestamp), broadcast immediately at emit
// time to every placed AI within BOTH the noise's own radius and that
// listener's own authored Hearing Radius (the tighter of the two bounds).
// No persistent event queue/list to manage -- an instantaneous scan is
// simpler and sufficient for "did anyone just hear this," matching Section
// 33's own "no audio analysis, no ML" framing.
function emitNoiseEvent(position, radius) {
  for (const other of placed) {
    if (other.kind !== 'cube' || !other.entity.ai) continue;
    const perception = other.entity.ai.perception;
    if (!perception || !perception.hearingRadius) continue;
    const dist = other.entity.position.sub(position).length();
    if (dist <= Math.min(radius, perception.hearingRadius)) {
      other._lastHeardNoisePos = position.clone();
      other._lastHeardNoiseAt = simElapsed;
    }
  }
}
function evaluateAiTransitionCondition(cond, item, pos) {
  if (!cond) return false;
  switch (cond.type) {
    case 'distanceToPlayerAtMost': return distanceToPlayerXZ(pos) <= (cond.value || 0);
    case 'distanceToPlayerAtLeast': return distanceToPlayerXZ(pos) >= (cond.value || 0);
    case 'lineOfSightToPlayer': return hasLineOfSightToPlayer(pos);
    case 'noLineOfSightToPlayer': return !hasLineOfSightToPlayer(pos);
    case 'healthAtMost': ensureObjectHealthInit(item); return item.health.current <= (cond.value || 0);
    case 'timeInStateAtLeast': return (simElapsed - (item._aiStateEnteredAt || 0)) >= (cond.value || 0);
    case 'canSeePlayer': return aiCanSeePlayer(item, pos);
    case 'cannotSeePlayer': return !aiCanSeePlayer(item, pos);
    case 'heardNoiseRecently': return item._lastHeardNoiseAt != null && (simElapsed - item._lastHeardNoiseAt) <= (cond.value || 3);
    default: return false;
  }
}
function aiStateDef(ai, name) {
  return (ai.states || []).find((s) => s.name === name);
}
function enterAiState(item, ai, stateName) {
  const state = aiStateDef(ai, stateName);
  if (!state) return;
  ai._currentState = stateName;
  item._aiStateEnteredAt = simElapsed;
  if (state.animRole && item.characterAnimSync && item.entity.skin) setCharacterLocomotionState(item, state.animRole);
  for (const action of (state.entryActions || [])) executeAction(action.action, action.params, item);
}
// The one per-frame entry point for a State Machine character -- checks
// transitions (authored order, first valid wins), THEN runs the resulting
// (possibly just-switched) state's own movement/attack through the exact
// same shared steps every Simple-AI type already uses. Returns the resolved
// follow-target entity so the caller's animation-locomotion logic can stay
// uniform if it ever needs to (currently unused there -- State Machine
// characters animate per-state, not from movement delta).
function tickAiStateMachine(item, ai, pos, dt, elapsed) {
  if (!ai.states || ai.states.length === 0) return null;
  if (!ai._currentState || !aiStateDef(ai, ai._currentState)) enterAiState(item, ai, ai.startState || ai.states[0].name);
  let state = aiStateDef(ai, ai._currentState);
  if (!state) return null;
  for (const tr of (state.transitions || [])) {
    if (evaluateAiTransitionCondition(tr.condition, item, pos)) {
      if (tr.to !== ai._currentState) enterAiState(item, ai, tr.to);
      break; // authored-order, first-valid-wins -- never evaluate a later transition once one has matched
    }
  }
  state = aiStateDef(ai, ai._currentState); // re-read AFTER a possible same-tick transition
  if (!state) return null;
  const movementCfg = state.movement || { type: '' };
  const followTargetEntity = applyAiMovementStep(item, movementCfg, pos, dt, elapsed);
  if (state.attack) applyAiAttackStep(item, state.attack, pos, followTargetEntity, elapsed);
  return followTargetEntity;
}

function spawnPlayer(position) {
  const type = (currentPlayerSettings && PLAYER_CONTROLLERS[currentPlayerSettings.controllerType]) ? currentPlayerSettings.controllerType : 'hovercraft';
  PLAYER_CONTROLLERS[type].spawn(position);
  footstepTimer = 0;
  movementNoiseTimer = 0;
  // See VOID_FALL_MARGIN's own comment: recomputed every spawn/respawn so a
  // multi-level game's void floor always tracks THAT level's own spawn
  // height, not level 1's.
  voidFallY = position.y - VOID_FALL_MARGIN;
}
function despawnPlayer() {
  if (!player) return;
  PLAYER_CONTROLLERS[player.controllerType].despawn();
}
// Wave 6 (Priority L): the one missing piece a scripted camera sequence
// needed to actually BE a cutscene rather than "the camera cuts away while
// the player silently keeps walking around off-screen" -- Change Camera +
// Delay (both already existed, Wave 4/5) can already sequence a multi-shot
// camera pan today, but nothing could stop the player CONTROLLER from
// still processing input and moving during it. Deliberately bounded: this
// freezes CONTROLLER-driven movement only (gravity/input/physics), not the
// whole simulation the way Dialogue's app.pause() does -- AI, animations,
// tweens, and the camera itself all keep running, exactly what a cutscene
// needs (everything else in the world still plays out; only the player
// stops moving). Not a full Cutscene/Sequence track editor -- see the
// CHANGELOG entry for this priority's own gate reasoning on why that
// larger feature wasn't built.
let playerFrozen = false;
// Returns the player's position before this frame's movement, for swept
// trigger checks (or null if no player is spawned).
function updatePlayerController(dt, elapsed) {
  if (!player) { teardownPlayerVisual(); return null; }
  if (playerFrozen) {
    syncPlayerVisual(); // position may still change during a frozen cutscene (Change Camera doesn't move the player, but stay correct regardless)
    return player.entity.position.clone(); // no movement this frame -- "previous position" for swept checks is just the current one
  }
  const result = PLAYER_CONTROLLERS[player.controllerType].update(dt, elapsed);
  // Void-fall catch (logic-check pass) -- see VOID_FALL_MARGIN's own comment.
  // One check, after every controller's own update, regardless of
  // controllerType: a hovercraft never drops in Y so this never fires for
  // it, but a jump-enabled topdown/third-person/first-person controller
  // that clears the last floor collider gets caught and returned to the
  // last checkpoint (or spawn) instead of free-falling forever.
  if (player && player.entity.position.y < voidFallY) {
    const target = window.__checkpoint ? window.__checkpoint.clone() : computeSpawnPoint();
    player.entity.position = target;
    player.velocity = new Opus.Vec3();
    voidFallY = target.y - VOID_FALL_MARGIN;
  }
  // Wave 6B (Priority A): sync THIS frame's body position/rotation to the
  // visual, then drive locomotion off THIS frame's freshly-computed
  // grounded/velocity state -- called from the same dispatcher every
  // controller's own update already funnels through, so there's no one-
  // frame lag reading last frame's state (the risk of instead syncing from
  // a separately-registered app.onUpdate callback, which runs in
  // registration order, not necessarily after this dispatcher).
  syncPlayerVisual();
  drivePlayerVisualLocomotion();
  syncPlayerEquipmentVisuals();
  syncHeldObjectPosition();
  driveFootstepAudio(dt);
  driveMovementNoise(dt);
  // Wave 7 (Priority B): the Player's own visual entity is not a `placed`
  // item, so it needs its own explicit call here rather than falling under
  // the `placed`-loop version above -- same shared `tickAnimationEvents`,
  // no separate code path. `contextItem` is `null` (there is no Player
  // "item" the way an AI character has one); every action reachable from an
  // animation event in this dogfood (`fireWeapon`) reads global player
  // state directly and doesn't need one.
  if (playerVisualEntity) tickAnimationEvents(playerVisualEntity, currentPlayerSettings.visual && currentPlayerSettings.visual.assetId, null);
  return result;
}

// --- Terrain Sculpting (Wave 4) ---
// A gesture-level brush editor over the engine's new opts.heightEdits layer
// (see engine/src/19-terrain.js). Deliberately NOT a separate rendering/
// physics path -- every sculpt stroke just mutates the delta grid and
// remove+recreates the terrain through the exact same app.removeTerrain /
// app.createTerrain pair the inspector's own Seed/Size/Radius regenerate-on-
// edit already used and proved (see the terrain inspector below), so
// rendering, `sampleHeight`/`sampleNormal` (physics/AI/spawn), and picking
// all read the identical edited heightfield with no separate code path to
// drift out of sync.
let sculptMode = false;
const sculptSettings = { brush: 'raise', radius: 2.5, strength: 0.5 };
let sculptDragState = null; // { item, strokeStarted (pushUndo gate), flattenHeight }

// Shared by the sculpt brush and the terrain inspector's own Seed/Size/
// Radius fields -- one place that knows how to swap a terrain's live handle
// for a freshly-regenerated one from patched options.
function regenerateTerrain(item, patch) {
  app.removeTerrain(item.handle);
  if (patch) Object.assign(item.options, patch);
  item.handle = app.createTerrain(item.options);
  syncTerrainLayerTextures(item);
  const marker = selectionMarkers.get(item);
  if (marker) marker.position.set(item.options.position.x, 0.02, item.options.position.z);
}

function ensureHeightEdits(item) {
  const opts = item.options;
  const segs = opts.segments;
  const verts = segs + 1;
  if (!opts.heightEdits || opts.heightEdits.segments !== segs) {
    opts.heightEdits = { segments: segs, deltas: new Array(verts * verts).fill(0) };
  }
  return opts.heightEdits;
}

function smoothFalloff(distRatio) {
  // 1 at the brush center, 0 at the edge, smoothstep in between -- a hard
  // cutoff would leave a visible ring at the brush radius.
  const t = Math.max(0, Math.min(1, 1 - distRatio));
  return t * t * (3 - 2 * t);
}

// Applies one brush "dab" (called on pointerdown and every pointermove of
// an active stroke) at `worldPoint`, then regenerates the terrain so the
// stroke is visible live. `first` marks the very first dab of a stroke --
// used by Flatten to capture its one reference height for the whole stroke.
function applySculptBrush(item, worldPoint, first) {
  const opts = item.options;
  const edits = ensureHeightEdits(item);
  const { deltas, segments: segs } = edits;
  const verts = segs + 1;
  const size = opts.size;
  const lx = worldPoint.x - opts.position.x;
  const lz = worldPoint.z - opts.position.z;
  const { brush, radius, strength } = sculptSettings;
  if (brush === 'flatten' && first) sculptDragState.flattenHeight = item.handle.sampleHeight(worldPoint.x, worldPoint.z);
  for (let iz = 0; iz <= segs; iz++) {
    for (let ix = 0; ix <= segs; ix++) {
      const vx = (ix / segs - 0.5) * size;
      const vz = (iz / segs - 0.5) * size;
      const dist = Math.hypot(vx - lx, vz - lz);
      if (dist > radius) continue;
      const falloff = smoothFalloff(dist / radius);
      const idx = iz * verts + ix;
      if (brush === 'raise') deltas[idx] += strength * falloff * 0.12;
      else if (brush === 'lower') deltas[idx] -= strength * falloff * 0.12;
      else if (brush === 'flatten') {
        const cur = item.handle.sampleHeight(vx + opts.position.x, vz + opts.position.z);
        deltas[idx] += (sculptDragState.flattenHeight - cur) * falloff * strength * 0.5;
      } else if (brush === 'smooth') {
        const neighbors = [[ix - 1, iz], [ix + 1, iz], [ix, iz - 1], [ix, iz + 1]].filter(([nx, nz]) => nx >= 0 && nx <= segs && nz >= 0 && nz <= segs);
        let sum = 0;
        for (const [nx, nz] of neighbors) {
          const nwx = (nx / segs - 0.5) * size + opts.position.x;
          const nwz = (nz / segs - 0.5) * size + opts.position.z;
          sum += item.handle.sampleHeight(nwx, nwz);
        }
        const avg = sum / neighbors.length;
        const cur = item.handle.sampleHeight(vx + opts.position.x, vz + opts.position.z);
        deltas[idx] += (avg - cur) * falloff * strength * 0.5;
      }
    }
  }
  regenerateTerrain(item);
}

// Wave 6 (Priority G): Terrain Painting -- a brush editor over
// opts.paintEdits (see engine/src/19-terrain.js's own comment on the color
// blend), built as a direct sibling of the sculpt brush above -- same
// pointerdown/pointermove wiring, same falloff, same regenerateTerrain
// call to make a stroke visible live, so an author who already knows how
// to sculpt already knows how to paint.
let paintMode = false;
const PAINT_MAX_LAYERS = 3;
const paintSettings = { radius: 3, strength: 0.6, activeLayer: 0, automask: 'off' }; // automask: 'off' | 'flat' | 'steep'
let paintDragState = null; // { item }

// --- Wave 9C (Priority A, Sections 10-13): Scatter Brush -- Paint/Erase,
// the exact same Pointer Events gesture shape Sculpt/Terrain-Paint above
// already established (mutually exclusive with them and with each other;
// checked first in pointerdown, same reasoning). Configures the EXISTING
// `scatterFillRegion`/`removeItemFromScene` machinery -- no second
// placement or removal path.
let scatterBrushMode = null; // null | 'paint' | 'erase'
let scatterBrushDragState = null; // { layer, dabIndex, lastPoint, placedCount, removedCount }
function scatterLayerSourcesConfig(layer) {
  return (layer.sources || []).filter((s) => s.prefabName).map((s) => ({ type: 'prefab', ref: s.prefabName, weight: s.weight > 0 ? s.weight : 1 }));
}
// One "dab" = one bounded circular scatterFillRegion call centered on the
// pointer's current world position. `dabIndex` (incremented once per dab,
// never reset mid-gesture) folds into the seed so a repeated identical
// gesture (same layer settings, same starting seed, same dab sequence)
// picks the same sources/positions -- Section 8's own "reproducible where
// the algorithm permits."  Count-per-dab is deliberately small and
// area-proportional (not the layer's whole target density at once) so a
// slow drag doesn't way overshoot Density relative to a fast one covering
// the same ground in fewer dabs -- a bounded, honest approximation, not a
// true continuous-density brush.
function applyScatterBrushPaint(layer, worldPoint) {
  const sources = scatterLayerSourcesConfig(layer);
  if (sources.length === 0) { showStatus('Add at least one Source to this Scatter Layer first'); return 0; }
  const terrainItem = placed.find((p) => p.kind === 'terrain');
  const area = Math.PI * layer.brushRadius * layer.brushRadius;
  const count = Math.max(1, Math.round(area * layer.density * 0.12));
  const config = {
    sources, region: 'circle', centerX: worldPoint.x, centerZ: worldPoint.z, radius: layer.brushRadius,
    count, minSpacing: layer.minSpacing, seed: (layer.seed + scatterBrushDragState.dabIndex) >>> 0,
    scaleMin: layer.scaleMin, scaleMax: layer.scaleMax, maxSlopeDegrees: layer.maxSlope,
    randomYRotation: layer.randomYaw, terrainConform: !!terrainItem, terrainItemId: terrainItem ? terrainItem.id : undefined,
    layerId: layer.id,
  };
  scatterBrushDragState.dabIndex++;
  const result = scatterFillRegion(config);
  return result.placedCount;
}
// Erase only ever removes THIS layer's own owned objects (Section 12's own
// explicit "do not erase manual objects/another Layer/terrain/triggers/
// gameplay objects/Paths") -- filtering strictly on `scatterLayerId ===
// layer.id` makes every one of those exclusions automatic, not a list of
// special cases to maintain.
function applyScatterBrushErase(layer, worldPoint) {
  const toRemove = placed.filter((p) => p.scatterLayerId === layer.id && p.entity && Math.hypot(p.entity.position.x - worldPoint.x, p.entity.position.z - worldPoint.z) <= layer.brushRadius);
  for (const it of toRemove) removeItemFromScene(it);
  return toRemove.length;
}
// Editor-only brush-radius ring (Section 13/26) -- a thin flattened
// cylinder-ish marker reusing the existing cube mesh scaled flat, the same
// "no new renderer, a simple marker is enough" approach Waypoint
// connection lines already established. Hidden during Play (never even
// created there, since the brush itself is edit-only).
let scatterBrushMarker = null;
function syncScatterBrushMarker(worldPoint, radius, active) {
  if (!active || !worldPoint) { if (scatterBrushMarker) scatterBrushMarker.visible = false; return; }
  if (!scatterBrushMarker) scatterBrushMarker = app.addEntity({ mesh: cubeMesh, color: scatterBrushMode === 'erase' ? [0.85, 0.35, 0.3] : [0.4, 0.85, 0.55], position: worldPoint, scale: new Opus.Vec3(radius * 2, 0.02, radius * 2) });
  scatterBrushMarker.position.set(worldPoint.x, worldPoint.y + 0.05, worldPoint.z);
  scatterBrushMarker.scale.set(radius * 2, 0.02, radius * 2);
  scatterBrushMarker.visible = true;
}

function ensurePaintEdits(item) {
  const opts = item.options;
  const segs = opts.segments;
  const verts = segs + 1;
  if (!opts.paintEdits || opts.paintEdits.segments !== segs) {
    opts.paintEdits = {
      segments: segs,
      layers: [{ name: 'Dirt', color: [0.42, 0.32, 0.2] }, { name: 'Rock', color: [0.45, 0.45, 0.47] }],
      weights: new Array(2 * verts * verts).fill(0),
    };
  }
  return opts.paintEdits;
}
// Wave 6B (Priority D): resolves each of this terrain's up to 3 paint
// layers' own optional `textureAssetId` into a real GPU texture handle (via
// the SAME lazy `getTextureHandle` every other texture picker in this editor
// already uses) and assigns the resulting array straight onto the live
// terrain handle's `layerTextures` accessor. Called after every `handle =
// app.createTerrain(...)` (initial placement, regenerateTerrain, duplicate,
// load) since a fresh handle always starts with `layerTextures` reset to
// `[null, null, null]` engine-side. A layer whose image hasn't finished
// decoding yet registers a pending callback (the same `pendingCallbacks`
// convention `applyTextureToEntity` already established) that re-syncs once
// the image is ready, rather than silently leaving that layer untextured
// forever.
function syncTerrainLayerTextures(item) {
  const paintEdits = item.options.paintEdits;
  const layers = paintEdits ? paintEdits.layers : [];
  const textures = [null, null, null];
  for (let li = 0; li < Math.min(layers.length, 3); li++) {
    const assetId = layers[li].textureAssetId;
    if (!assetId) continue;
    const asset = findTextureAssetById(assetId);
    if (!asset) continue;
    const handle = getTextureHandle(asset);
    if (handle) {
      textures[li] = handle;
    } else {
      (asset.pendingCallbacks = asset.pendingCallbacks || []).push(() => { if (placed.includes(item)) syncTerrainLayerTextures(item); });
    }
  }
  item.handle.layerTextures = textures;
}
function addPaintLayer(item) {
  const edits = ensurePaintEdits(item);
  if (edits.layers.length >= PAINT_MAX_LAYERS) return;
  const verts = edits.segments + 1;
  const cellCount = verts * verts;
  const palette = [[0.42, 0.32, 0.2], [0.45, 0.45, 0.47], [0.85, 0.8, 0.55]];
  edits.layers.push({ name: `Layer ${edits.layers.length + 1}`, color: palette[edits.layers.length % palette.length] });
  // Grow `weights` to fit the new layer -- new layer starts at 0 everywhere,
  // existing layers' weights are untouched (a straight array-length
  // extension, not a reshuffle, since layers are already laid out
  // layer-major with each layer's own contiguous cellCount-sized block).
  for (let i = 0; i < cellCount; i++) edits.weights.push(0);
}
// Applies one paint "dab" at `worldPoint` for the currently active layer.
// Weight is added to the target layer and the OTHER layers at that same
// vertex are proportionally scaled down to keep the total at or below 1 --
// real "painting over" behavior, not each layer independently able to
// exceed full opacity.
function applyPaintBrush(item, worldPoint) {
  const opts = item.options;
  const edits = ensurePaintEdits(item);
  const { weights, segments: segs, layers } = edits;
  const verts = segs + 1;
  const cellCount = verts * verts;
  const size = opts.size;
  const lx = worldPoint.x - opts.position.x;
  const lz = worldPoint.z - opts.position.z;
  const { radius, strength, activeLayer, automask } = paintSettings;
  const targetLayer = Math.min(activeLayer, layers.length - 1);
  if (targetLayer < 0) return;
  for (let iz = 0; iz <= segs; iz++) {
    for (let ix = 0; ix <= segs; ix++) {
      const vx = (ix / segs - 0.5) * size;
      const vz = (iz / segs - 0.5) * size;
      const dist = Math.hypot(vx - lx, vz - lz);
      if (dist > radius) continue;
      const falloff = smoothFalloff(dist / radius);
      const idx = iz * verts + ix;
      let maskFactor = 1;
      if (automask !== 'off') {
        // Reads the terrain's OWN already-live handle for slope, the same
        // way the sculpt Flatten/Smooth brushes above already sample
        // `item.handle.sampleHeight` -- one source of truth for "what does
        // this terrain's surface currently look like", not a second normal
        // computation duplicated here.
        const wx = vx + opts.position.x, wz = vz + opts.position.z;
        const normal = item.handle.sampleNormal(wx, wz);
        const slope = 1 - normal.y;
        maskFactor = automask === 'flat' ? Math.max(0, 1 - slope * 2) : Math.min(1, slope * 2);
      }
      const add = strength * falloff * maskFactor * 0.15;
      if (add <= 0) continue;
      const targetIdx = targetLayer * cellCount + idx;
      const newTarget = Math.min(1, (weights[targetIdx] || 0) + add);
      weights[targetIdx] = newTarget;
      const remaining = Math.max(0, 1 - newTarget);
      let othersSum = 0;
      for (let li = 0; li < layers.length; li++) { if (li !== targetLayer) othersSum += weights[li * cellCount + idx] || 0; }
      if (othersSum > remaining && othersSum > 0) {
        const scale = remaining / othersSum;
        for (let li = 0; li < layers.length; li++) { if (li !== targetLayer) weights[li * cellCount + idx] = (weights[li * cellCount + idx] || 0) * scale; }
      }
    }
  }
  regenerateTerrain(item);
}

// With more than one island, physics must use whichever terrain the craft
// is actually near, not always the first one placed — otherwise collision/
// hover on the second island would be checked against the first island's
// (far away) heightfield. No position -> first terrain (used for spawn).
function currentTerrainItem(nearPosition) {
  const terrains = placed.filter((item) => item.kind === 'terrain');
  if (terrains.length === 0) return null;
  if (!nearPosition || terrains.length === 1) return terrains[0];
  let closest = terrains[0];
  let closestDist = Infinity;
  for (const item of terrains) {
    const d = Math.hypot(nearPosition.x - item.handle.position.x, nearPosition.z - item.handle.position.z);
    if (d < closestDist) { closestDist = d; closest = item; }
  }
  return closest;
}
function currentWaterItem() {
  return placed.find((item) => item.kind === 'water');
}

const SPAWN_CLEARANCE = 0.55;

function findDefaultSpawnPointItem() {
  return placed.find((p) => p.isSpawnPoint && p.isDefaultSpawn) || placed.find((p) => p.isSpawnPoint) || null;
}

// Highest solid cube's top surface whose XZ footprint (axis-aligned --
// consistent with how every other footprint-based query in this editor,
// e.g. Trigger Volume radius, already treats rotation as out of scope)
// contains (x, z). Returns null if nothing solid covers that point at all.
// This is what API-FRICTION #51 flagged as missing: a Start Platform used
// as a level's actual ground previously had to be hand-positioned so its
// top happened to sit at the terrain-less default of world Y=0.
function findSolidGroundTopAt(x, z) {
  let best = null;
  for (const item of placed) {
    if (item.kind !== 'cube' || !item.entity.solid) continue;
    const pos = item.entity.position, scale = item.entity.scale;
    const halfX = scale.x / 2, halfZ = scale.z / 2;
    if (x < pos.x - halfX || x > pos.x + halfX || z < pos.z - halfZ || z > pos.z + halfZ) continue;
    const top = pos.y + scale.y / 2;
    if (best === null || top > best) best = top;
  }
  return best;
}

// Wave 4: generalized in priority order rather than layering more special
// cases onto a function that used to assume every game starts on an island
// (see API-FRICTION.md for the full before/after). The generalized Player
// system owns spawn behavior end to end now:
//   1. an explicit, author-placed default Spawn Point -- always wins outright
//   2. a solid authored platform/ground under the fallback XZ
//   3. terrain-derived height at that XZ (the original sole behavior)
//   4. a safe fixed default, for a level with no Spawn Point/solid/terrain at all
function computeSpawnPoint() {
  const spawnPointItem = findDefaultSpawnPointItem();
  if (spawnPointItem) return spawnPointItem.entity.position.clone().add(new Opus.Vec3(0, SPAWN_CLEARANCE, 0));

  const terrainItem = currentTerrainItem();
  const waterItem = currentWaterItem();
  // Sample at the terrain's own center, not world (0,0) — with more than one
  // island, (0,0) may not be on any terrain at all (e.g. open water between them).
  const spawnX = terrainItem ? terrainItem.handle.position.x : 0;
  const spawnZ = terrainItem ? terrainItem.handle.position.z : 0;

  const solidTop = findSolidGroundTopAt(spawnX, spawnZ);
  if (solidTop !== null) {
    const waterY = waterItem ? waterItem.handle.position.y : -Infinity;
    return new Opus.Vec3(spawnX, Math.max(solidTop, waterY) + SPAWN_CLEARANCE, spawnZ);
  }

  if (terrainItem) {
    const groundY = terrainItem.handle.sampleHeight(spawnX, spawnZ);
    const waterY = waterItem ? waterItem.handle.position.y : -Infinity;
    return new Opus.Vec3(spawnX, Math.max(groundY, waterY) + SPAWN_CLEARANCE, spawnZ);
  }

  if (waterItem) return new Opus.Vec3(spawnX, waterItem.handle.position.y + SPAWN_CLEARANCE, spawnZ);

  return new Opus.Vec3(0, 1, 0);
}

function spawnHovercraftController(position) {
  craft = app.addEntity({ mesh: cubeMesh, color: [0.08, 0.42, 0.85], position: position.clone(), scale: new Opus.Vec3(1.25, 0.28, 1.9) });
  craftParts = [];
  const addPart = (color, scale, offset) => {
    const entity = app.addEntity({ mesh: cubeMesh, color, position: position.clone(), scale });
    craftParts.push({ entity, offset });
  };
  addPart([0.35, 0.75, 1], new Opus.Vec3(0.72, 0.28, 0.78), new Opus.Vec3(0, 0.32, -0.22)); // cockpit
  addPart([0.08, 0.12, 0.18], new Opus.Vec3(0.28, 0.2, 1.65), new Opus.Vec3(-0.78, -0.12, 0)); // pad
  addPart([0.08, 0.12, 0.18], new Opus.Vec3(0.28, 0.2, 1.65), new Opus.Vec3(0.78, -0.12, 0)); // pad
  addPart([1, 0.3, 0.08], new Opus.Vec3(0.24, 0.24, 0.38), new Opus.Vec3(-0.42, 0.12, -1.02)); // thruster
  addPart([1, 0.3, 0.08], new Opus.Vec3(0.24, 0.24, 0.38), new Opus.Vec3(0.42, 0.12, -1.02)); // thruster
  addPart([0.8, 0.9, 1], new Opus.Vec3(0.75, 0.08, 0.22), new Opus.Vec3(0, 0.02, 1.08)); // stabilizer
  addPart([0.38, 0.24, 0.12], new Opus.Vec3(0.72, 0.08, 0.55), new Opus.Vec3(0, 0.34, 0.62)); // cargo deck

  craftVelocity = new Opus.Vec3();
  craftSteering = 0;
  craftBoostActive = 0;
  craftBoostCooldown = 0;

  craftExhaust = app.createEmitter({ position: position.clone(), rate: 10, life: [0.25, 0.65], riseSpeed: [0.1, 0.4], spread: 0.32, size: [0.06, 0.16], color: [0.3, 0.65, 1], gravity: -0.1, maxParticles: 90 });
  craftSpray = app.createEmitter({ position: position.clone(), rate: 0, life: [0.35, 0.75], riseSpeed: [0.6, 1.3], spread: 0.8, size: [0.08, 0.2], color: [0.8, 0.95, 1], gravity: -0.7, maxParticles: 90 });
  craftFoam = app.createEmitter({ position: position.clone(), rate: 0, life: [0.25, 0.5], riseSpeed: [0.03, 0.12], spread: 1.15, size: [0.12, 0.24], color: [0.94, 1, 1], gravity: 0, maxParticles: 70 });

  app.camera.setTarget(craft);
  app.camera.setChaseOptions({ distance: 7.6, height: 3.2, pitch: 0.2, lerpSpeed: 6.5, rotationLerpSpeed: 8.5, lookAhead: 1.2 });
  app.camera.setMode('chase');

  app.audio.startEngineHum();

  if (isTouchDevice) {
    document.getElementById('touch-controls').classList.add('visible');
  } else {
    const controlsHintEl = document.getElementById('controls-hint');
    controlsHintEl.classList.add('visible');
    clearTimeout(controlsHintEl._hideTimer);
    controlsHintEl._hideTimer = setTimeout(() => controlsHintEl.classList.remove('visible'), 5000);
  }

  player = {
    controllerType: 'hovercraft',
    entity: craft,
    radius: 0.55,
    get velocity() { return craftVelocity; },
    set velocity(v) { craftVelocity = v; },
  };
}

function despawnHovercraftController() {
  if (!craft) return;
  app.scene.remove(craft);
  for (const part of craftParts) app.scene.remove(part.entity);
  craftParts = [];
  app.removeEmitter(craftExhaust);
  app.removeEmitter(craftSpray);
  app.removeEmitter(craftFoam);
  craft = null;
  craftExhaust = craftSpray = craftFoam = null;
  app.camera.setTarget(null);
  app.camera.setMode('orbit');
  app.audio.stopEngineHum();
  document.getElementById('touch-controls').classList.remove('visible');
  player = null;
}

function updateCraftParts() {
  const c = Math.cos(craft.rotationY);
  const s = Math.sin(craft.rotationY);
  for (const item of craftParts) {
    const offset = item.offset;
    item.entity.position.set(
      craft.position.x + offset.x * c + offset.z * s,
      craft.position.y + offset.y,
      craft.position.z - offset.x * s + offset.z * c
    );
    item.entity.rotationY = craft.rotationY;
  }
}

// Returns the craft's position before this frame's movement, for swept
// trigger checks. Movement/collision/hover formulas match the original
// Delivery Run demo exactly.
function updateHovercraftController(dt, elapsed) {
  if (!craft) return null;
  const input = app.input;

  // Input Actions (Wave 5, Priority D): Move Forward/Back/Left/Right and
  // Jump (here, Boost) now go through the rebindable map, defaulting to
  // the exact keys this controller always hardcoded -- Arrow keys stay a
  // permanent secondary binding alongside whatever the primary is rebound
  // to, so a player who's used to arrows never loses them.
  if ([effectiveInputMap.moveForward, 'ArrowUp', effectiveInputMap.moveBack, 'ArrowDown', effectiveInputMap.moveLeft, 'ArrowLeft', effectiveInputMap.moveRight, 'ArrowRight', effectiveInputMap.jump].some((code) => input.isDown(code))) {
    document.getElementById('controls-hint').classList.remove('visible');
  }

  const throttle = (input.isDown(effectiveInputMap.moveForward) || input.isDown('ArrowUp') ? 1 : 0) - (input.isDown(effectiveInputMap.moveBack) || input.isDown('ArrowDown') ? 0.55 : 0);
  const steerInput = (input.isDown(effectiveInputMap.moveLeft) || input.isDown('ArrowLeft') ? 1 : 0) - (input.isDown(effectiveInputMap.moveRight) || input.isDown('ArrowRight') ? 1 : 0);
  const tapForward = input.wasPressed(effectiveInputMap.moveForward) || input.wasPressed('ArrowUp');
  const tapReverse = input.wasPressed(effectiveInputMap.moveBack) || input.wasPressed('ArrowDown');
  const tapLeft = input.wasPressed(effectiveInputMap.moveLeft) || input.wasPressed('ArrowLeft');
  const tapRight = input.wasPressed(effectiveInputMap.moveRight) || input.wasPressed('ArrowRight');

  craftSteering += (steerInput * 1.8 - craftSteering) * Math.min(1, dt * 5);
  if (tapLeft) craftSteering += 0.55;
  if (tapRight) craftSteering -= 0.55;
  const speedRatio = Math.min(1, craftVelocity.length() / 16);
  craft.rotationY += craftSteering * (0.35 + speedRatio * 0.85) * dt;

  if (input.wasPressed(effectiveInputMap.jump) && craftBoostCooldown <= 0) {
    craftBoostActive = 0.8;
    craftBoostCooldown = 4;
    craftVelocity = craftVelocity.add(new Opus.Vec3(Math.sin(craft.rotationY), 0, Math.cos(craft.rotationY)).scale(6));
    app.audio.playBlip({ frequency: 220, duration: 0.2, type: 'sawtooth' });
  }
  craftBoostActive = Math.max(0, craftBoostActive - dt);
  craftBoostCooldown = Math.max(0, craftBoostCooldown - dt);

  const forward = new Opus.Vec3(Math.sin(craft.rotationY), 0, Math.cos(craft.rotationY));
  const right = new Opus.Vec3(Math.cos(craft.rotationY), 0, -Math.sin(craft.rotationY));
  const acceleration = throttle * 13 + (craftBoostActive > 0 ? 9 : 0);
  craftVelocity = craftVelocity.add(forward.scale(acceleration * dt));
  if (tapForward) craftVelocity = craftVelocity.add(forward.scale(1.3));
  if (tapReverse) craftVelocity = craftVelocity.sub(forward.scale(0.8));
  const lateral = craftVelocity.dot(right);
  craftVelocity = craftVelocity.sub(right.scale(lateral * Math.min(1, dt * 2.8)));
  craftVelocity = craftVelocity.scale(Math.exp(-0.55 * dt));
  const cap = craftBoostActive > 0 ? 24 : 16;
  if (craftVelocity.length() > cap) craftVelocity = craftVelocity.scale(cap / craftVelocity.length());

  const previousPosition = craft.position.clone();
  craft.position = craft.position.add(craftVelocity.scale(dt));

  const terrainItem = currentTerrainItem(craft.position);
  const waterItem = currentWaterItem();

  if (terrainItem) {
    const collision = Opus.Physics.resolveTerrainCollision(craft.position, craftVelocity, 0.55, terrainItem.options);
    if (collision.collided) {
      craft.position = collision.correctedPosition;
      craftVelocity = collision.correctedVelocity;
    }
  }
  // Solid objects (opt-in per item, most cubes stay pass-through -- crates/
  // hazards/triggers are meant to be driven into) physically block the
  // craft, horizontally only, same XZ-only reasoning as
  // Physics.resolveBoxCollision itself. An invisible solid object doesn't
  // block -- this is deliberate, not an oversight: it means Show/Hide
  // Object doubles as a real door mechanic (hide it to open it) with no
  // separate "unlock" action needed.
  for (const item of placed) {
    if (item.kind !== 'cube' || !item.entity.solid || !item.entity.visible) continue;
    const solidCollision = resolveItemColliderCollision(craft.position, craftVelocity, 0.55, item);
    if (solidCollision.collided) {
      craft.position = solidCollision.correctedPosition;
      craftVelocity = solidCollision.correctedVelocity;
    }
  }
  const boundary = Opus.Physics.applyMapBoundary(craft.position, craftVelocity, 0.55, MAP_BOUNDARY);
  craft.position = boundary.correctedPosition;
  craftVelocity = boundary.correctedVelocity;
  if (boundary.warning) showToast('MAP EDGE — TURN INWARD');

  const terrainHeight = terrainItem ? terrainItem.handle.sampleHeight(craft.position.x, craft.position.z) : 0;
  const waterHeight = waterItem ? waterItem.handle.sampleHeight(craft.position.x, craft.position.z, elapsed) : -Infinity;
  let hoverTarget;
  if (waterItem) {
    const shore = Math.max(0, Math.min(1, terrainHeight - waterHeight + 0.5));
    const blend = shore * shore * (3 - 2 * shore);
    const surface = waterHeight + (terrainHeight - waterHeight) * blend;
    hoverTarget = surface + 0.55 + Math.sin(elapsed * 4.2) * 0.035;
  } else {
    hoverTarget = terrainHeight + 0.55;
  }
  craft.position.y += (hoverTarget - craft.position.y) * Math.min(1, dt * 8);
  updateCraftParts();

  const speed = craftVelocity.length();
  app.audio.updateEngineHum(speed / cap, 0.08 + Math.abs(throttle) * 0.3);
  const rear = craft.position.sub(forward.scale(1.1));
  craftExhaust.position = new Opus.Vec3(rear.x, rear.y + 0.05, rear.z);
  craftExhaust.rate = 8 + Math.abs(throttle) * 42 + (craftBoostActive > 0 ? 55 : 0);
  const overWater = !!waterItem && terrainHeight < waterHeight + 0.15;
  craftSpray.position = craft.position.clone();
  craftFoam.position = craft.position.clone();
  craftSpray.rate = overWater ? speed * 2.5 : 0;
  craftFoam.rate = overWater && speed > 2 ? 18 : 0;

  return previousPosition;
}

// --- Top-down player controller ---
// Direct WASD/arrow/touch movement on the XZ plane (no steering, no hover) --
// same terrain/water lookup and solid-collision primitives as the
// hovercraft, just simpler integration since there's no lateral drift to
// resist. Reuses the same touch buttons (they drive KeyW/A/S/D key state,
// which this reads exactly like a real keyboard would).
let topdownEntity = null;
let topdownVelocity = null;

function spawnTopDownController(position) {
  const settings = currentPlayerSettings;
  topdownEntity = app.addEntity({ mesh: cubeMesh, color: [0.85, 0.35, 0.2], position: position.clone(), scale: new Opus.Vec3(0.7, 0.7, 0.7) });
  topdownVelocity = new Opus.Vec3();

  app.camera.setTarget(topdownEntity);
  app.camera.setChaseOptions({ distance: 9, height: 13, pitch: 1.35, lerpSpeed: 7, rotationLerpSpeed: 8, lookAhead: 0 });
  app.camera.setMode('chase');

  if (isTouchDevice) document.getElementById('touch-controls').classList.add('visible');

  player = {
    controllerType: 'topdown',
    entity: topdownEntity,
    radius: settings.collisionRadius || 0.5,
    get velocity() { return topdownVelocity; },
    set velocity(v) { topdownVelocity = v; },
  };
}

function despawnTopDownController() {
  if (!topdownEntity) return;
  app.scene.remove(topdownEntity);
  topdownEntity = null;
  topdownVelocity = null;
  app.camera.setTarget(null);
  app.camera.setMode('orbit');
  document.getElementById('touch-controls').classList.remove('visible');
  player = null;
}

function updateTopDownController(dt) {
  if (!topdownEntity) return null;
  const settings = currentPlayerSettings;
  const speed = settings.moveSpeed || 6;
  const accel = settings.acceleration || 24;
  const input = app.input;
  let x = 0, z = 0;
  if (input.isDown(effectiveInputMap.moveForward) || input.isDown('ArrowUp')) z -= 1;
  if (input.isDown(effectiveInputMap.moveBack) || input.isDown('ArrowDown')) z += 1;
  if (input.isDown(effectiveInputMap.moveLeft) || input.isDown('ArrowLeft')) x -= 1;
  if (input.isDown(effectiveInputMap.moveRight) || input.isDown('ArrowRight')) x += 1;
  const moveDir = new Opus.Vec3(x, 0, z);
  const previousPosition = topdownEntity.position.clone();
  if (moveDir.length() > 0) {
    const target = moveDir.normalize().scale(speed);
    topdownVelocity = topdownVelocity.add(target.sub(topdownVelocity).scale(Math.min(1, (accel * dt) / speed)));
    if (settings.rotateToMovement) topdownEntity.rotationY = Math.atan2(x, -z);
  } else {
    topdownVelocity = topdownVelocity.scale(Math.exp(-0.6 * (accel / 10) * dt));
  }
  topdownEntity.position = topdownEntity.position.add(topdownVelocity.scale(dt));

  const terrainItem = currentTerrainItem(topdownEntity.position);
  if (terrainItem) {
    const collision = Opus.Physics.resolveTerrainCollision(topdownEntity.position, topdownVelocity, player.radius, terrainItem.options);
    if (collision.collided) { topdownEntity.position = collision.correctedPosition; topdownVelocity = collision.correctedVelocity; }
  }
  for (const item of placed) {
    if (item.kind !== 'cube' || !item.entity.solid || !item.entity.visible) continue;
    const solidCollision = resolveItemColliderCollision(topdownEntity.position, topdownVelocity, player.radius, item);
    if (solidCollision.collided) { topdownEntity.position = solidCollision.correctedPosition; topdownVelocity = solidCollision.correctedVelocity; }
  }
  const boundary = Opus.Physics.applyMapBoundary(topdownEntity.position, topdownVelocity, player.radius, MAP_BOUNDARY);
  topdownEntity.position = boundary.correctedPosition;
  topdownVelocity = boundary.correctedVelocity;

  return previousPosition;
}

// --- Third-person player controller ---
// Camera-relative WASD/touch movement. Vertical physics (gravity/jump/
// grounded-state) is OPT-IN per level via Player Settings' Jump checkbox --
// off by default so every existing Third-Person level keeps its exact prior
// flat-ground behavior unchanged. When on, Y is integrated like any other
// axis (gravity accelerates thirdPersonVelocity.y every frame) and resolved
// against terrain (resolveTerrainCollision, already Y-aware) and solid
// objects (the new resolveVerticalBoxCollision, landing on top / bonking
// the underside) each frame, exactly the same two collision sources the
// XZ movement below already resolves against.
let thirdPersonEntity = null;
let thirdPersonVelocity = null;
let thirdPersonGrounded = false;
let jumpKeyWasDown = false;

function spawnThirdPersonController(position) {
  const settings = currentPlayerSettings;
  thirdPersonEntity = app.addEntity({ mesh: cubeMesh, color: [0.2, 0.75, 0.55], position: position.clone(), scale: new Opus.Vec3(0.6, 1.1, 0.6) });
  thirdPersonVelocity = new Opus.Vec3();
  thirdPersonGrounded = false;
  jumpKeyWasDown = false;

  app.camera.setTarget(thirdPersonEntity);
  app.camera.setChaseOptions({ distance: 6.5, height: 2.6, pitch: 0.28, lerpSpeed: 6.5, rotationLerpSpeed: 8.5, lookAhead: 0.8 });
  app.camera.setMode('chase');

  if (isTouchDevice) document.getElementById('touch-controls').classList.add('visible');
  // The existing Boost touch button is otherwise unused by this controller
  // (Boost is a Hovercraft-only action) -- repurposed as Jump when the
  // level opts into vertical physics, hidden entirely otherwise so it
  // doesn't sit on screen as a dead button.
  const touchBoostBtn = document.getElementById('touch-boost');
  touchBoostBtn.style.display = settings.jumpEnabled ? '' : 'none';
  touchBoostBtn.textContent = 'JUMP';

  player = {
    controllerType: 'thirdperson',
    entity: thirdPersonEntity,
    radius: settings.collisionRadius || 0.5,
    get velocity() { return thirdPersonVelocity; },
    set velocity(v) { thirdPersonVelocity = v; },
  };
}

function despawnThirdPersonController() {
  if (!thirdPersonEntity) return;
  app.scene.remove(thirdPersonEntity);
  thirdPersonEntity = null;
  thirdPersonVelocity = null;
  document.getElementById('touch-boost').textContent = 'BOOST';
  document.getElementById('touch-boost').style.display = '';
  app.camera.setTarget(null);
  app.camera.setMode('orbit');
  document.getElementById('touch-controls').classList.remove('visible');
  player = null;
}

// Moving platform carry (Wave 5, Priority E) -- a player standing on a
// solid that's itself moving (Property Animation, a Tween) should move
// WITH it, not be left behind or slide off as it translates. Deliberately
// self-contained (no separate per-frame "capture platform positions" hook
// needed): called once per solid, every frame, from each Player
// Controller's own collision loop -- which already runs AFTER
// updateAnimations/tickTweens have moved that frame's platforms (see their
// onUpdate registration order, both earlier in this file than the main
// gameplay loop), so `item.entity.position` here is already this frame's
// moved position. `item._carryPrevPos`, stashed on the ITEM itself, is
// simply "wherever this same function last saw this item" -- last frame's
// moved position -- so the delta between the two is exactly how far the
// platform moved this one frame. Only applied to the mover when it's
// actually grounded ON this specific item this frame; the position is
// still refreshed on every solid every frame regardless, so a mover that
// steps onto a DIFFERENT platform next frame doesn't inherit a stale delta
// accumulated while it wasn't standing there. Kinematic (position-driven),
// not a physics constraint -- no rigid-body/mass involved, matching the
// spec's own "this is kinematic character-platform interaction" framing.
// Horizontal (X/Z) ONLY -- Y is deliberately excluded. The caller always
// invokes this immediately after the SAME frame's vertical box-snap (see
// updateThirdPersonController/updateFirstPersonController), which already
// repositions the mover's Y to exactly `box.max.y + halfHeight` using the
// platform's OWN already-moved-this-frame position -- authoritative and
// exact, not an approximation. Applying carry's Y delta on top of that
// double-counts the platform's vertical movement for the frame: found by
// dogfooding a fast (easeInOut, ~2-3 u/s peak) vertical elevator, where the
// compounding overshoot grew a small starting gap frame over frame until
// the mover drifted far enough above the platform to fall outside the
// snap's own tolerance band a few frames later and dropped off entirely --
// a translating (horizontal-only) platform never exposed this, since there
// is no competing vertical snap to double up against on that axis.
// --- Explicit Collider data (Wave 6, Priority A/Sections 3-4) ----------
// A visible mesh and its collision shape no longer have to be the same
// thing. `item.collider` is OPTIONAL component data -- `{ shape: 'box'|
// 'sphere', enabled, offset: {x,y,z}, size: {x,y,z} (box) | radius
// (sphere) }` -- authored independently of `entity.scale`/`entity.mesh`.
// Absent (every solid placed before this existed, and the overwhelming
// majority of new ones too) means "derive a box exactly from entity.scale,
// centered on the entity" -- bit-identical to every pre-Wave-6 solid's own
// collision, computed the SAME way it always was, just now funneled
// through this one function so every controller reads collider shape
// consistently instead of four separate copies of "half = scale/2".
// `enabled:false` on an existing collider record falls back to the same
// default-box derivation, rather than meaning "no collision at all" --
// `entity.solid` remains the one true master on/off switch for whether an
// object collides at all, matching its own pre-existing meaning.
function itemColliderConfig(item) {
  const c = item.collider;
  const offset = (c && c.offset) ? new Opus.Vec3(c.offset.x || 0, c.offset.y || 0, c.offset.z || 0) : new Opus.Vec3(0, 0, 0);
  if (!c || c.enabled === false || !c.shape || c.shape === 'box') {
    const size = (c && c.shape === 'box' && c.size) ? new Opus.Vec3(c.size.x, c.size.y, c.size.z) : item.entity.scale;
    return { shape: 'box', half: size.scale(0.5), offset };
  }
  // Sphere: radius defaults from the entity's own largest horizontal
  // scale/2 if not explicitly authored, so dropping a Sphere Collider onto
  // an unmodified cube still gives a sensible bounding sphere immediately.
  const radius = c.radius != null ? c.radius : Math.max(item.entity.scale.x, item.entity.scale.z) / 2;
  return { shape: 'sphere', radius, offset };
}

// Resolves a mover against ONE item's collider (box or sphere), already
// offset-adjusted -- the single choke point every Player Controller's
// horizontal solid-push loop now calls, so a new collider shape only ever
// needs to be taught to this one function, not four copies of it.
function resolveItemColliderCollision(moverPosition, moverVelocity, moverRadius, item) {
  const cfg = itemColliderConfig(item);
  const center = item.entity.position.add(cfg.offset);
  if (cfg.shape === 'sphere') {
    return Opus.Physics.resolveSphereCollision(moverPosition, moverVelocity, moverRadius, center, cfg.radius);
  }
  return Opus.Physics.resolveOrientedBoxCollision(moverPosition, moverVelocity, moverRadius, { center, half: cfg.half, quat: item.entity.quaternion });
}

// Wave 6 (Priority B/Section 16): Step Height -- a small stair-step obstacle
// (real stairs are authored as a stack of thin solid boxes, not a special
// primitive) gets auto-climbed instead of blocking the mover sideways, the
// same way a real person's foot doesn't need to "jump" over a curb. Only
// engages for a Box-shaped collider (a Sphere Collider or a Ramp -- which
// already has its own resolveRampCollision -- has no flat "step surface" to
// snap onto) and only while the mover is already grounded (an airborne
// mover mid-jump shouldn't get magnetically snapped onto a ledge it's
// merely passing beside). Deliberately ignores the box's own rotation for
// its top-face height, the exact same simplification resolveVerticalBoxCollision
// already makes for landing -- a yaw-rotated stair step's Y-extent is
// unaffected by that rotation either way. Returns true (and mutates the
// mover's own position/velocity in place) only when it actually stepped up;
// the caller skips the ordinary horizontal push for this item this frame
// when it does, the same "landing and being shoved are mutually exclusive"
// rule the vertical box check already established.
const STEP_HEIGHT = 0.5;
function tryStepUp(moverEntity, moverVelocity, halfHeight, isGrounded, item) {
  if (!isGrounded) return false;
  const cfg = itemColliderConfig(item);
  if (cfg.shape !== 'box') return false;
  const center = item.entity.position.add(cfg.offset);
  const topY = center.y + cfg.half.y;
  const feetY = moverEntity.position.y - halfHeight;
  const stepUpAmount = topY - feetY;
  if (stepUpAmount <= 0 || stepUpAmount > STEP_HEIGHT) return false;
  // Only step up when the mover's XZ footprint is actually over this box's
  // own top face (not merely somewhere nearby) -- otherwise a step-height
  // check on a TALL wall well within range would wrongly teleport the mover
  // up its face the instant they got close, instead of blocking them like
  // an ordinary wall.
  const local = item.entity.quaternion ? item.entity.quaternion.conjugate().rotateVec3(moverEntity.position.sub(center)) : moverEntity.position.sub(center);
  if (Math.abs(local.x) > cfg.half.x || Math.abs(local.z) > cfg.half.z) return false;
  moverEntity.position.y = topY + halfHeight;
  if (moverVelocity.y < 0) moverVelocity.y = 0;
  return true;
}

// Wave 6 (Priority B/Section 17): Crouch -- shrinks the mover's own
// collision height, not just a visual pose, so a crouched player genuinely
// fits under a low obstacle a standing one couldn't. Reuses the SAME
// `entity.scale.y` every other height check already reads (`halfHeight =
// entity.scale.y * 0.5`, computed fresh every frame in each controller) --
// no separate "crouch collision shape" needed, crouching IS shrinking the
// mover's real shape. Adjusts `position.y` by half the height delta in the
// SAME call so the mover's FEET stay planted at their current ground height
// instead of sinking through the floor (shrinking around the center) or
// floating (shrinking around the old top). The entity's original standing
// height is cached on the entity itself (`_standingScaleY`) the first time
// this runs, so it can always be restored exactly, even after multiple
// crouch/stand cycles.
const CROUCH_HEIGHT_MULTIPLIER = 0.55;
// Wave 6B (Priority C): bounded ceiling-clearance check -- "is there a
// solid whose underside would overlap the region between the mover's feet
// and its WOULD-BE standing head height, at its current XZ position." An
// axis-aligned-box approximation of each solid's real (possibly oriented/
// sphere) collider is a deliberate, documented simplification for this one
// check -- a true oriented-overlap test would need a real box-vs-box SAT
// routine this engine doesn't have (every existing collision function here
// resolves a CIRCULAR mover against a box, never box-vs-box), and an AABB
// approximation is the same "bounded, not a general solver" scope every
// other collider function in this engine already commits to.
function canStandAt(position, radius, feetY, standingHeadY) {
  for (const item of placed) {
    if (item.kind !== 'cube' || !item.entity.solid || !item.entity.visible || item.isRamp) continue;
    const cfg = itemColliderConfig(item);
    const center = item.entity.position.add(cfg.offset);
    let halfX, halfY, halfZ;
    if (cfg.shape === 'sphere') { halfX = halfY = halfZ = cfg.radius; } else { halfX = cfg.half.x; halfY = cfg.half.y; halfZ = cfg.half.z; }
    const minY = center.y - halfY, maxY = center.y + halfY;
    if (maxY <= feetY || minY >= standingHeadY) continue; // no Y-overlap with the region the head would sweep through while standing
    const dx = Math.abs(position.x - center.x), dz = Math.abs(position.z - center.z);
    if (dx < halfX + radius && dz < halfZ + radius) return false;
  }
  return true;
}
// Returns the ACTUALLY-APPLIED crouch state (which may differ from
// `wantsCrouch` -- releasing Crouch under a low duct must NOT let the
// mover's collision shape instantly expand up through the ceiling above
// it; this is what keeps it crouched until there's real clearance).
function applyCrouchState(entity, wantsCrouch, radius) {
  if (entity._standingScaleY == null) entity._standingScaleY = entity.scale.y;
  const currentlyCrouched = entity.scale.y < entity._standingScaleY - 1e-6;
  let shouldCrouch = wantsCrouch;
  if (!wantsCrouch && currentlyCrouched) {
    const feetY = entity.position.y - entity.scale.y / 2;
    const standingHeadY = feetY + entity._standingScaleY;
    if (!canStandAt(entity.position, radius, feetY, standingHeadY)) shouldCrouch = true;
  }
  const targetScaleY = shouldCrouch ? entity._standingScaleY * CROUCH_HEIGHT_MULTIPLIER : entity._standingScaleY;
  const delta = targetScaleY - entity.scale.y;
  if (Math.abs(delta) > 1e-9) {
    entity.position.y += delta / 2;
    entity.scale.y = targetScaleY;
  }
  return shouldCrouch;
}

function applyPlatformCarry(moverEntity, item, isGroundedOnThis) {
  if (isGroundedOnThis && item._carryPrevPos) {
    const delta = item.entity.position.sub(item._carryPrevPos);
    if (delta.x !== 0 || delta.z !== 0) moverEntity.position = new Opus.Vec3(moverEntity.position.x + delta.x, moverEntity.position.y, moverEntity.position.z + delta.z);
  }
  item._carryPrevPos = item.entity.position.clone();
}

// Wave 6B (Priority A): Skinned Player Character -- a SEPARATE visual
// entity that follows the controller body (position/facing/jump/platform
// carry/respawn/level switches all already move `player.entity`, which
// this just mirrors every frame; the body stays the one authoritative
// physics/collision shape, exactly the "do not make the skeleton itself
// the collision representation" requirement). Third-Person and Top-Down
// only -- First-Person keeps its existing invisible-body convention
// unchanged (Section 2's own explicit scope).
let playerVisualEntity = null;
function playerVisualSupportsSkinnedBody() {
  return player && (player.controllerType === 'thirdperson' || player.controllerType === 'topdown');
}
function teardownPlayerVisual() {
  if (playerVisualEntity) { app.scene.remove(playerVisualEntity); playerVisualEntity = null; }
  if (player && player.entity) player.entity.visible = true; // restore the primitive body's own visibility if a skinned visual had hidden it
  // Wave 9 (Priority A) fix -- visuals only, NOT the full teardown; see
  // teardownPlayerEquipmentVisualsOnly's own comment. A real Play session
  // start/despawn still calls the FULL teardownPlayerEquipment directly
  // (enterPlayMode, despawnPlayer's own callers) -- this per-frame path
  // must never delete which item is equipped, only its visual.
  teardownPlayerEquipmentVisualsOnly();
}
// Wave 7 (Priority C): Player Equipment -- a bounded slot layer on top of
// the existing Inventory-lite (window.__gameInventory), NOT a second item
// database. `currentPlayerSettings.equipmentDefs = [{itemName, slot,
// assetId, socketName, scale, weapon}]` is authored data (which inventory
// item name maps to which visual + socket + optional weapon config);
// runtime equip state lives in `playerEquipment`, entirely transient
// (rebuilt by Equip actions, not itself the thing Priority E's Save Game
// persists -- what's SAVED is which item is equipped, not a live entity).
let playerEquipment = {}; // { [slot]: { itemName, def, entity } }
function equipmentDefFor(itemName) {
  return (currentPlayerSettings.equipmentDefs || []).find((d) => d.itemName === itemName);
}
function unequipSlot(slot) {
  const cur = playerEquipment[slot];
  if (cur && cur.entity) app.scene.remove(cur.entity);
  delete playerEquipment[slot];
}
function equipItemToSlot(itemName, slot) {
  if (!player || !slot) return;
  window.__gameInventory = window.__gameInventory || {};
  if ((window.__gameInventory[itemName] || 0) < 1) return; // must actually hold it -- reuses Inventory, no separate item-count database
  const def = equipmentDefFor(itemName);
  if (!def) return;
  unequipSlot(slot); // always clear whatever was there first -- no orphaned visuals
  let entity = null;
  if (def.assetId) {
    const asset = findAssetById(def.assetId);
    if (asset) entity = app.addEntity({ mesh: getAssetMeshHandle(asset), color: [1, 1, 1], position: new Opus.Vec3(), scale: new Opus.Vec3(def.scale || 1, def.scale || 1, def.scale || 1) });
  }
  playerEquipment[slot] = { itemName, def, entity };
  syncActiveWeaponVisualVisibility(); // Wave 9 (Priority A/Section 23): only the active slot's visual is ever visible
}
// Called every real frame alongside syncPlayerVisual/drivePlayerVisualLocomotion
// so an equipped visual's socket-follow has zero one-frame lag, the same
// reasoning that dispatcher already established for the visual body itself.
// `resolveSocketSourceTransform` (Priority A) only ever reads `.entity`/
// `.assetId` off its first argument -- the Player Visual is not a `placed`
// item and never becomes one, so this minimal duck-typed wrapper is a real
// use of the EXACT SAME composition path every ordinary placed-object
// socket attachment already uses, not a parallel special-cased one.
function syncPlayerEquipmentVisuals() {
  if (!playerVisualEntity) return;
  const characterProxy = { entity: playerVisualEntity, assetId: currentPlayerSettings.visual && currentPlayerSettings.visual.assetId };
  for (const slot in playerEquipment) {
    const eq = playerEquipment[slot];
    if (!eq.entity || !eq.def.socketName) continue;
    const t = resolveSocketSourceTransform(characterProxy, eq.def.socketName);
    if (!t) continue;
    eq.entity.position = t.position;
    eq.entity.quaternion = t.quaternion;
  }
}
function teardownPlayerEquipment() {
  for (const slot in playerEquipment) unequipSlot(slot);
  playerEquipment = {};
}
// Wave 9 (Priority A) -- REAL BUG found live dogfooding Equipment Weapon
// mode in First-Person: `syncPlayerVisual` calls `teardownPlayerVisual`
// EVERY FRAME whenever the current controller doesn't support a skinned
// body (First-Person, Hovercraft -- see `playerVisualSupportsSkinnedBody`),
// and `teardownPlayerVisual` called the FULL `teardownPlayerEquipment`
// unconditionally -- wiping `playerEquipment` (which item is in which
// slot) completely, every single frame, for the entire duration of any
// First-Person session. Equipment Weapon mode (Section 22's Primary/
// Secondary switching) was therefore silently impossible in First-Person
// from the moment Wave 7 introduced it, pre-dating this Wave -- exposed
// now because Weapons 2.0's ammo/switching is the first thing that
// actually reads `playerEquipment` back a frame later instead of only
// reading it once, synchronously, right after Equip. Fix: only the
// VISUAL entities need tearing down when there's no skinned body to
// attach them to -- the itemName/def bookkeeping (which drives
// resolveActivePlayerWeapon/switching regardless of whether anything is
// visibly rendered) must survive.
function teardownPlayerEquipmentVisualsOnly() {
  for (const slot in playerEquipment) {
    const eq = playerEquipment[slot];
    if (eq.entity) { app.scene.remove(eq.entity); eq.entity = null; }
  }
}
// Wave 7 (Priority J, Sections 61-64): Pickup/Carry/Drop -- kinematic
// carrying, deliberately independent of the Dynamic Physics gate above
// (which was deferred). `item.carryable` (author flag) opts an ordinary
// placed object into being held; `heldObjectItem` tracks the ONE currently
// held object (this engine's own established "one at a time" bound, same
// spirit as Player Equipment's one-item-per-slot). Held-object POSITION
// sync happens every real frame from the same dispatcher Priority A/C's
// visual/equipment syncs already use.
let heldObjectItem = null;
function pickUpObject(item) {
  if (!item || item.kind !== 'cube' || !item.carryable || heldObjectItem) return;
  heldObjectItem = item;
  item._preCarrySolid = item.entity.solid;
  item.entity.solid = false; // a carried object must not block the very player carrying it
}
function dropHeldObject() {
  if (!heldObjectItem) return;
  heldObjectItem.entity.solid = !!heldObjectItem._preCarrySolid;
  heldObjectItem = null;
}
// Third-Person with a skinned Player Visual: prefer an authored hand
// socket (name containing "hand", case-insensitive -- a real, non-
// hardcoded test of Priority A's socket infrastructure, per the spec's
// own framing of this as "a great test of socket infrastructure"), via
// the exact same `resolveSocketSourceTransform` duck-typed-wrapper reuse
// Priority C's Equipment visuals already established. First-Person (no
// visible body/hand) and any Third-Person character with no hand socket
// authored both fall back to a simple forward-offset hold position.
function syncHeldObjectPosition() {
  if (!heldObjectItem || !player) return;
  const fallback = () => {
    heldObjectItem.entity.position = player.entity.position.add(player.entity.forward.scale(1.6)).add(new Opus.Vec3(0, 0.5, 0));
  };
  if (player.controllerType !== 'firstperson' && playerVisualEntity && playerVisualEntity.skin && currentPlayerSettings.visual) {
    const asset = findAssetById(currentPlayerSettings.visual.assetId);
    const handSocket = asset && asset.sockets && asset.sockets.find((s) => /hand/i.test(s.name));
    if (handSocket) {
      const t = resolveSocketSourceTransform({ entity: playerVisualEntity, assetId: currentPlayerSettings.visual.assetId }, handSocket.name);
      if (t) { heldObjectItem.entity.position = t.position; heldObjectItem.entity.quaternion = t.quaternion; return; }
    }
    fallback();
    return;
  }
  fallback();
}
// The ONE place that creates/tears down/repositions the Player's skinned
// visual -- called every frame (unconditional, like Billboard facing),
// so it stays correct through spawn, movement, platform carry, respawn,
// and a level switch with no special-casing needed at any of those sites.
function syncPlayerVisual() {
  if (!player || !playerVisualSupportsSkinnedBody()) { teardownPlayerVisual(); return; }
  const visual = currentPlayerSettings.visual || defaultPlayerVisual();
  const wantsSkinned = visual.mode === 'skinned' && visual.assetId;
  const asset = wantsSkinned ? findAssetById(visual.assetId) : null;
  if (!asset || asset.type !== 'skinnedMesh') { teardownPlayerVisual(); return; }
  if (!playerVisualEntity) {
    playerVisualEntity = app.addEntity({ mesh: getAssetMeshHandle(asset), color: [1, 1, 1], position: player.entity.position.clone(), scale: new Opus.Vec3(visual.scale || 1, visual.scale || 1, visual.scale || 1) });
    player.entity.visible = false; // the primitive body becomes an invisible physics-only shape once a skinned visual is showing
  }
  playerVisualEntity.scale.set(visual.scale || 1, visual.scale || 1, visual.scale || 1);
  const off = visual.positionOffset || { x: 0, y: 0, z: 0 };
  const worldOffset = player.entity.quaternion.rotateVec3(new Opus.Vec3(off.x, off.y, off.z));
  playerVisualEntity.position = player.entity.position.add(worldOffset);
  playerVisualEntity.quaternion = player.entity.quaternion.multiply(Opus.Quat.fromEuler(0, (visual.rotationOffsetY || 0) * Math.PI / 180, 0));
}
// Explicit clip-mapping (Section 5) takes priority; falls back to the same
// name-matching Auto-Animate already uses for AI (Section 6) -- one shared
// keyword table either way, never a second matching convention.
function resolvePlayerClip(role) {
  if (!playerVisualEntity || !playerVisualEntity.skin) return null;
  const visual = currentPlayerSettings.visual || defaultPlayerVisual();
  const explicit = visual.clipMap && visual.clipMap[role];
  if (explicit != null && playerVisualEntity.skin.clips[explicit]) return explicit;
  return findCharacterClip(playerVisualEntity, CHARACTER_ANIM_KEYWORDS[role] || [role]);
}
// Player locomotion (Section 7) -- driven by the REAL controller state
// (grounded/velocity), not an AI position-delta the way Auto-Animate infers
// it for NPCs (the Player has no `entity.ai` to read a delta from in the
// first place). Reuses `entity.animationClip`/`_animOverrideUntil`, the
// exact same override mechanism Priority M's character state machine
// already established -- no second state system.
function drivePlayerVisualLocomotion() {
  if (!playerVisualEntity || !playerVisualEntity.skin || !player) return;
  const visual = currentPlayerSettings.visual || defaultPlayerVisual();
  playerVisualEntity.animationBlendTime = visual.blendTime != null ? visual.blendTime : 0.15;
  if (playerVisualEntity._animOverrideUntil > simElapsed) return; // Attack/Death override active -- locomotion defers to it
  const vel = player.velocity || new Opus.Vec3();
  const horizSpeed = Math.hypot(vel.x, vel.z);
  const grounded = player.controllerType === 'thirdperson' ? thirdPersonGrounded : true; // Top-Down has no vertical-physics concept
  const settings = currentPlayerSettings;
  const sprintSpeed = (settings.moveSpeed || 6.5) * (settings.sprintSpeedMultiplier ?? 1.6);
  let role;
  if (!grounded && vel.y > 0.5) role = 'jump';
  else if (!grounded && vel.y < -0.5) role = 'fall';
  else if (horizSpeed < 0.3) role = 'idle';
  else if (horizSpeed > sprintSpeed * 0.7) role = 'run';
  else role = 'walk';
  // Graceful fallback chain for an unmapped role (e.g. no Jump clip
  // authored) -- fall back toward Walk, then Idle, rather than leaving the
  // Player frozen on whatever clip happened to be playing before.
  let clipIndex = resolvePlayerClip(role);
  if (clipIndex === null && (role === 'jump' || role === 'fall' || role === 'run')) clipIndex = resolvePlayerClip('walk');
  if (clipIndex === null) clipIndex = resolvePlayerClip('idle');
  if (clipIndex !== null && playerVisualEntity.animationClip !== clipIndex) playerVisualEntity.animationClip = clipIndex;
}
function triggerPlayerAttackAnim() {
  const idx = resolvePlayerClip('attack');
  if (idx === null) return;
  playerVisualEntity.animationClip = idx;
  const duration = playerVisualEntity.skin.clips[idx].duration || 0.5;
  playerVisualEntity._animOverrideUntil = simElapsed + duration;
}
// Wave 9 (Priority A/Section 12): optional Reload clip -- correctness of
// the reload never depends on this playing (Section 13's own "Duration is
// sufficient"); a project with no Reload clip mapped just keeps whatever
// locomotion animation was already showing while the real timer runs.
function triggerPlayerReloadAnim(duration) {
  if (!playerVisualEntity || !playerVisualEntity.skin) return;
  const idx = resolvePlayerClip('reload');
  if (idx === null) return;
  playerVisualEntity.animationClip = idx;
  playerVisualEntity._animOverrideUntil = simElapsed + (duration || playerVisualEntity.skin.clips[idx].duration || 1);
}
function triggerPlayerDeathAnim() {
  const idx = resolvePlayerClip('death');
  if (idx === null) return false;
  playerVisualEntity.animationClip = idx;
  playerVisualEntity._animOverrideUntil = Infinity;
  return true;
}

// Wave 6B (Priority J): Footstep audio -- plays only when grounded AND
// actually moving, at an author-set interval, reading the exact same
// grounded/velocity state the locomotion driver above already computes (no
// second physics read). Scoped to Third-Person/First-Person only, matching
// Crouch/Sprint's own scoping (Priority B) -- Hovercraft/Top-Down have no
// "footsteps on the ground" concept. Fields are read lazily straight off
// `currentPlayerSettings` with sensible code-level defaults (the same
// `?? ` pattern `crouchSpeedMultiplier`/`sprintSpeedMultiplier` already use),
// so a project saved before this priority has none of these fields and is
// completely unaffected (footstepAudioAssetId is null -> the whole function
// is a no-op).
let footstepTimer = 0;
function driveFootstepAudio(dt) {
  const settings = currentPlayerSettings;
  if (!settings.footstepAudioAssetId) return;
  if (player.controllerType !== 'thirdperson' && player.controllerType !== 'firstperson') return;
  const grounded = player.controllerType === 'thirdperson' ? thirdPersonGrounded : firstPersonGrounded;
  const vel = player.velocity || new Opus.Vec3();
  const horizSpeed = Math.hypot(vel.x, vel.z);
  if (!grounded || horizSpeed < 0.3) { footstepTimer = 0; return; }
  footstepTimer += dt;
  const interval = Math.max(0.05, settings.footstepInterval ?? 0.4);
  if (footstepTimer < interval) return;
  footstepTimer -= interval;
  const asset = findAudioAssetById(settings.footstepAudioAssetId);
  if (!asset || !asset.audioBuffer) return;
  const sprintSpeed = (settings.moveSpeed || 6.5) * (settings.sprintSpeedMultiplier ?? 1.6);
  const running = horizSpeed > sprintSpeed * 0.7;
  const volume = running ? (settings.footstepRunVolume ?? 0.7) : (settings.footstepWalkVolume ?? 0.5);
  app.audio.playBuffer(asset.audioBuffer, { volume });
}
// Wave 9B (Silent Sector, Section 17): movement-generated noise -- crouch <
// walk < sprint radii, so a crouch-walking Player is meaningfully quieter
// to nearby AI than a sprinting one. Deliberately reuses the SAME bounded
// step/interval cadence footstep audio above already established (one
// noise event per footstep, not one per frame -- the spec's own explicit
// "do not flood event handling"), and is entirely independent of whether
// footstep AUDIO is configured (`footstepAudioAssetId` unset is a common,
// valid case that should still emit noise for AI hearing to react to).
// Opt-in: `movementNoiseEnabled` unset (every pre-Wave-9B project) means
// this is a complete no-op, so no existing game's AI hearing behavior
// changes just because this function now runs every frame.
let movementNoiseTimer = 0;
function driveMovementNoise(dt) {
  const settings = currentPlayerSettings;
  if (!settings.movementNoiseEnabled || !player) return;
  if (player.controllerType !== 'thirdperson' && player.controllerType !== 'firstperson') return;
  const grounded = player.controllerType === 'thirdperson' ? thirdPersonGrounded : firstPersonGrounded;
  const vel = player.velocity || new Opus.Vec3();
  const horizSpeed = Math.hypot(vel.x, vel.z);
  if (!grounded || horizSpeed < 0.3) { movementNoiseTimer = 0; return; }
  movementNoiseTimer += dt;
  const interval = Math.max(0.05, settings.footstepInterval ?? 0.4);
  if (movementNoiseTimer < interval) return;
  movementNoiseTimer -= interval;
  const sprintSpeed = (settings.moveSpeed || 6.5) * (settings.sprintSpeedMultiplier ?? 1.6);
  const running = horizSpeed > sprintSpeed * 0.7;
  const radius = player.crouching ? (settings.crouchNoiseRadius ?? 2)
    : running ? (settings.sprintNoiseRadius ?? 16)
    : (settings.walkNoiseRadius ?? 6);
  if (radius > 0) emitNoiseEvent(player.entity.position, radius);
}

function updateThirdPersonController(dt) {
  if (!thirdPersonEntity) return null;
  const settings = currentPlayerSettings;
  const input = app.input;
  // Wave 6 (Priority B/Section 17-18): Crouch takes priority over Sprint --
  // can't sprint while crouched, the standard convention every shooter/
  // platformer shares, and a simpler rule than trying to define what
  // "crouch-sprinting" would even mean physically.
  const crouchWanted = input.isDown(effectiveInputMap.crouch);
  const sprintDown = !crouchWanted && input.isDown(effectiveInputMap.sprint);
  // Wave 6B (Priority C): the ACTUALLY-applied crouch state (may stay true
  // even after the key is released, if there's no ceiling clearance to
  // stand into) drives speed too -- a mover still physically crouched under
  // a duct must not suddenly move at standing speed just because the key
  // was released.
  const crouchDown = applyCrouchState(thirdPersonEntity, crouchWanted, player.radius);
  player.crouching = crouchDown; // Wave 9B (Silent Sector): exposed so driveMovementNoise can read crouch state without a second physics pass
  const baseSpeed = settings.moveSpeed || 6.5;
  const speed = baseSpeed * (crouchDown ? (settings.crouchSpeedMultiplier ?? 0.5) : sprintDown ? (settings.sprintSpeedMultiplier ?? 1.6) : 1);
  const accel = settings.acceleration || 30;
  const jumpEnabled = !!settings.jumpEnabled;
  const gravity = settings.gravity || 20;
  const jumpSpeed = settings.jumpSpeed || 8;
  let forwardIn = 0, strafeIn = 0;
  if (input.isDown(effectiveInputMap.moveForward) || input.isDown('ArrowUp')) forwardIn += 1;
  if (input.isDown(effectiveInputMap.moveBack) || input.isDown('ArrowDown')) forwardIn -= 1;
  if (input.isDown(effectiveInputMap.moveRight) || input.isDown('ArrowRight')) strafeIn += 1;
  if (input.isDown(effectiveInputMap.moveLeft) || input.isDown('ArrowLeft')) strafeIn -= 1;

  const basis = app.camera.getBasis();
  const camForward = new Opus.Vec3(basis.forward.x, 0, basis.forward.z);
  const flatLen = camForward.length();
  const camForwardFlat = flatLen > 0.0001 ? camForward.scale(1 / flatLen) : new Opus.Vec3(0, 0, -1);
  const camRight = new Opus.Vec3(camForwardFlat.z, 0, -camForwardFlat.x);

  const moveDir = camForwardFlat.scale(forwardIn).add(camRight.scale(strafeIn));
  const previousPosition = thirdPersonEntity.position.clone();

  // Horizontal (XZ) velocity is blended toward the desired move direction
  // as before. Vertical (Y) velocity is now handled entirely separately
  // below (gravity/jump) -- blending it toward a flat XZ target would bleed
  // it back toward zero every frame, killing gravity and jump arcs outright.
  const currentHorizontal = new Opus.Vec3(thirdPersonVelocity.x, 0, thirdPersonVelocity.z);
  let horizontal;
  if (moveDir.length() > 0.001) {
    const dir = moveDir.normalize();
    const target = dir.scale(speed);
    horizontal = currentHorizontal.add(target.sub(currentHorizontal).scale(Math.min(1, (accel * dt) / speed)));
    thirdPersonEntity.rotationY = Math.atan2(dir.x, dir.z);
  } else {
    horizontal = currentHorizontal.scale(Math.exp(-0.6 * (accel / 10) * dt));
  }

  let verticalY = jumpEnabled ? thirdPersonVelocity.y : 0;
  if (jumpEnabled) {
    verticalY -= gravity * dt;
    const jumpDown = input.isDown(effectiveInputMap.jump);
    if (jumpDown && !jumpKeyWasDown && thirdPersonGrounded) verticalY = jumpSpeed;
    jumpKeyWasDown = jumpDown;
  }
  thirdPersonVelocity = new Opus.Vec3(horizontal.x, verticalY, horizontal.z);
  thirdPersonEntity.position = thirdPersonEntity.position.add(thirdPersonVelocity.scale(dt));

  thirdPersonGrounded = false;
  const terrainItem = currentTerrainItem(thirdPersonEntity.position);
  if (terrainItem) {
    const collision = Opus.Physics.resolveTerrainCollision(thirdPersonEntity.position, thirdPersonVelocity, player.radius, terrainItem.options);
    if (collision.collided) { thirdPersonEntity.position = collision.correctedPosition; thirdPersonVelocity = collision.correctedVelocity; }
    if (collision.grounded) thirdPersonGrounded = true;
  }
  const halfHeight = thirdPersonEntity.scale.y * 0.5;
  for (const item of placed) {
    if (item.kind !== 'cube' || !item.entity.solid || !item.entity.visible) continue;
    // Wave 6 (Priority B/Section 14): a Ramp gets its own sloped-surface
    // resolution instead of the flat-top box check below -- only when jump
    // (and therefore real per-frame vertical physics) is enabled; a
    // non-jump controller has no Y-axis movement to climb a slope with
    // anyway, so it falls through to the plain box branch further down and
    // treats the ramp as an ordinary wall, exactly like a jump-disabled
    // controller already treats every other solid.
    if (item.isRamp && jumpEnabled) {
      const rampCfg = { center: item.entity.position, half: item.entity.scale.scale(0.5), quat: item.entity.quaternion };
      const rCollision = Opus.Physics.resolveRampCollision(thirdPersonEntity.position, thirdPersonVelocity, player.radius, halfHeight, rampCfg, dt);
      if (rCollision.collided) {
        thirdPersonEntity.position = rCollision.correctedPosition;
        thirdPersonVelocity = rCollision.correctedVelocity;
      }
      if (rCollision.grounded) thirdPersonGrounded = true;
      applyPlatformCarry(thirdPersonEntity, item, rCollision.grounded);
      continue;
    }
    const half = item.entity.scale.scale(0.5);
    // With jump enabled, a solid object can be a PLATFORM the player lands
    // on top of or clears underneath, not just a wall. Vertical (top/bottom
    // face) resolution runs FIRST and, when it fires, SKIPS the horizontal
    // wall push for this object this frame -- landing/bonking and being
    // shoved sideways are mutually exclusive outcomes for the same contact.
    // Tried gating the horizontal push on simple vertical-range overlap
    // instead (checked before this): it still fired on the exact landing
    // frame (feet freshly inside the top-face tolerance band, which also
    // reads as "overlapping"), shoving the player to the box's edge via
    // resolveBoxCollision's degenerate dead-center fallback and dropping
    // them off the platform on the very frame they landed on it -- caught
    // live dogfooding a player spawned dead-center above a platform.
    // Non-jump controllers keep the original always-a-wall behavior unchanged.
    let verticalHandled = false;
    if (jumpEnabled) {
      const vBox = new Opus.Physics.AABB(
        new Opus.Vec3(item.entity.position.x - half.x, item.entity.position.y - half.y, item.entity.position.z - half.z),
        new Opus.Vec3(item.entity.position.x + half.x, item.entity.position.y + half.y, item.entity.position.z + half.z),
      );
      const vCollision = Opus.Physics.resolveVerticalBoxCollision(thirdPersonEntity.position, thirdPersonVelocity, player.radius, halfHeight, vBox, dt);
      if (vCollision.collided) {
        thirdPersonEntity.position = vCollision.correctedPosition;
        thirdPersonVelocity = vCollision.correctedVelocity;
        verticalHandled = true;
      }
      if (vCollision.grounded) thirdPersonGrounded = true;
      applyPlatformCarry(thirdPersonEntity, item, vCollision.grounded);
    }
    const feetY = thirdPersonEntity.position.y - halfHeight;
    const headY = thirdPersonEntity.position.y + halfHeight;
    const verticallyOverlapping = !jumpEnabled || (headY > item.entity.position.y - half.y && feetY < item.entity.position.y + half.y);
    if (verticallyOverlapping && !verticalHandled) {
      if (jumpEnabled && tryStepUp(thirdPersonEntity, thirdPersonVelocity, halfHeight, thirdPersonGrounded, item)) {
        thirdPersonGrounded = true;
        continue;
      }
      const solidCollision = resolveItemColliderCollision(thirdPersonEntity.position, thirdPersonVelocity, player.radius, item);
      if (solidCollision.collided) { thirdPersonEntity.position = solidCollision.correctedPosition; thirdPersonVelocity = solidCollision.correctedVelocity; }
    }
  }
  const boundary = Opus.Physics.applyMapBoundary(thirdPersonEntity.position, thirdPersonVelocity, player.radius, MAP_BOUNDARY);
  thirdPersonEntity.position = boundary.correctedPosition;
  thirdPersonVelocity = new Opus.Vec3(boundary.correctedVelocity.x, thirdPersonVelocity.y, boundary.correctedVelocity.z);

  return previousPosition;
}

// --- First-Person Controller (Wave 5, Priority C) -----------------------
// Justified now (per the spec's own reasoning) because everything it needs
// already exists: solids, vertical physics/jump, projectiles/weapons, and
// Input Actions. Reuses the EXACT same physics Third-Person already uses
// (terrain collision, vertical box landing, horizontal solid push, map
// boundary) -- no second collision solver. The one genuine new piece is
// camera ownership: instead of a chase camera trailing a visible player
// model, this controller drives `app.camera` directly in 'fixed' mode every
// frame from its own yaw/pitch state (no new engine API needed for that --
// Camera.setFixedOptions/. fovY were already public, just never driven by a
// per-frame controller before). The player entity itself still exists (for
// collision) but is invisible, the standard "you don't render your own
// body" FPS convention.
let firstPersonEntity = null;
let firstPersonVelocity = null;
let firstPersonGrounded = false;
let fpJumpKeyWasDown = false;
let fpYaw = 0, fpPitch = 0; // radians; pitch clamped to just under +/-90 degrees below
const FP_PITCH_LIMIT = 1.5; // ~85.9 degrees -- short of true +/-90 to avoid the look direction ever exactly reaching straight up/down (a degenerate camera basis there)
// Wave 9 (Priority A, Sections 19-20): First-Person Recoil -- a transient
// ADDITIVE offset layered on top of fpYaw/fpPitch, never written INTO them,
// so recoil recovering to 0 never fights or drifts the player's own actual
// aim. Kicked on fire (applyWeaponRecoilKick), decayed every real frame
// (tickRecoilRecovery, simulation-time driven) regardless of whether the
// mouse itself moved that frame -- unlike applyFirstPersonLook, which only
// runs on a mouse-move event.
let recoilPitchOffset = 0, recoilYawOffset = 0;
// Wave 9 (Priority C, Sections 43-46): Camera Shake -- simulation-time
// driven (survives pause correctly: paused sim time doesn't advance, so a
// shake started right before pause correctly freezes rather than finishing
// silently in the background), decaying linearly to zero over `duration`.
// `triggerCameraShake` called again before a prior shake finishes replaces
// it (a fresh hit re-triggering shake mid-shake is the natural expectation,
// not additive stacking, per Section 44's own "bounded" framing).
let cameraShakeIntensity = 0, cameraShakeDuration = 0, cameraShakeElapsed = 0;
function triggerCameraShake(intensity, duration) {
  cameraShakeIntensity = Math.max(0, intensity);
  cameraShakeDuration = Math.max(0.01, duration);
  cameraShakeElapsed = 0;
}
// Wave 9 (Priority C/Section 43): Player Damage Feedback -- a short red
// screen flash plus a small Camera Shake, both fixed/subtle rather than a
// full per-hit-authored config (a bounded default, not a graphic editor).
function triggerPlayerDamageFeedback() {
  const flashEl = document.getElementById('damage-flash');
  if (flashEl) {
    flashEl.style.background = 'rgba(200, 20, 20, 0.35)';
    requestAnimationFrame(() => { flashEl.style.background = 'rgba(200, 20, 20, 0.001)'; });
  }
  triggerCameraShake(0.12, 0.25);
}
function tickCameraShake(dt) {
  if (cameraShakeElapsed >= cameraShakeDuration) {
    if (app.camera.shakeOffset) app.camera.shakeOffset = null;
    return;
  }
  cameraShakeElapsed += dt;
  const t = Math.min(1, cameraShakeElapsed / cameraShakeDuration);
  const remaining = cameraShakeIntensity * (1 - t); // linear falloff
  app.camera.shakeOffset = new Opus.Vec3((Math.random() * 2 - 1) * remaining, (Math.random() * 2 - 1) * remaining, (Math.random() * 2 - 1) * remaining);
}
function applyWeaponRecoilKick(weapon) {
  const v = weapon.recoilVertical || 0;
  const h = weapon.recoilHorizontal || 0;
  if (!v && !h) return;
  recoilPitchOffset += v * (Math.PI / 180);
  recoilYawOffset += (Math.random() * 2 - 1) * h * (Math.PI / 180);
}
function tickRecoilRecovery(dt) {
  if (!recoilPitchOffset && !recoilYawOffset) return;
  const decay = Math.max(0, 1 - dt * 6); // recovery is bounded/fixed-feel rather than a full per-weapon curve editor, per Section 19's "no competitive-shooter recoil pattern editor"
  recoilPitchOffset *= decay;
  recoilYawOffset *= decay;
  if (Math.abs(recoilPitchOffset) < 0.0003) recoilPitchOffset = 0;
  if (Math.abs(recoilYawOffset) < 0.0003) recoilYawOffset = 0;
  if (firstPersonEntity) {
    const p = Math.max(-FP_PITCH_LIMIT, Math.min(FP_PITCH_LIMIT, fpPitch + recoilPitchOffset));
    firstPersonEntity.quaternion = Opus.Quat.fromEuler(p, fpYaw + recoilYawOffset, 0);
  }
}

function spawnFirstPersonController(position) {
  const settings = currentPlayerSettings;
  firstPersonEntity = app.addEntity({ mesh: cubeMesh, color: [0.2, 0.75, 0.55], position: position.clone(), scale: new Opus.Vec3(0.6, 1.1, 0.6) });
  firstPersonEntity.visible = false; // FPS convention: never render your own body
  firstPersonVelocity = new Opus.Vec3();
  firstPersonGrounded = false;
  fpJumpKeyWasDown = false;
  fpYaw = 0; fpPitch = 0;

  app.camera.setMode('fixed');
  app.camera.fovY = (settings.fovDegrees || 70) * Math.PI / 180;

  if (isTouchDevice) {
    document.getElementById('touch-controls').classList.add('visible');
    document.getElementById('touch-look-zone').classList.add('visible');
  } else {
    requestFirstPersonPointerLock();
  }
  const touchBoostBtn = document.getElementById('touch-boost');
  touchBoostBtn.style.display = '';
  touchBoostBtn.textContent = 'JUMP';

  player = {
    controllerType: 'firstperson',
    entity: firstPersonEntity,
    radius: settings.collisionRadius || 0.4,
    get velocity() { return firstPersonVelocity; },
    set velocity(v) { firstPersonVelocity = v; },
  };
}

function despawnFirstPersonController() {
  if (!firstPersonEntity) return;
  app.scene.remove(firstPersonEntity);
  firstPersonEntity = null;
  firstPersonVelocity = null;
  document.getElementById('touch-boost').textContent = 'BOOST';
  document.getElementById('touch-controls').classList.remove('visible');
  document.getElementById('touch-look-zone').classList.remove('visible');
  releaseFirstPersonPointerLock();
  app.camera.setMode('orbit');
  player = null;
}

// Shared by mouse (Pointer Lock movementX/Y), touch (drag delta on the
// look zone), and gamepad (right stick, scaled by dt in pollGamepad) --
// ONE function updates yaw/pitch and the entity's full orientation, so all
// three input sources stay perfectly consistent with each other and with
// whatever fireAttack/AI targeting reads off `entity.forward`.
function applyFirstPersonLook(dx, dy, sensitivity) {
  fpYaw -= dx * sensitivity;
  fpPitch -= dy * sensitivity;
  fpPitch = Math.max(-FP_PITCH_LIMIT, Math.min(FP_PITCH_LIMIT, fpPitch));
  if (firstPersonEntity) firstPersonEntity.quaternion = Opus.Quat.fromEuler(fpPitch, fpYaw, 0);
}

function updateFirstPersonController(dt) {
  if (!firstPersonEntity) return null;
  const settings = currentPlayerSettings;
  const input = app.input;
  // Wave 6 (Priority B/Section 17-18): same Crouch/Sprint rule as
  // Third-Person's own controller above -- crouch wins over sprint, both
  // read through the shared inputActionMap so they rebind the same way
  // every other action already does. Crouching also naturally lowers the
  // First-Person camera's eye position -- `eye = position + eyeHeight`
  // already reads `position.y`, which `applyCrouchState` itself lowers to
  // keep the mover's feet planted, so no separate "crouch eye height" math
  // is needed at all.
  const crouchWanted = input.isDown(effectiveInputMap.crouch);
  const sprintDown = !crouchWanted && input.isDown(effectiveInputMap.sprint);
  const crouchDown = applyCrouchState(firstPersonEntity, crouchWanted, player.radius);
  player.crouching = crouchDown; // Wave 9B (Silent Sector): exposed so driveMovementNoise can read crouch state without a second physics pass
  const baseSpeed = settings.moveSpeed || 6;
  const speed = baseSpeed * (crouchDown ? (settings.crouchSpeedMultiplier ?? 0.5) : sprintDown ? (settings.sprintSpeedMultiplier ?? 1.6) : 1);
  const accel = settings.acceleration || 40;
  const gravity = settings.gravity || 20;
  const jumpSpeed = settings.jumpSpeed || 8;
  let forwardIn = 0, strafeIn = 0;
  if (input.isDown(effectiveInputMap.moveForward) || input.isDown('ArrowUp')) forwardIn += 1;
  if (input.isDown(effectiveInputMap.moveBack) || input.isDown('ArrowDown')) forwardIn -= 1;
  if (input.isDown(effectiveInputMap.moveRight) || input.isDown('ArrowRight')) strafeIn += 1;
  if (input.isDown(effectiveInputMap.moveLeft) || input.isDown('ArrowLeft')) strafeIn -= 1;

  // Movement direction uses YAW ONLY (flat) -- standard FPS convention;
  // looking up/down doesn't tip your walking direction into the ground/sky.
  const yawForward = new Opus.Vec3(Math.sin(fpYaw), 0, Math.cos(fpYaw));
  const yawRight = new Opus.Vec3(yawForward.z, 0, -yawForward.x);
  const moveDir = yawForward.scale(forwardIn).add(yawRight.scale(strafeIn));
  const previousPosition = firstPersonEntity.position.clone();

  const currentHorizontal = new Opus.Vec3(firstPersonVelocity.x, 0, firstPersonVelocity.z);
  let horizontal;
  if (moveDir.length() > 0.001) {
    const dir = moveDir.normalize();
    const target = dir.scale(speed);
    horizontal = currentHorizontal.add(target.sub(currentHorizontal).scale(Math.min(1, (accel * dt) / speed)));
  } else {
    horizontal = currentHorizontal.scale(Math.exp(-0.6 * (accel / 10) * dt));
  }

  let verticalY = firstPersonVelocity.y - gravity * dt;
  const jumpDown = input.isDown(effectiveInputMap.jump);
  if (jumpDown && !fpJumpKeyWasDown && firstPersonGrounded) verticalY = jumpSpeed;
  fpJumpKeyWasDown = jumpDown;

  firstPersonVelocity = new Opus.Vec3(horizontal.x, verticalY, horizontal.z);
  firstPersonEntity.position = firstPersonEntity.position.add(firstPersonVelocity.scale(dt));

  // Terrain, vertical (landing-on-top) and horizontal solid collision --
  // the exact same three checks Third-Person's own jump-enabled path
  // already runs, reused verbatim rather than a second implementation.
  firstPersonGrounded = false;
  const terrainItem = currentTerrainItem(firstPersonEntity.position);
  if (terrainItem) {
    const collision = Opus.Physics.resolveTerrainCollision(firstPersonEntity.position, firstPersonVelocity, player.radius, terrainItem.options);
    if (collision.collided) { firstPersonEntity.position = collision.correctedPosition; firstPersonVelocity = collision.correctedVelocity; }
    if (collision.grounded) firstPersonGrounded = true;
  }
  const halfHeight = firstPersonEntity.scale.y * 0.5;
  for (const item of placed) {
    if (item.kind !== 'cube' || !item.entity.solid || !item.entity.visible) continue;
    // Wave 6 (Priority B/Section 14): same Ramp branch as Third-Person's own
    // loop above -- First-Person always has real per-frame vertical physics,
    // so a Ramp always gets its sloped-surface resolution here, never the
    // flat-top box fallback.
    if (item.isRamp) {
      const rampCfg = { center: item.entity.position, half: item.entity.scale.scale(0.5), quat: item.entity.quaternion };
      const rCollision = Opus.Physics.resolveRampCollision(firstPersonEntity.position, firstPersonVelocity, player.radius, halfHeight, rampCfg, dt);
      if (rCollision.collided) {
        firstPersonEntity.position = rCollision.correctedPosition;
        firstPersonVelocity = rCollision.correctedVelocity;
      }
      if (rCollision.grounded) firstPersonGrounded = true;
      applyPlatformCarry(firstPersonEntity, item, rCollision.grounded);
      continue;
    }
    const half = item.entity.scale.scale(0.5);
    let verticalHandled = false;
    const vBox = new Opus.Physics.AABB(
      new Opus.Vec3(item.entity.position.x - half.x, item.entity.position.y - half.y, item.entity.position.z - half.z),
      new Opus.Vec3(item.entity.position.x + half.x, item.entity.position.y + half.y, item.entity.position.z + half.z),
    );
    const vCollision = Opus.Physics.resolveVerticalBoxCollision(firstPersonEntity.position, firstPersonVelocity, player.radius, halfHeight, vBox, dt);
    if (vCollision.collided) {
      firstPersonEntity.position = vCollision.correctedPosition;
      firstPersonVelocity = vCollision.correctedVelocity;
      verticalHandled = true;
    }
    if (vCollision.grounded) firstPersonGrounded = true;
    applyPlatformCarry(firstPersonEntity, item, vCollision.grounded);
    const feetY = firstPersonEntity.position.y - halfHeight;
    const headY = firstPersonEntity.position.y + halfHeight;
    const verticallyOverlapping = headY > item.entity.position.y - half.y && feetY < item.entity.position.y + half.y;
    if (verticallyOverlapping && !verticalHandled) {
      if (tryStepUp(firstPersonEntity, firstPersonVelocity, halfHeight, firstPersonGrounded, item)) {
        firstPersonGrounded = true;
        continue;
      }
      const solidCollision = resolveItemColliderCollision(firstPersonEntity.position, firstPersonVelocity, player.radius, item);
      if (solidCollision.collided) { firstPersonEntity.position = solidCollision.correctedPosition; firstPersonVelocity = solidCollision.correctedVelocity; }
    }
  }
  const boundary = Opus.Physics.applyMapBoundary(firstPersonEntity.position, firstPersonVelocity, player.radius, MAP_BOUNDARY);
  firstPersonEntity.position = boundary.correctedPosition;
  firstPersonVelocity = new Opus.Vec3(boundary.correctedVelocity.x, firstPersonVelocity.y, boundary.correctedVelocity.z);

  // The controller owns the camera transform directly -- eye at the
  // authored eye height above the entity's feet-anchored position, looking
  // along the SAME full pitch+yaw orientation the entity's own quaternion
  // already holds (applyFirstPersonLook keeps them in lockstep), so
  // aiming/shooting (fireAttack reads player.entity.forward) always matches
  // what's actually rendered on screen.
  const eyeHeight = settings.eyeHeight != null ? settings.eyeHeight : 0.6;
  const eye = firstPersonEntity.position.add(new Opus.Vec3(0, eyeHeight, 0));
  const lookDir = firstPersonEntity.forward;
  app.camera.setFixedOptions({ eye, target: eye.add(lookDir) });

  return previousPosition;
}

// Pointer Lock (Wave 5): requested on Play start for a First-Person level
// on a non-touch device, released on Stop/pause/Escape -- never silently
// re-acquired without a fresh user gesture (the browser wouldn't allow that
// anyway, but the explicit release on exitPlayMode/pause means a paused
// game never traps the mouse). `mousemove`'s movementX/Y only means
// anything WHILE actually locked (checked every event, not just at
// listener-registration time, since lock state can end at any moment via
// the browser's own Escape handling, outside this code's control).
function requestFirstPersonPointerLock() {
  // requestPointerLock() returns a Promise (in browsers that resolve it at
  // all) that can reject for reasons entirely outside this code's control
  // -- the tab lost focus between the gesture and the grant, the embedding
  // context genuinely can't support it (caught live: this exact rejection,
  // WrongDocumentError, firing in this session's own sandboxed preview
  // frame), or the user simply hasn't interacted with the page yet. None of
  // those are bugs to surface as an uncaught error; Pointer Lock is already
  // optional (touch/non-locked-mouse look still work), so a rejection here
  // is silently swallowed exactly like the older callback-based API (which
  // has no rejection to observe at all) always behaved.
  if (!canvas.requestPointerLock) return;
  try {
    const result = canvas.requestPointerLock();
    if (result && typeof result.catch === 'function') result.catch(() => {});
  } catch (err) { /* some environments throw synchronously instead of rejecting a promise -- either way, Pointer Lock is optional and this is never a product error */ }
}
function releaseFirstPersonPointerLock() {
  if (document.pointerLockElement === canvas && document.exitPointerLock) document.exitPointerLock();
}
document.addEventListener('mousemove', (e) => {
  if (!playMode || !player || player.controllerType !== 'firstperson') return;
  if (document.pointerLockElement !== canvas) return;
  if (app.paused) return;
  applyFirstPersonLook(e.movementX || 0, e.movementY || 0, currentPlayerSettings.mouseSensitivity || 0.0022);
});
// Clicking back into the canvas mid-session re-acquires lock after the
// browser (or the player pressing Escape) released it -- a real, expected
// gesture, not code silently fighting the browser's own Escape handling.
canvas.addEventListener('click', () => {
  if (playMode && player && player.controllerType === 'firstperson' && !isTouchDevice && document.pointerLockElement !== canvas) {
    requestFirstPersonPointerLock();
  }
});

// Touch look (Wave 5, section 18): a dedicated invisible drag zone on the
// right half of the viewport (left half stays free for the existing D-pad
// touch buttons to sit on/near) -- drag delta between successive touch
// samples feeds the exact same applyFirstPersonLook function Pointer Lock
// uses, so touch/mouse/gamepad look can never disagree about sensitivity
// or pitch clamping.
let touchLookPointerId = null;
let touchLookLastX = 0, touchLookLastY = 0;
const touchLookZoneEl = document.getElementById('touch-look-zone');
touchLookZoneEl.addEventListener('pointerdown', (e) => {
  touchLookPointerId = e.pointerId;
  touchLookLastX = e.clientX; touchLookLastY = e.clientY;
  e.preventDefault();
});
touchLookZoneEl.addEventListener('pointermove', (e) => {
  if (e.pointerId !== touchLookPointerId) return;
  const dx = e.clientX - touchLookLastX, dy = e.clientY - touchLookLastY;
  touchLookLastX = e.clientX; touchLookLastY = e.clientY;
  applyFirstPersonLook(dx, dy, (currentPlayerSettings.mouseSensitivity || 0.0022) * 2.2); // touch drags cover fewer pixels than a mouse for the same intended turn, so scaled up
  e.preventDefault();
});
function endTouchLook(e) { if (e.pointerId === touchLookPointerId) touchLookPointerId = null; }
touchLookZoneEl.addEventListener('pointerup', endTouchLook);
touchLookZoneEl.addEventListener('pointercancel', endTouchLook);

// --- Behaviors ---
// A small, fixed trigger/action set (not a general visual scripting system):
// On Click / On Enter (proximity to the camera) -> Show Message / Play Sound.
// This is the actual "is no-code feasible" test, not just scene composition.

const toastEl = document.getElementById('game-toast');
let toastTimer = null;
function showToast(text) {
  toastEl.textContent = text;
  toastEl.classList.add('visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove('visible'), 1800);
}

function escapeHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// Win/Lose: the primitive that turns "a scene with behaviors" into "a game
// with an end state." Freezes further trigger processing once fired.
const endOverlayEl = document.getElementById('end-overlay');
const endOverlayTitleEl = document.getElementById('end-overlay-title');
const pauseOverlayEl = document.getElementById('pause-overlay');
let gameEnded = false;

// Pause Menu (Wave 4) -- reuses the existing pause overlay/App.pause-resume
// plumbing entirely (no second "is input blocked" concept, same reasoning
// the Start Screen and Dialogue already followed); this just adds real
// buttons to the overlay that was previously a static "Paused" message with
// nothing to click. Restart Level and Main Menu both reuse
// switchLevelWithTransition -- the exact function the Restart Level/Switch
// Level ACTIONS already call -- so a Pause Menu click and a Node-Graph-
// triggered Restart Level behave identically, not two implementations.
document.getElementById('pause-resume-btn').addEventListener('click', () => { if (app.paused) app.resume(); });
document.getElementById('pause-restart-btn').addEventListener('click', () => {
  if (app.paused) app.resume();
  switchLevelWithTransition(currentLevelIndex, true);
});
document.getElementById('pause-mainmenu-btn').addEventListener('click', () => {
  if (app.paused) app.resume();
  switchLevelWithTransition(startLevelIndex, true);
  showStartScreenIfConfigured();
});

// Project Settings / Game Quality Options (Wave 4) -- real engine-backed
// options, not sliders that change nothing: Volume drives the actual
// AudioEngine category gains (Opus.AudioEngine.setVolume, already public,
// previously unreachable from the no-code editor path since it was only
// ever wired to the opt-in Opus.HUD chrome this editor doesn't use),
// Quality toggles the actual device-pixel-ratio cap App already uses
// internally for exactly this purpose, and Fullscreen calls the standard
// browser Fullscreen API directly. Lives on the Pause Menu rather than a
// separate Settings screen -- one bounded surface, not a second app-routing
// concept, per the explicit "do not build full app routing" constraint.
let masterVolume = 1;
function applyMasterVolume(v) {
  masterVolume = Math.max(0, Math.min(1, v));
  for (const category of ['music', 'sfx', 'ambient']) app.audio.setVolume(category, masterVolume);
  app.audio.setMuted(masterVolume <= 0);
}
function renderQualityButton() {
  const label = `Quality: ${app.settings.get('quality') === 'low' ? 'Low' : 'High'}`;
  for (const id of ['pause-quality-btn', 'mainmenu-quality-btn']) {
    const btn = document.getElementById(id);
    if (btn) btn.textContent = label;
  }
}
document.getElementById('pause-volume').addEventListener('input', (e) => applyMasterVolume(parseFloat(e.target.value)));
document.getElementById('pause-quality-btn').addEventListener('click', () => {
  const currentlyHigh = app.settings.get('quality') !== 'low';
  app.setQuality(currentlyHigh ? 'low' : 'high');
  renderQualityButton();
});
document.getElementById('pause-fullscreen-btn').addEventListener('click', () => {
  if (document.fullscreenElement) document.exitFullscreen();
  else canvas.requestFullscreen().catch(() => showStatus("Fullscreen isn't available"));
});
document.getElementById('pause-volume').value = masterVolume;
renderQualityButton();

function endGame(result) {
  if (gameEnded) return;
  gameEnded = true;
  endOverlayEl.className = result;
  endOverlayEl.classList.add('visible');
  // Per-level Win/Lose title/message (Win/Lose Screen panel) override the
  // defaults below when set, so a project that never touches those fields
  // behaves exactly as before this existed.
  const configuredTitle = result === 'win' ? currentUiConfig.winTitle : currentUiConfig.loseTitle;
  const configuredMessage = result === 'win' ? currentUiConfig.winMessage : currentUiConfig.loseMessage;
  endOverlayTitleEl.textContent = configuredTitle || (result === 'win' ? '🏆 You Win!' : '💀 Game Over');
  document.getElementById('end-overlay-message').textContent = configuredMessage || '';
  if (result === 'win') {
    app.audio.playBlip({ frequency: 523, duration: 0.14, type: 'triangle' });
    setTimeout(() => { if (!app.destroyed) app.audio.playBlip({ frequency: 784, duration: 0.3, type: 'triangle' }); }, 120);
  } else {
    app.audio.playBlip({ frequency: 160, duration: 0.4, type: 'sawtooth' });
  }
}

document.getElementById('end-overlay-btn').addEventListener('click', () => setEditorVisible(true));

// Objective/progress display: a persistent counter companion to Win/Lose
// (a toast fades, a live "Crates: 2/3" shouldn't). Reset on each play
// session, updatable from the fixed action or from a script via game.setObjective.
const objectiveEl = document.getElementById('game-objective');
function setObjective(text) {
  if (!text) {
    objectiveEl.classList.remove('visible');
    return;
  }
  objectiveEl.textContent = text;
  objectiveEl.classList.add('visible');
}

// --- Shared action-execution core ---
// Single source of truth for what each action TYPE does. Both the fixed
// trigger/action dropdown (runAction, below) and the Node Graph
// (runGraphActionNode, below) dispatch into this same table via
// executeAction -- so a new or fixed behavior happens in exactly one place
// instead of two parallel implementations drifting apart. GRAPH_NODE_TYPES
// (further down) is itself generated FROM this table's action entries.
//
// field.type: 'text' | 'number' | 'color' | 'checkbox' | 'target'.
// 'target' renders as a dropdown of placed items and is resolved through
// findItemById, so it survives rename/duplicate/Save-Load/Undo-Redo and
// no-ops gracefully if the target was since deleted -- see the Object
// References section near the top of this file. An action with no
// 'targetId' field, or one left as '(self)', acts on the item whose
// behavior fired it.
//
// `legacy: true` marks the original fixed-list actions, which persist as a
// flat `behavior.param` string (existing saved Crate Run projects already
// use this shape -- must keep loading unchanged). Newer actions persist as
// `behavior.params`, an object, since they take more than one field.
function resolveTarget(params, item) {
  if (!params || !params.targetId) return item;
  return findItemById(params.targetId) || null;
}
function targetEntity(target) {
  return target && target.kind === 'cube' ? target.entity : null;
}

// Player Health: a first-class pair of __gameState keys (still plain named
// counters underneath, see the comment above decrementCounter) that every
// health action reads/writes through this one init path, so health always
// exists with a valid maxHealth by the time anything touches it, regardless
// of whether an On Start behavior set it up first. maxHealthDefault comes
// from the active level's player settings (Player panel), defaulting to 100
// for projects/levels that never set one.
let simElapsed = 0;
// Tween animation -- see the moveTo/rotateTo/scaleTo actions above.
let activeTweens = [];
function easeValue(t, easing) {
  if (easing === 'easeIn') return t * t;
  if (easing === 'easeOut') return 1 - (1 - t) * (1 - t);
  if (easing === 'easeInOut') return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
  return t; // linear
}
function startTween(entity, property, from, to, duration, easing) {
  activeTweens = activeTweens.filter((tw) => !(tw.entity === entity && tw.property === property));
  activeTweens.push({ entity, property, from, to, duration: Math.max(0.01, parseFloat(duration) || 1), elapsed: 0, easing: easing || 'linear' });
}
// --- Property Animation (Wave 4) ---
// Generalizes Tweens into reusable, editor-authored clips instead of a
// single fire-and-forget move -- deliberately property animation only, NOT
// skeletal (see the glTF skeletal-animation utility gate below). Reuses
// `easeValue` (the exact same easing curve Tweens already use) so a clip's
// per-segment easing looks and feels identical to a Move To (Tween), not a
// second animation "feel" to learn.
//
// A clip lives on the cube item itself (`item.animationClips`, plain
// serializable data -- keyframe values are arrays/numbers, never live Vec3
// references). Playback state (`item._anim`) is intentionally NOT part of
// that data and never serialized -- it's runtime-only, the same "clone
// deeply for data, never persist live playback" split `spawnerState` and
// the hierarchy tick token already established.
function sampleAnimationTrack(keyframes, t, isVec3) {
  if (!keyframes || keyframes.length === 0) return null;
  const sorted = keyframes; // already kept time-sorted by the editor UI
  if (sorted.length === 1 || t <= sorted[0].t) return sorted[0].value;
  if (t >= sorted[sorted.length - 1].t) return sorted[sorted.length - 1].value;
  for (let i = 0; i < sorted.length - 1; i++) {
    const a = sorted[i], b = sorted[i + 1];
    if (t >= a.t && t <= b.t) {
      const localT = (b.t - a.t) > 0 ? (t - a.t) / (b.t - a.t) : 1;
      const et = easeValue(localT, b.easing);
      if (isVec3) return [a.value[0] + (b.value[0] - a.value[0]) * et, a.value[1] + (b.value[1] - a.value[1]) * et, a.value[2] + (b.value[2] - a.value[2]) * et];
      return a.value + (b.value - a.value) * et;
    }
  }
  return sorted[sorted.length - 1].value;
}
function updateAnimations(dt) {
  for (const item of placed) {
    if (item.kind !== 'cube' || !item._anim || !item._anim.playing) continue;
    // Preview (Animation Editor's own Play button) plays the WORKING,
    // not-yet-saved clip directly -- `clipIndex: -1` + `_previewClip` is
    // never a shape a real Play Animation action produces (its clipIndex
    // always comes from a real array lookup), so there's no ambiguity.
    const clip = item._anim._previewClip || (item.animationClips && item.animationClips[item._anim.clipIndex]);
    if (!clip) { item._anim.playing = false; continue; }
    item._anim.elapsed += dt;
    let t = item._anim.elapsed;
    let ended = false;
    if (clip.loop === 'loop') {
      t = clip.duration > 0 ? t % clip.duration : 0;
    } else if (clip.loop === 'pingpong') {
      const cycle = clip.duration * 2;
      const m = cycle > 0 ? t % cycle : 0;
      t = m <= clip.duration ? m : cycle - m;
    } else if (t >= clip.duration) { t = clip.duration; ended = true; }
    const tr = clip.tracks;
    if (tr.position && tr.position.length) { const v = sampleAnimationTrack(tr.position, t, true); item.entity.position.set(v[0], v[1], v[2]); }
    if (tr.rotationY && tr.rotationY.length) item.entity.rotationY = sampleAnimationTrack(tr.rotationY, t, false);
    if (tr.scale && tr.scale.length) { const v = sampleAnimationTrack(tr.scale, t, true); item.entity.scale.set(v[0], v[1], v[2]); }
    if (tr.visible && tr.visible.length) {
      let v = tr.visible[0].value;
      for (const kf of tr.visible) if (kf.t <= t) v = kf.value;
      item.entity.visible = v;
    }
    if (ended) item._anim.playing = false;
  }
}

// --- Animation Editor (Wave 4) ---
// A simple scrollable list of track cards, not a timeline ruler -- same
// reasoning the Dialogue Editor already used for its own "not a node
// canvas" call (a clip's data is small; a full Dope-Sheet-style UI would be
// far more surface than authoring 2-6 keyframes actually needs). Values are
// never hand-typed: "Add Keyframe" always captures the object's CURRENT
// live transform at an authored time, upserting (replacing) any existing
// keyframe at that exact time -- position the object, hit Add, matching how
// most simple keyframe tools actually work, and sidestepping a large grid
// of editable number inputs per keyframe.
const ANIM_TRACK_DEFS = [
  { key: 'position', label: 'Position', kind: 'vec3', capture: (e) => [e.position.x, e.position.y, e.position.z], format: (v) => `(${v[0].toFixed(2)}, ${v[1].toFixed(2)}, ${v[2].toFixed(2)})`, apply: (e, v) => e.position.set(v[0], v[1], v[2]) },
  { key: 'rotationY', label: 'Rotation Y', kind: 'number', capture: (e) => e.rotationY, format: (v) => `${(v * 180 / Math.PI).toFixed(1)}°`, apply: (e, v) => { e.rotationY = v; } },
  { key: 'scale', label: 'Scale', kind: 'vec3', capture: (e) => [e.scale.x, e.scale.y, e.scale.z], format: (v) => `(${v[0].toFixed(2)}, ${v[1].toFixed(2)}, ${v[2].toFixed(2)})`, apply: (e, v) => e.scale.set(v[0], v[1], v[2]) },
  { key: 'visible', label: 'Visibility', kind: 'bool', capture: (e) => e.visible, format: (v) => (v ? 'Visible' : 'Hidden'), apply: (e, v) => { e.visible = v; } },
];
function defaultAnimationClip() { return { name: '', duration: 2, loop: 'once', tracks: { position: [], rotationY: [], scale: [], visible: [] } }; }
let animEditorState = null; // { item, clipIndex (null = new clip), clip (working deep clone) }
function openAnimationEditor(item, clipIndex) {
  const clip = (clipIndex != null && item.animationClips && item.animationClips[clipIndex])
    ? JSON.parse(JSON.stringify(item.animationClips[clipIndex]))
    : defaultAnimationClip();
  for (const def of ANIM_TRACK_DEFS) if (!clip.tracks[def.key]) clip.tracks[def.key] = [];
  animEditorState = { item, clipIndex: clipIndex != null ? clipIndex : null, clip };
  document.getElementById('animation-editor-modal').classList.add('visible');
  renderAnimationEditor();
}
function closeAnimationEditor() {
  if (animEditorState) animEditorState.item._anim = null; // stop any live Preview
  document.getElementById('animation-editor-modal').classList.remove('visible');
  animEditorState = null;
}
function renderAnimationEditor() {
  const { item, clip } = animEditorState;
  document.getElementById('anim-clip-name').value = clip.name;
  document.getElementById('anim-clip-duration').value = clip.duration;
  document.getElementById('anim-clip-loop').value = clip.loop;
  document.getElementById('anim-clip-name').oninput = (e) => { clip.name = e.target.value; };
  document.getElementById('anim-clip-duration').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) clip.duration = v; };
  document.getElementById('anim-clip-loop').onchange = (e) => { clip.loop = e.target.value; };
  document.getElementById('anim-preview-btn').onclick = () => {
    item._anim = { clipIndex: -1, elapsed: 0, playing: true };
    item._anim._previewClip = clip; // Preview plays the WORKING clip, not any saved one -- see updateAnimations' -1 special case below
  };

  document.getElementById('anim-track-list').innerHTML = ANIM_TRACK_DEFS.map((def) => {
    const kfs = clip.tracks[def.key];
    const rows = kfs.map((kf, i) => `
      <div class="anim-keyframe-row">
        <input type="number" step="0.1" min="0" data-kf-time="${def.key}:${i}" value="${kf.t}">s
        <span style="flex:1">${escapeHtml(def.format(kf.value))}</span>
        ${def.kind !== 'bool' ? `<select data-kf-easing="${def.key}:${i}">${['linear', 'easeIn', 'easeOut', 'easeInOut'].map((e) => `<option value="${e}"${kf.easing === e ? ' selected' : ''}>${e}</option>`).join('')}</select>` : ''}
        <button data-kf-delete="${def.key}:${i}">✕</button>
      </div>`).join('');
    return `<div class="anim-track-card">
      <strong>${def.label}</strong> <span style="color:#66759a;font-size:11px">(${kfs.length} keyframe${kfs.length === 1 ? '' : 's'})</span>
      <div>${rows || '<p style="color:#66759a;font-size:11px;margin:4px 0">No keyframes yet.</p>'}</div>
      <div style="display:flex;gap:6px;align-items:center;margin-top:8px">
        <input type="number" id="add-time-${def.key}" step="0.1" min="0" value="0" style="width:56px">s
        <button data-add-kf="${def.key}" class="toolbar-btn" style="margin-bottom:0">+ Add Keyframe (captures live ${def.label})</button>
      </div>
    </div>`;
  }).join('');

  document.querySelectorAll('[data-kf-time]').forEach((el) => {
    el.onchange = (e) => {
      const [key, i] = el.dataset.kfTime.split(':');
      const v = parseFloat(e.target.value);
      if (!Number.isNaN(v) && v >= 0) { clip.tracks[key][Number(i)].t = v; clip.tracks[key].sort((a, b) => a.t - b.t); renderAnimationEditor(); }
    };
  });
  document.querySelectorAll('[data-kf-easing]').forEach((el) => {
    el.onchange = (e) => { const [key, i] = el.dataset.kfEasing.split(':'); clip.tracks[key][Number(i)].easing = e.target.value; };
  });
  document.querySelectorAll('[data-kf-delete]').forEach((el) => {
    el.onclick = () => { const [key, i] = el.dataset.kfDelete.split(':'); clip.tracks[key].splice(Number(i), 1); renderAnimationEditor(); };
  });
  document.querySelectorAll('[data-add-kf]').forEach((el) => {
    el.onclick = () => {
      const key = el.dataset.addKf;
      const def = ANIM_TRACK_DEFS.find((d) => d.key === key);
      const t = parseFloat(document.getElementById(`add-time-${key}`).value) || 0;
      const value = def.capture(item.entity);
      const track = clip.tracks[key];
      const existingIdx = track.findIndex((kf) => Math.abs(kf.t - t) < 0.001);
      const kf = { t, value, easing: 'linear' };
      if (existingIdx !== -1) track[existingIdx] = kf; else track.push(kf);
      track.sort((a, b) => a.t - b.t);
      renderAnimationEditor();
    };
  });
}
document.getElementById('animation-editor-cancel-btn').addEventListener('click', closeAnimationEditor);
document.getElementById('animation-editor-save-btn').addEventListener('click', () => {
  const { item, clip, clipIndex } = animEditorState;
  if (!clip.name.trim()) { showStatus('Animation clip needs a name'); return; }
  pushUndo();
  item.animationClips = item.animationClips || [];
  if (clipIndex != null) item.animationClips[clipIndex] = clip; else item.animationClips.push(clip);
  closeAnimationEditor();
  renderInspector();
  showStatus(`Saved animation clip "${clip.name}"`);
});

function tickTweens(dt) {
  if (activeTweens.length === 0) return;
  const stillActive = [];
  for (const tw of activeTweens) {
    if (tw.entity.destroyed) continue; // dropped, not resumed -- the object is gone
    tw.elapsed += dt;
    const t = Math.min(1, tw.elapsed / tw.duration);
    const et = easeValue(t, tw.easing);
    if (tw.property === 'position') tw.entity.position = tw.from.add(tw.to.sub(tw.from).scale(et));
    else if (tw.property === 'scale') tw.entity.scale.set(tw.from.x + (tw.to.x - tw.from.x) * et, tw.from.y + (tw.to.y - tw.from.y) * et, tw.from.z + (tw.to.z - tw.from.z) * et);
    else if (tw.property === 'rotationY') tw.entity.rotationY = tw.from + (tw.to - tw.from) * et;
    if (t < 1) stillActive.push(tw);
  }
  activeTweens = stillActive;
}
// --- Runtime multi-object Prefab Assemblies (Wave 5) -----------------
// Wave 4's own documented gap: Spawner/Spawn Prefab only ever instantiated
// a multi-object prefab's ROOT record, dropping every other piece. Closed
// by reusing instantiatePrefabAssembly -- the exact function design-time
// prefab placement already uses, itself built on remapObjectIds, the ONE
// shared id-remapping mechanism (fresh ids + every internal reference
// rewritten: parentId, AI targetId, Camera lookAtTargetId, Waypoint
// connections, animation Play-Animation targetId, any ACTION_TYPES field of
// type 'target'/'cameraPreset') -- no second remap implementation for the
// runtime path. A single-object prefab (the common case: one Bolt, one
// simple Hunter) still takes the exact one-record path it always did.
let nextAssemblyId = 1;
function generateAssemblyId() { return `assembly${nextAssemblyId++}`; }
// Wave 8 (Priority M, Sections 74-76): `paramOverrides` is optional --
// `{paramId: value | {min, max}}`. A plain value is a fixed override,
// exactly like an ordinary placed instance's own `prefabParams`. A
// `{min, max}` range is resolved through a deterministic seeded RNG
// (`mulberry32`, the same PRNG Wave 7's Scatter already established) so
// two spawns given the SAME `rngSeed` produce the SAME random value --
// "deterministically seeded randomness preferred," per the spec's own
// explicit requirement -- never `Math.random()`. Numeric ranges only
// (Section 75's own explicit bound).
function resolveSpawnParamOverrides(paramOverrides, rngSeed) {
  if (!paramOverrides) return undefined;
  const rng = mulberry32((rngSeed >>> 0) || 1);
  const resolved = {};
  for (const key in paramOverrides) {
    const v = paramOverrides[key];
    resolved[key] = (v && typeof v === 'object' && v.min != null && v.max != null) ? (v.min + rng() * (v.max - v.min)) : v;
  }
  return resolved;
}
function spawnPrefabAssembly(prefab, position, paramOverrides, rngSeed) {
  let newItems;
  if (prefab.records && prefab.records.length > 0) {
    newItems = instantiatePrefabAssembly(prefab, position);
  } else {
    const single = instantiateCubeRecord(prefab.record, position);
    single.id = generateItemId();
    newItems = [single];
    newItems._newRootId = single.id;
  }
  // Assembly bookkeeping (Wave 5, section 12) only exists for a GENUINE
  // multi-object spawn -- a single-object spawn never gets an assemblyId,
  // so every pre-Wave-5 single-prefab Spawn Prefab/Spawner behaves exactly
  // as before (nothing new to cascade-destroy, nothing new to track).
  const assemblyId = newItems.length > 1 ? generateAssemblyId() : null;
  const rootId = newItems._newRootId;
  for (const it of newItems) {
    it.runtimeSpawned = true;
    if (assemblyId) { it.assemblyId = assemblyId; it.assemblyRootId = rootId; }
    addPlaced(it);
    wireItemTrigger(it);
  }
  hierarchyTickToken++;
  updateHierarchyTransforms();
  const rootItem = newItems.find((it) => it.id === rootId) || newItems[0];
  if (paramOverrides) rootItem.prefabParams = { ...(rootItem.prefabParams || {}), ...resolveSpawnParamOverrides(paramOverrides, rngSeed) };
  applyPrefabParameters(prefab, rootItem);
  return { rootItem, members: newItems, assemblyId };
}
// Destroys every member of `item`'s assembly (or, for an item with no
// assembly, just `item` itself -- the exact old single-object behavior,
// unchanged). This is intentionally a SEPARATE function from
// removeItemFromScene rather than making that function itself cascade --
// removeItemFromScene is called from many existing places (Destroy Object
// action, general cleanup) whose current single-object semantics must not
// silently change; assembly-aware destruction is opt-in, used explicitly by
// the new Destroy Assembly action and by the combat-death path below (an
// assembly member's Object Health reaching 0 is the dogfood's own "no
// orphan children after a spawned enemy is destroyed" requirement).
// Wave 6 (Priority M): deeper character gameplay -- animated locomotion/
// attack/death, the exact character-clip-NAME-mapping follow-up Priority C's
// own CHANGELOG entry named as a deliberate, real, deferred piece rather
// than a silently-shipped gap. Bounded to AI-driven (entity.ai) skinned
// characters -- the Player is a separate authoring surface (Player Settings,
// not a placed Inspector object) with no skinned-mesh option today, so
// player-character locomotion animation is explicitly out of this pass's
// scope (see the CHANGELOG entry for this priority). Every piece here is a
// clip-NAME convention (case-insensitive substring match against the
// skin's own imported clip names) layered on top of the EXISTING
// entity.animationClip/skin machinery (Priority C) -- no new engine surface.
function findCharacterClip(entity, keywords) {
  if (!entity.skin) return null;
  for (let i = 0; i < entity.skin.clips.length; i++) {
    const lower = entity.skin.clips[i].name.toLowerCase();
    if (keywords.some((k) => lower.includes(k))) return i;
  }
  return null;
}
// Wave 7 (Priority B): bounded per-clip Animation Events -- {id, clipIndex,
// time, action, params} records living on a skinned ASSET's own
// `animationEvents` array (the exact same asset-level-authoring-metadata
// pattern Priority A's sockets already established: shared by every placed
// instance, never mutating the imported clip data). Effects reuse
// ACTION_TYPES/executeAction, the SAME action language every ordinary
// Behavior already uses -- no arbitrary JS callback, no second action
// system. A missing/undefined assetId, asset, or empty animationEvents is
// always a silent no-op, so every project that never authors an event is
// completely unaffected.
//
// Crossing detection is entirely generic, driven off two snapshots of
// entity.animationTime (before/after THIS frame's engine-level
// Entity.update() already advanced it, per 11-entity.js), stored directly
// on the entity itself (`_aeClip`/`_aeTime`, so a fresh entity or one with
// no events costs nothing beyond one property compare):
//  - Ordinary playback: fires every event with prevTime < event.time <=
//    currentTime (half-open on the low end, so re-ticking at the exact same
//    time twice in a row -- paused/dt=0 -- never double-fires).
//  - Looping: Entity.update's own `animationTime %= clip.duration` makes
//    currentTime < prevTime exactly once per wrap. Modeled as the SAME
//    half-open interval unrolled across the wrap: (prevTime, duration] then
//    [0, currentTime] -- the second segment's 0 is INCLUDED (the wrap point
//    itself), so an event authored at time===0 fires exactly once per full
//    loop, never twice at the boundary (the spec's own explicit
//    "no duplicate at wrap boundary" requirement) and never from the
//    non-wrap branch (which can only ever match event.time > prevTime >= 0).
//  - A genuine clip SWITCH (this frame's animationClip differs from what was
//    tracked last tick, including the very first tick a character is ever
//    seen) is treated as a fresh start: no retroactive firing across the
//    switch, tracking simply resyncs to the new clip/time and returns.
//  - Crossfade needs no special-casing at all: Entity.update advances
//    `animationClip`/`animationTime` to the NEW clip's own timeline
//    immediately on a blended switch (the old clip only fades out
//    visually via the separate `_blendFromClip` pair) -- so this function,
//    which only ever reads the entity's own current clip/time, already
//    fires purely off the new clip's real timeline during a blend, exactly
//    matching ordinary (non-blended) playback.
//  - High-dt crossing (an event's time falls strictly between prevTime and
//    currentTime after a single large frame step) is covered by the same
//    half-open interval check with no per-substep loop -- bounded
//    correctly for anything up to one full clip duration per frame; a
//    single frame so large it laps a clip more than once could still only
//    fire an event once, an accepted bounded edge case matching this
//    project's own "bounded, not a general-purpose animation state
//    machine" discipline.
function tickAnimationEvents(entity, assetId, contextItem) {
  if (!entity || !entity.skin) return;
  const asset = assetId ? findAssetById(assetId) : null;
  const events = asset && asset.animationEvents;
  const clip = entity.animationClip;
  const time = entity.animationTime;
  if (entity._aeClip !== clip) {
    entity._aeClip = clip;
    entity._aeTime = time;
    return;
  }
  if (events && events.length > 0) {
    const prev = entity._aeTime;
    const clipEvents = events.filter((e) => e.clipIndex === clip);
    if (clipEvents.length > 0) {
      if (time >= prev) {
        for (const ev of clipEvents) if (ev.time > prev && ev.time <= time) executeAction(ev.action, ev.params, contextItem);
      } else {
        const clipDef = entity.skin.clips[clip];
        const duration = clipDef ? clipDef.duration : prev;
        for (const ev of clipEvents) {
          if ((ev.time > prev && ev.time <= duration) || (ev.time >= 0 && ev.time <= time)) executeAction(ev.action, ev.params, contextItem);
        }
      }
    }
  }
  entity._aeTime = time;
}
// Switches to the clip matching `state` ('idle'/'walk'/'run') ONLY if it's
// actually different from the character's current auto-driven state --
// re-assigning the SAME clip index every frame would otherwise restart its
// animationTime to 0 every tick (Entity.update's own "a clip switch
// restarts at t=0" contract, Priority C), which would freeze a looping
// Walk cycle on frame 1 forever instead of actually playing it.
const CHARACTER_ANIM_KEYWORDS = {
  idle: ['idle'], walk: ['walk'], run: ['run', 'sprint'],
  jump: ['jump'], fall: ['fall'], // Wave 6B (Priority A/Section 5): Player-only roles -- AI locomotion has no vertical-physics concept to map these to.
  attack: ['attack', 'punch', 'shoot', 'swing'], death: ['death', 'die'],
  hit: ['hit', 'hurt', 'flinch'], // Wave 7 (Priority K)
  reload: ['reload'], // Wave 9 (Priority A/Section 12) -- Player-only, optional; duration-based reload is correct with no clip mapped at all
};
function setCharacterLocomotionState(item, state) {
  if (item._animState === state) return;
  const clipIndex = findCharacterClip(item.entity, CHARACTER_ANIM_KEYWORDS[state]);
  if (clipIndex === null) return; // no matching clip authored for this state -- leave whatever's currently playing alone
  item.entity.animationClip = clipIndex;
  item._animState = state;
}
// Attack is a brief OVERRIDE on top of locomotion, not a persistent state --
// `_animOverrideUntil` (a simElapsed timestamp) tells the locomotion driver
// below to leave the character alone until the attack clip's own duration
// has played out, then locomotion resumes picking Idle/Walk/Run normally.
function triggerCharacterAttackAnim(item) {
  if (!item.characterAnimSync || !item.entity.skin) return;
  const clipIndex = findCharacterClip(item.entity, CHARACTER_ANIM_KEYWORDS.attack);
  if (clipIndex === null) return;
  item.entity.animationClip = clipIndex;
  item._animState = 'attack';
  const duration = item.entity.skin.clips[clipIndex].duration || 0.5;
  item._animOverrideUntil = simElapsed + duration;
}
// Returns true if a Death clip was found and started -- the caller
// (applyHitDamage) uses this to decide whether to delay the actual
// destruction so the clip is visible at all, or destroy immediately as
// before (a character with no Death clip authored behaves EXACTLY like
// every character did before this priority existed -- instant removal).
function triggerCharacterDeathAnim(item) {
  if (!item.characterAnimSync || !item.entity.skin) return false;
  const clipIndex = findCharacterClip(item.entity, CHARACTER_ANIM_KEYWORDS.death);
  if (clipIndex === null) return false;
  item.entity.animationClip = clipIndex;
  item._animState = 'death';
  item._animOverrideUntil = Infinity; // death is terminal -- locomotion never resumes for a dying character
  return true;
}
function removeAssembly(item) {
  if (!item) return;
  if (!item.assemblyId) { removeItemFromScene(item); return; }
  const members = placed.filter((p) => p.assemblyId === item.assemblyId);
  for (const m of members) if (!m.entity || !m.entity.destroyed) removeItemFromScene(m);
}
// Spawner ticking -- reuses instantiateCubeRecord + wireItemTrigger, the
// exact same reconstruction Spawn Prefab/Save-Load/design-time prefab
// placement all already share, so a spawner-produced instance behaves
// identically to any other spawned/placed item (fully wired triggers/AI).
function spawnOneFromSpawner(item) {
  const opts = item.options;
  const prefab = prefabs.find((pf) => pf.name === opts.prefabName);
  if (!prefab) return;
  const angle = Math.random() * Math.PI * 2;
  const r = Math.random() * (opts.radius || 0);
  // Root placement determines the assembly's transform; scatter radius
  // applies to the root only -- children keep their authored local offsets
  // (Wave 5, section 52), not independently randomized.
  const rootRecord = prefab.records ? (prefab.records.find((rr) => rr.id === prefab.rootId) || prefab.records[0]) : prefab.record;
  const rootY = (rootRecord.position || (rootRecord.options && rootRecord.options.position))[1];
  const position = new Opus.Vec3(item.entity.position.x + Math.cos(angle) * r, rootY, item.entity.position.z + Math.sin(angle) * r);
  // Wave 8 (Priority M): each spawn gets its OWN deterministic seed derived
  // from the Spawner's own base seed + how many it has already produced --
  // the SAME Spawner replayed from the SAME save produces the SAME sequence
  // of randomized parameter values, not a fresh random draw every session.
  const { rootItem, members } = spawnPrefabAssembly(prefab, position, opts.paramOverrides, (opts.paramSeed || 1) + item.spawnerState.spawnedTotal);
  // Assembly Tagging (Wave 5, section 53): the Spawner's Tag applies to
  // EVERY member, not just the root -- the one clear default, since Count/
  // Hide/Destroy Tagged must keep finding every piece of a tagged enemy,
  // not just its root, exactly as they already do for a single-object spawn.
  if (opts.tag) for (const m of members) m.tags = [...(m.tags || []), opts.tag];
  // ONE logical spawn = the root's id, whether it's a lone object or a
  // whole assembly -- Max Active/activeIds already only ever check whether
  // this one id is still present in `placed` (see tickSpawners below), and
  // removeAssembly guarantees the root disappears exactly when the whole
  // assembly does, so no separate per-assembly counting logic is needed.
  item.spawnerState.activeIds.push(rootItem.id);
  item.spawnerState.spawnedTotal += 1;
}
// --- Projectiles (Wave 4) ---
// A bounded projectile system built on primitives that already exist --
// prefab instantiation (the exact same instantiateCubeRecord/addPlaced/
// wireItemTrigger sequence Spawn Prefab and Spawner already use, so a
// fired projectile is indistinguishable from any other placed/spawned
// object -- has its own behaviors, can BE a Trigger Volume, etc.) and
// Object Health (above) for what it hits. No ballistic solver, no
// continuous-collision sweep -- a per-frame sphere-distance check against
// solids/Player/tagged targets, same bounded spirit as every other
// collision primitive already in this engine (see API-FRICTION.md's own
// "no sweep/CCD" notes on terrain/platform collision).
let activeProjectiles = [];
function fireProjectile(prefabName, origin, direction, speed, damage, ownerTag, lifetime, radius, gravity, targetTag, impactEffectConfig) {
  const prefab = prefabs.find((pf) => pf.name === prefabName);
  if (!prefab) return;
  const spawned = instantiateCubeRecord(prefab.record, origin.clone());
  spawned.runtimeSpawned = true;
  spawned.id = generateItemId();
  addPlaced(spawned);
  wireItemTrigger(spawned);
  activeProjectiles.push({
    item: spawned,
    velocity: direction.clone().normalize().scale(speed),
    damage, ownerTag: ownerTag || '', targetTag: targetTag || '',
    lifetime: lifetime > 0 ? lifetime : 3, radius: radius > 0 ? radius : 0.3, gravity: gravity || 0,
    // Wave 9D (Priority B/Section 17-19): optional weapon impact feedback,
    // remembered on the projectile itself (not just at fire time) since a
    // Projectile's hit happens later, asynchronously, inside tickProjectiles
    // -- `undefined` for every non-weapon/AI-fired projectile, a complete
    // no-op for all of them.
    impactEffectConfig: impactEffectConfig || null,
  });
}
function removeProjectile(proj) {
  const idx = activeProjectiles.indexOf(proj);
  if (idx !== -1) activeProjectiles.splice(idx, 1);
  if (!proj.item.entity.destroyed) removeItemFromScene(proj.item);
}
// Shared damage resolution (Wave 5, Priority F/section 33) -- both weapon
// modes (Projectile and the new Hitscan below) resolve a hit through this
// ONE function, per the explicit "do not duplicate damage logic" spec
// requirement. `hit` is the same `{type, item}` shape tickProjectiles
// already produces from its own candidate-collection/sort.
// Wave 7 (Priority K, Sections 65-67): bounded hit-reaction support --
// `knockback`/`sourcePos` are both optional (default 0/null), so every
// pre-Wave-7 call site (unchanged, only ever passing `(hit, damage)`)
// keeps its exact old behavior. No ragdolls, no full physics impulse
// system -- a kinematic velocity/position push only.
function applyHitReaction(item, knockback, sourcePos) {
  if (!knockback || !sourcePos) return;
  const dir = item.entity.position.sub(sourcePos);
  dir.y = 0;
  const len = dir.length();
  const pushDir = len > 1e-6 ? dir.scale(1 / len) : new Opus.Vec3(1, 0, 0);
  item.entity.position.set(item.entity.position.x + pushDir.x * knockback, item.entity.position.y, item.entity.position.z + pushDir.z * knockback);
}
// Hit clip -- temporary override like Attack, EXCEPT Death always wins:
// only called from the "still alive after this hit" branch below, never
// from the death branch, so a lethal hit's Death clip can never be
// pre-empted or interrupted by a Hit clip racing it.
function triggerCharacterHitAnim(item) {
  if (!item.characterAnimSync || !item.entity.skin) return;
  const clipIndex = findCharacterClip(item.entity, CHARACTER_ANIM_KEYWORDS.hit);
  if (clipIndex === null) return;
  item.entity.animationClip = clipIndex;
  item._animState = 'hit';
  const duration = item.entity.skin.clips[clipIndex].duration || 0.3;
  item._animOverrideUntil = simElapsed + duration;
}
// Flash/tint -- a brief bright tint reusing the entity's own existing
// `.color` field (no new renderer path), reverted via the SAME
// `deferredCalls` mechanism Death-animation delay already established,
// not a second scheduling system.
function triggerHitFlash(item) {
  if (!item.entity || !item.entity.color) return;
  if (item._hitFlashOriginalColor === undefined) item._hitFlashOriginalColor = item.entity.color.slice();
  item.entity.color = [1, 1, 1];
  const target = item;
  deferredCalls.push({ fireAt: simElapsed + 0.12, fn: () => { if (target.entity && target._hitFlashOriginalColor) target.entity.color = target._hitFlashOriginalColor; } });
}
function applyHitDamage(hit, damage, knockback, sourcePos) {
  if (hit.type === 'player') {
    ensureHealthInit();
    // Wave 6B (Priority A/Section 9): same wasAlreadyDead transition guard
    // Priority M's own object-death fix already established -- combat
    // damage landing on an already-0-health player (its own Death-animation
    // grace period, or just repeated hits after Lose was already supposed
    // to fire) must not re-trigger the death sequence a second time.
    const playerWasAlreadyDead = window.__gameState.health <= 0;
    if (damage > 0 && !playerWasAlreadyDead) triggerPlayerDamageFeedback(); // Wave 9 (Priority C/Section 43)
    window.__gameState.health = Math.max(0, window.__gameState.health - damage);
    if (window.__gameState.health <= 0 && !playerWasAlreadyDead) {
      // No automatic Lose here otherwise -- exactly the pre-existing
      // behavior (an author wires their own "Health At Most(0) -> Lose"
      // Node Graph condition, the same established pattern object death
      // used before Priority M). A mapped Death clip on a skinned Player
      // Visual is a NEW, opt-in addition: play it, freeze the controller,
      // and show Lose after the clip's own duration -- never a silent
      // change to a project that has no skinned Player configured.
      if (triggerPlayerDeathAnim()) {
        const duration = playerVisualEntity.skin.clips[playerVisualEntity.animationClip].duration || 1;
        playerFrozen = true;
        deferredCalls.push({ fireAt: simElapsed + duration, fn: () => { if (!gameEnded) endGame('lose'); } });
      }
    } else if (knockback && sourcePos && player) {
      // Wave 7 (Priority K): "Player controller adds to current velocity" --
      // only on a non-lethal hit (Death above already ends/freezes movement
      // its own way), added directly to `player.velocity`, the exact state
      // field every Player Controller's own per-frame integration already
      // reads, so knockback participates in normal physics the very next tick.
      const dir = player.entity.position.sub(sourcePos);
      dir.y = 0;
      const len = dir.length();
      const pushDir = len > 1e-6 ? dir.scale(1 / len) : new Opus.Vec3(1, 0, 0);
      player.velocity = (player.velocity || new Opus.Vec3()).add(pushDir.scale(knockback));
    }
  } else if (hit.type === 'object') {
    ensureObjectHealthInit(hit.item);
    // Wave 6 (Priority M) found this while dogfooding Iron Arena, not
    // assumed from reading the code alone: before the Death-animation delay
    // existed, a dead object was removed from `placed` (and therefore un-
    // hittable) the SAME frame its health reached 0, so "health just hit 0"
    // and "health is already at 0" were never distinguishable in practice --
    // this branch could only ever run once per object. Once a dying
    // character can sit in `placed` for a real duration (its Death clip's
    // length) before actually being removed, it's hittable again during
    // that window -- re-entering this branch on every subsequent hit,
    // awarding a bonus kill and queueing a redundant deferred removal each
    // time. `wasAlreadyDead` gates the kill/animation/removal logic to the
    // one genuine alive-to-dead TRANSITION, not every hit that happens to
    // land while health is already at (or clamped to) 0.
    const wasAlreadyDead = hit.item.health.current <= 0;
    hit.item.health.current = Math.max(0, hit.item.health.current - damage);
    if (hit.item.health.current <= 0 && !wasAlreadyDead) {
      // Same fixed-name 'kills' counter and assembly-aware cleanup
      // tickProjectiles' own hit handling already established.
      window.__gameState = window.__gameState || {};
      window.__gameState.kills = (window.__gameState.kills || 0) + 1;
      // Wave 6 (Priority M): a character with a real Death clip authored
      // plays it and destroys itself a moment later, instead of vanishing
      // the instant health reaches 0 -- a character with no Death clip (the
      // exact behavior of every enemy in every project saved before this
      // priority existed) is destroyed immediately, unchanged.
      if (triggerCharacterDeathAnim(hit.item)) {
        const duration = hit.item.entity.skin.clips[hit.item.entity.animationClip].duration || 1;
        const deadItem = hit.item;
        deferredCalls.push({ fireAt: simElapsed + duration, fn: () => { if (placed.includes(deadItem)) removeAssembly(deadItem); } });
      } else {
        removeAssembly(hit.item);
      }
    } else if (!wasAlreadyDead) {
      // Wave 7 (Priority K): a non-lethal hit on a still-alive character --
      // Hit clip (only reachable from THIS branch, never the death one
      // above, so Death always wins over Hit on a simultaneously-lethal
      // hit), flash/tint, and a simple AI position knockback push.
      triggerCharacterHitAnim(hit.item);
      triggerHitFlash(hit.item);
      applyHitReaction(hit.item, knockback, sourcePos);
    }
  }
}
// Hitscan (Wave 5, Priority F/section 33) -- an INSTANT ray query (no
// travel time, no visible projectile object) using the exact same
// raySphere/rayAABB primitives and nearest-hit-wins ordering
// tickProjectiles' own swept check already uses, just over one full-length
// ray instead of one frame's movement segment. Returns the hit (or null),
// same shape tickProjectiles produces, so a caller (fireAttack, an Enemy
// Ranged Attack extension, a future Node Graph action) can inspect what
// was hit without re-deriving it.
// Wave 9D (Priority B, Sections 13-21): the last bounded "feel" layer for
// Weapons 2.0 -- muzzle/impact feedback. Reuses the existing Particle
// Emitter (`app.createEmitter`/`.emit(count)`, the SAME primitive the
// Hovercraft's own boost exhaust/spray already uses in burst mode via
// `rate: 0` + a manual `.emit()` call) and `app.audio.playBuffer` -- no new
// VFX graph, no new audio system. A transient burst emitter is created,
// fires its particles once, and is scheduled for removal once its own
// longest particle life has definitely elapsed (Section 21's own explicit
// "no new permanent scene objects" -- `app.removeEmitter` via the existing
// generic `deferredCalls` scheduler, the same one Priority M's death-
// animation delay and every Sequence Delay already use).
function spawnTransientBurst(position, color) {
  const emitter = app.createEmitter({ position: position.clone(), rate: 0, life: [0.15, 0.35], riseSpeed: [0.6, 1.6], spread: 0.18, size: [0.03, 0.09], color: color || [1, 0.8, 0.3], gravity: -0.5, maxParticles: 24 });
  emitter.emit(12);
  deferredCalls.push({ fireAt: simElapsed + 0.5, fn: () => { try { app.removeEmitter(emitter); } catch (e) {} } });
}
function playWeaponEffectAudio(assetId, position) {
  if (!assetId) return;
  const asset = findAudioAssetById(assetId);
  if (asset && asset.audioBuffer) app.audio.playBuffer(asset.audioBuffer, { volume: 0.7, position: position || undefined });
}
// Wave 9D (Priority B/Section 14): resolves the SAME actual firing origin
// the weapon already uses (Wave 7's own `resolveMuzzleOrigin` -- configured
// muzzle Socket, else Player root) -- effects never get a second,
// independently-guessed origin.
function triggerMuzzleEffect(weapon, origin) {
  playWeaponEffectAudio(weapon.fireAudioAssetId, origin);
  if (weapon.muzzleEffect) spawnTransientBurst(origin, weapon.muzzleEffectColor ? hexToRgb(weapon.muzzleEffectColor) : [1, 0.85, 0.3]);
}
// Wave 9D (Priority B/Section 17, 20): fires for EVERY hit type (Section
// 20's own explicit "works on wall/solid hit, not only damageable
// enemies") -- `impactPoint` is always the real geometric hit point the
// caller computed (Sections 18-19), never a target's center or a
// projectile's post-step position.
function triggerImpactEffect(weapon, impactPoint) {
  if (!weapon) return;
  playWeaponEffectAudio(weapon.impactAudioAssetId, impactPoint);
  if (weapon.impactEffect) spawnTransientBurst(impactPoint, weapon.impactEffectColor ? hexToRgb(weapon.impactEffectColor) : [0.9, 0.9, 0.85]);
}
// Wave 9D (Priority B/Section 22): the Tracer utility gate -- reassessed
// (Hitscan is an instant ray, genuinely invisible without one) and built:
// a tiny short-lived stretched-cube line, the exact same thin-cube-line
// technique Waypoint connection lines and Path visualization already
// established (no beam-weapon architecture, no new line-rendering
// primitive). Cleaned up via the same `deferredCalls` scheduler every
// other transient effect here uses.
function spawnHitscanTracer(origin, endPoint) {
  const delta = endPoint.sub(origin);
  const len = delta.length();
  if (len < 1e-4) return;
  const mid = origin.add(endPoint).scale(0.5);
  const angleY = Math.atan2(delta.x, delta.z);
  const horiz = Math.hypot(delta.x, delta.z);
  const angleX = Math.atan2(-delta.y, horiz);
  const tracer = app.addEntity({ mesh: cubeMesh, color: [1, 0.95, 0.7], position: mid, scale: new Opus.Vec3(0.02, 0.02, len) });
  tracer.rotationY = angleY;
  tracer.quaternion = Opus.Quat.fromEuler(angleX, angleY, 0);
  tracer.unlit = true;
  deferredCalls.push({ fireAt: simElapsed + 0.06, fn: () => { if (!tracer.destroyed) app.scene.remove(tracer); } });
}
function fireHitscan(origin, dir, range, damage, ownerTag, targetTag, knockback) {
  const candidates = [];
  if (ownerTag !== 'player' && player) {
    const t = Opus.Physics.raySphere(origin, dir, player.entity.position, player.radius);
    if (t !== null && t <= range) candidates.push({ t, type: 'player' });
  }
  for (const other of placed) {
    if (other.kind !== 'cube') continue;
    const isSolid = other.entity.solid;
    const isTaggedTarget = other.tags && other.tags.length && (!targetTag || other.tags.includes(targetTag)) && !(ownerTag && other.tags.includes(ownerTag));
    if (!isSolid && !isTaggedTarget) continue;
    if (isSolid) {
      const half = other.entity.scale.scale(0.5);
      const box = new Opus.Physics.AABB(other.entity.position.sub(half), other.entity.position.add(half));
      const t = Opus.Physics.rayAABB(origin, dir, box);
      if (t !== null && t <= range) candidates.push({ t, type: 'solid', item: other });
    } else {
      const r = Math.max(other.entity.scale.x, other.entity.scale.y, other.entity.scale.z) * 0.5;
      const t = Opus.Physics.raySphere(origin, dir, other.entity.position, r);
      if (t !== null && t <= range) candidates.push({ t, type: 'object', item: other });
    }
  }
  if (candidates.length === 0) return null;
  candidates.sort((a, b) => a.t - b.t);
  const hit = candidates[0];
  if (hit.type === 'player' || hit.type === 'object') applyHitDamage(hit, damage, knockback, origin);
  return hit;
}
// Melee (Wave 5, section 35 utility gate: cheap once Hitscan's damage
// resolution already exists, so implemented -- a radius/cone check reusing
// applyHitDamage, not a fourth damage implementation). No raycast at all:
// just "is this tagged target within `range` AND within a forward-facing
// cone of `coneHalfAngleRad`" -- deliberately simpler than Hitscan/
// Projectile since melee has no travel and no line-of-sight requirement in
// this engine (a real swing could plausibly connect slightly around a thin
// corner; accepted as the bounded simplification this primitive is worth).
function fireMelee(origin, dir, range, coneHalfAngleRad, damage, ownerTag, targetTag, knockback) {
  const candidates = [];
  if (ownerTag !== 'player' && player) {
    const toTarget = player.entity.position.sub(origin);
    const dist = toTarget.length();
    if (dist <= range + player.radius && (dist < 1e-6 || toTarget.normalize().dot(dir) >= Math.cos(coneHalfAngleRad))) candidates.push({ dist, type: 'player' });
  }
  for (const other of placed) {
    if (other.kind !== 'cube') continue;
    const isTaggedTarget = other.tags && other.tags.length && (!targetTag || other.tags.includes(targetTag)) && !(ownerTag && other.tags.includes(ownerTag));
    if (!isTaggedTarget) continue;
    const r = Math.max(other.entity.scale.x, other.entity.scale.y, other.entity.scale.z) * 0.5;
    const toTarget = other.entity.position.sub(origin);
    const dist = toTarget.length();
    if (dist > range + r) continue;
    if (dist >= 1e-6 && toTarget.normalize().dot(dir) < Math.cos(coneHalfAngleRad)) continue;
    candidates.push({ dist, type: 'object', item: other });
  }
  if (candidates.length === 0) return null;
  candidates.sort((a, b) => a.dist - b.dist);
  const hit = candidates[0];
  applyHitDamage(hit, damage, knockback, origin);
  return hit;
}
// Projectile Collision 2.0 (Wave 5, Priority F) -- swept, not a per-frame
// end-point overlap check. Reuses the exact math TriggerVolume.update()
// already established for its own swept enter/exit detection (`raySphere`
// against the segment from where the mover WAS to where it IS now,
// checking the hit distance against the segment length) -- both are
// already public on Opus.Physics, so no new engine API was needed at all,
// closing what would otherwise have been section 34's own question before
// it became one. Solids get the more precise `rayAABB` (their real box
// shape, not a sphere approximation) since it was equally available and no
// harder to call; damageable/tagged targets keep the sphere approximation
// already used elsewhere for Object Health hit-testing.
//
// Hit order (section 31): every candidate the swept segment could plausibly
// hit this frame is collected first, then sorted by hit distance along the
// segment -- the NEAREST one wins, exactly once, never "damage everything
// crossed" (this engine has no penetration/piercing concept to opt into).
function tickProjectiles(dt) {
  if (activeProjectiles.length === 0) return;
  for (const proj of activeProjectiles.slice()) {
    if (proj.item.entity.destroyed) { removeProjectile(proj); continue; }
    proj.lifetime -= dt;
    if (proj.lifetime <= 0) { removeProjectile(proj); continue; }
    if (proj.gravity) proj.velocity.y -= proj.gravity * dt;
    const prevPos = proj.item.entity.position.clone();
    const moveVec = proj.velocity.scale(dt);
    const moveDist = moveVec.length();
    proj.item.entity.position = prevPos.add(moveVec);
    const pos = proj.item.entity.position;
    const dir = moveDist > 1e-6 ? moveVec.scale(1 / moveDist) : null;

    const candidates = []; // { t, type, item }
    if (proj.ownerTag !== 'player' && player) {
      const combinedR = proj.radius + player.radius;
      const t = dir ? Opus.Physics.raySphere(prevPos, dir, player.entity.position, combinedR) : null;
      const endDist = pos.sub(player.entity.position).length();
      if ((t !== null && t <= moveDist) || endDist < combinedR) candidates.push({ t: t !== null ? t : moveDist, type: 'player' });
    }
    for (const other of placed) {
      if (other === proj.item || other.kind !== 'cube') continue;
      const isSolid = other.entity.solid;
      const isTaggedTarget = other.tags && other.tags.length && (!proj.targetTag || other.tags.includes(proj.targetTag)) && !(proj.ownerTag && other.tags.includes(proj.ownerTag));
      if (!isSolid && !isTaggedTarget) continue;
      if (isSolid) {
        const half = other.entity.scale.scale(0.5);
        const box = new Opus.Physics.AABB(other.entity.position.sub(half), other.entity.position.add(half));
        const t = dir ? Opus.Physics.rayAABB(prevPos, dir, box) : null;
        if ((t !== null && t <= moveDist) || box.containsPoint(pos)) candidates.push({ t: t !== null ? t : moveDist, type: 'solid', item: other });
      } else {
        const combinedR = proj.radius + Math.max(other.entity.scale.x, other.entity.scale.y, other.entity.scale.z) * 0.5;
        const t = dir ? Opus.Physics.raySphere(prevPos, dir, other.entity.position, combinedR) : null;
        const endDist = pos.sub(other.entity.position).length();
        if ((t !== null && t <= moveDist) || endDist < combinedR) candidates.push({ t: t !== null ? t : moveDist, type: 'object', item: other });
      }
    }
    // Terrain (section 32, "if practical") -- a bounded check: did the
    // projectile's feet cross from above to at-or-below the sampled
    // terrain height at its current XZ this frame? Not a full ray-march
    // along the segment (terrain has no closed-form ray intersection the
    // way a sphere/AABB does), but correct for the common case of a
    // projectile arcing down into the ground, and cheap.
    const terrainItem = currentTerrainItem(pos);
    if (terrainItem) {
      const groundY = terrainItem.handle.sampleHeight(pos.x, pos.z);
      if (prevPos.y >= groundY && pos.y <= groundY + proj.radius) {
        const terrainT = moveDist > 0 ? Math.max(0, Math.min(moveDist, (prevPos.y - groundY) / Math.max(1e-6, prevPos.y - pos.y) * moveDist)) : 0;
        candidates.push({ t: terrainT, type: 'terrain' });
      }
    }

    let hit = null;
    if (candidates.length > 0) {
      candidates.sort((a, b) => a.t - b.t);
      hit = candidates[0];
    }
    if (hit) {
      // applyHitDamage (Wave 5): the same shared resolution Hitscan now
      // also calls -- see its own comment for the 'kills' counter / assembly-
      // aware cleanup reasoning, unchanged from before this was factored out.
      if (hit.type === 'player' || hit.type === 'object') applyHitDamage(hit, proj.damage);
      // Wave 9D (Priority B/Section 19): the REAL swept collision point
      // (`prevPos + dir * hit.t`), not the projectile's post-step `pos` --
      // for every hit type, including solid/terrain (Section 20).
      if (proj.impactEffectConfig && dir) triggerImpactEffect(proj.impactEffectConfig, prevPos.add(dir.scale(hit.t)));
      removeProjectile(proj);
    }
  }
}

function tickSpawners(dt) {
  for (const item of placed) {
    if (item.kind !== 'spawner' || !item.spawnerState) continue;
    const st = item.spawnerState;
    // Prune ids for instances that were destroyed by other means (Destroy
    // Object, Damage-related cleanup, etc.) since the last tick -- Max
    // Active must reflect what's REALLY still alive, not a stale count.
    st.activeIds = st.activeIds.filter((id) => placed.some((p) => p.id === id));
    if (!st.enabled) continue;
    const opts = item.options;
    if (opts.totalCount > 0 && st.spawnedTotal >= opts.totalCount) continue;
    if (st.activeIds.length >= opts.maxActive) continue;
    st.timer += dt;
    // First spawn waits Initial Delay; every spawn after that waits Interval.
    const threshold = st.firstSpawnDone ? opts.interval : (opts.initialDelay || 0);
    if (st.timer >= threshold) {
      st.timer = 0;
      st.firstSpawnDone = true;
      spawnOneFromSpawner(item);
    }
  }
}
function tickTimers(dt) {
  const timers = window.__gameTimers;
  if (!timers) return;
  for (const name in timers) {
    const t = timers[name];
    if (!t.running || t.finished) continue;
    if (t.countDown) {
      t.elapsed = Math.max(0, t.elapsed - dt);
      if (t.elapsed <= 0) { t.finished = true; t.running = false; }
    } else {
      t.elapsed += dt;
      if (t.duration > 0 && t.elapsed >= t.duration) { t.finished = true; t.running = false; }
    }
  }
}
function ensureHealthInit() {
  window.__gameState = window.__gameState || {};
  if (window.__gameState.maxHealth === undefined) {
    const fromSettings = currentPlayerSettings && currentPlayerSettings.maxHealth;
    window.__gameState.maxHealth = fromSettings > 0 ? fromSettings : 100;
  }
  if (window.__gameState.health === undefined) window.__gameState.health = window.__gameState.maxHealth;
}
// Object Health (Wave 4) -- lazily initialized on first damage/heal/query,
// same "exists with a valid max by the time anything touches it" reasoning
// as ensureHealthInit above, just per-object instead of one global player
// state. Defaults to 100/100 unless a behavior/graph author explicitly sets
// otherwise via Set Object Health (not built this pass -- Damage/Heal cover
// the dogfooded cases; a dedicated setter is a natural, low-risk follow-up).
function ensureObjectHealthInit(item) {
  if (!item.health) item.health = { current: 100, max: 100 };
}

// Applies one authored Camera object's settings to the real app.camera --
// shared by the Change Camera action and (for consistency) could be reused
// by future camera-preset UI. Mirrors the exact working call order the
// hovercraft's own chase setup already relies on: setTarget BEFORE
// setMode('chase')/setMode('followLookAt') -- Camera.setMode re-triggers
// setTarget's real positioning logic only once `this.mode` already matches,
// so calling them in the other order silently skips that positioning.
// Wave 9C: best-effort "what was the last REAL Camera object applied"
// tracker -- lets Play Camera Path's own "Return To Previous Camera"
// restore something sensible without a new, separate "current camera"
// concept. Deliberately NOT set by the camera-path/blend vehicles
// themselves (which borrow 'fixed' mode transiently), only by an actual
// authored Camera object being applied for real.
let lastAppliedCameraItemId = null;
function applyCameraPreset(cameraItem) {
  if (!cameraItem || cameraItem.kind !== 'camera') return;
  lastAppliedCameraItemId = cameraItem.id;
  const opts = cameraItem.options;
  app.camera.fovY = (opts.fovDegrees || 45) * Math.PI / 180;
  const lookAtItem = opts.lookAtTargetId ? findItemById(opts.lookAtTargetId) : null;
  const lookAtEntity = lookAtItem && lookAtItem.entity ? lookAtItem.entity : null;
  if (opts.mode === 'chase') {
    app.camera.setTarget(player ? player.entity : null);
    app.camera.setChaseOptions(opts.chase);
    app.camera.setMode('chase');
  } else if (opts.mode === 'orbit') {
    app.camera.setMode('orbit');
    app.camera.target = cameraItem.entity.position.clone();
  } else if (opts.mode === 'fixed') {
    const lookAtPos = lookAtEntity ? lookAtEntity.position : cameraItem.entity.position.add(new Opus.Vec3(0, 0, -1));
    app.camera.setFixedOptions({ eye: cameraItem.entity.position.clone(), target: lookAtPos.clone() });
    app.camera.setMode('fixed');
  } else if (opts.mode === 'followLookAt') {
    app.camera.setTarget(lookAtEntity || (player ? player.entity : null));
    app.camera.setFixedOptions({ eye: cameraItem.entity.position.clone() });
    app.camera.setMode('followLookAt');
  }
}

// Wave 6B (Priority K): Camera Blend Duration -- a bounded interpolated
// transition, built entirely from EXISTING camera pieces rather than a new
// camera architecture (the spec's own explicit escape hatch: "defer if it
// becomes a new camera architecture"). The trick: `app.camera`'s `eye`/
// `currentTarget` getters already return a real world position/lookAt
// regardless of which mode (chase/orbit/fixed/followLookAt) is currently
// active, and the EXISTING 'fixed' mode already accepts an arbitrary literal
// eye+target via `setFixedOptions` -- so 'fixed' mode is repurposed here as
// the interpolation VEHICLE for the blend window only. Start state is read
// off the live getters (whatever mode was active); end state is read the
// SAME way immediately after actually applying the real target preset (so
// the "end" is always exactly correct, never a second hand-duplicated
// camera-math path); every frame in between overwrites 'fixed' mode's own
// eye/target with the lerp; once elapsed >= duration, `applyCameraPreset`
// is called for REAL, snapping to the target camera's own actual configured
// mode -- so a blend into a chase/orbit/followLookAt camera correctly hands
// off to that mode's own live-updating behavior once the blend completes,
// rather than getting stuck in 'fixed' forever.
// Wave 9C (Priority B, Sections 20-27): Camera Path -- the authoring/
// runtime BRIDGE between three systems that already exist (Path/Spline
// storage+`samplePathPosition`, and this exact "repurpose 'fixed' mode as
// an interpolation vehicle" trick the Camera Blend above already
// established) -- no second spline implementation, no second camera
// architecture. `activeCameraPath` is simulation-time driven (correctly
// freezes on pause, since this is ticked from the same dispatcher every
// other simulation-time system already funnels through).
let activeCameraPath = null; // { pathItem, duration, elapsed, loop, lookMode, lookAtTargetId, fixedTarget, returnCameraId }
function startCameraPath(pathItem, duration, loop, lookMode, lookAtTargetId, fixedTarget, returnCameraId) {
  if (!pathItem || pathItem.kind !== 'path' || !pathItem.pointIds || pathItem.pointIds.length < 2) return;
  activeCameraBlend = null; // a Camera Path and a Camera Blend both borrow 'fixed' mode as their vehicle -- mutually exclusive, the newer one wins
  activeCameraPath = { pathItem, duration: duration > 0 ? duration : 5, elapsed: 0, loop: !!loop, lookMode: lookMode || 'alongPath', lookAtTargetId, fixedTarget, returnCameraId };
  app.camera.setMode('fixed');
}
function tickCameraPath(dt) {
  if (!activeCameraPath) return;
  const cp = activeCameraPath;
  cp.elapsed += dt;
  let t = cp.elapsed / cp.duration;
  let finished = false;
  if (t >= 1) { if (cp.loop) t %= 1; else { t = 1; finished = true; } }
  const pos = samplePathPosition(cp.pathItem, t);
  let target;
  if (cp.lookMode === 'lookAtObject' && cp.lookAtTargetId) {
    const obj = findItemById(cp.lookAtTargetId);
    target = obj && obj.entity ? obj.entity.position : pos.add(new Opus.Vec3(0, 0, -1));
  } else if (cp.lookMode === 'fixedTarget' && cp.fixedTarget) {
    target = cp.fixedTarget;
  } else {
    // Along Path (Section 23's own "sample current position, slightly-ahead
    // position, normalized direction, no authored roll") -- a hair past the
    // final sample when nearly at t=1 so the very last frame still looks
    // forward instead of snapping to look at itself.
    target = samplePathPosition(cp.pathItem, Math.min(1, t + 0.02));
  }
  app.camera.setFixedOptions({ eye: pos, target });
  if (finished) {
    const returnItem = cp.returnCameraId ? findItemById(cp.returnCameraId) : null;
    activeCameraPath = null;
    if (returnItem) applyCameraPreset(returnItem);
  }
}
let activeCameraBlend = null;
function applyCameraPresetBlended(cameraItem, duration) {
  if (!cameraItem || cameraItem.kind !== 'camera') return;
  if (!duration || duration <= 0) { activeCameraBlend = null; applyCameraPreset(cameraItem); return; }
  const startEye = app.camera.eye.clone();
  const startTarget = app.camera.currentTarget.clone();
  const startFov = app.camera.fovY;
  applyCameraPreset(cameraItem); // apply for real so the end state is read off the exact same live getters, never a second hand-derived path
  const endEye = app.camera.eye.clone();
  const endTarget = app.camera.currentTarget.clone();
  const endFov = app.camera.fovY;
  app.camera.setFixedOptions({ eye: startEye.clone(), target: startTarget.clone() });
  app.camera.setMode('fixed');
  app.camera.fovY = startFov;
  activeCameraBlend = { startEye, endEye, startTarget, endTarget, startFov, endFov, duration, elapsed: 0, targetCameraItem: cameraItem };
}
function tickCameraBlend(dt) {
  if (!activeCameraBlend) return;
  const b = activeCameraBlend;
  b.elapsed += dt;
  const t = Math.min(1, b.elapsed / b.duration);
  const eye = b.startEye.add(b.endEye.sub(b.startEye).scale(t));
  const target = b.startTarget.add(b.endTarget.sub(b.startTarget).scale(t));
  app.camera.setFixedOptions({ eye, target });
  app.camera.fovY = b.startFov + (b.endFov - b.startFov) * t;
  if (t >= 1) {
    const finalItem = b.targetCameraItem;
    activeCameraBlend = null;
    applyCameraPreset(finalItem); // hand off to the target camera's REAL mode (chase/orbit/fixed/followLookAt), not stuck in the blend's borrowed 'fixed' mode
  }
}
app.onUpdate((dt) => { if (playMode) { tickCameraBlend(dt); tickCameraPath(dt); tickFogBlend(dt); } });

// Wave 8 (Priority H, Sections 49-51): the ONE place a Save Game payload is
// actually built and written -- shared by the manual `saveGame` action and
// the new `autosave` action (Section 50), so a slot written by either one
// carries the exact same shape/metadata, never two slightly-different save
// formats. Metadata (Section 51 -- timestamp handled by SaveSystem.save
// itself; level name/objective title/playtime added here) lets a Continue
// screen show real context instead of a bare slot name.
function writeSaveGameSlot(slot) {
  captureCurrentLevelWorldState(); // capture THIS level's live persistent state before writing
  const saveSystem = new Opus.SaveSystem('doengine:playersave');
  const level = levels[currentLevelIndex];
  // Wave 8 (Priority F/Section 97 -- built ahead of full Weapons 2.0 since
  // it's cheap and Power Grid's own dogfood benefits from it): the
  // currently-equipped item per slot, NOT any transient animation/visual
  // state -- restored by re-running the real `equipItemToSlot` on load,
  // not by trying to serialize a live entity.
  const equipment = {};
  for (const slotName in playerEquipment) equipment[slotName] = playerEquipment[slotName].itemName;
  // Wave 9 (Priority D, Sections 47-49): weapon runtime -- ONLY magazine/
  // reserve per slot are persisted (Section 47's explicit exclusions: no
  // mid-reload fractional progress, no recoil, no animation time -- a
  // reload in progress at save time is simply not represented at all, so
  // Load correctly finds it not-reloading, per Section 47's own "Reload
  // state can cancel on Load"). `saveFormatVersion: 3` (Section 48 -- the
  // RUNTIME save schema, never the project schema) so a Wave-8-or-earlier
  // save (no `weaponRuntime`/`activeWeaponSlot` keys at all) still loads
  // correctly: `data.weaponRuntime || {}` below is a harmless empty object,
  // every weapon just starts fresh exactly as it already did before this
  // priority existed.
  const weaponRuntime = {};
  for (const key in weaponRuntimeState) {
    const rt = weaponRuntimeState[key];
    weaponRuntime[key] = { magazine: rt.magazine, reserve: rt.reserve };
  }
  saveSystem.save(slot, {
    saveFormatVersion: 3,
    levelIndex: currentLevelIndex,
    levelName: level ? level.name : '',
    objectiveTitle: currentActiveObjectiveTitle(),
    playtimeSeconds: window.__gamePlaytimeSeconds || 0,
    checkpoint: window.__checkpoint ? [window.__checkpoint.x, window.__checkpoint.y, window.__checkpoint.z] : null,
    gameState: window.__gameState || {},
    flags: window.__gameFlags || {},
    inventory: window.__gameInventory || {},
    objectives: window.__gameObjectives || {},
    worldState: window.__worldState || {},
    equipment,
    weaponRuntime,
    activeWeaponSlot,
    playerPosition: player ? [player.entity.position.x, player.entity.position.y, player.entity.position.z] : null,
  });
}
const ACTION_TYPES = {
  message: {
    label: 'Show Message', legacy: true, legacyParam: 'text',
    fields: [{ key: 'text', label: 'Message', type: 'text', placeholder: 'Message text' }],
    exec: (p) => showToast(p.text || '...'),
  },
  // NOT `legacy` (unlike the other original six) -- it USED to claim
  // legacyParam: null, meaning the fixed dropdown's Add Behavior flow never
  // wrote a `.param` OR a `.params` for it at all. That silently made the
  // Frequency field a no-op: behaviorParams() had nothing to read back, so
  // every fixed-dropdown Play Sound behavior always played the hardcoded
  // 660Hz default regardless of what was typed in, for as long as this
  // action has existed. Found while extending Duration/Waveform authoring
  // -- fixed by making it a normal `.params`-backed action like every other
  // non-legacy one, which a saved project with no `.params` at all
  // (any prior Play Sound behavior) still falls back through correctly.
  // Play Sound 2.0 -- Mode picks Synth (the original procedural blip, still
  // the default) or Asset (a real imported sound from the Audio Library).
  // Both field groups are always rendered rather than dynamically shown/
  // hidden by Mode, since the fixed-dropdown Behaviors UI has no per-field
  // conditional-visibility mechanism (unlike the AI Behavior inspector,
  // which hand-wires that); exec() only reads whichever group Mode selects.
  // A saved behavior with no `.mode` at all (every pre-2.0 Play Sound) falls
  // through to 'synth' by default, so old projects are unaffected.
  sound: {
    label: 'Play Sound',
    fields: [
      { key: 'mode', label: 'Mode', type: 'select', options: ['synth', 'asset'] },
      { key: 'frequency', label: 'Synth: Frequency (Hz)', type: 'number', placeholder: '660' },
      { key: 'duration', label: 'Synth: Duration (sec)', type: 'number', placeholder: '0.15' },
      { key: 'waveform', label: 'Synth: Waveform', type: 'select', options: ['sine', 'square', 'sawtooth', 'triangle'] },
      { key: 'audioAssetId', label: 'Asset: Sound', type: 'audioAsset' },
      { key: 'volume', label: 'Asset: Volume (0-1)', type: 'number', placeholder: '1' },
    ],
    exec: (p) => {
      if (p.mode === 'asset' && p.audioAssetId) {
        const asset = findAudioAssetById(p.audioAssetId);
        if (asset && asset.audioBuffer) app.audio.playBuffer(asset.audioBuffer, { volume: p.volume ? parseFloat(p.volume) || 1 : 1 });
        return;
      }
      app.audio.playBlip({ frequency: p.frequency || 660, duration: p.duration || 0.15, type: p.waveform || 'sine' });
    },
  },
  // Wave 7 (Priority B/Section 15): the one new action this priority's own
  // dogfood justified -- reachable both as an ordinary Behavior action (for
  // completeness/consistency, matching "reuse ACTION_TYPES, don't invent a
  // parallel language") and as an Animation Event action (its actual
  // motivating use case: firing the Player's weapon at a specific animated
  // frame instead of the instant Attack was pressed). Deliberately a no-op
  // when there's no Player/weapon to fire (an Animation Event authored on a
  // non-Player character's clip, or fired with nobody spawned, is silently
  // inert rather than throwing).
  fireWeapon: { label: 'Fire Player Weapon (Animation Event)', fields: [], exec: () => performPlayerWeaponFire() },
  // Wave 9 (Priority B/Section 34): shared `Emit Noise` action -- reachable
  // as an ordinary Behavior/Node Graph/Sequence action like every other
  // action, for authored noise sources beyond weapon fire itself (a loud
  // machine, a thrown object, a scripted alarm). Target-optional, defaults
  // to self (the item this behavior is authored on), same convention every
  // other target-optional action already uses.
  emitNoise: {
    label: 'Emit Noise',
    fields: [
      { key: 'targetId', label: 'Source (empty = self)', type: 'target' },
      { key: 'radius', label: 'Radius', type: 'number', placeholder: '15' },
    ],
    exec: (p, item) => {
      const source = resolveTarget(p, item);
      const pos = source && source.entity ? source.entity.position : (player ? player.entity.position : null);
      if (pos) emitNoiseEvent(pos, p.radius ? parseFloat(p.radius) || 15 : 15);
    },
  },
  // Wave 9 (Priority C, Sections 44-45): Camera Shake -- a reusable
  // primitive layered TEMPORARILY over whatever Camera/controller is
  // currently active, never mutating any authored Camera setting
  // permanently (Section 44's own explicit requirement). Reachable from
  // Behaviors, Node Graph, Animation Events, and Sequences alike through
  // this same ACTION_TYPES entry -- no parallel "shake" mechanism per
  // caller.
  cameraShake: {
    label: 'Camera Shake',
    fields: [
      { key: 'intensity', label: 'Intensity', type: 'number', placeholder: '0.3' },
      { key: 'duration', label: 'Duration (sec)', type: 'number', placeholder: '0.3' },
    ],
    exec: (p) => triggerCameraShake(p.intensity ? parseFloat(p.intensity) || 0.3 : 0.3, p.duration ? parseFloat(p.duration) || 0.3 : 0.3),
  },
  // Wave 9C (Priority B, Sections 24-26): Play Camera Path -- the shared
  // action every caller (Behaviors, Node Graph, Sequence) reaches through
  // the SAME `executeAction` every other action already funnels through;
  // no Sequence-only camera-path code (Section 25/33's own explicit
  // requirement). `pathId`/`lookAtTargetId` are ordinary `target`-type
  // fields (reused, not a new "path reference" field type) -- any placed
  // item can technically be picked, but only a real `kind:'path'` item
  // does anything (`startCameraPath`'s own guard). `returnToPrevious`
  // resolves the currently-authored ACTIVE camera by name at the moment
  // this fires (best-effort -- there's no single global "the current
  // camera" concept beyond whatever `app.camera` is doing live) via a
  // simple heuristic: the last Camera object `applyCameraPreset` touched.
  playCameraPath: {
    label: 'Play Camera Path',
    fields: [
      { key: 'pathId', label: 'Path', type: 'target' },
      { key: 'duration', label: 'Duration (sec)', type: 'number', placeholder: '5' },
      { key: 'loop', label: 'Loop', type: 'checkbox', placeholder: 'Loop' },
      { key: 'lookMode', label: 'Look Mode', type: 'select', options: ['alongPath', 'lookAtObject', 'fixedTarget'] },
      { key: 'lookAtTargetId', label: 'Look At Object (if Look Mode = lookAtObject)', type: 'target' },
      { key: 'returnToPrevious', label: 'Return To Previous Camera When Done', type: 'checkbox', placeholder: 'Return To Previous Camera' },
    ],
    exec: (p) => {
      const pathItem = p.pathId ? findItemById(p.pathId) : null;
      if (!pathItem || pathItem.kind !== 'path') return;
      const duration = p.duration ? parseFloat(p.duration) || 5 : 5;
      const lookAtTargetId = p.lookMode === 'lookAtObject' ? p.lookAtTargetId : null;
      const returnCameraId = p.returnToPrevious ? (lastAppliedCameraItemId || null) : null;
      startCameraPath(pathItem, duration, !!p.loop, p.lookMode, lookAtTargetId, null, returnCameraId);
    },
  },
  win: { label: 'Win Game', legacy: true, legacyParam: null, fields: [], exec: () => endGame('win') },
  lose: { label: 'Lose Game', legacy: true, legacyParam: null, fields: [], exec: () => endGame('lose') },
  objective: {
    label: 'Update Objective', legacy: true, legacyParam: 'text',
    fields: [{ key: 'text', label: 'Objective', type: 'text', placeholder: 'Objective text' }],
    exec: (p) => setObjective(p.text || ''),
  },
  boost: {
    label: 'Boost Pad', legacy: true, legacyParam: 'force',
    fields: [{ key: 'force', label: 'Force', type: 'number', placeholder: '10' }],
    exec: (p) => {
      if (!player) return;
      const forward = new Opus.Vec3(Math.sin(player.entity.rotationY), 0, Math.cos(player.entity.rotationY));
      player.velocity = player.velocity.add(forward.scale(parseFloat(p.force) || 10));
      if (player.controllerType === 'hovercraft') craftBoostActive = Math.max(craftBoostActive, 0.4);
      app.audio.playBlip({ frequency: 340, duration: 0.15, type: 'square' });
      showToast('⚡ Boost!');
    },
  },
  moveObject: {
    label: 'Move Object (relative)',
    fields: [
      { key: 'targetId', label: 'Target', type: 'target' },
      { key: 'dx', label: 'dX', type: 'number', placeholder: '0' },
      { key: 'dy', label: 'dY', type: 'number', placeholder: '0' },
      { key: 'dz', label: 'dZ', type: 'number', placeholder: '0' },
    ],
    exec: (p, item) => {
      const entity = targetEntity(resolveTarget(p, item));
      if (!entity) return;
      entity.position.set(entity.position.x + (p.dx || 0), entity.position.y + (p.dy || 0), entity.position.z + (p.dz || 0));
    },
  },
  setPosition: {
    label: 'Set Position',
    fields: [
      { key: 'targetId', label: 'Target', type: 'target' },
      { key: 'x', label: 'X', type: 'number', placeholder: '0' },
      { key: 'y', label: 'Y', type: 'number', placeholder: '0' },
      { key: 'z', label: 'Z', type: 'number', placeholder: '0' },
    ],
    exec: (p, item) => {
      const entity = targetEntity(resolveTarget(p, item));
      if (!entity) return;
      entity.position.set(p.x || 0, p.y || 0, p.z || 0);
    },
  },
  rotateObject: {
    label: 'Rotate Object (relative Y)',
    fields: [
      { key: 'targetId', label: 'Target', type: 'target' },
      { key: 'degrees', label: 'Degrees', type: 'number', placeholder: '90' },
    ],
    exec: (p, item) => {
      const entity = targetEntity(resolveTarget(p, item));
      if (!entity) return;
      entity.rotationY += (p.degrees || 0) * Math.PI / 180;
    },
  },
  setVisibility: {
    label: 'Show/Hide Object',
    fields: [
      { key: 'targetId', label: 'Target', type: 'target' },
      { key: 'visible', label: 'Visible', type: 'checkbox' },
    ],
    exec: (p, item) => {
      const entity = targetEntity(resolveTarget(p, item));
      if (entity) entity.visible = !!p.visible;
    },
  },
  enableObject: {
    label: 'Enable Object',
    fields: [{ key: 'targetId', label: 'Target', type: 'target' }],
    exec: (p, item) => { const e = targetEntity(resolveTarget(p, item)); if (e) e.visible = true; },
  },
  disableObject: {
    label: 'Disable Object',
    fields: [{ key: 'targetId', label: 'Target', type: 'target' }],
    exec: (p, item) => { const e = targetEntity(resolveTarget(p, item)); if (e) e.visible = false; },
  },
  destroyObject: {
    label: 'Destroy Object',
    fields: [{ key: 'targetId', label: 'Target', type: 'target' }],
    // Deliberately non-cascading even when the target happens to be part of
    // a runtime-spawned assembly -- "just this piece" (shoot off a robot's
    // Weapon Mount without destroying the whole robot) is a real, distinct
    // use case from Destroy Assembly below, and every pre-Wave-5 saved
    // game's Destroy Object behavior must not silently start cascading.
    exec: (p, item) => {
      const target = resolveTarget(p, item);
      if (target) removeItemFromScene(target);
    },
  },
  // Runtime assembly destruction (Wave 5, section 13) -- the explicit
  // counterpart to Destroy Object's single-piece removal. Resolves the
  // target to its assembly (via assemblyId) and removes every member; for
  // a target with no assemblyId (anything not a multi-object runtime spawn)
  // this is identical to Destroy Object, so using it on an ordinary object
  // is always safe, never a surprise.
  destroyAssembly: {
    label: 'Destroy Assembly',
    fields: [{ key: 'targetId', label: 'Target', type: 'target' }],
    exec: (p, item) => {
      const target = resolveTarget(p, item);
      if (target) removeAssembly(target);
    },
  },
  spawnPrefab: {
    label: 'Spawn Prefab',
    fields: [
      { key: 'prefabName', label: 'Prefab', type: 'prefab' },
      { key: 'dx', label: 'Offset X', type: 'number', placeholder: '0' },
      { key: 'dz', label: 'Offset Z', type: 'number', placeholder: '0' },
    ],
    // Runtime spawning -- the "another wave of enemies appears" case a
    // design-time-only palette/prefab system can't cover on its own.
    // Reuses spawnPrefabAssembly (Wave 5) -- the exact same instantiation +
    // trigger-wiring + assembly-bookkeeping path Spawner uses -- so a
    // graph/behavior-triggered spawn of a MULTI-object prefab creates the
    // complete assembly (all parts, hierarchy, lights, emitters), not just
    // its root the way this action shipped in Wave 4.
    exec: (p, item) => {
      const prefab = prefabs.find((pf) => pf.name === p.prefabName);
      if (!prefab) return;
      const base = item.entity ? item.entity.position : new Opus.Vec3();
      const rootRecord = prefab.records ? (prefab.records.find((rr) => rr.id === prefab.rootId) || prefab.records[0]) : prefab.record;
      const rootY = (rootRecord.position || (rootRecord.options && rootRecord.options.position))[1];
      const position = new Opus.Vec3(base.x + (p.dx || 0), rootY, base.z + (p.dz || 0));
      spawnPrefabAssembly(prefab, position);
    },
  },
  changeColor: {
    label: 'Change Color',
    fields: [
      { key: 'targetId', label: 'Target', type: 'target' },
      { key: 'color', label: 'Color', type: 'color', placeholder: '#ffffff' },
    ],
    exec: (p, item) => {
      const entity = targetEntity(resolveTarget(p, item));
      if (!entity || !p.color) return;
      const [r, g, b] = hexToRgb(p.color);
      entity.color[0] = r; entity.color[1] = g; entity.color[2] = b;
    },
  },
  setCounter: {
    label: 'Set Counter',
    fields: [
      { key: 'counter', label: 'Counter name', type: 'text', placeholder: 'score' },
      { key: 'value', label: 'Value', type: 'number', placeholder: '0' },
    ],
    exec: (p) => { window.__gameState = window.__gameState || {}; window.__gameState[p.counter] = p.value || 0; },
  },
  setCheckpoint: {
    label: 'Set Checkpoint',
    fields: [],
    // Records the firing item's OWN position -- a checkpoint is meant to be
    // touched (an On Enter behavior on a Trigger Volume or any object), so
    // "self" is the only position that makes sense; no target field needed.
    // Keeps the automatic void-fall floor (see VOID_FALL_MARGIN) tracking
    // the most recently touched checkpoint, not the level's original spawn
    // -- a checkpoint reached high above the starting area shouldn't leave
    // the void floor 30 units below a spawn point far below it.
    exec: (p, item) => { if (item.entity) { window.__checkpoint = item.entity.position.clone(); voidFallY = item.entity.position.y - VOID_FALL_MARGIN; } },
  },
  respawnAtCheckpoint: {
    label: 'Respawn At Checkpoint',
    fields: [],
    // Falls back to the level's normal spawn point if no checkpoint has
    // been set yet -- e.g. dying to the very first hazard, before reaching
    // any checkpoint, should still respawn somewhere sane, not do nothing.
    exec: () => {
      if (!player) return;
      const target = window.__checkpoint ? window.__checkpoint.clone() : computeSpawnPoint();
      player.entity.position = target;
      player.velocity = new Opus.Vec3();
      voidFallY = target.y - VOID_FALL_MARGIN;
    },
  },
  switchLevel: {
    label: 'Switch Level',
    fields: [{ key: 'levelId', label: 'Level', type: 'level' }],
    // Mid-play transition, not a fresh session: __gameState (score/lives)
    // deliberately carries over -- a multi-level game where beating level 1
    // reset your score entering level 2 would be a bug, not a feature. The
    // current level's live edits ARE saved first (syncCurrentLevelObjects),
    // so returning to it later (e.g. Switch Level back) isn't a silent
    // rollback to however it looked when the project was last saved.
    // Resolves by id first (current/Wave-3-saved behaviors); falls back to
    // a name lookup for any behavior saved before stable level ids existed.
    exec: (p) => {
      const index = p.levelId ? levels.findIndex((l) => l.id === p.levelId) : levels.findIndex((l) => l.name === p.levelName);
      if (index === -1 || index === currentLevelIndex) return;
      switchLevelWithTransition(index, true);
    },
  },
  nextLevel: {
    label: 'Next Level',
    fields: [],
    exec: () => {
      if (currentLevelIndex + 1 >= levels.length) return; // already the last level -- no-op, not a wraparound
      switchLevelWithTransition(currentLevelIndex + 1, true);
    },
  },
  previousLevel: {
    label: 'Previous Level',
    fields: [],
    exec: () => {
      if (currentLevelIndex - 1 < 0) return;
      switchLevelWithTransition(currentLevelIndex - 1, true);
    },
  },
  restartLevel: {
    label: 'Restart Level',
    fields: [],
    // Reloads the CURRENT level's own saved objects (undoing runtime
    // changes like collected pickups) without the session-wide resets a
    // fresh Play does -- score/lives/inventory/flags deliberately carry
    // over, same reasoning as Switch Level above.
    exec: () => switchLevelWithTransition(currentLevelIndex, true),
  },
  changeCamera: {
    label: 'Change Camera',
    // Wave 6B (Priority K): optional Blend Duration -- 0 (the default, and
    // what every project saved before this priority has) is an INSTANT cut,
    // bit-identical to the old behavior; a positive value interpolates
    // through applyCameraPresetBlended instead. Pairs naturally with a
    // Sequence's own Change Camera / Delay / Change Camera steps (Priority E).
    fields: [{ key: 'cameraId', label: 'Camera', type: 'cameraPreset' }, { key: 'blendSeconds', label: 'Blend Duration (sec, 0 = instant cut)', type: 'number', placeholder: '0' }],
    exec: (p) => {
      const camItem = p.cameraId ? findItemById(p.cameraId) : null;
      if (camItem) applyCameraPresetBlended(camItem, parseFloat(p.blendSeconds) || 0);
    },
  },
  // Wave 6 (Priority L): the cutscene gate's own missing piece -- pairs
  // with Change Camera + Delay/Wait (Node Graph) to build "On Start: Freeze
  // Player -> Change Camera A -> Delay -> Change Camera B -> Delay ->
  // Change Camera (back to the player's own chase/follow preset) -> Unfreeze
  // Player" entirely from existing action/graph primitives, no dedicated
  // Cutscene track editor needed. See updatePlayerController's own comment
  // for exactly what freezing does and doesn't stop.
  freezePlayer: {
    label: 'Freeze Player (for a cutscene)',
    fields: [],
    exec: () => { playerFrozen = true; },
  },
  unfreezePlayer: {
    label: 'Unfreeze Player',
    fields: [],
    exec: () => { playerFrozen = false; },
  },
  // Wave 6B (Priority E): the one new shared action Sequence authoring
  // needs -- usable from a Behavior OR the Node Graph exactly like any other
  // action, since it goes through this same ACTION_TYPES/executeAction path.
  // Deliberately just triggers a run; no "wait for it to finish" here (a
  // Sequence step that itself needs to wait uses its own Delay step).
  playSequence: {
    label: 'Play Sequence',
    fields: [{ key: 'sequenceId', label: 'Sequence', type: 'sequence' }],
    exec: (p, item) => { const seq = findSequenceById(p.sequenceId); if (seq) playSequence(seq, item); },
  },
  incrementCounter: {
    label: 'Increment Counter',
    fields: [{ key: 'counter', label: 'Counter name', type: 'text', placeholder: 'Counter name' }],
    exec: (p) => { window.__gameState = window.__gameState || {}; window.__gameState[p.counter] = (window.__gameState[p.counter] || 0) + 1; },
  },
  // Named counters (setCounter/incrementCounter/decrementCounter, read back
  // via the Node Graph's Counter Reaches condition) are still the generic
  // primitive lives/score/inventory-count/anything-else build on. Health
  // specifically graduated to its own actions below (Wave 2) -- still just
  // window.__gameState.health/.maxHealth under the hood (so the generic
  // Counter Reaches/At Most conditions keep working on it unmodified,
  // exactly as they did when 'health' was only a convention), but with
  // clamping to [0, maxHealth], auto-init, and damage/heal semantics that a
  // bare counter name typed by hand couldn't express (an "Increment Counter"
  // on 'health' has no idea what the max should clamp to).
  decrementCounter: {
    label: 'Decrement Counter',
    fields: [
      { key: 'counter', label: 'Counter name', type: 'text', placeholder: 'Counter name' },
      { key: 'floorAtZero', label: 'Stop at 0 (no negatives)', type: 'checkbox' },
    ],
    exec: (p) => {
      window.__gameState = window.__gameState || {};
      const next = (window.__gameState[p.counter] || 0) - 1;
      window.__gameState[p.counter] = p.floorAtZero ? Math.max(0, next) : next;
    },
  },
  // ensureHealthInit: called by every health action below before it reads or
  // writes health/maxHealth, so firing Damage Player before any On Start
  // behavior has run (e.g. a Damage Zone touched a split-second into Play)
  // still lands on a sane starting value instead of NaN/undefined math.
  damagePlayer: {
    label: 'Damage Player',
    fields: [
      { key: 'amount', label: 'Amount', type: 'number', placeholder: '10' },
      { key: 'instantKill', label: 'Instant Kill', type: 'checkbox' },
      { key: 'cooldown', label: 'Cooldown, sec (0 = every trigger)', type: 'number', placeholder: '0' },
    ],
    exec: (p, item) => {
      ensureHealthInit();
      const cooldown = parseFloat(p.cooldown) || 0;
      if (cooldown > 0) {
        const key = item ? item.id : '__global__';
        window.__damageCooldowns = window.__damageCooldowns || {};
        const last = window.__damageCooldowns[key];
        if (last !== undefined && simElapsed - last < cooldown) return;
        window.__damageCooldowns[key] = simElapsed;
      }
      const amount = p.instantKill ? window.__gameState.maxHealth : (parseFloat(p.amount) || 0);
      window.__gameState.health = Math.max(0, window.__gameState.health - amount);
    },
  },
  healPlayer: {
    label: 'Heal Player',
    fields: [{ key: 'amount', label: 'Amount', type: 'number', placeholder: '10' }],
    exec: (p) => {
      ensureHealthInit();
      window.__gameState.health = Math.min(window.__gameState.maxHealth, window.__gameState.health + (parseFloat(p.amount) || 0));
    },
  },
  setPlayerHealth: {
    label: 'Set Player Health',
    fields: [
      { key: 'value', label: 'Health', type: 'number', placeholder: '100' },
      { key: 'maxHealth', label: 'Also set Max Health to (optional)', type: 'number', placeholder: '' },
    ],
    exec: (p) => {
      ensureHealthInit();
      if (p.maxHealth !== undefined && p.maxHealth !== '') window.__gameState.maxHealth = Math.max(1, parseFloat(p.maxHealth) || 1);
      window.__gameState.health = Math.max(0, Math.min(window.__gameState.maxHealth, parseFloat(p.value) || 0));
    },
  },
  // Object Health (Wave 4) -- generalizes Player Health to ANY placed
  // object, the same `{current, max}` shape, so an enemy no longer needs a
  // generic Counter + a hand-wired Node Graph "Health At Most(0) -> Lose"
  // to simulate dying (the exact pattern Survival Arena's Hunter prefab
  // used before this existed) -- Damage Object destroys the object outright
  // once health reaches 0, no separate "Destroy on Zero" action needed.
  damageObject: {
    label: 'Damage Object',
    fields: [
      { key: 'targetId', label: 'Object', type: 'target' },
      { key: 'amount', label: 'Amount', type: 'number', placeholder: '10' },
    ],
    exec: (p, item) => {
      const t = resolveTarget(p, item);
      if (!t || t.kind !== 'cube') return;
      ensureObjectHealthInit(t);
      t.health.current = Math.max(0, t.health.current - (parseFloat(p.amount) || 0));
      if (t.health.current <= 0) removeAssembly(t); // Wave 5: cascades for a runtime-spawned assembly, identical to before for anything else
    },
  },
  healObject: {
    label: 'Heal Object',
    fields: [
      { key: 'targetId', label: 'Object', type: 'target' },
      { key: 'amount', label: 'Amount', type: 'number', placeholder: '10' },
    ],
    exec: (p, item) => {
      const t = resolveTarget(p, item);
      if (!t || t.kind !== 'cube') return;
      ensureObjectHealthInit(t);
      t.health.current = Math.min(t.health.max, t.health.current + (parseFloat(p.amount) || 0));
    },
  },
  showHudElement: {
    label: 'Show HUD Element',
    fields: [{ key: 'hudId', label: 'Element', type: 'hudElementRef' }],
    exec: (p) => { const el = currentUiConfig.hudElements.find((e) => e.id === p.hudId); if (el) el.visible = true; },
  },
  hideHudElement: {
    label: 'Hide HUD Element',
    fields: [{ key: 'hudId', label: 'Element', type: 'hudElementRef' }],
    exec: (p) => { const el = currentUiConfig.hudElements.find((e) => e.id === p.hudId); if (el) el.visible = false; },
  },
  setHudText: {
    label: 'Set HUD Text',
    fields: [
      { key: 'hudId', label: 'Element', type: 'hudElementRef' },
      { key: 'text', label: 'New text', type: 'text', placeholder: 'New text' },
    ],
    exec: (p) => { const el = currentUiConfig.hudElements.find((e) => e.id === p.hudId); if (el) el.text = p.text || ''; },
  },
  // Tween actions -- Move/Rotate/Scale To, animated over `duration` seconds
  // rather than snapping. Each pushes an entry onto `activeTweens`, ticked
  // once per frame by tickTweens() in the main update loop (same
  // simulation-time, pause-safe reasoning as Timers/Delay above). A second
  // tween on the same entity+property replaces the first outright (not
  // blended) -- simplest predictable behavior for "the door was already
  // closing, now open it instead".
  moveTo: {
    label: 'Move To (Tween)',
    fields: [
      { key: 'targetId', label: 'Object', type: 'target' },
      { key: 'x', label: 'X', type: 'number', placeholder: '0' },
      { key: 'y', label: 'Y', type: 'number', placeholder: '0' },
      { key: 'z', label: 'Z', type: 'number', placeholder: '0' },
      { key: 'duration', label: 'Duration (sec)', type: 'number', placeholder: '1' },
      { key: 'easing', label: 'Easing', type: 'select', options: ['linear', 'easeIn', 'easeOut', 'easeInOut'] },
    ],
    exec: (p, item) => {
      const entity = targetEntity(resolveTarget(p, item));
      if (!entity) return;
      startTween(entity, 'position', entity.position.clone(), new Opus.Vec3(parseFloat(p.x) || 0, parseFloat(p.y) || 0, parseFloat(p.z) || 0), p.duration, p.easing);
    },
  },
  rotateTo: {
    label: 'Rotate To (Tween)',
    fields: [
      { key: 'targetId', label: 'Object', type: 'target' },
      { key: 'degrees', label: 'Rotation Y (degrees)', type: 'number', placeholder: '0' },
      { key: 'duration', label: 'Duration (sec)', type: 'number', placeholder: '1' },
      { key: 'easing', label: 'Easing', type: 'select', options: ['linear', 'easeIn', 'easeOut', 'easeInOut'] },
    ],
    exec: (p, item) => {
      const entity = targetEntity(resolveTarget(p, item));
      if (!entity) return;
      startTween(entity, 'rotationY', entity.rotationY, (parseFloat(p.degrees) || 0) * Math.PI / 180, p.duration, p.easing);
    },
  },
  scaleTo: {
    label: 'Scale To (Tween)',
    fields: [
      { key: 'targetId', label: 'Object', type: 'target' },
      { key: 'x', label: 'Scale X', type: 'number', placeholder: '1' },
      { key: 'y', label: 'Scale Y', type: 'number', placeholder: '1' },
      { key: 'z', label: 'Scale Z', type: 'number', placeholder: '1' },
      { key: 'duration', label: 'Duration (sec)', type: 'number', placeholder: '1' },
      { key: 'easing', label: 'Easing', type: 'select', options: ['linear', 'easeIn', 'easeOut', 'easeInOut'] },
    ],
    exec: (p, item) => {
      const entity = targetEntity(resolveTarget(p, item));
      if (!entity) return;
      startTween(entity, 'scale', entity.scale.clone(), new Opus.Vec3(parseFloat(p.x) || 1, parseFloat(p.y) || 1, parseFloat(p.z) || 1), p.duration, p.easing);
    },
  },
  // Property Animation Clips -- distinct from the Tween actions above (a
  // clip is multi-keyframe, authored once via the Animation Editor and
  // replayed by name; a Tween is a single one-shot move). Shares nothing at
  // the action layer with Tweens beyond both existing in the same vocabulary
  // and both ultimately calling entity.position/rotationY/scale.set.
  playAnimation: {
    label: 'Play Animation',
    fields: [
      { key: 'targetId', label: 'Object', type: 'target' },
      { key: 'clipName', label: 'Clip Name', type: 'text', placeholder: 'e.g. DoorOpen' },
    ],
    exec: (p, item) => {
      const t = resolveTarget(p, item);
      if (!t || t.kind !== 'cube' || !t.animationClips) return;
      const idx = t.animationClips.findIndex((c) => c.name === p.clipName);
      if (idx === -1) return;
      t._anim = { clipIndex: idx, elapsed: 0, playing: true };
    },
  },
  stopAnimation: {
    label: 'Stop Animation',
    fields: [{ key: 'targetId', label: 'Object', type: 'target' }],
    exec: (p, item) => { const t = resolveTarget(p, item); if (t && t._anim) { t._anim.playing = false; t._anim.elapsed = 0; } },
  },
  restartAnimation: {
    label: 'Restart Animation',
    fields: [{ key: 'targetId', label: 'Object', type: 'target' }],
    exec: (p, item) => { const t = resolveTarget(p, item); if (t && t._anim) { t._anim.elapsed = 0; t._anim.playing = true; } },
  },
  pauseAnimation: {
    label: 'Pause Animation',
    fields: [{ key: 'targetId', label: 'Object', type: 'target' }],
    exec: (p, item) => { const t = resolveTarget(p, item); if (t && t._anim) t._anim.playing = false; },
  },
  // Fire Projectile (Wave 4) -- ONE implementation for every case (Player
  // attack input, an AI's ranged attack, a Node Graph-scripted trap), per
  // the explicit "do not create three separate projectile implementations"
  // requirement. Direction is resolved here (object forward / toward Player
  // / toward an explicit Object Reference) and handed to the shared
  // fireProjectile() as a plain normalized Vec3, so the projectile-tracking
  // system itself never needs to know which mode fired it.
  fireProjectile: {
    label: 'Fire Projectile',
    fields: [
      { key: 'prefabName', label: 'Projectile Prefab', type: 'prefab' },
      { key: 'directionMode', label: 'Direction', type: 'select', options: ['forward', 'towardPlayer', 'towardTarget'] },
      { key: 'targetId', label: 'Target (if Toward Target)', type: 'target' },
      { key: 'speed', label: 'Speed', type: 'number', placeholder: '15' },
      { key: 'damage', label: 'Damage', type: 'number', placeholder: '10' },
      { key: 'lifetime', label: 'Lifetime (sec)', type: 'number', placeholder: '3' },
      { key: 'radius', label: 'Collision Radius', type: 'number', placeholder: '0.3' },
      { key: 'ownerTag', label: "Owner Tag (won't hit its own tag)", type: 'text', placeholder: 'enemy' },
      { key: 'targetTag', label: 'Target Tag (blank = any tagged object)', type: 'text', placeholder: 'player' },
    ],
    exec: (p, item) => {
      if (!item || !item.entity) return;
      const origin = item.entity.position.clone();
      let dir;
      if (p.directionMode === 'towardPlayer' && player) dir = player.entity.position.sub(origin);
      else if (p.directionMode === 'towardTarget') {
        const t = findItemById(p.targetId);
        dir = (t && t.entity) ? t.entity.position.sub(origin) : null;
      }
      if (!dir || dir.length() < 0.001) dir = new Opus.Vec3(Math.sin(item.entity.rotationY), 0, Math.cos(item.entity.rotationY));
      fireProjectile(p.prefabName, origin, dir, parseFloat(p.speed) || 15, parseFloat(p.damage) || 10, p.ownerTag, parseFloat(p.lifetime) || 3, parseFloat(p.radius) || 0.3, 0, p.targetTag);
    },
  },
  // Particle actions -- `emit()`/`.rate` were already public on
  // ParticleEmitter (used internally for the hovercraft's own trail
  // effects); Start/Stop toggle continuous emission by zeroing/restoring
  // `.rate` (saved on the item itself, not a module global, so multiple
  // stopped emitters don't clobber each other's remembered rate), Burst is
  // a direct pass-through to the existing `emit(count)`.
  startEmitter: {
    label: 'Start Emitter',
    fields: [{ key: 'targetId', label: 'Emitter', type: 'target' }],
    exec: (p, item) => {
      const target = resolveTarget(p, item);
      if (target && target.kind === 'emitter') target.handle.rate = target._savedRate != null ? target._savedRate : target.options.rate;
    },
  },
  stopEmitter: {
    label: 'Stop Emitter',
    fields: [{ key: 'targetId', label: 'Emitter', type: 'target' }],
    exec: (p, item) => {
      const target = resolveTarget(p, item);
      if (target && target.kind === 'emitter') { target._savedRate = target.handle.rate; target.handle.rate = 0; }
    },
  },
  burstEmitter: {
    label: 'Burst Emitter',
    fields: [
      { key: 'targetId', label: 'Emitter', type: 'target' },
      { key: 'count', label: 'Particle Count', type: 'number', placeholder: '20' },
    ],
    exec: (p, item) => {
      const target = resolveTarget(p, item);
      if (target && target.kind === 'emitter') target.handle.emit(Math.max(1, parseInt(p.count, 10) || 20));
    },
  },
  startSpawner: {
    label: 'Start Spawner',
    fields: [{ key: 'targetId', label: 'Spawner', type: 'target' }],
    exec: (p, item) => { const t = resolveTarget(p, item); if (t && t.kind === 'spawner' && t.spawnerState) t.spawnerState.enabled = true; },
  },
  stopSpawner: {
    label: 'Stop Spawner',
    fields: [{ key: 'targetId', label: 'Spawner', type: 'target' }],
    exec: (p, item) => { const t = resolveTarget(p, item); if (t && t.kind === 'spawner' && t.spawnerState) t.spawnerState.enabled = false; },
  },
  spawnOnceFromSpawner: {
    label: 'Spawn Once',
    fields: [{ key: 'targetId', label: 'Spawner', type: 'target' }],
    exec: (p, item) => { const t = resolveTarget(p, item); if (t && t.kind === 'spawner' && t.spawnerState) spawnOneFromSpawner(t); },
  },
  resetSpawner: {
    label: 'Reset Spawner',
    fields: [{ key: 'targetId', label: 'Spawner', type: 'target' }],
    // Destroys every instance the spawner currently has alive and rewinds
    // its counters to zero -- "start this wave over from scratch", not just
    // "resume counting" (Start/Stop already cover pause/resume).
    exec: (p, item) => {
      const t = resolveTarget(p, item);
      if (!t || t.kind !== 'spawner' || !t.spawnerState) return;
      for (const id of t.spawnerState.activeIds.slice()) {
        const spawned = findItemById(id);
        if (spawned) removeAssembly(spawned); // Wave 5: activeIds now tracks one id per logical spawn (assembly root or lone object) -- cascade so a reset never orphans a spawned assembly's other parts
      }
      t.spawnerState.activeIds = [];
      t.spawnerState.spawnedTotal = 0;
      t.spawnerState.timer = 0;
      t.spawnerState.firstSpawnDone = false;
    },
  },
  // Bounded, deterministic Dialogue -- a speaker/text modal, pausing the
  // game (reusing the same proven App.pause plumbing the Start Screen
  // already relies on) until dismissed. Branching is via Flags, not a
  // second action-execution path: each choice button just sets its own
  // named flag before closing, and ordinary Node Graph conditions
  // (Is Flag True/False) downstream decide what that choice actually DOES
  // -- no separate "choice action" vocabulary to duplicate the existing one.
  showDialogue: {
    label: 'Show Dialogue',
    fields: [
      { key: 'speaker', label: 'Speaker', type: 'text', placeholder: 'Speaker name' },
      { key: 'text', label: 'Text', type: 'text', placeholder: 'What they say' },
      { key: 'choice1Label', label: 'Choice 1 label (optional)', type: 'text', placeholder: 'e.g. Yes' },
      { key: 'choice1Flag', label: 'Choice 1 sets flag', type: 'text', placeholder: 'Flag name' },
      { key: 'choice2Label', label: 'Choice 2 label (optional)', type: 'text', placeholder: 'e.g. No' },
      { key: 'choice2Flag', label: 'Choice 2 sets flag', type: 'text', placeholder: 'Flag name' },
    ],
    exec: (p) => showDialogue(p),
  },
  // Inventory-lite -- window.__gameInventory[itemName] = count, the same
  // "plain named state" shape as counters/flags rather than a whole new
  // item-object/database concept. Give/Remove are the same primitive with
  // opposite sign; Has Item (below, a condition) is the read side, e.g.
  // gating a door's Open action on holding a key.
  giveItem: {
    label: 'Give Item',
    fields: [
      { key: 'name', label: 'Item name', type: 'text', placeholder: 'Key' },
      { key: 'count', label: 'Count', type: 'number', placeholder: '1' },
    ],
    exec: (p) => {
      window.__gameInventory = window.__gameInventory || {};
      window.__gameInventory[p.name] = (window.__gameInventory[p.name] || 0) + (parseInt(p.count, 10) || 1);
    },
  },
  // Wave 8 (Priority K, Sections 69-71): Audio Zone -- the highest-value
  // piece of "Environment/Gameplay Zones" (Section 69's own "highest-value
  // first"), reusing an ordinary Trigger Volume's existing Enter/Exit
  // behaviors (Box/Sphere geometry ALREADY exists, per Section 70's own
  // explicit "do not build complex spatial volumes" instruction) rather
  // than a new zone-geometry primitive. Reuses the exact same
  // `app.audio.playBuffer` the level's own persistent Ambient Audio
  // already uses.
  // Wave 9 (Priority G/Sections 70-72): Audio Zone crossfade. `Fade Duration`
  // (default 0 -- old projects/behaviors with no field at all keep the exact
  // Wave 8 hard-switch) ramps the old loop out and the new one in using the
  // engine's new `setVolume(value, rampSeconds)` handle method (Section 68)
  // instead of a stop/start pop. `Priority` (Section 71) is a bounded,
  // deterministic "highest active zone wins" rule: entering a lower-priority
  // zone while a higher one is still active is a no-op (the zone is
  // recorded as entered, but audio doesn't change); leaving the currently-
  // AUDIBLE zone falls back to the level's own persistent Ambient Audio
  // (Section 72's "No silence unless that's what level ambient specifies").
  // Wave 9B: real active-zone MEMBERSHIP (Sections 37-40), not a single
  // remembered "current winner" scalar -- an Enter adds this zone to
  // `activeAudioZones`, an Exit removes it, and `recomputeAudioZoneWinner`
  // re-derives "highest-priority zone still entered, or level ambient" from
  // the WHOLE set every time. This is what correctly reveals a still-active
  // lower-priority zone when the top one is exited, instead of falling
  // straight through to level ambient (Wave 9's own documented gap).
  setAmbientAudio: {
    label: 'Set Ambient Audio (Zone)',
    fields: [
      { key: 'audioAssetId', label: 'Track', type: 'audioAsset' },
      { key: 'volume', label: 'Volume (0-1)', type: 'number', placeholder: '0.4' },
      { key: 'fadeDuration', label: 'Fade Duration (sec)', type: 'number', placeholder: '0' },
      { key: 'priority', label: 'Priority', type: 'number', placeholder: '0' },
    ],
    exec: (p, item) => {
      const fade = p.fadeDuration ? Math.max(0, parseFloat(p.fadeDuration) || 0) : 0;
      const priority = p.priority ? parseFloat(p.priority) || 0 : 0;
      const zoneId = item ? item.id : '__unowned__';
      if (p.audioAssetId) {
        activeAudioZones.set(zoneId, { priority, audioAssetId: p.audioAssetId, volume: p.volume ? parseFloat(p.volume) || 0.4 : 0.4, fadeDuration: fade });
      } else {
        activeAudioZones.delete(zoneId); // leaving this zone -- it no longer competes for "audible winner"
      }
      recomputeAudioZoneWinner(fade);
    },
  },
  // Wave 9C (Priority C, Sections 31-40): Fog Zone -- an ordinary Trigger
  // Volume's Enter/Exit behaviors again (same Box/Sphere geometry, same
  // "no new zone-geometry primitive" reasoning Audio Zone already
  // established), routed through the SAME active-zone-membership shape.
  // Enter with a Fog Color/Density = joining the membership set; Exit
  // (leave Fog Color blank) = leaving it. Never touches sun direction,
  // shadow config, or panorama -- scope is fog only.
  setFogZone: {
    label: 'Set Fog Zone',
    fields: [
      { key: 'fogColor', label: 'Fog Color', type: 'color' },
      { key: 'fogDensity', label: 'Fog Density', type: 'number', placeholder: '0.05' },
      { key: 'blendDuration', label: 'Blend Duration (sec)', type: 'number', placeholder: '0' },
      { key: 'priority', label: 'Priority', type: 'number', placeholder: '0' },
    ],
    exec: (p, item) => {
      const duration = p.blendDuration ? Math.max(0, parseFloat(p.blendDuration) || 0) : 0;
      const priority = p.priority ? parseFloat(p.priority) || 0 : 0;
      const zoneId = item ? item.id : '__unowned__';
      if (p.fogColor) {
        activeFogZones.set(zoneId, { priority, fogColor: hexToRgb(p.fogColor), fogDensity: p.fogDensity != null && p.fogDensity !== '' ? Math.max(0, parseFloat(p.fogDensity) || 0) : 0.05, blendDuration: duration });
      } else {
        activeFogZones.delete(zoneId);
      }
      recomputeFogZoneWinner(duration);
    },
  },
  removeItem: {
    label: 'Remove Item',
    fields: [
      { key: 'name', label: 'Item name', type: 'text', placeholder: 'Key' },
      { key: 'count', label: 'Count', type: 'number', placeholder: '1' },
    ],
    exec: (p) => {
      window.__gameInventory = window.__gameInventory || {};
      window.__gameInventory[p.name] = Math.max(0, (window.__gameInventory[p.name] || 0) - (parseInt(p.count, 10) || 1));
    },
  },
  // Wave 8 (Priority D/Section 33, utility gate -- built, not deferred):
  // consumables. `def.useAction` reuses ACTION_TYPES/executeAction the same
  // way an Animation Event or AI entry-action already does (no second
  // action language), so a Health Kit's own "use" effect is just an
  // ordinary action (e.g. Increment Object Variable / Set Counter) an
  // author already knows how to wire. Silently a no-op with nothing to
  // use, no error -- consistent with every other "nothing to act on" case
  // in this action set.
  useItem: {
    label: 'Use Item',
    fields: [{ key: 'itemId', label: 'Item', type: 'itemDefRef' }],
    exec: (p, item) => {
      const def = findItemDefById(p.itemId);
      if (!def || !def.useAction || !def.useAction.action) return;
      window.__gameInventory = window.__gameInventory || {};
      if ((window.__gameInventory[def.id] || 0) < 1) return;
      executeAction(def.useAction.action, def.useAction.params, item);
      window.__gameInventory[def.id] -= 1;
    },
  },
  // Wave 7 (Priority C): Equip/Unequip -- the two shared actions the
  // bounded Equipment layer needs, reusing Inventory as the source of truth
  // for "does the player actually have this" (no separate item-count
  // database). `slot` matches whichever slot name the equipment def itself
  // specifies (typically 'primaryHand', but authored, not hardcoded here).
  equipItem: {
    label: 'Equip Item',
    fields: [
      { key: 'name', label: 'Item name', type: 'text', placeholder: 'Rifle' },
      { key: 'slot', label: 'Slot', type: 'text', placeholder: 'primaryHand' },
    ],
    exec: (p) => equipItemToSlot(p.name, p.slot || 'primaryHand'),
  },
  unequipItem: {
    label: 'Unequip Slot',
    fields: [{ key: 'slot', label: 'Slot', type: 'text', placeholder: 'primaryHand' }],
    exec: (p) => unequipSlot(p.slot || 'primaryHand'),
  },
  // Wave 7 (Priority F/Sections 42-46): a small structured Objective system
  // -- state lives in window.__gameObjectives[id], the same "plain named
  // state" shape as Inventory/flags/counters. `completeObjective` honors an
  // authored `nextObjective` chain ONLY when it's simple (auto-activate the
  // next id, no branching) -- matching the spec's own explicit bound;
  // anything more complex stays an explicit author-authored Activate call.
  // Wave 8 (Priority B, Sections 9-13): Object Variables -- a bounded,
  // per-instance alternative to global counters/flags, purpose-built for
  // reusable prefab logic (five placed Terminals no longer need five
  // globally-unique counter names). `target.variables = {name: value}`,
  // Number/Boolean/String only (Section 10's own explicit bound -- no
  // nested objects). `targetId` empty/unset defaults to Self (Section 12),
  // the same `resolveTarget` convention every other target-optional action
  // already uses -- a reusable enemy prefab never has to reference its own
  // generated Object ID.
  setObjectVariable: {
    label: 'Set Object Variable',
    fields: [
      { key: 'targetId', label: 'Target', type: 'target' },
      { key: 'name', label: 'Variable name', type: 'text', placeholder: 'activated' },
      { key: 'valueType', label: 'Type', type: 'select', options: ['number', 'boolean', 'string'] },
      { key: 'value', label: 'Value', type: 'text', placeholder: 'true / 0 / label' },
    ],
    exec: (p, item) => {
      const target = resolveTarget(p, item);
      if (!target || !p.name) return;
      target.variables = target.variables || {};
      let v = p.value;
      if (p.valueType === 'number') v = parseFloat(v) || 0;
      else if (p.valueType === 'boolean') v = (v === true || v === 'true');
      target.variables[p.name] = v;
    },
  },
  incrementObjectVariable: {
    label: 'Increment Object Variable',
    fields: [
      { key: 'targetId', label: 'Target', type: 'target' },
      { key: 'name', label: 'Variable name', type: 'text', placeholder: 'healthPhase' },
      { key: 'amount', label: 'Amount', type: 'number', placeholder: '1' },
    ],
    exec: (p, item) => {
      const target = resolveTarget(p, item);
      if (!target || !p.name) return;
      target.variables = target.variables || {};
      target.variables[p.name] = (Number(target.variables[p.name]) || 0) + (parseFloat(p.amount) || 1);
    },
  },
  toggleObjectVariable: {
    label: 'Toggle Object Variable',
    fields: [
      { key: 'targetId', label: 'Target', type: 'target' },
      { key: 'name', label: 'Variable name', type: 'text', placeholder: 'activated' },
    ],
    exec: (p, item) => {
      const target = resolveTarget(p, item);
      if (!target || !p.name) return;
      target.variables = target.variables || {};
      target.variables[p.name] = !target.variables[p.name];
    },
  },
  activateObjective: {
    label: 'Activate Objective',
    fields: [{ key: 'objectiveId', label: 'Objective', type: 'objectiveRef' }],
    exec: (p) => { if (p.objectiveId) { window.__gameObjectives = window.__gameObjectives || {}; window.__gameObjectives[p.objectiveId] = 'active'; } },
  },
  completeObjective: {
    label: 'Complete Objective',
    fields: [{ key: 'objectiveId', label: 'Objective', type: 'objectiveRef' }],
    exec: (p) => {
      if (!p.objectiveId) return;
      window.__gameObjectives = window.__gameObjectives || {};
      window.__gameObjectives[p.objectiveId] = 'complete';
      const def = findObjectiveDefById(p.objectiveId);
      if (def && def.nextObjective) window.__gameObjectives[def.nextObjective] = 'active';
    },
  },
  failObjective: {
    label: 'Fail Objective',
    fields: [{ key: 'objectiveId', label: 'Objective', type: 'objectiveRef' }],
    exec: (p) => { if (p.objectiveId) { window.__gameObjectives = window.__gameObjectives || {}; window.__gameObjectives[p.objectiveId] = 'failed'; } },
  },
  // Wave 7 (Priority J): Pickup/Carry/Drop -- `resolveTarget` defaults to
  // self, matching every other target-optional action's own convention
  // (e.g. Destroy Object), so an On Interact behavior authored directly on
  // the carryable object itself needs no explicit target.
  pickUpObject: {
    label: 'Pick Up Object',
    fields: [{ key: 'targetId', label: 'Target', type: 'target' }],
    exec: (p, item) => pickUpObject(resolveTarget(p, item)),
  },
  dropHeldObject: {
    label: 'Drop Held Object',
    fields: [],
    exec: () => dropHeldObject(),
  },
  // Runtime Save Game/Player Progress -- distinct from the EDITOR's own
  // project save (SaveSystem under a different namespace, 'editor-project'
  // et al.) -- this is the PLAYER's progress within a shipped game: level,
  // checkpoint, counters/flags, health, and last known position. Reuses the
  // existing public Opus.SaveSystem (already used for editor project saves)
  // under its own namespace rather than a second storage mechanism.
  //
  // Wave 7 (Priority E, Sections 33-41): World-State Save Game 2.0 --
  // `worldState` persists ONLY deliberately-marked runtime state
  // (`item.persistRuntimeState`, OFF by default), never a blind snapshot of
  // the whole live scene. Format version 2 (`saveFormatVersion: 2`) so a
  // save written by a pre-Wave-7 game (no `worldState` key at all) still
  // loads correctly -- `applyWorldStateToCurrentLevel` is a no-op with
  // nothing to apply, and every other field reads exactly as before.
  saveGame: {
    label: 'Save Game',
    fields: [{ key: 'slot', label: 'Slot name', type: 'text', placeholder: 'default' }],
    exec: (p) => { writeSaveGameSlot(p.slot || 'default'); showToast('Game saved'); },
  },
  // Wave 8 (Priority H/Section 50): Autosave -- an author-triggered write
  // to a fixed 'auto' slot (checkpoint/level-transition/objective-complete
  // -- the AUTHOR decides when, via an ordinary Behavior/Sequence step
  // calling this action; Section 50's own explicit "no surprise background
  // saves"). Reuses the exact same `writeSaveGameSlot` a manual Save Game
  // does -- one save-payload implementation, two slots.
  autosave: {
    label: 'Autosave',
    fields: [],
    exec: () => { writeSaveGameSlot('auto'); },
  },
  loadGame: {
    label: 'Load Game',
    fields: [{ key: 'slot', label: 'Slot name', type: 'text', placeholder: 'default' }],
    exec: (p) => {
      const saveSystem = new Opus.SaveSystem('doengine:playersave');
      const data = saveSystem.load(p.slot || 'default');
      if (!data) { showToast('No save found'); return; }
      window.__gameState = data.gameState || {};
      window.__gameFlags = data.flags || {};
      window.__gameInventory = data.inventory || {};
      window.__gameObjectives = data.objectives || {};
      window.__worldState = data.worldState || {}; // whole multi-level accumulator, not just the target level's slice
      window.__checkpoint = data.checkpoint ? new Opus.Vec3(...data.checkpoint) : null;
      window.__gamePlaytimeSeconds = data.playtimeSeconds || 0; // Wave 8 (Priority H): continues accumulating from where this save left off, not from 0
      // Wave 8 (Priority F/Section 97): re-equip whatever was equipped at
      // save time via the REAL `equipItemToSlot` (which itself already
      // checks Inventory has the item) -- never a raw state assignment,
      // so a save that somehow lost the underlying inventory item just
      // correctly equips nothing, not a broken half-state.
      if (data.equipment) for (const slotName in data.equipment) equipItemToSlot(data.equipment[slotName], slotName);
      // Wave 9 (Priority D/Section 49): restore weapon runtime AFTER
      // equipment (so the equip calls above haven't reset anything -- they
      // never touch weaponRuntimeState) -- a save with no `weaponRuntime`
      // key at all (every pre-Wave-9 save) leaves it `{}`, so every weapon
      // just starts fresh exactly as it already did before this priority
      // existed.
      weaponRuntimeState = {};
      if (data.weaponRuntime) {
        for (const key in data.weaponRuntime) weaponRuntimeState[key] = { magazine: data.weaponRuntime[key].magazine, reserve: data.weaponRuntime[key].reserve, reloading: false, reloadEnd: 0 };
      }
      activeWeaponSlot = data.activeWeaponSlot || 'primaryHand';
      syncActiveWeaponVisualVisibility();
      // Restore order (Section 37): (1) switch level [already happened by
      // the time we get here, or is about to], (2) the authored scene
      // rebuilds itself as a normal side effect of that switch, (3) THEN
      // apply worldState overrides -- never before the objects it targets
      // actually exist -- (4)/(5) spawn Player + restore its own position,
      // (6) resume. `switchToLevelDuringPlay` already handles (1)+(2)+spawn;
      // this action's own job is ordering (3) after it and before/alongside
      // the player-position restore.
      const applyPlayerPosition = () => { if (player && data.playerPosition) player.entity.position.set(...data.playerPosition); };
      if (Number.isInteger(data.levelIndex) && data.levelIndex !== currentLevelIndex && levels[data.levelIndex]) {
        switchToLevelDuringPlay(data.levelIndex);
        applyWorldStateToCurrentLevel();
        applyPlayerPosition();
      } else {
        applyWorldStateToCurrentLevel();
        applyPlayerPosition();
      }
      showToast('Game loaded');
    },
  },
  clearSaveGame: {
    label: 'Clear Save',
    fields: [{ key: 'slot', label: 'Slot name', type: 'text', placeholder: 'default' }],
    exec: (p) => new Opus.SaveSystem('doengine:playersave').delete(p.slot || 'default'),
  },
  // Named boolean Flags -- window.__gameFlags[name], a simpler primitive
  // than a counter for pure on/off state (a door unlocked, a switch
  // thrown) where "0 or 1" would be a slightly odd way to say it.
  setFlagTrue: {
    label: 'Set Flag True',
    fields: [{ key: 'name', label: 'Flag name', type: 'text', placeholder: 'Flag name' }],
    exec: (p) => { window.__gameFlags = window.__gameFlags || {}; window.__gameFlags[p.name] = true; },
  },
  setFlagFalse: {
    label: 'Set Flag False',
    fields: [{ key: 'name', label: 'Flag name', type: 'text', placeholder: 'Flag name' }],
    exec: (p) => { window.__gameFlags = window.__gameFlags || {}; window.__gameFlags[p.name] = false; },
  },
  toggleFlag: {
    label: 'Toggle Flag',
    fields: [{ key: 'name', label: 'Flag name', type: 'text', placeholder: 'Flag name' }],
    exec: (p) => { window.__gameFlags = window.__gameFlags || {}; window.__gameFlags[p.name] = !window.__gameFlags[p.name]; },
  },
  // Object Tags -- category-style membership (any number of objects can
  // share a tag), distinct from the stable per-object `id` Object
  // References already use for "this one specific object". Tag-wide
  // operations read `item.tags` (see the inspector's Tags field) against
  // `placed` directly, no separate registry to keep in sync.
  hideTagged: {
    label: 'Hide Tagged',
    fields: [{ key: 'tag', label: 'Tag', type: 'text', placeholder: 'Tag' }],
    exec: (p) => { for (const it of placed) if (it.kind === 'cube' && (it.tags || []).includes(p.tag)) it.entity.visible = false; },
  },
  destroyTagged: {
    label: 'Destroy Tagged',
    fields: [{ key: 'tag', label: 'Tag', type: 'text', placeholder: 'Tag' }],
    exec: (p) => { for (const it of placed.slice()) if (it.kind === 'cube' && (it.tags || []).includes(p.tag)) removeItemFromScene(it); },
  },
  countTagged: {
    label: 'Count Tagged Into Counter',
    fields: [
      { key: 'tag', label: 'Tag', type: 'text', placeholder: 'Tag' },
      { key: 'counter', label: 'Counter name', type: 'text', placeholder: 'Counter name' },
    ],
    exec: (p) => {
      window.__gameState = window.__gameState || {};
      window.__gameState[p.counter] = placed.filter((it) => it.kind === 'cube' && it.entity.visible && (it.tags || []).includes(p.tag)).length;
    },
  },
  // Named Timers -- window.__gameTimers[name] = {elapsed, duration,
  // countDown, running, finished}, ticked once per frame by tickTimers()
  // inside the main play-mode update loop (see app.onUpdate below), so
  // advancing is simulation-time and automatically pause-safe the same way
  // Player physics and AI already are (that whole callback is skipped while
  // app.paused). Count-up finishes at `duration` (0 = runs forever, only
  // useful with Timer At Least); count-down finishes at 0.
  startTimer: {
    label: 'Start Timer',
    fields: [
      { key: 'name', label: 'Timer name', type: 'text', placeholder: 'Timer name' },
      { key: 'duration', label: 'Duration (sec, 0 = no limit)', type: 'number', placeholder: '10' },
      { key: 'countDown', label: 'Count down (from Duration to 0)', type: 'checkbox' },
    ],
    exec: (p) => {
      window.__gameTimers = window.__gameTimers || {};
      const duration = Math.max(0, parseFloat(p.duration) || 0);
      window.__gameTimers[p.name] = { elapsed: p.countDown ? duration : 0, duration, countDown: !!p.countDown, running: true, finished: false };
    },
  },
  stopTimer: {
    label: 'Stop Timer',
    fields: [{ key: 'name', label: 'Timer name', type: 'text', placeholder: 'Timer name' }],
    exec: (p) => { const t = window.__gameTimers && window.__gameTimers[p.name]; if (t) t.running = false; },
  },
  resetTimer: {
    label: 'Reset Timer',
    fields: [{ key: 'name', label: 'Timer name', type: 'text', placeholder: 'Timer name' }],
    exec: (p) => {
      const t = window.__gameTimers && window.__gameTimers[p.name];
      if (t) { t.elapsed = t.countDown ? t.duration : 0; t.finished = false; }
    },
  },
  setTimer: {
    label: 'Set Timer',
    fields: [
      { key: 'name', label: 'Timer name', type: 'text', placeholder: 'Timer name' },
      { key: 'value', label: 'Value (sec)', type: 'number', placeholder: '0' },
    ],
    exec: (p) => {
      window.__gameTimers = window.__gameTimers || {};
      const t = window.__gameTimers[p.name] || (window.__gameTimers[p.name] = { elapsed: 0, duration: 0, countDown: false, running: false, finished: false });
      t.elapsed = Math.max(0, parseFloat(p.value) || 0);
      t.finished = false;
    },
  },
  script: {
    label: 'Advanced: Custom Script', legacy: true, legacyParam: 'code',
    fields: [{ key: 'code', label: 'Script', type: 'text', placeholder: 'JS using entity/app/Opus/game' }],
    exec: (p, item) => {
      // Custom Script runs arbitrary JS with full page access (window,
      // document, fetch, ...), not just the named params -- fine for a
      // project you're authoring yourself, not fine for one you just loaded
      // from someone else's file, where an 'On Enter' script would otherwise
      // fire the moment the player walks near it, with zero warning. See
      // API-FRICTION.md and AUDIT.md finding #1.
      if (!scriptsTrusted) {
        showToast('⚠ Custom Script is disabled for this loaded project — enable it in Project first');
        return;
      }
      try {
        const game = { win: () => endGame('win'), lose: () => endGame('lose'), setObjective };
        new Function('entity', 'app', 'Opus', 'game', p.code || '')(item.entity, app, Opus, game);
      } catch (err) {
        showToast(`Script error: ${err.message}`);
      }
    },
  },
};

function executeAction(actionType, params, item) {
  const def = ACTION_TYPES[actionType];
  if (!def) return;
  def.exec(params || {}, item);
}

// Reads a behavior record back into the flat params object executeAction
// expects, regardless of which of the two persisted shapes (legacy `.param`
// string vs. newer `.params` object) it was saved in.
function behaviorParams(behavior, def) {
  if (behavior.params) return behavior.params;
  if (def.legacy && def.legacyParam) return { [def.legacyParam]: behavior.param };
  return {};
}

// Renders one form field for an action param -- shared by the Node Graph
// node UI and the fixed dropdown's Add Behavior UI so a new field TYPE only
// needs handling written once.
function renderActionFieldInput(f, value, idAttr) {
  const idPart = idAttr ? ` id="${idAttr}"` : '';
  if (f.type === 'target') {
    const options = placed.map((p, i) => `<option value="${escapeHtml(p.id)}"${value === p.id ? ' selected' : ''}>${escapeHtml(itemDisplayName(p, i))}</option>`).join('');
    return `<select data-field="${f.key}"${idPart}><option value="">(self)</option>${options}</select>`;
  }
  if (f.type === 'prefab') {
    if (prefabs.length === 0) return '<p style="color:#8592a8;font-size:11.5px;margin:2px 0">No prefabs saved yet.</p>';
    const options = prefabs.map((p) => `<option value="${escapeHtml(p.name)}"${value === p.name ? ' selected' : ''}>${escapeHtml(p.name)}</option>`).join('');
    return `<select data-field="${f.key}"${idPart}>${options}</select>`;
  }
  if (f.type === 'audioAsset') {
    if (audioAssets.length === 0) return '<p style="color:#8592a8;font-size:11.5px;margin:2px 0">No audio imported yet (Assets tab).</p>';
    const options = audioAssets.map((a) => `<option value="${escapeHtml(a.id)}"${value === a.id ? ' selected' : ''}>${escapeHtml(a.name)}</option>`).join('');
    return `<select data-field="${f.key}"${idPart}><option value="">(none)</option>${options}</select>`;
  }
  // Wave 9D (Priority A): Prefab Parameter Mesh/Texture Asset types reuse
  // this exact same shared field-rendering function (not a parallel picker)
  // -- the SAME Asset Library dropdowns every other mesh/texture reference
  // in this editor already uses.
  if (f.type === 'meshAsset') {
    if (assets.length === 0) return '<p style="color:#8592a8;font-size:11.5px;margin:2px 0">No mesh assets imported yet (Assets tab).</p>';
    const options = assets.map((a) => `<option value="${escapeHtml(a.id)}"${value === a.id ? ' selected' : ''}>${escapeHtml(a.name)}</option>`).join('');
    return `<select data-field="${f.key}"${idPart}><option value="">(none)</option>${options}</select>`;
  }
  if (f.type === 'textureAsset') {
    if (textureAssets.length === 0) return '<p style="color:#8592a8;font-size:11.5px;margin:2px 0">No textures imported yet (Assets tab).</p>';
    const options = textureAssets.map((a) => `<option value="${escapeHtml(a.id)}"${value === a.id ? ' selected' : ''}>${escapeHtml(a.name)}</option>`).join('');
    return `<select data-field="${f.key}"${idPart}><option value="">(none)</option>${options}</select>`;
  }
  if (f.type === 'hudElementRef') {
    if (currentUiConfig.hudElements.length === 0) return '<p style="color:#8592a8;font-size:11.5px;margin:2px 0">No HUD elements on this level yet.</p>';
    const options = currentUiConfig.hudElements.map((el) => `<option value="${escapeHtml(el.id)}"${value === el.id ? ' selected' : ''}>${HUD_KIND_LABELS[el.kind]}${el.text ? ` "${escapeHtml(el.text)}"` : ''}</option>`).join('');
    return `<select data-field="${f.key}"${idPart}>${options}</select>`;
  }
  if (f.type === 'cameraPreset') {
    const cams = placed.filter((p) => p.kind === 'camera');
    if (cams.length === 0) return '<p style="color:#8592a8;font-size:11.5px;margin:2px 0">No Camera objects placed yet.</p>';
    const options = cams.map((p) => `<option value="${escapeHtml(p.id)}"${value === p.id ? ' selected' : ''}>${escapeHtml(itemDisplayName(p, placed.indexOf(p)))}</option>`).join('');
    return `<select data-field="${f.key}"${idPart}>${options}</select>`;
  }
  if (f.type === 'sequence') {
    if (currentSequences.length === 0) return '<p style="color:#8592a8;font-size:11.5px;margin:2px 0">No Sequences on this level yet (Level tab).</p>';
    const options = currentSequences.map((s) => `<option value="${escapeHtml(s.id)}"${value === s.id ? ' selected' : ''}>${escapeHtml(s.name)}</option>`).join('');
    return `<select data-field="${f.key}"${idPart}>${options}</select>`;
  }
  if (f.type === 'objectiveRef') {
    if (currentObjectiveDefs.length === 0) return '<p style="color:#8592a8;font-size:11.5px;margin:2px 0">No Objectives on this level yet (Level tab).</p>';
    const options = currentObjectiveDefs.map((o) => `<option value="${escapeHtml(o.id)}"${value === o.id ? ' selected' : ''}>${escapeHtml(o.title)}</option>`).join('');
    return `<select data-field="${f.key}"${idPart}>${options}</select>`;
  }
  if (f.type === 'itemDefRef') {
    if (currentItemDefs.length === 0) return '<p style="color:#8592a8;font-size:11.5px;margin:2px 0">No Items defined yet (Project tab).</p>';
    const options = currentItemDefs.map((d) => `<option value="${escapeHtml(d.id)}"${value === d.id ? ' selected' : ''}>${escapeHtml(d.name)}</option>`).join('');
    return `<select data-field="${f.key}"${idPart}>${options}</select>`;
  }
  if (f.type === 'level') {
    // Value is the level's stable id (survives rename/reorder), not its
    // name -- a raw name-based reference would silently point at the wrong
    // level (or nothing) the moment someone renamed it.
    const options = levels.map((l) => `<option value="${escapeHtml(l.id)}"${value === l.id ? ' selected' : ''}>${escapeHtml(l.name)}</option>`).join('');
    return `<select data-field="${f.key}"${idPart}>${options}</select>`;
  }
  if (f.type === 'select') {
    const options = (f.options || []).map((opt) => `<option value="${escapeHtml(opt)}"${value === opt ? ' selected' : ''}>${escapeHtml(opt)}</option>`).join('');
    return `<select data-field="${f.key}"${idPart}>${options}</select>`;
  }
  if (f.type === 'color') return `<input type="color" data-field="${f.key}"${idPart} value="${value || '#ffffff'}">`;
  if (f.type === 'checkbox') return `<label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#c7d3ea"><input type="checkbox" data-field="${f.key}"${idPart}${value ? ' checked' : ''}> ${escapeHtml(f.placeholder || '')}</label>`;
  return `<input type="${f.type === 'number' ? 'number' : 'text'}" data-field="${f.key}"${idPart} placeholder="${escapeHtml(f.placeholder || '')}" value="${value != null ? escapeHtml(String(value)) : ''}">`;
}

function runAction(behavior, item) {
  if (behavior.action === 'graph') {
    runGraph(behavior.graph, item);
    return;
  }
  if (behavior.action === 'dialogueTree') {
    runDialogueTree(behavior.dialogueTree);
    return;
  }
  const def = ACTION_TYPES[behavior.action];
  if (!def) return;
  executeAction(behavior.action, behaviorParams(behavior, def), item);
}

// --- Node graph (visual scripting) ---
// Additive, not a replacement: the fixed trigger/action list above stays
// exactly as-is (simple, tested, the common case). This is another Action
// choice for logic that's more than one fixed action but doesn't need the
// Custom Script escape hatch -- wiring together the SAME primitives
// (Message/Sound/Win/Lose/Boost/Objective) plus basic flow (AND/OR,
// a named counter) visually. Deliberately not general-purpose: no loops,
// no arbitrary math -- Custom Script remains the ceiling for that, same
// as it already is for the fixed list.
//
// Execution model: a graph has one implicit 'start' node. 'next' edges
// chain action nodes in sequence (start -> first action -> second -> ...).
// An action node may have at most one incoming 'gate' edge from a
// condition node; if present, the action only *executes* when the
// condition is true, but the chain always continues past it either way
// (a guard clause, not a branch) -- so "skip this one action if the
// condition's false, keep going" is expressible without needing an
// explicit else path. AND/OR read their operands via 'cond' edges from
// other condition nodes, recursively.
function evaluateConditionNode(node, graph, item) {
  if (!node) return false;
  if (node.type === 'and' || node.type === 'or') {
    const inputs = graph.edges
      .filter((e) => e.kind === 'cond' && e.to === node.id)
      .map((e) => graph.nodes.find((n) => n.id === e.from))
      .filter(Boolean);
    if (inputs.length === 0) return false;
    return node.type === 'and'
      ? inputs.every((n) => evaluateConditionNode(n, graph, item))
      : inputs.some((n) => evaluateConditionNode(n, graph, item));
  }
  if (node.type === 'counterReaches') {
    const value = (window.__gameState && window.__gameState[node.counter]) || 0;
    return value >= (node.target || 0);
  }
  // The >= direction above fits a counter that only ever climbs (score,
  // damage taken, crates collected) toward a threshold. A counter that
  // only ever falls (health, lives, ammo) needs the opposite direction --
  // found by dogfooding a health-based stress-test game, where wiring
  // Lose to Counter Reaches(health, 0) fired the instant health dropped
  // BELOW its starting value, since e.g. 2 >= 0 is already true.
  if (node.type === 'counterAtMost') {
    const value = (window.__gameState && window.__gameState[node.counter]) || 0;
    return value <= (node.target || 0);
  }
  // Health-specific wrapping of the same two comparisons above, reading the
  // fixed 'health' key instead of a free-typed counter name -- one less
  // place a typo ("Health" vs "health") could silently make a condition
  // never fire.
  if (node.type === 'healthAtLeast') {
    ensureHealthInit();
    return window.__gameState.health >= (node.target || 0);
  }
  if (node.type === 'healthAtMost') {
    ensureHealthInit();
    return window.__gameState.health <= (node.target || 0);
  }
  if (node.type === 'objectHealthAtLeast' || node.type === 'objectHealthAtMost') {
    const t = findItemById(node.targetId);
    if (!t || t.kind !== 'cube') return false;
    ensureObjectHealthInit(t);
    return node.type === 'objectHealthAtLeast' ? t.health.current >= (node.target || 0) : t.health.current <= (node.target || 0);
  }
  if (node.type === 'timerFinished') {
    const t = window.__gameTimers && window.__gameTimers[node.timer];
    return !!(t && t.finished);
  }
  if (node.type === 'timerAtLeast') {
    const t = window.__gameTimers && window.__gameTimers[node.timer];
    return !!t && t.elapsed >= (node.target || 0);
  }
  if (node.type === 'timerAtMost') {
    const t = window.__gameTimers && window.__gameTimers[node.timer];
    return !!t && t.elapsed <= (node.target || 0);
  }
  // NOT reads its single operand the same way AND/OR read theirs (a 'cond'
  // edge from another condition node) -- absent input is treated as false,
  // so NOT(nothing wired) is true, matching "nothing said this was true".
  if (node.type === 'not') {
    const inputEdge = graph.edges.find((e) => e.kind === 'cond' && e.to === node.id);
    const inputNode = inputEdge ? graph.nodes.find((n) => n.id === inputEdge.from) : null;
    return !evaluateConditionNode(inputNode, graph, item);
  }
  // Wave 8 (Priority B/Section 11): Object Variable conditions -- `targetId`
  // empty/unset resolves to `item` (Section 12's own "Target = Self must be
  // easy/default" requirement, the same `resolveTarget` convention every
  // target-optional ACTION already uses), so a reusable prefab's own logic
  // never has to reference its own generated Object ID.
  // Wave 8 (Priority K dogfood/Power Grid): Carry/Drop (Wave 7 Priority J)
  // never gained its own condition to gate logic on "is a specific object
  // currently held" -- its own dogfood used direct function calls, not a
  // real Node Graph. A generator/altar/socket-style "insert what you're
  // carrying" interaction genuinely needs this, so it's added here now,
  // matching every other bounded condition's own pattern.
  if (node.type === 'objectIsHeld') {
    if (!heldObjectItem) return false;
    return node.targetId ? heldObjectItem.id === node.targetId : true; // no targetId = "is ANYTHING currently held"
  }
  if (node.type === 'objectVariableEquals' || node.type === 'numberAtLeast' || node.type === 'numberAtMost' || node.type === 'booleanIs') {
    const t = node.targetId ? findItemById(node.targetId) : item;
    if (!t || !t.variables) return false;
    const v = t.variables[node.name];
    if (node.type === 'objectVariableEquals') return String(v) === String(node.value);
    if (node.type === 'numberAtLeast') return (Number(v) || 0) >= (parseFloat(node.value) || 0);
    if (node.type === 'numberAtMost') return (Number(v) || 0) <= (parseFloat(node.value) || 0);
    if (node.type === 'booleanIs') return !!v === (node.value === true || node.value === 'true');
  }
  if (node.type === 'counterEquals') {
    const value = (window.__gameState && window.__gameState[node.counter]) || 0;
    return value === (node.target || 0);
  }
  if (node.type === 'counterLessThan') {
    const value = (window.__gameState && window.__gameState[node.counter]) || 0;
    return value < (node.target || 0);
  }
  if (node.type === 'counterGreaterThan') {
    const value = (window.__gameState && window.__gameState[node.counter]) || 0;
    return value > (node.target || 0);
  }
  if (node.type === 'objectVisible') {
    const target = node.targetId ? findItemById(node.targetId) : null;
    const entity = target && target.kind === 'cube' ? target.entity : null;
    return !!(entity && entity.visible);
  }
  if (node.type === 'isFlagTrue') return !!(window.__gameFlags && window.__gameFlags[node.name]);
  if (node.type === 'isFlagFalse') return !(window.__gameFlags && window.__gameFlags[node.name]);
  if (node.type === 'hasItem') return ((window.__gameInventory && window.__gameInventory[node.name]) || 0) >= (node.count || 1);
  // Wave 7 (Priority F): objectiveIsComplete/objectiveIsActive read the
  // exact same window.__gameObjectives[id] state the three Objective
  // actions write, reusing this same evaluateConditionNode pattern rather
  // than a parallel objective-condition mechanism.
  if (node.type === 'objectiveIsComplete') return !!(window.__gameObjectives && window.__gameObjectives[node.objectiveId] === 'complete');
  if (node.type === 'objectiveIsActive') return !!(window.__gameObjectives && window.__gameObjectives[node.objectiveId] === 'active');
  // Wave 7 (Priority C/Section 21): "Slot Has Item" -- the one new condition
  // this priority's own dogfood justified, reusing the same evaluateConditionNode
  // pattern every other condition already follows rather than inventing a
  // parallel check mechanism.
  if (node.type === 'slotHasItem') return !!(playerEquipment[node.slot] && (!node.name || playerEquipment[node.slot].itemName === node.name));
  return false;
}

// A graph action node's own fields (node.text, node.force, node.targetId,
// ...) are already flat, in exactly the shape executeAction expects as
// `params` -- so the node object doubles as its own params object, no
// conversion needed (unlike runAction's legacy `.param` string, which does).
function runGraphActionNode(node, item) {
  executeAction(node.type, node, item);
}

// Delay/Wait nodes pause a graph run mid-sequence without blocking anything
// else -- Node Graph execution is normally fully synchronous (a bounded for
// loop), so a Delay literally can't "wait" inline; instead it registers
// itself here and the main per-frame loop resumes runGraph from right after
// it once enough simulation time (not real/wall time -- pause-safe for
// free, since this whole scheduler is only ever ticked from inside the
// engine's own onUpdate, which the engine itself stops calling while
// paused) has passed. Cleared on every Play start/Stop (enterPlayMode/
// exitPlayMode) so a delay from a previous session can never fire into a
// fresh one, and each entry is dropped if its item was removed from
// `placed` in the meantime (destroyed mid-delay) rather than resumed into
// a graph run against a no-longer-live object.
let pendingDelays = []; // { resumeAt, graph, item, fromId }
// Wave 6 (Priority M): a small, GENERIC "call this later" scheduler --
// deliberately separate from pendingDelays above, which is shaped
// specifically for resuming a Node Graph at a particular node, not for an
// arbitrary callback. Used by the Death animation delay (applyHitDamage)
// so a character isn't destroyed until its Death clip has actually had
// time to play.
let deferredCalls = []; // { fireAt, fn }
function processDeferredCalls() {
  if (deferredCalls.length === 0) return;
  const ready = deferredCalls.filter((d) => d.fireAt <= simElapsed);
  if (ready.length === 0) return;
  deferredCalls = deferredCalls.filter((d) => d.fireAt > simElapsed);
  for (const d of ready) d.fn();
}

// Wave 6B (Priority E): Sequence RUNTIME -- executes a Sequence's ordered
// steps through the exact same executeAction every Behavior/Node Graph
// action already funnels through (no second per-action implementation). A
// Delay step pauses the walk by scheduling its continuation through the
// SAME generic `deferredCalls` scheduler Priority M's death-animation delay
// already built (simulation time, not a setTimeout -- Freeze Player doesn't
// pause simulation, so a Sequence's own Delay keeps advancing correctly
// during a cutscene). `runningSequenceIds` is the reentrancy guard: while a
// sequence is mid-run, a second `playSequence` call for the SAME sequence is
// a no-op (Ignore policy) -- a predictable, documented default rather than
// silently starting a second overlapping run of the same steps.
let runningSequenceIds = [];
function runSequenceSteps(seq, item, stepIndex) {
  for (let i = stepIndex; i < seq.steps.length; i++) {
    const step = seq.steps[i];
    if (step.kind === 'delay') {
      const seconds = Math.max(0, parseFloat(step.seconds) || 0);
      // `sequenceRun: true` tags this deferred call as Sequence continuation
      // state specifically (not e.g. a Priority M death-animation removal,
      // which also uses this same generic scheduler) -- switchToLevelDuringPlay
      // filters on exactly this tag to cancel an in-flight cutscene cleanly on
      // Restart Level/Switch Level, without disturbing unrelated deferred work.
      deferredCalls.push({ fireAt: simElapsed + seconds, fn: () => runSequenceSteps(seq, item, i + 1), sequenceRun: true });
      return; // pause here -- resumes via the deferred call above
    }
    executeAction(step.actionType, step.params, item);
  }
  runningSequenceIds = runningSequenceIds.filter((id) => id !== seq.id);
}
function playSequence(seq, item) {
  if (!seq || !seq.steps || seq.steps.length === 0) return;
  if (runningSequenceIds.includes(seq.id)) return; // reentrancy: Ignore (see comment above)
  runningSequenceIds.push(seq.id);
  runSequenceSteps(seq, item, 0);
}

function runGraph(graph, item, startId) {
  if (!graph || !graph.nodes || !graph.edges) return;
  let currentId = startId || 'start';
  const visited = new Set(); // guards against an accidental cycle hanging the game
  for (let guard = 0; guard < 200; guard++) {
    const nextEdge = graph.edges.find((e) => e.kind === 'next' && e.from === currentId);
    if (!nextEdge || visited.has(nextEdge.to)) break;
    visited.add(nextEdge.to);
    const node = graph.nodes.find((n) => n.id === nextEdge.to);
    if (!node) break;
    // Dogfood (Signal Relay) fix: a node can have MORE THAN ONE gate edge
    // (e.g. a completion action gated on both "not already done" AND "all N
    // sub-conditions met"). This used to look up only the FIRST matching
    // gate edge via .find() and silently ignore any others -- so a node
    // with two gates would fire as soon as EITHER was true, not both,
    // since the second gate edge was dead code. Collect every gate edge
    // targeting this node and require ALL of their conditions to hold
    // (AND), matching what visual graph authoring actually implies by
    // drawing multiple gate arrows into the same node.
    const gateEdges = graph.edges.filter((e) => e.kind === 'gate' && e.to === node.id);
    const gatesPass = gateEdges.every((ge) => evaluateConditionNode(graph.nodes.find((n) => n.id === ge.from), graph, item));
    if (gateEdges.length === 0 || gatesPass) {
      if (node.type === 'delay') {
        const seconds = Math.max(0, parseFloat(node.seconds) || 0);
        pendingDelays.push({ resumeAt: simElapsed + seconds, graph, item, fromId: node.id });
        return; // sequence pauses here; the per-frame scheduler resumes it
      }
      runGraphActionNode(node, item);
      if (gameEnded) break;
    }
    currentId = node.id;
  }
}

function processPendingDelays() {
  if (pendingDelays.length === 0) return;
  const ready = pendingDelays.filter((pd) => pd.resumeAt <= simElapsed);
  if (ready.length === 0) return;
  pendingDelays = pendingDelays.filter((pd) => pd.resumeAt > simElapsed);
  for (const pd of ready) {
    if (gameEnded) break;
    if (pd.item && placed.indexOf(pd.item) === -1) continue; // item destroyed mid-delay
    runGraph(pd.graph, pd.item, pd.fromId);
  }
}

function runBehaviors(item, triggerType) {
  if (!item.behaviors || gameEnded) return;
  for (const behavior of item.behaviors) {
    if (behavior.trigger === triggerType) runAction(behavior, item);
  }
}

// Generic Interact: unlike Enter/Exit/Stay (proximity-driven, fire on their
// own), Interact needs an explicit press while in range -- closest
// interactable wins if more than one overlaps, matching how a player would
// expect "the thing I'm facing/nearest to" to respond, not all of them at
// once. INTERACT_RANGE is deliberately more generous than a Trigger
// Volume's own radius (1.5x scale) since Interact is meant to work from a
// natural "standing in front of it" distance, not requiring literal overlap.
const INTERACT_RANGE = 2.5;
let nearestInteractable = null;
function updateInteract() {
  const promptEl = document.getElementById('interact-prompt');
  const touchBtn = document.getElementById('touch-interact');
  if (!player) { nearestInteractable = null; promptEl.classList.remove('visible'); touchBtn.classList.remove('interactable-visible'); return; }
  let closest = null;
  let closestDist = INTERACT_RANGE;
  for (const item of placed) {
    if (item.kind !== 'cube' || !item.behaviors || !item.behaviors.some((b) => b.trigger === 'interact')) continue;
    if (!item.entity.visible) continue;
    const dist = player.entity.position.sub(item.entity.position).length();
    if (dist < closestDist) { closestDist = dist; closest = item; }
  }
  nearestInteractable = closest;
  promptEl.classList.toggle('visible', !!closest);
  touchBtn.classList.toggle('interactable-visible', !!closest);
}
function fireInteract() {
  // The keyboard path (app.input.wasPressed('KeyF'), read from inside
  // app.onUpdate) never reaches this function while app.paused -- the
  // engine itself gates ALL onUpdate callbacks behind `!this.paused` (see
  // 22-api.js). The touch Interact button's pointerdown listener is a raw
  // DOM listener with no such gate, so without this check, tapping it while
  // a Dialogue (or the Start Screen, or Pause itself) has the game paused
  // would re-fire the SAME interact behavior a second time on top of the
  // first -- e.g. opening a second Dialogue while the first is still
  // showing. Found while confirming Show Dialogue can't double-trigger.
  if (app.paused) return;
  if (nearestInteractable) runBehaviors(nearestInteractable, 'interact');
}

// --- Gamepad (optional) ---
// A small, generic mapping layer onto the SAME key codes every controller
// already reads (Input.simulateKeyDown/Up) -- no gamepad-specific code path
// in the Player Controllers, Boost action, or Interact, mirroring exactly
// how touch buttons already work. Deadzone on the left stick avoids drift
// on cheap/worn sticks constantly reporting a tiny nonzero axis value.
const GAMEPAD_STICK_DEADZONE = 0.25;
// Gamepad face buttons: A/Cross = Jump/Boost, B/Circle = Interact, X/Square
// = Attack -- all three (and Move on the left stick) read the CURRENT
// Input Action binding at poll time (see pollGamepad below), not a fixed
// map, so a rebind takes effect on gamepad with zero gamepad-specific code.
// --- Input Actions (Wave 4) ---
// A small, deliberately bounded rebind layer: named actions
// (`input.wasPressed(inputActionMap.NAME)` replacing a hardcoded key code
// directly) for Interact and Attack specifically -- the two inputs that
// were ALREADY dispatched from one central place (this file's own gameplay
// onUpdate) rather than embedded inside a specific Player Controller's own
// movement math. Movement (WASD) and Jump/Boost (Space) stayed hardcoded in
// Wave 4 for exactly that reason (threading a config lookup through three
// separate controllers' physics functions was real regression risk for a
// part of the input surface nobody had asked to rebind yet).
//
// Wave 5, Priority D: finishes the job. Move Forward/Back/Left/Right and
// Jump now go through this same map too, read by all four Player
// Controllers (`inputActionMap.moveForward` etc, see each controller's own
// movement block) instead of a hardcoded 'KeyW'. Every default value is the
// exact key it always was (KeyW/A/S/D, Space), so "existing controller
// behavior remains unchanged under default mappings" holds trivially -- and
// the Arrow keys stay a permanent, non-rebindable SECONDARY binding
// alongside whatever the primary is rebound to (every movement check below
// is `isDown(inputActionMap.moveForward) || isDown('ArrowUp')`, never just
// the mapped key alone), so a player who's used to arrows never loses them
// even after the primary WASD key is rebound to something else.
// Wave 6 (Priority B/Section 17-18): Crouch/Sprint join the map the exact
// same way Jump did in Wave 5 -- new named actions, real default keys
// (KeyC/ShiftLeft, chosen to avoid the browser/OS's own reserved Ctrl+key
// chords), read by name (`inputActionMap.crouch`/`.sprint`) by Third-Person
// and First-Person only (see CONTROLLER_RELEVANT_ACTIONS below), fully
// rebindable and warn-not-block conflict-checked like every other action.
let inputActionMap = { interact: 'KeyF', attack: 'KeyQ', moveForward: 'KeyW', moveBack: 'KeyS', moveLeft: 'KeyA', moveRight: 'KeyD', jump: 'Space', crouch: 'KeyC', sprint: 'ShiftLeft' };
// Wave 8 (Priority E/Section 30): `inventory` -- one new logical Input
// Action, reaching touch/gamepad through the exact same
// simulateKeyDown/Up remapping layer every other logical action already
// uses (no device-specific code needed, the same reasoning this project's
// own Gamepad Utility Gate re-confirmed for Jump back in Wave 3).
// Wave 9 (Priority A/Section 9): `reload` and `switchWeapon` join the same
// author-default/player-override architecture every other Input Action
// already uses -- no separate device logic, works through keyboard/touch/
// gamepad exactly like Interact/Attack.
const INPUT_ACTION_LABELS = { moveForward: 'Move Forward', moveBack: 'Move Back', moveLeft: 'Move Left', moveRight: 'Move Right', jump: 'Jump', interact: 'Interact', attack: 'Attack', crouch: 'Crouch', sprint: 'Sprint', inventory: 'Inventory', reload: 'Reload', switchWeapon: 'Switch Weapon' };
const INPUT_ACTION_DEFAULTS = { interact: 'KeyF', attack: 'KeyQ', moveForward: 'KeyW', moveBack: 'KeyS', moveLeft: 'KeyA', moveRight: 'KeyD', jump: 'Space', crouch: 'KeyC', sprint: 'ShiftLeft', inventory: 'KeyI', reload: 'KeyR', switchWeapon: 'KeyV' };
let rebindingAction = null; // action name currently waiting for its next keydown, or null

// Wave 6 (Priority D): the PLAYER's own rebind, kept entirely separate from
// `inputActionMap` (the AUTHOR's default, saved into the project and edited
// by the panel below). A shipped game's player can rebind Attack to their
// own preferred key/mouse button without that ever touching the author's
// saved default -- the exact "author-default-vs-player-override" split the
// spec asks for. Persisted per-project via the same `app.settings`
// namespace volume/quality already use (localStorage, keyed by the app's
// own settings namespace), loaded once on Play start.
let playerInputOverrides = {};
function loadPlayerInputOverrides() {
  playerInputOverrides = app.settings.get('inputOverrides') || {};
}
function savePlayerInputOverrides() {
  app.settings.set('inputOverrides', playerInputOverrides);
}
// The ONE read path every controller/gamepad/touch/interact call site below
// uses -- a Proxy so no call site needs to change from `inputActionMap.x`
// to some new name; reading `effectiveInputMap.x` transparently prefers the
// player's own override, falling back to the author's default. Editor-side
// code that's actually SETTING an author default (the rebind panel further
// down) still reads/writes the real `inputActionMap` directly, on purpose --
// that panel configures what ships as the default, not what an already-
// playing player currently has bound.
// Wave 6B (Priority G): a real bug found while dogfooding a multi-game/
// multi-project-load session, not assumed correct from reading the code
// alone -- this Proxy was constructed with `inputActionMap` (the object,
// captured ONCE, at module load) as its OWN `target`. `loadProjectFull`
// REASSIGNS the `inputActionMap` *variable* to a brand-new object every time
// a project loads (`inputActionMap = {...INPUT_ACTION_DEFAULTS, ...}`) --
// but a Proxy's target is bound at construction and can never repoint to
// follow a later reassignment of the variable that was passed in. The result:
// `effectiveInputMap` silently kept reading the FIRST project's (or the
// hardcoded pre-any-load default's) input map forever after, for the rest
// of the page session -- every subsequently loaded project's own custom
// bindings (e.g. an attack rebound to Mouse0) never actually took effect in
// real gameplay, even though `inputActionMap` itself held the correct
// value. Fixed by closing over the outer `inputActionMap` BINDING (a `let`,
// always current) inside the `get` trap instead of relying on the Proxy's
// own frozen target -- the dummy `{}` target is never actually read, since
// this trap intercepts every property access.
const effectiveInputMap = new Proxy({}, {
  get(_target, prop) { return (prop in playerInputOverrides) ? playerInputOverrides[prop] : inputActionMap[prop]; },
});
// Wave 6B (Priority G): a few more common `KeyboardEvent.code` values get a
// readable label -- found while dogfooding a real HUD `{bind:sprint}` prompt
// showing the raw "ShiftLeft" (still technically readable, just clunkier
// than every other binding this function already formats nicely). Modifier
// keys collapse their Left/Right variant into one label (an author rebinding
// to either physical key sees the same clean "Shift"/"Ctrl"/"Alt"), matching
// how this function already treats every OTHER binding as "the key", not
// "which physical copy of it".
function keyCodeToLabel(code) {
  if (!code) return '(unset)';
  if (code === 'Mouse0') return 'Left Click';
  if (code === 'Mouse1') return 'Middle Click';
  if (code === 'Mouse2') return 'Right Click';
  if (code.startsWith('Key')) return code.slice(3);
  if (code === 'Space') return 'Space';
  if (code === 'ShiftLeft' || code === 'ShiftRight') return 'Shift';
  if (code === 'ControlLeft' || code === 'ControlRight') return 'Ctrl';
  if (code === 'AltLeft' || code === 'AltRight') return 'Alt';
  if (code.startsWith('Digit')) return code.slice(5);
  if (code.startsWith('Arrow')) return code.slice(5);
  return code;
}
// Default Controller Maps (Wave 5, section 24): only the actions a given
// controller actually reads are worth showing in the rebind panel -- a
// Top-Down level has no Jump, so listing one would be a meaningless control
// nobody can ever trigger. 'jump' doubles as Hovercraft's own Boost input
// (both were always the same hardcoded Space key before this pass; still
// one shared slot, just rebindable now), labeled adaptively below.
const CONTROLLER_RELEVANT_ACTIONS = {
  hovercraft: ['moveForward', 'moveBack', 'moveLeft', 'moveRight', 'jump', 'interact', 'attack'],
  topdown: ['moveForward', 'moveBack', 'moveLeft', 'moveRight', 'interact', 'attack', 'reload', 'switchWeapon'],
  thirdperson: ['moveForward', 'moveBack', 'moveLeft', 'moveRight', 'jump', 'crouch', 'sprint', 'interact', 'attack', 'reload', 'switchWeapon'],
  firstperson: ['moveForward', 'moveBack', 'moveLeft', 'moveRight', 'jump', 'crouch', 'sprint', 'interact', 'attack', 'reload', 'switchWeapon'],
};
function renderInputActionPanel() {
  const listEl = document.getElementById('input-action-list');
  if (!listEl) return;
  const relevant = CONTROLLER_RELEVANT_ACTIONS[currentPlayerSettings.controllerType] || Object.keys(INPUT_ACTION_LABELS);
  listEl.innerHTML = relevant.map((name) => {
    const label = (name === 'jump' && currentPlayerSettings.controllerType === 'hovercraft') ? 'Boost' : INPUT_ACTION_LABELS[name];
    return `
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
      <span style="flex:1;font-size:12px;color:#c7d3ea">${label}</span>
      <button data-rebind-action="${name}" style="min-width:90px">${rebindingAction === name ? 'Press a key…' : keyCodeToLabel(inputActionMap[name])}</button>
    </div>`;
  }).join('');
  listEl.querySelectorAll('[data-rebind-action]').forEach((btn) => {
    btn.onclick = () => { rebindingAction = btn.dataset.rebindAction; renderInputActionPanel(); };
  });
}
window.addEventListener('keydown', (e) => {
  if (!rebindingAction) return;
  const tag = e.target.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
  e.preventDefault();
  // Input collision policy (Wave 5, section 23): a bounded "warn, don't
  // block" -- an author might genuinely want Attack and Interact on the
  // same key for a simple game (fewer buttons to explain), so refusing the
  // rebind outright would be presumptuous. The rebind still happens; the
  // OTHER action(s) already on that key just get flagged in the status
  // toast so it's never a silent surprise.
  const conflicting = Object.keys(inputActionMap).filter((k) => k !== rebindingAction && inputActionMap[k] === e.code);
  const reboundLabel = INPUT_ACTION_LABELS[rebindingAction];
  inputActionMap[rebindingAction] = e.code;
  rebindingAction = null;
  renderInputActionPanel();
  if (conflicting.length > 0) {
    showStatus(`${reboundLabel} rebound to ${keyCodeToLabel(e.code)} -- also used by ${conflicting.map((k) => INPUT_ACTION_LABELS[k]).join(', ')}`);
  } else {
    showStatus(`${reboundLabel} rebound to ${keyCodeToLabel(e.code)}`);
  }
});
renderInputActionPanel();

// Wave 6 (Priority D): the PLAYER-facing counterpart to renderInputActionPanel
// above -- shown from the Pause Menu during a real Play session, writes to
// `playerInputOverrides` (never touching the author's own `inputActionMap`),
// and accepts a MOUSE BUTTON as the next binding, not just a keyboard key
// (a rebind waiting on keydown alone would have no way to ever bind Attack
// to a mouse click). "(default)" vs a highlighted custom binding makes the
// override state visible at a glance, and a per-row Reset clears just that
// one action back to the author's own default.
let playerRebindingAction = null;
function renderControlsPanel() {
  const listEl = document.getElementById('controls-panel-list');
  if (!listEl) return;
  const relevant = CONTROLLER_RELEVANT_ACTIONS[currentPlayerSettings.controllerType] || Object.keys(INPUT_ACTION_LABELS);
  listEl.innerHTML = relevant.map((name) => {
    const label = (name === 'jump' && currentPlayerSettings.controllerType === 'hovercraft') ? 'Boost' : INPUT_ACTION_LABELS[name];
    const isCustom = name in playerInputOverrides;
    const current = effectiveInputMap[name];
    const display = playerRebindingAction === name ? 'Press a key or click…' : `${keyCodeToLabel(current)}${isCustom ? '' : ' (default)'}`;
    return `
    <div class="controls-row">
      <span>${label}</span>
      <div style="display:flex;gap:4px">
        <button class="${isCustom ? 'controls-row-custom' : ''}" data-controls-rebind="${name}">${display}</button>
        ${isCustom ? `<button data-controls-reset-one="${name}" title="Reset to default">↺</button>` : ''}
      </div>
    </div>`;
  }).join('');
  listEl.querySelectorAll('[data-controls-rebind]').forEach((btn) => {
    btn.onclick = () => { playerRebindingAction = btn.dataset.controlsRebind; renderControlsPanel(); };
  });
  listEl.querySelectorAll('[data-controls-reset-one]').forEach((btn) => {
    btn.onclick = () => {
      delete playerInputOverrides[btn.dataset.controlsResetOne];
      savePlayerInputOverrides();
      renderControlsPanel();
    };
  });
}
// Shared by both the keydown and mouse-button capture paths below -- one
// place that commits a player rebind, so the two input sources can never
// apply the conflict-check/save/status-toast logic differently.
function commitPlayerRebind(code) {
  if (!playerRebindingAction) return;
  const action = playerRebindingAction;
  playerRebindingAction = null;
  const conflicting = Object.keys(inputActionMap).filter((k) => k !== action && effectiveInputMap[k] === code);
  playerInputOverrides[action] = code;
  savePlayerInputOverrides();
  renderControlsPanel();
  const label = INPUT_ACTION_LABELS[action];
  if (conflicting.length > 0) {
    showStatus(`${label} rebound to ${keyCodeToLabel(code)} -- also used by ${conflicting.map((k) => INPUT_ACTION_LABELS[k]).join(', ')}`);
  } else {
    showStatus(`${label} rebound to ${keyCodeToLabel(code)}`);
  }
}
window.addEventListener('keydown', (e) => {
  if (!playerRebindingAction) return;
  const tag = e.target.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
  e.preventDefault();
  commitPlayerRebind(e.code);
});
// Mouse-button capture: listens on the canvas itself (not window) so a
// click on the rebind BUTTON that started this capture doesn't immediately
// end up being captured as its own new binding -- pointerdown on the
// button element is a different target than the canvas, so this listener
// simply never fires for that click at all.
canvas.addEventListener('pointerdown', (e) => {
  if (!playerRebindingAction || e.pointerType !== 'mouse') return;
  e.preventDefault();
  commitPlayerRebind(`Mouse${e.button}`);
});
// Wave 6 (Priority E): the Controls panel is now a top-level overlay
// reachable from BOTH the Pause Menu and the Main Menu (Start Screen) --
// one shared open/close pair wired to both trigger buttons, rather than
// two separate panel instances that could drift apart.
function openControlsPanel() {
  document.getElementById('controls-panel').classList.add('visible');
  renderControlsPanel();
}
function closeControlsPanel() {
  document.getElementById('controls-panel').classList.remove('visible');
  playerRebindingAction = null;
}
document.getElementById('pause-controls-btn').addEventListener('click', openControlsPanel);
document.getElementById('mainmenu-controls-btn').addEventListener('click', openControlsPanel);
document.getElementById('controls-close-btn').addEventListener('click', closeControlsPanel);
document.getElementById('controls-reset-btn').addEventListener('click', () => {
  playerInputOverrides = {};
  savePlayerInputOverrides();
  renderControlsPanel();
  showStatus('Controls reset to defaults');
});

// How To Play / Credits (Priority E) -- simple author-text overlays, same
// top-level-sibling pattern as Controls, only ever reachable from the Main
// Menu (there's no in-Play equivalent need for either, unlike Controls).
document.getElementById('mainmenu-howtoplay-btn').addEventListener('click', () => {
  document.getElementById('howtoplay-text').textContent = currentUiConfig.startScreen.howToPlay || '';
  document.getElementById('howtoplay-overlay').classList.add('visible');
});
document.getElementById('howtoplay-close-btn').addEventListener('click', () => {
  document.getElementById('howtoplay-overlay').classList.remove('visible');
});
document.getElementById('mainmenu-credits-btn').addEventListener('click', () => {
  document.getElementById('credits-text').textContent = currentUiConfig.startScreen.credits || '';
  document.getElementById('credits-overlay').classList.add('visible');
});
document.getElementById('credits-close-btn').addEventListener('click', () => {
  document.getElementById('credits-overlay').classList.remove('visible');
});
// Shows/hides the How To Play / Credits buttons based on whether the
// author actually wrote anything for them -- an untouched project (no text
// in either field) shows the Main Menu exactly as bare as it always was,
// matching the "omit at defaults" discipline every other optional feature
// in this editor already follows.
function updateMainMenuExtras() {
  const cfg = currentUiConfig.startScreen;
  document.getElementById('mainmenu-howtoplay-btn').style.display = (cfg.howToPlay && cfg.howToPlay.trim()) ? '' : 'none';
  document.getElementById('mainmenu-credits-btn').style.display = (cfg.credits && cfg.credits.trim()) ? '' : 'none';
  // Wave 6B (Priority G) / Wave 8 (Priority H, Section 53): Continue's own
  // visibility gate now checks BOTH the manual ('default') and Autosave
  // ('auto') slots via the real `SaveSystem.list()` (already sorted
  // newest-first) -- "choose newest valid save" when both exist, per this
  // Wave's own explicit policy, rather than always preferring one over the
  // other regardless of actual recency.
  const saveList = new Opus.SaveSystem('doengine:playersave').list().filter((s) => s.slot === 'default' || s.slot === 'auto');
  document.getElementById('mainmenu-continue-btn').style.display = saveList.length > 0 ? '' : 'none';
}
document.getElementById('mainmenu-continue-btn').addEventListener('click', () => {
  document.getElementById('start-overlay').classList.remove('visible');
  if (app.paused) app.resume();
  const saveList = new Opus.SaveSystem('doengine:playersave').list().filter((s) => s.slot === 'default' || s.slot === 'auto');
  const newestSlot = saveList.length > 0 ? saveList[0].slot : 'default'; // list() is already sorted newest-first
  executeAction('loadGame', { slot: newestSlot }, null);
});
// Shared Settings (Priority E) -- the SAME applyMasterVolume/renderQualityButton/
// fullscreen logic the Pause Menu already uses (Wave 4), just wired to a
// second set of elements living on the Main Menu -- no second
// volume/quality/fullscreen implementation, one behavior reachable from
// two screens.
document.getElementById('mainmenu-volume').addEventListener('input', (e) => applyMasterVolume(parseFloat(e.target.value)));
document.getElementById('mainmenu-quality-btn').addEventListener('click', () => {
  const currentlyHigh = app.settings.get('quality') !== 'low';
  app.setQuality(currentlyHigh ? 'low' : 'high');
  renderQualityButton();
});
document.getElementById('mainmenu-fullscreen-btn').addEventListener('click', () => {
  if (document.fullscreenElement) document.exitFullscreen();
  else canvas.requestFullscreen().catch(() => showStatus("Fullscreen isn't available"));
});
document.getElementById('mainmenu-volume').value = masterVolume;

// Tracks which keys WE (the gamepad poll) currently believe are held, so a
// key only gets simulateKeyUp'd on OUR OWN release edge -- never blindly
// every frame the pad isn't pressing it, which would fight a real physical
// keyboard held on the same code while a gamepad also happens to be
// connected (Input's key-state Set is shared between both input sources).
const gamepadHeldKeys = new Set();
let gamepadStartWasHeld = false; // Wave 9D (Priority I): edge-tracker for the gamepad Start->Pause wiring, reset alongside gamepadHeldKeys on Stop
// Right-stick look rate, in radians/second at full deflection -- a fixed
// constant rather than a per-project setting, since a stick already reports
// a continuous [-1,1] deflection (unlike a mouse's discrete pixel deltas),
// so "sensitivity" here just scales that continuous rate.
const GAMEPAD_LOOK_RATE = 2.6;
function pollGamepad(dt) {
  if (!navigator.getGamepads) return;
  const pads = navigator.getGamepads();
  const pad = pads && [...pads].find((p) => p && p.connected);
  const axX = pad ? (pad.axes[0] || 0) : 0;
  const axY = pad ? (pad.axes[1] || 0) : 0;
  // Move Forward/Back/Left/Right (Wave 5, Priority D) read the CURRENT
  // Input Action binding at poll time, exactly like Interact/Attack/Jump
  // below -- a rebind takes effect on gamepad too with zero gamepad-
  // specific rebind code, since this is just "what key does the stick
  // simulate right now," re-read every poll.
  const want = {};
  want[effectiveInputMap.moveForward] = !!pad && ((pad.buttons[12] && pad.buttons[12].pressed) || axY < -GAMEPAD_STICK_DEADZONE);
  want[effectiveInputMap.moveBack] = !!pad && ((pad.buttons[13] && pad.buttons[13].pressed) || axY > GAMEPAD_STICK_DEADZONE);
  want[effectiveInputMap.moveLeft] = !!pad && ((pad.buttons[14] && pad.buttons[14].pressed) || axX < -GAMEPAD_STICK_DEADZONE);
  want[effectiveInputMap.moveRight] = !!pad && ((pad.buttons[15] && pad.buttons[15].pressed) || axX > GAMEPAD_STICK_DEADZONE);
  want[effectiveInputMap.interact] = !!pad && !!(pad.buttons[1] && pad.buttons[1].pressed);
  want[effectiveInputMap.attack] = !!pad && !!(pad.buttons[2] && pad.buttons[2].pressed);
  want[effectiveInputMap.jump] = !!pad && !!(pad.buttons[0] && pad.buttons[0].pressed);
  // Wave 9D (Priority I/Section 57): gamepad coverage for the Wave 9/9B
  // Input Actions that pollGamepad had never been extended to reach --
  // Reload/Switch Weapon (new this Wave 9 arc) and Crouch/Sprint/Inventory/
  // Pause (pre-existing actions with a keyboard/touch mapping but no
  // gamepad one at all). Standard-layout button indices (Y/L1/L2/L3/R3/
  // Select/Start); reads `effectiveInputMap` at poll time exactly like
  // every action above, so a rebind takes effect on gamepad too with zero
  // gamepad-specific rebind code, same reasoning already established here.
  if (effectiveInputMap.reload) want[effectiveInputMap.reload] = !!pad && !!(pad.buttons[3] && pad.buttons[3].pressed);
  if (effectiveInputMap.switchWeapon) want[effectiveInputMap.switchWeapon] = !!pad && !!(pad.buttons[4] && pad.buttons[4].pressed);
  if (effectiveInputMap.crouch) want[effectiveInputMap.crouch] = !!pad && !!(pad.buttons[6] && pad.buttons[6].pressed);
  if (effectiveInputMap.sprint) want[effectiveInputMap.sprint] = !!pad && !!(pad.buttons[10] && pad.buttons[10].pressed);
  if (effectiveInputMap.inventory) want[effectiveInputMap.inventory] = !!pad && !!(pad.buttons[8] && pad.buttons[8].pressed);
  // Pause has no logical Input Action at all (a UI button, `#pause-btn`,
  // not part of `inputActionMap`) -- gamepad Start is wired directly to
  // that same button, edge-triggered off the held-button tracker every
  // other gamepad action already uses, not a second polling mechanism.
  const startHeld = !!pad && !!(pad.buttons[9] && pad.buttons[9].pressed);
  if (startHeld && !gamepadStartWasHeld) document.getElementById('pause-btn').click();
  gamepadStartWasHeld = startHeld;
  for (const code of Object.keys(want)) {
    if (want[code] && !gamepadHeldKeys.has(code)) { app.input.simulateKeyDown(code); gamepadHeldKeys.add(code); }
    else if (!want[code] && gamepadHeldKeys.has(code)) { app.input.simulateKeyUp(code); gamepadHeldKeys.delete(code); }
  }
  // First-Person right-stick look (Wave 5, section 19) -- feeds the exact
  // same applyFirstPersonLook function mouse Pointer Lock and touch drag
  // already use, so all three input sources share one clamp/sensitivity
  // path. Dead zone preserved (axes3/4 below GAMEPAD_STICK_DEADZONE are
  // ignored entirely, same threshold movement already uses).
  if (pad && player && player.controllerType === 'firstperson') {
    const lookX = pad.axes[2] || 0, lookY = pad.axes[3] || 0;
    const dx = Math.abs(lookX) > GAMEPAD_STICK_DEADZONE ? lookX : 0;
    const dy = Math.abs(lookY) > GAMEPAD_STICK_DEADZONE ? lookY : 0;
    if (dx !== 0 || dy !== 0) applyFirstPersonLook(dx * GAMEPAD_LOOK_RATE * dt, dy * GAMEPAD_LOOK_RATE * dt, 1);
  }
}
document.getElementById('touch-interact').addEventListener('pointerdown', (e) => { e.preventDefault(); fireInteract(); });
document.getElementById('touch-attack').addEventListener('pointerdown', (e) => { e.preventDefault(); fireAttack(); });
// Wave 9 (Priority A/Section 107): real touch coverage for Reload/Switch
// Weapon, Pointer Events, no touch-only parallel gameplay system -- both
// just call the exact same functions the keyboard path calls.
document.getElementById('touch-reload').addEventListener('pointerdown', (e) => { e.preventDefault(); const w = resolveActivePlayerWeapon(); if (w) startWeaponReload(w); });
document.getElementById('touch-switch').addEventListener('pointerdown', (e) => { e.preventDefault(); switchActiveWeaponSlot(); });
// Wave 9D (Priority H/Section 54): a dedicated touch Inventory button --
// Inventory was previously only reachable via the raw `KeyI` keydown
// listener (Wave 8), with no touch equivalent at all. Calls the exact same
// `toggleInventory()` the keyboard path already calls, no touch-only
// parallel gameplay code.
document.getElementById('touch-inventory').addEventListener('pointerdown', (e) => { e.preventDefault(); toggleInventory(); });

// --- Dialogue ---
// Pauses the engine (App.pause) so nothing moves/damages/spawns behind the
// box while it's up, same reasoning as the Start Screen -- a player reading
// dialogue text isn't dodging lava at the same time by accident.
function closeDialogue() {
  document.getElementById('dialogue-overlay').classList.remove('visible');
  if (app.paused) app.resume();
}
function showDialogue(p) {
  document.getElementById('dialogue-speaker').textContent = p.speaker || '';
  document.getElementById('dialogue-text').textContent = p.text || '';
  const choicesEl = document.getElementById('dialogue-choices');
  choicesEl.innerHTML = '';
  const addChoice = (label, flagName) => {
    const btn = document.createElement('button');
    btn.textContent = label;
    btn.onclick = () => {
      if (flagName) { window.__gameFlags = window.__gameFlags || {}; window.__gameFlags[flagName] = true; }
      closeDialogue();
    };
    choicesEl.appendChild(btn);
  };
  if (p.choice1Label) addChoice(p.choice1Label, p.choice1Flag);
  if (p.choice2Label) addChoice(p.choice2Label, p.choice2Flag);
  if (!p.choice1Label && !p.choice2Label) addChoice('Continue', null);
  document.getElementById('dialogue-overlay').classList.add('visible');
  app.pause();
}

// --- Branching Dialogue (Wave 3 Dialogue upgrade) ---
// The Wave 2 `showDialogue` above stays completely unmodified -- a real,
// working, still-useful bounded dialogue action for the common one-shot
// "speaker says a line, maybe two closing choices that set a flag" case.
// This is a SECOND, additive action (`dialogueTree`, not in ACTION_TYPES --
// same "outside the table" pattern 'graph' already uses) for when a scene
// wants an actual multi-line branching conversation: named entries, each
// with up to 3 choices, each choice optionally gated by a condition
// (reusing evaluateConditionNode -- the exact same leaf conditions the Node
// Graph already evaluates, not a second condition-evaluation system) and
// optionally jumping to another entry instead of always closing.
const DIALOGUE_CHOICE_CONDITIONS = {
  '': 'Always show',
  isFlagTrue: 'Flag is true',
  isFlagFalse: 'Flag is false',
  hasItem: 'Has item',
  healthAtLeast: 'Health at least',
  healthAtMost: 'Health at most',
  counterReaches: 'Counter at least',
  counterAtMost: 'Counter at most',
};
let nextDialogueEntryId = 1;
function generateDialogueEntryId() { return `d${nextDialogueEntryId++}`; }
function reconcileDialogueEntryIdCounter(tree) {
  for (const entry of tree.entries || []) {
    const match = /^d(\d+)$/.exec(entry.id);
    if (match) nextDialogueEntryId = Math.max(nextDialogueEntryId, Number(match[1]) + 1);
  }
}
function defaultDialogueChoice() { return { label: '', next: '', setFlag: '', condition: null }; }
function defaultDialogueEntry() { return { id: generateDialogueEntryId(), speaker: '', text: '', choices: [defaultDialogueChoice()] }; }

let dialogueEditorState = null;
function openDialogueEditor(item, existingBehavior, newTrigger) {
  const tree = existingBehavior && existingBehavior.dialogueTree
    ? JSON.parse(JSON.stringify(existingBehavior.dialogueTree))
    : { entries: [defaultDialogueEntry()], startEntry: null };
  reconcileDialogueEntryIdCounter(tree);
  if (!tree.startEntry && tree.entries.length) tree.startEntry = tree.entries[0].id;
  dialogueEditorState = { item, existingBehavior, trigger: existingBehavior ? existingBehavior.trigger : newTrigger, tree };
  document.getElementById('dialogue-editor-modal').classList.add('visible');
  renderDialogueEditor();
}
function closeDialogueEditor() {
  document.getElementById('dialogue-editor-modal').classList.remove('visible');
  dialogueEditorState = null;
}
function renderDialogueEditor() {
  const { tree } = dialogueEditorState;
  const startSel = document.getElementById('dialogue-start-entry');
  startSel.innerHTML = tree.entries.map((e) => `<option value="${e.id}"${tree.startEntry === e.id ? ' selected' : ''}>${escapeHtml(e.speaker || '(no speaker)')} — ${e.id}</option>`).join('');
  startSel.onchange = () => { tree.startEntry = startSel.value; };

  const nextOptions = (currentValue) => `<option value=""${!currentValue ? ' selected' : ''}>(close dialogue)</option>`
    + tree.entries.map((e) => `<option value="${e.id}"${currentValue === e.id ? ' selected' : ''}>${escapeHtml(e.speaker || '(no speaker)')} — ${e.id}</option>`).join('');

  const listEl = document.getElementById('dialogue-entry-list');
  listEl.innerHTML = tree.entries.map((entry, entryIndex) => `
    <div class="dialogue-entry-card" data-entry-id="${entry.id}">
      <div class="dialogue-entry-card-header">
        <span class="dialogue-entry-id">${entry.id}${tree.startEntry === entry.id ? ' · START' : ''}</span>
        <button class="dialogue-remove-btn" data-remove-entry="${entry.id}" title="Delete entry">✕ Delete Entry</button>
      </div>
      <label style="font-size:11px;color:#8592a8">Speaker</label>
      <input type="text" data-entry-field="speaker" placeholder="e.g. Old Sailor" value="${escapeHtml(entry.speaker || '')}">
      <label style="font-size:11px;color:#8592a8;display:block;margin-top:6px">Text</label>
      <textarea data-entry-field="text" placeholder="What they say" rows="2">${escapeHtml(entry.text || '')}</textarea>
      <label style="font-size:11px;color:#8592a8;display:block;margin-top:8px">Choices (shown as buttons; a choice with no condition always shows)</label>
      ${entry.choices.map((choice, choiceIndex) => `
        <div class="dialogue-choice-row" data-choice-index="${choiceIndex}">
          <div class="dialogue-choice-row-header">
            <span>Choice ${choiceIndex + 1}</span>
            <button class="dialogue-remove-btn" data-remove-choice="${choiceIndex}" title="Remove choice">✕</button>
          </div>
          <div class="dialogue-choice-grid">
            <input type="text" data-choice-field="label" placeholder="Button label (default: Continue)" value="${escapeHtml(choice.label || '')}">
            <select data-choice-field="next">${nextOptions(choice.next)}</select>
            <input type="text" data-choice-field="setFlag" placeholder="Sets flag (optional)" value="${escapeHtml(choice.setFlag || '')}">
            <select data-choice-field="conditionType">${Object.entries(DIALOGUE_CHOICE_CONDITIONS).map(([type, label]) => `<option value="${type}"${(choice.condition ? choice.condition.type : '') === type ? ' selected' : ''}>${label}</option>`).join('')}</select>
          </div>
          ${choice.condition ? `
          <div class="dialogue-choice-grid" style="margin-top:6px">
            <input type="text" data-choice-field="conditionName" placeholder="${choice.condition.type === 'hasItem' ? 'Item name' : choice.condition.type.startsWith('health') ? '(health, no name needed)' : 'Counter/Flag name'}" value="${escapeHtml(choice.condition.name || '')}"${choice.condition.type.startsWith('health') ? ' disabled' : ''}>
            ${choice.condition.type !== 'isFlagTrue' && choice.condition.type !== 'isFlagFalse' ? `<input type="number" data-choice-field="conditionValue" placeholder="Value" value="${choice.condition.value ?? (choice.condition.type === 'hasItem' ? 1 : 0)}">` : '<span></span>'}
          </div>` : ''}
        </div>
      `).join('')}
      <button class="dialogue-add-choice-btn" data-add-choice="${entry.id}">+ Add Choice</button>
    </div>
  `).join('');

  listEl.querySelectorAll('[data-entry-field]').forEach((el) => {
    const entryId = el.closest('.dialogue-entry-card').dataset.entryId;
    el.addEventListener('input', () => {
      const entry = tree.entries.find((e) => e.id === entryId);
      entry[el.dataset.entryField] = el.value;
      if (el.dataset.entryField === 'speaker') renderDialogueEditor(); // start-entry dropdown labels need refreshing
    });
  });
  listEl.querySelectorAll('[data-choice-field]').forEach((el) => {
    const card = el.closest('.dialogue-entry-card');
    const entryId = card.dataset.entryId;
    const choiceIndex = Number(el.closest('.dialogue-choice-row').dataset.choiceIndex);
    el.addEventListener('input', () => applyDialogueChoiceField(tree, entryId, choiceIndex, el));
    el.addEventListener('change', () => applyDialogueChoiceField(tree, entryId, choiceIndex, el));
  });
  listEl.querySelectorAll('[data-add-choice]').forEach((btn) => {
    btn.onclick = () => {
      const entry = tree.entries.find((e) => e.id === btn.dataset.addChoice);
      if (entry.choices.length >= 3) return; // bounded, same spirit as the Wave 2 action's fixed 2-choice cap, just one wider
      entry.choices.push(defaultDialogueChoice());
      renderDialogueEditor();
    };
  });
  listEl.querySelectorAll('[data-remove-choice]').forEach((btn) => {
    btn.onclick = () => {
      const entryId = btn.closest('.dialogue-entry-card').dataset.entryId;
      const entry = tree.entries.find((e) => e.id === entryId);
      entry.choices.splice(Number(btn.dataset.removeChoice), 1);
      renderDialogueEditor();
    };
  });
  listEl.querySelectorAll('[data-remove-entry]').forEach((btn) => {
    btn.onclick = () => {
      if (tree.entries.length <= 1) { showStatus('A dialogue needs at least one entry.'); return; }
      const removedId = btn.dataset.removeEntry;
      tree.entries = tree.entries.filter((e) => e.id !== removedId);
      // Any choice that pointed at the removed entry now closes the dialogue
      // instead of jumping to a dangling id -- simpler and safer than
      // forcing the author to fix every referencing choice before deleting.
      for (const entry of tree.entries) for (const choice of entry.choices) if (choice.next === removedId) choice.next = '';
      if (tree.startEntry === removedId) tree.startEntry = tree.entries[0].id;
      renderDialogueEditor();
    };
  });
}
function applyDialogueChoiceField(tree, entryId, choiceIndex, el) {
  const entry = tree.entries.find((e) => e.id === entryId);
  const choice = entry.choices[choiceIndex];
  const field = el.dataset.choiceField;
  if (field === 'conditionType') {
    choice.condition = el.value ? { type: el.value, name: '', value: el.value === 'hasItem' ? 1 : 0 } : null;
    renderDialogueEditor();
    return;
  }
  if (field === 'conditionName') { choice.condition.name = el.value; return; }
  if (field === 'conditionValue') { choice.condition.value = parseFloat(el.value) || 0; return; }
  choice[field] = el.value;
}
document.getElementById('dialogue-add-entry-btn').addEventListener('click', () => {
  dialogueEditorState.tree.entries.push(defaultDialogueEntry());
  renderDialogueEditor();
});
document.getElementById('dialogue-editor-cancel-btn').addEventListener('click', closeDialogueEditor);
document.getElementById('dialogue-editor-save-btn').addEventListener('click', () => {
  const { item, existingBehavior, trigger, tree } = dialogueEditorState;
  pushUndo();
  if (existingBehavior) existingBehavior.dialogueTree = tree;
  else item.behaviors.push({ trigger, action: 'dialogueTree', dialogueTree: tree });
  closeDialogueEditor();
  renderBehaviorList(item);
});

// Translates a dialogue-choice condition (a plain {type, name, value}
// object authored in the editor above) into the shape evaluateConditionNode
// already expects from a Node Graph condition node, and evaluates it with
// no `graph` context -- safe because dialogue conditions are deliberately
// restricted to LEAF condition types (no and/or/not nesting, which are the
// only branches that ever read the second argument).
function evaluateDialogueCondition(condition) {
  if (!condition) return true;
  const node = { type: condition.type, name: condition.name, counter: condition.name, target: condition.value, count: condition.value };
  return evaluateConditionNode(node, null);
}
function runDialogueEntry(tree, entryId) {
  const entry = tree.entries.find((e) => e.id === entryId);
  if (!entry) { closeDialogue(); return; }
  document.getElementById('dialogue-speaker').textContent = entry.speaker || '';
  document.getElementById('dialogue-text').textContent = entry.text || '';
  const choicesEl = document.getElementById('dialogue-choices');
  choicesEl.innerHTML = '';
  const visibleChoices = (entry.choices || []).filter((c) => evaluateDialogueCondition(c.condition));
  const addChoice = (label, choice) => {
    const btn = document.createElement('button');
    btn.textContent = label;
    btn.onclick = () => {
      if (choice.setFlag) { window.__gameFlags = window.__gameFlags || {}; window.__gameFlags[choice.setFlag] = true; }
      if (choice.next) runDialogueEntry(tree, choice.next);
      else closeDialogue();
    };
    choicesEl.appendChild(btn);
  };
  if (visibleChoices.length === 0) addChoice('Continue', {});
  else visibleChoices.forEach((c) => addChoice(c.label || 'Continue', c));
  document.getElementById('dialogue-overlay').classList.add('visible');
  app.pause();
}
function runDialogueTree(tree) {
  if (!tree || !tree.entries || tree.entries.length === 0) return;
  runDialogueEntry(tree, tree.startEntry || tree.entries[0].id);
}

const TRIGGER_LABELS = { click: 'On Click', enter: 'On Enter', exit: 'On Exit', start: 'On Start', stay: 'On Stay (every frame while inside)', interact: 'On Interact (F / touch button, in range)' };
// Action labels come from ACTION_TYPES (the shared action-execution core,
// above) rather than a second hand-maintained label map; 'graph' is the one
// action outside that table, since it opens its own editor instead of
// executing through executeAction directly.
function actionLabel(action) {
  if (action === 'graph') return 'Node Graph';
  if (action === 'dialogueTree') return 'Show Dialogue (Branching)';
  return (ACTION_TYPES[action] || {}).label || action;
}

function behaviorPreview(b) {
  if ((b.action === 'message' || b.action === 'objective') && b.param) return `: "${escapeHtml(b.param)}"`;
  if (b.action === 'boost' && b.param) return `: force ${escapeHtml(b.param)}`;
  if (b.action === 'script' && b.param) {
    const oneLine = b.param.replace(/\s+/g, ' ').trim();
    return `: <code>${escapeHtml(oneLine.slice(0, 40))}${oneLine.length > 40 ? '…' : ''}</code>`;
  }
  if (b.action === 'graph' && b.graph) return `: ${b.graph.nodes.length} node${b.graph.nodes.length === 1 ? '' : 's'}`;
  if (b.action === 'dialogueTree' && b.dialogueTree) return `: ${b.dialogueTree.entries.length} entr${b.dialogueTree.entries.length === 1 ? 'y' : 'ies'}`;
  if (b.params) {
    const def = ACTION_TYPES[b.action];
    const parts = [];
    if (b.params.targetId) {
      const targetItem = findItemById(b.params.targetId);
      parts.push(`target: ${targetItem ? itemDisplayName(targetItem, placed.indexOf(targetItem)) : '(deleted)'}`);
    }
    for (const f of (def ? def.fields : [])) {
      if (f.key === 'targetId') continue;
      if (b.params[f.key] !== undefined && b.params[f.key] !== '') parts.push(`${f.key}: ${b.params[f.key]}`);
    }
    return parts.length ? `: ${escapeHtml(parts.join(', '))}` : '';
  }
  return '';
}

function renderBehaviorList(item) {
  const el = document.getElementById('behavior-list');
  if (!el) return;
  if (item.behaviors.length === 0) {
    el.innerHTML = '<div style="color:#66759a;font-size:11.5px;margin-bottom:6px">No behaviors yet.</div>';
    return;
  }
  el.innerHTML = item.behaviors.map((b, i) => {
    const summary = `${TRIGGER_LABELS[b.trigger]} → ${actionLabel(b.action)}${behaviorPreview(b)}`;
    return `
    <div class="behavior-item${b.action === 'script' ? ' script-behavior' : ''}">
      <span title="${escapeHtml(summary)}">${summary}</span>
      <span>${b.action === 'graph' ? `<button data-edit-index="${i}" title="Edit graph">✎</button>` : ''}${b.action === 'dialogueTree' ? `<button data-edit-dialogue-index="${i}" title="Edit dialogue">✎</button>` : ''}<button data-index="${i}">✕</button></span>
    </div>
  `;
  }).join('');
  el.querySelectorAll('button[data-index]').forEach((btn) => {
    btn.onclick = () => {
      pushUndo();
      item.behaviors.splice(Number(btn.dataset.index), 1);
      renderBehaviorList(item);
    };
  });
  el.querySelectorAll('button[data-edit-index]').forEach((btn) => {
    btn.onclick = () => {
      const behavior = item.behaviors[Number(btn.dataset.editIndex)];
      openGraphEditor(item, behavior);
    };
  });
  el.querySelectorAll('button[data-edit-dialogue-index]').forEach((btn) => {
    btn.onclick = () => {
      const behavior = item.behaviors[Number(btn.dataset.editDialogueIndex)];
      openDialogueEditor(item, behavior);
    };
  });
}

// --- Node graph editor UI ---
// Ports connect by clicking one, then clicking a compatible second one
// (not drag-to-connect) -- more forgiving than precise drag-release
// hit-testing on small circular targets, and works the same from touch as
// from mouse with no separate code path, consistent with the touch-support
// pass earlier this session.
// Action-kind entries are generated directly FROM ACTION_TYPES (same
// label, same field list) -- the graph never invents its own copy of what
// an action does or takes; see the shared action-execution core above.
// 'script' is deliberately excluded: Node Graph's whole point is a
// non-code visual path, so the code escape hatch stays fixed-dropdown-only.
// Condition nodes (and/or/counterReaches) are graph-only -- there's no
// equivalent concept in the fixed dropdown.
const GRAPH_NODE_TYPES = {};
for (const [type, def] of Object.entries(ACTION_TYPES)) {
  if (type === 'script') continue;
  GRAPH_NODE_TYPES[type] = { label: def.label, kind: 'action', fields: def.fields };
}
Object.assign(GRAPH_NODE_TYPES, {
  and: { label: 'AND', kind: 'condition', fields: [] },
  or: { label: 'OR', kind: 'condition', fields: [] },
  counterReaches: { label: 'Counter Reaches (>=)', kind: 'condition', fields: [{ key: 'counter', type: 'text', placeholder: 'Counter name' }, { key: 'target', type: 'number', placeholder: 'Target' }] },
  counterAtMost: { label: 'Counter At Most (<=)', kind: 'condition', fields: [{ key: 'counter', type: 'text', placeholder: 'Counter name' }, { key: 'target', type: 'number', placeholder: 'Target' }] },
  healthAtLeast: { label: 'Health At Least (>=)', kind: 'condition', fields: [{ key: 'target', type: 'number', placeholder: 'Target' }] },
  healthAtMost: { label: 'Health At Most (<=)', kind: 'condition', fields: [{ key: 'target', type: 'number', placeholder: 'Target' }] },
  // Object Health (Wave 4) -- an explicit `targetId` field rather than an
  // implicit "the object this graph is attached to", since evaluateConditionNode
  // has no item-context parameter (only node+graph) -- consistent with how
  // every OTHER object reference in this engine (Change Camera, AI Follow
  // Target, Set Position) is already an explicit dropdown, not implicit.
  objectHealthAtLeast: { label: 'Object Health At Least (>=)', kind: 'condition', fields: [{ key: 'targetId', label: 'Object', type: 'target' }, { key: 'target', type: 'number', placeholder: 'Target' }] },
  objectHealthAtMost: { label: 'Object Health At Most (<=)', kind: 'condition', fields: [{ key: 'targetId', label: 'Object', type: 'target' }, { key: 'target', type: 'number', placeholder: 'Target' }] },
  // Graph-only, same reasoning as and/or/counterReaches above -- Delay is a
  // sequencing primitive (see runGraph/processPendingDelays), not a single
  // fire-and-forget action, so it has no fixed-dropdown equivalent.
  delay: { label: 'Delay / Wait', kind: 'action', fields: [{ key: 'seconds', label: 'Seconds', type: 'number', placeholder: '1' }] },
  timerFinished: { label: 'Timer Finished', kind: 'condition', fields: [{ key: 'timer', type: 'text', placeholder: 'Timer name' }] },
  timerAtLeast: { label: 'Timer At Least (>=)', kind: 'condition', fields: [{ key: 'timer', type: 'text', placeholder: 'Timer name' }, { key: 'target', type: 'number', placeholder: 'Target' }] },
  timerAtMost: { label: 'Timer At Most (<=)', kind: 'condition', fields: [{ key: 'timer', type: 'text', placeholder: 'Timer name' }, { key: 'target', type: 'number', placeholder: 'Target' }] },
  not: { label: 'NOT', kind: 'condition', fields: [] },
  counterEquals: { label: 'Counter Equals (=)', kind: 'condition', fields: [{ key: 'counter', type: 'text', placeholder: 'Counter name' }, { key: 'target', type: 'number', placeholder: 'Target' }] },
  counterLessThan: { label: 'Counter Less Than (<)', kind: 'condition', fields: [{ key: 'counter', type: 'text', placeholder: 'Counter name' }, { key: 'target', type: 'number', placeholder: 'Target' }] },
  counterGreaterThan: { label: 'Counter Greater Than (>)', kind: 'condition', fields: [{ key: 'counter', type: 'text', placeholder: 'Counter name' }, { key: 'target', type: 'number', placeholder: 'Target' }] },
  objectVisible: { label: 'Object Visible', kind: 'condition', fields: [{ key: 'targetId', label: 'Object', type: 'target' }] },
  isFlagTrue: { label: 'Is Flag True', kind: 'condition', fields: [{ key: 'name', type: 'text', placeholder: 'Flag name' }] },
  isFlagFalse: { label: 'Is Flag False', kind: 'condition', fields: [{ key: 'name', type: 'text', placeholder: 'Flag name' }] },
  hasItem: { label: 'Has Item', kind: 'condition', fields: [{ key: 'name', type: 'text', placeholder: 'Item name' }, { key: 'count', type: 'number', placeholder: 'Count (default 1)' }] },
  // Wave 7: only nodes forced by a new system, per this wave's own explicit
  // Node Graph scope -- Objective conditions (Priority F) and Slot Has Item
  // (Priority C), reusing the exact same `evaluateConditionNode` cases
  // already written for the fixed-list side, nothing new evaluated here.
  objectiveIsComplete: { label: 'Objective Is Complete', kind: 'condition', fields: [{ key: 'objectiveId', type: 'objectiveRef' }] },
  objectiveIsActive: { label: 'Objective Is Active', kind: 'condition', fields: [{ key: 'objectiveId', type: 'objectiveRef' }] },
  slotHasItem: { label: 'Equipment Slot Has Item', kind: 'condition', fields: [{ key: 'slot', type: 'text', placeholder: 'primaryHand' }, { key: 'name', type: 'text', placeholder: 'Item name (optional)' }] },
  objectIsHeld: { label: 'Object Is Held (Carry/Drop)', kind: 'condition', fields: [{ key: 'targetId', type: 'target' }] },
  // Wave 8 (Priority B): `targetId` optional -- empty means Self, the exact
  // same default `evaluateConditionNode`'s own new cases resolve.
  objectVariableEquals: { label: 'Object Variable Equals', kind: 'condition', fields: [{ key: 'targetId', type: 'target' }, { key: 'name', type: 'text', placeholder: 'label' }, { key: 'value', type: 'text', placeholder: 'value' }] },
  numberAtLeast: { label: 'Object Variable Number At Least', kind: 'condition', fields: [{ key: 'targetId', type: 'target' }, { key: 'name', type: 'text', placeholder: 'healthPhase' }, { key: 'value', type: 'number', placeholder: '1' }] },
  numberAtMost: { label: 'Object Variable Number At Most', kind: 'condition', fields: [{ key: 'targetId', type: 'target' }, { key: 'name', type: 'text', placeholder: 'healthPhase' }, { key: 'value', type: 'number', placeholder: '1' }] },
  booleanIs: { label: 'Object Variable Boolean Is', kind: 'condition', fields: [{ key: 'targetId', type: 'target' }, { key: 'name', type: 'text', placeholder: 'activated' }, { key: 'value', type: 'select', options: ['true', 'false'] }] },
});
// (from-port, to-port) -> edge kind. Checked in both click orders, since
// the user might click either port of a pair first.
const GRAPH_EDGE_RULES = [
  { from: 'next-out', to: 'next-in', kind: 'next' },
  { from: 'cond-out', to: 'gate-in', kind: 'gate' },
  { from: 'cond-out', to: 'cond-in', kind: 'cond' },
];

let graphEditorState = null; // { item, existingBehavior, trigger, graph, dragNode, pendingConnection }
let graphNodeIdCounter = 1;

// AUDIT.md finding #3: graphNodeIdCounter is monotonic within one page
// session (safe there -- always increasing, so a new node never collides
// with an earlier one in ANY graph created that session), but resets to 1
// on every fresh load while a saved project's graphs keep whatever ids
// they were created with. Opening a previously-saved graph after a reload
// and adding a node could silently reuse an id already in that graph
// (e.g. 'n1'), leaving two DOM nodes sharing data-node-id and corrupting
// every id-keyed lookup (ports, drag, delete). Reconciling the counter
// against whatever the graph being opened already contains, every time,
// fixes this regardless of how it got out of sync.
function reconcileGraphNodeIdCounter(graph) {
  for (const node of graph.nodes) {
    const match = /^n(\d+)$/.exec(node.id);
    if (match) graphNodeIdCounter = Math.max(graphNodeIdCounter, Number(match[1]) + 1);
  }
}

function openGraphEditor(item, existingBehavior, newTrigger) {
  const graph = existingBehavior && existingBehavior.graph
    ? JSON.parse(JSON.stringify(existingBehavior.graph))
    : { nodes: [], edges: [] };
  reconcileGraphNodeIdCounter(graph);
  graphEditorState = { item, existingBehavior, trigger: existingBehavior ? existingBehavior.trigger : newTrigger, graph, dragNode: null, pendingConnection: null, view: { x: 40, y: 40, scale: 1 }, panning: null };
  document.getElementById('graph-modal').classList.add('visible');
  const searchEl = document.getElementById('graph-node-search');
  searchEl.value = '';
  searchEl.dispatchEvent(new Event('input')); // un-hides any buttons a previous session's filter left hidden
  renderGraphNodes();
  applyGraphViewTransform();
}

function closeGraphEditor() {
  document.getElementById('graph-modal').classList.remove('visible');
  graphEditorState = null;
}

function graphNodePortId(nodeId, port) {
  return `${nodeId}::${port}`;
}

function renderGraphNodeHTML(node) {
  if (node.id === 'start') {
    return `<div class="graph-node graph-node-start" style="left:${node.x}px;top:${node.y}px;width:90px">
      Start
      <div class="graph-port graph-port-next-out" data-port-id="${graphNodePortId('start', 'next-out')}" data-node="start" data-port="next-out"></div>
    </div>`;
  }
  const meta = GRAPH_NODE_TYPES[node.type];
  const fieldsHTML = meta.fields.map((f) => renderActionFieldInput(f, node[f.key])).join('');
  let ports;
  if (meta.kind === 'action') {
    ports = `
      <div class="graph-port graph-port-next-in" data-port-id="${graphNodePortId(node.id, 'next-in')}" data-node="${node.id}" data-port="next-in" title="Sequence in"></div>
      <div class="graph-port graph-port-next-out" data-port-id="${graphNodePortId(node.id, 'next-out')}" data-node="${node.id}" data-port="next-out" title="Sequence out"></div>
      <div class="graph-port graph-port-gate graph-port-gate-in" data-port-id="${graphNodePortId(node.id, 'gate-in')}" data-node="${node.id}" data-port="gate-in" title="Gate: only run when this condition is true"></div>
    `;
  } else if (node.type === 'and' || node.type === 'or' || node.type === 'not') {
    // Combinators: read one (NOT) or more (AND/OR) other condition nodes via
    // 'cond' edges, so they need an operand-in port too, unlike every leaf
    // condition below (which reads external game state directly, not
    // another node).
    ports = `
      <div class="graph-port graph-port-cond graph-port-cond-in" data-port-id="${graphNodePortId(node.id, 'cond-in')}" data-node="${node.id}" data-port="cond-in" title="Operand in"></div>
      <div class="graph-port graph-port-cond graph-port-cond-out" data-port-id="${graphNodePortId(node.id, 'cond-out')}" data-node="${node.id}" data-port="cond-out" title="Condition out"></div>
    `;
  } else {
    ports = `<div class="graph-port graph-port-cond graph-port-cond-out" data-port-id="${graphNodePortId(node.id, 'cond-out')}" data-node="${node.id}" data-port="cond-out" title="Condition out"></div>`;
  }
  return `<div class="graph-node${meta.kind === 'condition' ? ' graph-node-condition' : ''}" data-node-id="${node.id}" style="left:${node.x}px;top:${node.y}px">
    <div class="graph-node-header" data-drag-handle="${node.id}">
      <span class="graph-node-title">${meta.label}</span>
      <button class="graph-node-duplicate" data-duplicate-node="${node.id}" title="Duplicate">⧉</button>
      <button class="graph-node-delete" data-delete-node="${node.id}">✕</button>
    </div>
    ${fieldsHTML}
    ${ports}
  </div>`;
}

// --- Node Graph pan/zoom ---
// Nodes/edges are authored in a fixed, UNSCALED "graph space" (node.x/y, the
// same values saved to disk) -- pan/zoom is purely a CSS transform applied
// to the two rendering layers (#graph-canvas-nodes and #graph-canvas-svg)
// together, never a change to graph-space coordinates themselves. That's
// what keeps node dragging, edge drawing, and the saved graph data all
// working unmodified in graph-space; the only places that need to know
// about the CURRENT view are the few spots converting a raw mouse/screen
// position into graph space (node drag start/move) or vice versa (the grid
// background, which is cosmetic only).
const GRAPH_ZOOM_MIN = 0.35;
const GRAPH_ZOOM_MAX = 2.5;
function applyGraphViewTransform() {
  if (!graphEditorState) return;
  const { x, y, scale } = graphEditorState.view;
  const transform = `translate(${x}px, ${y}px) scale(${scale})`;
  document.getElementById('graph-canvas-nodes').style.transform = transform;
  document.getElementById('graph-canvas-svg').style.transform = transform;
  // The dotted grid is drawn on the WRAP (never transformed itself, so it
  // stays crisp at any zoom instead of blurring as an actual scaled image
  // would) -- moving/resizing its background-position/background-size in
  // lockstep with the same x/y/scale is what makes it read as "the graph
  // canvas has a grid" rather than "there's a grid painted on the window".
  const wrap = document.getElementById('graph-canvas-wrap');
  const baseSize = 22;
  wrap.style.backgroundSize = `${baseSize * scale}px ${baseSize * scale}px`;
  wrap.style.backgroundPosition = `${x}px ${y}px`;
  const zoomLabel = document.getElementById('graph-zoom-label');
  if (zoomLabel) zoomLabel.textContent = `${Math.round(scale * 100)}%`;
  renderGraphEdges();
}
// Screen (clientX/Y) -> graph-space, given the wrap's own rect (unaffected
// by the transform, since the transform lives on its CHILDREN) and the
// current view -- the one conversion node dragging and future
// screen-space-to-graph-space needs all share.
function graphScreenToSpace(clientX, clientY) {
  const wrapRect = document.getElementById('graph-canvas-wrap').getBoundingClientRect();
  const { x, y, scale } = graphEditorState.view;
  return {
    x: (clientX - wrapRect.left - x) / scale,
    y: (clientY - wrapRect.top - y) / scale,
  };
}
function resetGraphView() {
  if (!graphEditorState) return;
  graphEditorState.view = { x: 40, y: 40, scale: 1 };
  applyGraphViewTransform();
}
// Fits every node (plus the fixed Start node) into the visible wrap area,
// with padding -- the common "I've dragged nodes all over and lost track
// of the layout" recovery action.
function fitGraphViewToContent() {
  if (!graphEditorState) return;
  const nodes = [{ x: 40, y: 40 }, ...graphEditorState.graph.nodes];
  if (nodes.length === 0) { resetGraphView(); return; }
  const NODE_W = 148; const NODE_H = 110; // generous estimate -- exact height varies per node's field count, this only needs to be roughly right
  const minX = Math.min(...nodes.map((n) => n.x));
  const minY = Math.min(...nodes.map((n) => n.y));
  const maxX = Math.max(...nodes.map((n) => n.x + NODE_W));
  const maxY = Math.max(...nodes.map((n) => n.y + NODE_H));
  const wrapRect = document.getElementById('graph-canvas-wrap').getBoundingClientRect();
  const PAD = 60;
  const contentW = Math.max(1, maxX - minX);
  const contentH = Math.max(1, maxY - minY);
  const scale = Math.min(GRAPH_ZOOM_MAX, Math.max(GRAPH_ZOOM_MIN, Math.min((wrapRect.width - PAD * 2) / contentW, (wrapRect.height - PAD * 2) / contentH)));
  graphEditorState.view = {
    scale,
    x: (wrapRect.width - contentW * scale) / 2 - minX * scale,
    y: (wrapRect.height - contentH * scale) / 2 - minY * scale,
  };
  applyGraphViewTransform();
}
document.getElementById('graph-canvas-wrap').addEventListener('wheel', (e) => {
  if (!graphEditorState) return;
  e.preventDefault();
  const { view } = graphEditorState;
  const before = graphScreenToSpace(e.clientX, e.clientY);
  const factor = e.deltaY < 0 ? 1.1 : 1 / 1.1;
  view.scale = Math.min(GRAPH_ZOOM_MAX, Math.max(GRAPH_ZOOM_MIN, view.scale * factor));
  // Re-derive x/y so the graph-space point under the cursor BEFORE zooming
  // is still under the cursor after -- a zoom that isn't cursor-anchored
  // feels like the canvas sliding out from under you.
  const wrapRect = document.getElementById('graph-canvas-wrap').getBoundingClientRect();
  view.x = e.clientX - wrapRect.left - before.x * view.scale;
  view.y = e.clientY - wrapRect.top - before.y * view.scale;
  applyGraphViewTransform();
}, { passive: false });
// Panning: pointerdown directly on the wrap/nodes-container background
// (never on a node or port, which have their own pointerdown handlers that
// already run first via event target specificity) starts a view drag.
document.getElementById('graph-canvas-wrap').addEventListener('pointerdown', (e) => {
  if (!graphEditorState) return;
  if (e.target.id !== 'graph-canvas-wrap' && e.target.id !== 'graph-canvas-nodes') return;
  graphEditorState.panning = { startClientX: e.clientX, startClientY: e.clientY, startViewX: graphEditorState.view.x, startViewY: graphEditorState.view.y };
});
document.getElementById('graph-reset-view-btn').addEventListener('click', resetGraphView);
document.getElementById('graph-fit-btn').addEventListener('click', fitGraphViewToContent);

function renderGraphEdges() {
  const svg = document.getElementById('graph-canvas-svg');
  const wrapRect = document.getElementById('graph-canvas-nodes').getBoundingClientRect();
  const scale = graphEditorState.view.scale;
  svg.innerHTML = graphEditorState.graph.edges.map((edge, i) => {
    const fromPort = edge.kind === 'next' ? 'next-out' : 'cond-out';
    const toPort = edge.kind === 'next' ? 'next-in' : edge.kind === 'gate' ? 'gate-in' : 'cond-in';
    const fromEl = document.querySelector(`[data-port-id="${graphNodePortId(edge.from, fromPort)}"]`);
    const toEl = document.querySelector(`[data-port-id="${graphNodePortId(edge.to, toPort)}"]`);
    if (!fromEl || !toEl) return '';
    const fromRect = fromEl.getBoundingClientRect();
    const toRect = toEl.getBoundingClientRect();
    // getBoundingClientRect() reflects the ALREADY-TRANSFORMED (panned/
    // zoomed) rendered position -- but the <svg> itself carries that same
    // CSS transform too (see applyGraphViewTransform), so its internal
    // coordinate system is implicitly re-scaled already. Dividing back by
    // `scale` here converts the screen-space delta into the SVG's own
    // pre-transform coordinate space, which is what x1/y1/x2/y2 need to be
    // in -- without this, lines would drift away from their ports at any
    // zoom level other than 100%.
    const x1 = (fromRect.left + fromRect.width / 2 - wrapRect.left) / scale;
    const y1 = (fromRect.top + fromRect.height / 2 - wrapRect.top) / scale;
    const x2 = (toRect.left + toRect.width / 2 - wrapRect.left) / scale;
    const y2 = (toRect.top + toRect.height / 2 - wrapRect.top) / scale;
    // A wide, invisible line on top of the thin visible one -- a 2px stroke
    // is hard to click precisely, and SVG hit-testing follows the actual
    // stroke geometry, not just "near enough to the visible line".
    return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${edge.kind === 'next' ? '#6fd6bd' : '#e08a63'}" stroke-width="2" />`
      + `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="transparent" stroke-width="12" data-edge-index="${i}" class="graph-edge-hit" style="cursor:pointer"><title>Click to delete this connection</title></line>`;
  }).join('');
}
document.getElementById('graph-canvas-svg').addEventListener('click', (e) => {
  const index = e.target.dataset && e.target.dataset.edgeIndex;
  if (index === undefined || !graphEditorState) return;
  e.stopPropagation();
  graphEditorState.graph.edges.splice(Number(index), 1);
  renderGraphEdges();
});

function highlightGraphPort(nodeId, port, on) {
  const el = document.querySelector(`[data-port-id="${graphNodePortId(nodeId, port)}"]`);
  if (el) el.classList.toggle('graph-port-armed', on);
}

function handleGraphPortClick(nodeId, port) {
  const pending = graphEditorState.pendingConnection;
  if (!pending) {
    graphEditorState.pendingConnection = { node: nodeId, port };
    highlightGraphPort(nodeId, port, true);
    return;
  }
  highlightGraphPort(pending.node, pending.port, false);
  graphEditorState.pendingConnection = null;
  if (pending.node === nodeId && pending.port === port) return; // clicked the same port again: cancel

  const rule = GRAPH_EDGE_RULES.find((r) => r.from === pending.port && r.to === port)
    || GRAPH_EDGE_RULES.find((r) => r.from === port && r.to === pending.port);
  if (!rule) { showStatus("Those ports can't connect"); return; }
  const fromNode = rule.from === pending.port ? pending.node : nodeId;
  const toNode = rule.from === pending.port ? nodeId : pending.node;

  // next-in/next-out/gate-in each accept at most one edge; replace any
  // existing one at either end. cond-in deliberately allows several (AND/OR
  // take 2+ operands).
  if (rule.kind === 'next') {
    graphEditorState.graph.edges = graphEditorState.graph.edges.filter((e) => !(e.kind === 'next' && (e.from === fromNode || e.to === toNode)));
  } else if (rule.kind === 'gate') {
    graphEditorState.graph.edges = graphEditorState.graph.edges.filter((e) => !(e.kind === 'gate' && e.to === toNode));
  } else if (graphEditorState.graph.edges.some((e) => e.kind === 'cond' && e.from === fromNode && e.to === toNode)) {
    return; // duplicate cond edge between the same pair
  }
  graphEditorState.graph.edges.push({ from: fromNode, to: toNode, kind: rule.kind });
  renderGraphNodes();
}

function wireGraphNodeEvents() {
  const container = document.getElementById('graph-canvas-nodes');
  container.querySelectorAll('[data-field]').forEach((input) => {
    const handler = (e) => {
      const nodeEl = e.target.closest('[data-node-id]');
      const node = graphEditorState.graph.nodes.find((n) => n.id === nodeEl.dataset.nodeId);
      const fieldMeta = GRAPH_NODE_TYPES[node.type].fields.find((f) => f.key === e.target.dataset.field);
      if (fieldMeta.type === 'checkbox') node[fieldMeta.key] = e.target.checked;
      else node[fieldMeta.key] = fieldMeta.type === 'number' ? (parseFloat(e.target.value) || 0) : e.target.value;
    };
    input.addEventListener(input.tagName === 'SELECT' || input.type === 'checkbox' ? 'change' : 'input', handler);
  });
  container.querySelectorAll('[data-delete-node]').forEach((btn) => {
    btn.onclick = () => {
      const id = btn.dataset.deleteNode;
      graphEditorState.graph.nodes = graphEditorState.graph.nodes.filter((n) => n.id !== id);
      graphEditorState.graph.edges = graphEditorState.graph.edges.filter((e) => e.from !== id && e.to !== id);
      renderGraphNodes();
    };
  });
  container.querySelectorAll('[data-duplicate-node]').forEach((btn) => {
    btn.onclick = () => {
      const src = graphEditorState.graph.nodes.find((n) => n.id === btn.dataset.duplicateNode);
      if (!src) return;
      // Fields only, not connections -- a duplicated node is a fresh,
      // disconnected copy of the same TYPE with the same field values (the
      // common case: "one more Damage Player at 5 instead of 10"), not a
      // rewiring of the graph, which would be surprising to find already
      // half-connected to the source's own edges.
      const clone = { ...src, id: `n${graphNodeIdCounter++}`, x: src.x + 24, y: src.y + 24 };
      graphEditorState.graph.nodes.push(clone);
      renderGraphNodes();
    };
  });
  container.querySelectorAll('[data-drag-handle]').forEach((handle) => {
    handle.addEventListener('pointerdown', (e) => {
      const id = handle.dataset.dragHandle;
      const node = graphEditorState.graph.nodes.find((n) => n.id === id);
      if (!node) return; // the fixed Start node has no backing node object
      const grabPoint = graphScreenToSpace(e.clientX, e.clientY);
      graphEditorState.dragNode = { id, offsetX: grabPoint.x - node.x, offsetY: grabPoint.y - node.y };
      e.preventDefault();
    });
  });
  container.querySelectorAll('[data-port]').forEach((portEl) => {
    portEl.addEventListener('click', (e) => {
      e.stopPropagation();
      handleGraphPortClick(portEl.dataset.node, portEl.dataset.port);
    });
  });
}

function renderGraphNodes() {
  const container = document.getElementById('graph-canvas-nodes');
  container.innerHTML = renderGraphNodeHTML({ id: 'start', x: 40, y: 40 }) + graphEditorState.graph.nodes.map(renderGraphNodeHTML).join('');
  wireGraphNodeEvents();
  renderGraphEdges();
}

document.getElementById('graph-canvas-wrap').addEventListener('pointermove', (e) => {
  if (!graphEditorState) return;
  if (graphEditorState.panning) {
    const { startClientX, startClientY, startViewX, startViewY } = graphEditorState.panning;
    // Pan is a raw screen-pixel delta added to the view offset (NOT divided
    // by scale) -- view.x/y ARE screen-space translate offsets, unlike
    // node.x/y which live in graph space. Confusing the two here would make
    // panning drift faster/slower than the cursor at any zoom other than 100%.
    graphEditorState.view.x = startViewX + (e.clientX - startClientX);
    graphEditorState.view.y = startViewY + (e.clientY - startClientY);
    applyGraphViewTransform();
    return;
  }
  if (!graphEditorState.dragNode) return;
  const container = document.getElementById('graph-canvas-nodes');
  const { id, offsetX, offsetY } = graphEditorState.dragNode;
  const node = graphEditorState.graph.nodes.find((n) => n.id === id);
  if (!node) return;
  const point = graphScreenToSpace(e.clientX, e.clientY);
  node.x = Math.max(0, point.x - offsetX);
  node.y = Math.max(0, point.y - offsetY);
  const nodeEl = container.querySelector(`[data-node-id="${id}"]`);
  nodeEl.style.left = `${node.x}px`;
  nodeEl.style.top = `${node.y}px`;
  renderGraphEdges();
});
window.addEventListener('pointerup', () => {
  if (graphEditorState) { graphEditorState.dragNode = null; graphEditorState.panning = null; }
});
document.getElementById('graph-canvas-wrap').addEventListener('click', (e) => {
  if (graphEditorState && graphEditorState.pendingConnection && (e.target.id === 'graph-canvas-wrap' || e.target.id === 'graph-canvas-nodes')) {
    highlightGraphPort(graphEditorState.pendingConnection.node, graphEditorState.pendingConnection.port, false);
    graphEditorState.pendingConnection = null;
  }
});

// Toolbar buttons are generated from GRAPH_NODE_TYPES rather than
// hand-listed in index.html, so a new action type in ACTION_TYPES gets a
// graph button automatically instead of needing a second place to update.
document.getElementById('graph-toolbar-buttons').innerHTML = Object.entries(GRAPH_NODE_TYPES)
  .map(([type, meta]) => `<button data-node-type="${type}"${meta.kind === 'condition' ? ' class="graph-cond-btn"' : ''}>${escapeHtml(meta.label)}</button>`)
  .join('');
document.getElementById('graph-node-search').addEventListener('input', (e) => {
  const q = e.target.value.trim().toLowerCase();
  document.querySelectorAll('#graph-toolbar-buttons [data-node-type]').forEach((btn) => {
    btn.classList.toggle('graph-node-hidden', q.length > 0 && !btn.textContent.toLowerCase().includes(q));
  });
});
document.querySelectorAll('#graph-toolbar [data-node-type]').forEach((btn) => {
  btn.addEventListener('click', () => {
    if (!graphEditorState) return;
    const type = btn.dataset.nodeType;
    const id = `n${graphNodeIdCounter++}`;
    const count = graphEditorState.graph.nodes.length;
    graphEditorState.graph.nodes.push({ id, type, x: 60 + (count % 5) * 170, y: 140 + Math.floor(count / 5) * 120 });
    renderGraphNodes();
  });
});
document.getElementById('graph-cancel-btn').addEventListener('click', closeGraphEditor);
document.getElementById('graph-save-btn').addEventListener('click', () => {
  const { item, existingBehavior, trigger, graph } = graphEditorState;
  pushUndo();
  if (existingBehavior) existingBehavior.graph = graph;
  else item.behaviors.push({ trigger, action: 'graph', graph });
  closeGraphEditor();
  renderBehaviorList(item);
});

let playMode = false;
let playTriggers = []; // { item, volume } for active 'enter' behaviors while playing

// A fresh session (enterPlayMode) OR a mid-session level switch
// (switchToLevelDuringPlay) must both undo any "disappears when collected"
// state a previous playthrough left behind (see COLLECT_SCRIPT below) --
// otherwise replaying would start with already-collected crates missing --
// and must both give every Spawner a fresh, real `spawnerState` before
// `tickSpawners` ever runs, since `tickSpawners` silently skips any spawner
// item with none. Trigger Volume/Camera/Spawner/Light markers are
// editor-only furniture -- always hidden once Play is active, regardless of
// how Play got to this exact state (a fresh start or a level transition).
// Factored out because `switchToLevelDuringPlay` used to skip this entirely
// -- a level 2 loaded via Next Level/Switch Level had every Spawner
// permanently inert (no `spawnerState` ever set) and every marker left
// visible, found live dogfooding the Blacksite stress game's own
// Entry -> Core transition.
function preparePlacedForPlay() {
  for (const item of placed) {
    if (item.kind === 'cube') item.entity.visible = !item.isTrigger && !item.isWaypoint && !item.isSpawnPoint;
    else if (item.kind === 'camera') item.entity.visible = false;
    else if (item.kind === 'spawner') { item.entity.visible = false; item.spawnerState = { enabled: item.options.startEnabled !== false, timer: 0, spawnedTotal: 0, activeIds: [], firstSpawnDone: false }; }
    else if (item.kind === 'light') item.entity.visible = false;
  }
}
function enterPlayMode() {
  // A fresh session always boots from the designated Start Level, not
  // necessarily whichever level happens to be open for editing.
  if (startLevelIndex !== currentLevelIndex && levels[startLevelIndex]) switchToLevel(startLevelIndex);
  playMode = true;
  gameEnded = false;
  loadPlayerInputOverrides(); // Wave 6 (Priority D): reload the player's own rebinds fresh each session
  playerFrozen = false; // Wave 6 (Priority L): a fresh session must never start already frozen mid-cutscene
  if (app.paused) app.resume(); // defensive: a fresh session must never start already paused
  endOverlayEl.classList.remove('visible');
  pauseOverlayEl.classList.remove('visible');
  setObjective('');
  deselectAll();
  canvas.style.cursor = '';
  document.getElementById('play-btn').textContent = '■ Stop';
  document.getElementById('play-btn').classList.add('playing');
  document.getElementById('pause-btn').disabled = false;
  preparePlacedForPlay();
  // Named counters (health/lives/score/...) must start each play session
  // fresh too -- previously __gameState only ever got created lazily on
  // first write and otherwise persisted silently across Stop/Play cycles,
  // so a health counter depleted in a previous attempt would carry into the
  // next one instead of resetting.
  window.__gameState = {};
  window.__checkpoint = null;
  window.__damageCooldowns = {};
  window.__gameTimers = {};
  window.__gameFlags = {};
  window.__gameInventory = {};
  window.__gameObjectives = {};
  window.__worldState = {};
  window.__destroyedPersistentIds = {};
  window.__gamePlaytimeSeconds = 0; // Wave 8 (Priority H): reset on every fresh Play; Load Game restores it from the save's own metadata instead (see loadGame's exec)
  teardownPlayerEquipment(); // Wave 7 (Priority C): fresh Play must not carry a previous attempt's equipped visuals/state
  heldObjectItem = null; // Wave 7 (Priority J): fresh Play must not start with a stale held-object reference from a previous attempt
  pendingDelays = [];
  deferredCalls = [];
  runningSequenceIds = [];
  activeCameraBlend = null;
  activeCameraPath = null; // Wave 9C (Section 27): same cleanup requirement as Camera Blend just above
  lastAppliedCameraItemId = null;
  activeTweens = [];
  activeProjectiles = [];
  lastAttackTime = -Infinity;
  simElapsed = 0;
  for (const item of placed) {
    if (item._anim) item._anim.playing = false;
    if (item._carryPrevPos) item._carryPrevPos = undefined;
    // Dogfood (Signal Relay) fix: restore each object's variables to their
    // AUTHORED baseline on every fresh Play, not whatever the previous Stop
    // left mutated in place -- see the `_authoredVariables` comment in
    // instantiateCubeRecord/instantiateItemFromRecord for why a separate
    // snapshot exists at all. An item placed live during Play itself (never
    // went through either instantiate function with a record) has no
    // `_authoredVariables`, so it's simply left alone here.
    if (item._authoredVariables) item.variables = { ...item._authoredVariables };
  }
  for (const item of placed) wireItemTrigger(item);
  // Wave 9B -- REAL BUG found live dogfooding Arsenal Run's own "grant +
  // equip weapons on Start" pattern: `spawnPlayer` used to run AFTER
  // `runStartBehaviors()`, so `player` was still `null` (a genuine fresh
  // Stop->Play cycle always despawns it first) for the ENTIRE duration of
  // every On Start behavior -- `equipItemToSlot`'s own `if (!player) return`
  // silently no-oped every single time. This had never been caught before
  // because nothing prior to Weapons 2.0 called Equip Item from an On Start
  // behavior (Wave 7's own Equipment dogfood only ever equipped via a
  // runtime Interact/pickup, always well after spawn). Fixed by spawning
  // the Player BEFORE Start behaviors run, so any Start behavior that
  // reads/touches the Player (Equip Item included) sees a real, live one.
  spawnPlayer(computeSpawnPoint());
  runStartBehaviors();
  startAmbientAudioForCurrentLevel();
  initFogZonesForCurrentLevel();
  showStartScreenIfConfigured();
}

// Reuses the existing, already-proven Pause plumbing (App.pause/resume)
// rather than inventing a second "is input blocked" concept -- the Start
// Screen visually covers the viewport AND the game is genuinely paused
// underneath it, so there's no window where a keyboard key could move the
// player before the screen is dismissed.
function showStartScreenIfConfigured() {
  const cfg = currentUiConfig.startScreen;
  if (!cfg.enabled) return;
  document.getElementById('start-overlay-title').textContent = cfg.title || '';
  document.getElementById('start-overlay-subtitle').textContent = cfg.subtitle || '';
  document.getElementById('start-overlay-btn').textContent = cfg.buttonText || 'Start';
  updateMainMenuExtras(); // Wave 6 (Priority E): How To Play/Credits buttons reflect THIS level's config
  document.getElementById('start-overlay').classList.add('visible');
  app.pause();
}
document.getElementById('start-overlay-btn').addEventListener('click', () => {
  document.getElementById('start-overlay').classList.remove('visible');
  if (app.paused) app.resume();
});

// On Start fires once for every item that has one, giving a scene a place
// to initialize counters (starting health/lives) or show an opening
// objective -- the fixed Click/Enter/Exit triggers all need something to
// happen to the player first, which nothing does before this point.
// Called both at the start of a fresh Play session (enterPlayMode) and
// after a mid-session Switch Level (switchToLevelDuringPlay) -- a newly
// entered level deserves its own opening beat too, just without the
// session-wide state resets (__gameState, checkpoint) a FRESH session gets.
function runStartBehaviors() {
  // Wave 8 (Priority A dogfood, a real bug found via the dependency
  // collector's own cycle-protection test): iterates a SNAPSHOT
  // (`.slice()`), not the live `placed` array. `for...of` over the live
  // array is not a fixed-length pass -- if one object's own "On Start"
  // behavior spawns a NEW object (Spawn Prefab) that ALSO has an "On
  // Start" behavior, that new object gets appended to the SAME array this
  // loop is still iterating, and `for...of` keeps walking into it,
  // firing ITS "On Start" too. A genuine cycle (A's own On Start spawns B,
  // B's own On Start spawns A) turned this into an unbounded runaway --
  // reproduced live: `placed.length` reached 60,000+ objects and the tab
  // had to be recovered. A freshly Spawn-Prefab'd object's own "On Start"
  // behavior was never documented or intended to auto-fire (spawnPrefab's
  // own exec only ever wires enter/exit/stay via `wireItemTrigger`, not
  // 'start') -- this was purely an iteration-safety bug in THIS loop, not
  // a feature anything actually relied on.
  for (const item of placed.slice()) {
    if (item.kind === 'cube' && item.behaviors && item.behaviors.some((b) => b.trigger === 'start')) {
      runBehaviors(item, 'start');
    }
  }
}

// Creates and registers the live TriggerVolume for one item, if its
// behaviors call for one. Factored out of enterPlayMode's bulk setup loop
// so a runtime-spawned item (Spawn Prefab action, below) gets the exact
// same live wiring a design-time item gets at Play start, instead of only
// working starting the NEXT play session.
function wireItemTrigger(item) {
  if (item.kind !== 'cube' || !item.behaviors) return;
  const hasEnter = item.behaviors.some((b) => b.trigger === 'enter');
  const hasExit = item.behaviors.some((b) => b.trigger === 'exit');
  // On Stay -- fires every frame the player is inside (Damage Zones: a
  // Trigger Volume with a Damage Player behavior whose OWN Cooldown field
  // throttles actual damage, not the one-shot flag below, since a Damage
  // Zone must keep re-firing on every visit, not just the first).
  const hasStay = item.behaviors.some((b) => b.trigger === 'stay');
  if (!hasEnter && !hasExit && !hasStay) return;
  item.triggerFired = false; // reset one-shot state for this play session
  // One-shot only applies to Trigger Volumes (triggerRepeat === false) --
  // an ordinary crate/hazard keeps its existing "fires every time you
  // cross it" behavior, since that's what the shipped starter game relies on.
  const oneShot = item.isTrigger && item.triggerRepeat === false;
  // Wave 6 (Priority A/Section 8): a real Trigger Volume marker (isTrigger)
  // defaults to its ACTUAL rendered box shape now, fixing the long-standing
  // "looks like a box, behaves like a giant sphere" mismatch -- an author
  // can still explicitly opt back into Sphere via `triggerShape:'sphere'`.
  // Deliberately scoped to isTrigger markers only: an ordinary enter/exit/
  // stay cube that ISN'T an authored Trigger Volume (a crate, a hazard, a
  // Priority K pickup preset) keeps its existing sphere-1.5x-scale
  // "generous touch radius" behavior completely unchanged -- that's the
  // CORRECT feel for "walk near this and pick it up," not a bug to fix.
  const useBoxShape = item.isTrigger && item.triggerShape !== 'sphere';
  const shapeOptions = useBoxShape
    ? { shape: 'box', half: item.entity.scale.scale(0.5), quat: item.entity.quaternion }
    : { shape: 'sphere', radius: 1.5 * Math.max(item.entity.scale.x, item.entity.scale.z) };
  const volume = new Opus.Physics.TriggerVolume({
    center: item.entity.position,
    ...shapeOptions,
    onEnter: hasEnter ? () => {
      if (oneShot && item.triggerFired) return;
      item.triggerFired = true;
      runBehaviors(item, 'enter');
    } : undefined,
    onExit: hasExit ? () => {
      if (oneShot && item.triggerFired) return;
      if (oneShot) item.triggerFired = true;
      runBehaviors(item, 'exit');
    } : undefined,
    onStay: hasStay ? () => runBehaviors(item, 'stay') : undefined,
  });
  playTriggers.push({ item, volume });
}

function exitPlayMode() {
  playMode = false;
  playTriggers = [];
  pendingDelays = []; // a Delay from this session must never fire into the next one
  deferredCalls = [];
  runningSequenceIds = []; // a Sequence's own Delay must never fire into a dead/next session either
  activeCameraBlend = null; // an in-flight camera blend must never keep animating into a dead session
  activeCameraPath = null; // Wave 9C (Section 27): same reasoning for an in-flight Camera Path
  activeTweens = [];
  activeProjectiles = []; // the underlying items are cleaned up below via the existing runtimeSpawned sweep
  for (const code of gamepadHeldKeys) app.input.simulateKeyUp(code);
  gamepadHeldKeys.clear();
  gamepadStartWasHeld = false;
  // Runtime-spawned items (Spawn Prefab) are session furniture, not scene
  // content -- without this, repeated Play/Stop cycles would silently pile
  // up an ever-growing number of leftover enemies each time.
  for (const item of placed.slice()) {
    if (item.runtimeSpawned) removeItemFromScene(item);
  }
  despawnPlayer();
  stopAmbientAudio();
  if (app.paused) app.resume(); // Stop always leaves things in a resumed state, not paused-and-stuck
  document.getElementById('play-btn').textContent = '▶ Play';
  document.getElementById('play-btn').classList.remove('playing');
  document.getElementById('pause-btn').disabled = true;
  toastEl.classList.remove('visible');
  endOverlayEl.classList.remove('visible');
  pauseOverlayEl.classList.remove('visible');
  document.getElementById('start-overlay').classList.remove('visible');
  document.getElementById('dialogue-overlay').classList.remove('visible');
  document.getElementById('hud-elements-layer').innerHTML = '';
  setObjective('');
  // Wave 9 (Priority A/Section 26) -- crosshair/recoil/shake are all
  // session-scoped transient state; a Stop must not leave any of them
  // bleeding into the editor view or the next Play session.
  document.getElementById('crosshair').classList.remove('visible');
  recoilPitchOffset = 0; recoilYawOffset = 0;
  cameraShakeElapsed = cameraShakeDuration = 0;
  if (app.camera.shakeOffset) app.camera.shakeOffset = null;
  weaponRuntimeState = {};
  activeWeaponSlot = 'primaryHand';
}

document.getElementById('play-btn').addEventListener('click', () => {
  if (playMode) exitPlayMode();
  else enterPlayMode();
});

// Pause freezes simulation at the engine level (App.pause/resume, already
// built -- camera, physics/AI update callbacks, and audio's engine hum all
// stop; rendering and input keep running) but had no editor-facing way to
// reach it: no button, and no visible feedback for the Escape-key toggle
// the engine already wires up internally (App's own keydown listener,
// engine/src/22-api.js) -- a player pressing Escape had no way to tell
// whether anything had actually happened.
document.getElementById('pause-btn').addEventListener('click', () => {
  if (!playMode) return;
  if (app.paused) app.resume(); else app.pause();
});
// App.onPauseChange (already public, engine/src/22-api.js) fires
// regardless of WHICH path triggered the change -- this button or the
// engine's own internal Escape binding, which the editor has no other hook
// into at all -- so the overlay/label stay correct either way with no
// polling needed.
app.onPauseChange((paused) => {
  // Wave 4 fix, found dogfooding the new Pause Menu buttons: App.pause() is
  // also how the Start Screen and Dialogue already implement themselves
  // (see the comments on each -- reusing the same proven pause plumbing was
  // deliberate, not a bug). Before the pause overlay had real buttons, that
  // meant it was ALSO "visible" (by class) underneath the Start Screen the
  // whole time a fresh session's Start Screen was up -- invisible in
  // practice only because it had no interactive content and a lower
  // z-index. Now that it has real Resume/Restart/Main Menu buttons, showing
  // it stacked behind the Start Screen or a Dialogue box is a real bug, not
  // a cosmetic one -- gate it to the actual "player paused" case only.
  const startScreenShowing = document.getElementById('start-overlay').classList.contains('visible');
  const dialogueShowing = document.getElementById('dialogue-overlay').classList.contains('visible');
  // Wave 8 (Priority E): Inventory also pauses via this SAME app.pause()
  // plumbing (Section 31's chosen default) -- excluded here for the exact
  // same reason Dialogue/Start Screen already are, so opening Inventory
  // doesn't ALSO pop the plain Pause overlay stacked behind it.
  const inventoryShowing = document.getElementById('inventory-overlay').classList.contains('visible');
  pauseOverlayEl.classList.toggle('visible', playMode && paused && !startScreenShowing && !dialogueShowing && !inventoryShowing);
  document.getElementById('pause-btn').textContent = paused ? '▶ Resume' : '⏸ Pause';
  // Pointer Lock (Wave 5): released the instant ANYTHING pauses (the Pause
  // button, Start Screen, or Dialogue -- this callback fires for all three,
  // the exact reasoning the comment above already established) so the
  // mouse is free to click pause/dialogue/start UI, and never left locked
  // behind an overlay the player can't otherwise reach with the cursor --
  // "do not trap users in Pointer Lock." Re-acquired automatically once
  // resumed while still in a First-Person Play session (the canvas click
  // handler covers the case where the browser's own Escape key already
  // dropped it and a fresh click is what re-triggers this).
  if (playMode && player && player.controllerType === 'firstperson' && !isTouchDevice) {
    if (paused) releaseFirstPersonPointerLock();
    else requestFirstPersonPointerLock();
  }
});

// Wave 8 (Priority E, Sections 29-32): Inventory UI -- a bounded player-
// facing panel over the EXISTING runtime state (`window.__gameInventory`,
// `playerEquipment` from Wave 7 Priority C), not a new inventory model.
// Toggled via a RAW `keydown` listener (not the per-frame `wasPressed`
// polling loop every other gameplay input uses) -- deliberately, because
// that loop lives inside `app.onUpdate`'s own registered callbacks, which
// the engine's OWN `App.pause()` stops calling entirely while paused (see
// its own GameLoop implementation) -- a polled check could open Inventory
// but could never see the SECOND press that should close it again once
// paused. A raw listener keeps working in both states, the same reason
// the engine's own internal Escape-pause toggle already has to be wired
// this way. Reading `effectiveInputMap.inventory` at call time (not a
// captured key code) also means this transparently honors an author's
// custom rebinding, and (since Touch/Gamepad both dispatch through the
// SAME `simulateKeyDown`-driven synthetic keydown events every other
// logical action already uses) needs no separate device-specific code.
function toggleInventory() {
  if (!playMode) return;
  const willOpen = !document.getElementById('inventory-overlay').classList.contains('visible');
  document.getElementById('inventory-overlay').classList.toggle('visible', willOpen);
  if (willOpen) { renderInventoryOverlay(); if (!app.paused) app.pause(); } else if (app.paused) { app.resume(); }
}
window.addEventListener('keydown', (e) => {
  if (playMode && effectiveInputMap.inventory && e.code === effectiveInputMap.inventory) toggleInventory();
});
document.getElementById('inventory-close-btn').addEventListener('click', () => {
  if (document.getElementById('inventory-overlay').classList.contains('visible')) toggleInventory();
});
// Reused by both the button row (Equip/Unequip/Use) and re-render after
// any of those mutate state -- one function, always reflecting the real
// live `window.__gameInventory`/`playerEquipment`, never a stale snapshot.
// Wave 8 (Priority G, Sections 44-47): the player-facing Objective Log
// half of the shared Journal screen -- Active/Completed (Failed shown too
// if any exist, Section 44's own "optional"). Progress (Section 47)
// reuses EXISTING state (a named Counter in `window.__gameState`, or an
// Inventory item's own quantity) -- no second progress-storage system.
function objectiveProgressText(def) {
  if (!def.progress || !def.progress.key) return '';
  const current = def.progress.type === 'inventory'
    ? ((window.__gameInventory && window.__gameInventory[def.progress.key]) || 0)
    : ((window.__gameState && window.__gameState[def.progress.key]) || 0);
  return def.progress.target ? ` (${current}/${def.progress.target})` : ` (${current})`;
}
function renderObjectiveLog() {
  const listEl = document.getElementById('objective-log-list');
  if (!listEl) return;
  const state = window.__gameObjectives || {};
  const active = currentObjectiveDefs.filter((d) => state[d.id] === 'active');
  const complete = currentObjectiveDefs.filter((d) => state[d.id] === 'complete');
  const failed = currentObjectiveDefs.filter((d) => state[d.id] === 'failed');
  const section = (label, defs, style) => defs.length === 0 ? '' : `<div style="margin-top:6px"><div style="font-size:10.5px;color:#66759a;text-align:left">${label}</div>${defs.map((d) => `<div class="inventory-row" style="${style}"><span class="inv-name">${escapeHtml(d.title)}${objectiveProgressText(d)}</span></div>`).join('')}</div>`;
  listEl.innerHTML = section('Active', active, '') + section('Completed', complete, 'opacity:0.6;text-decoration:line-through') + section('Failed', failed, 'opacity:0.6;color:#e07a7a')
    || '<p style="color:#8592a8;font-size:12px">No objectives yet.</p>';
}
function renderInventoryOverlay() {
  renderObjectiveLog();
  const listEl = document.getElementById('inventory-list');
  const inv = window.__gameInventory || {};
  const entries = Object.entries(inv).filter(([, count]) => count > 0);
  if (entries.length === 0) {
    listEl.innerHTML = '<p style="color:#8592a8;font-size:12px">Nothing carried yet.</p>';
    return;
  }
  const equippedItemNames = new Set(Object.values(playerEquipment).map((eq) => eq.itemName));
  listEl.innerHTML = entries.map(([name, count]) => {
    const def = findItemDefById(name); // an Item Definition's own `id` is a valid, richer inventory key (Section 27); a free-typed legacy name just has no def
    const displayName = def ? def.name : name;
    const icon = def && def.iconTextureAssetId ? findTextureAssetById(def.iconTextureAssetId) : null;
    const isEquipped = equippedItemNames.has(name);
    const equipDef = (currentPlayerSettings.equipmentDefs || []).find((e) => e.itemName === name);
    return `
      <div class="inventory-row" data-inv-name="${escapeHtml(name)}">
        ${icon && icon.dataURL ? `<img src="${icon.dataURL}" alt="">` : '<div style="width:28px;height:28px;background:#182338;border-radius:3px"></div>'}
        <span class="inv-name">${escapeHtml(displayName)} x${count}${isEquipped ? ' <span class="inv-equipped">(equipped)</span>' : ''}</span>
        ${equipDef ? (isEquipped ? `<button data-inv-unequip="${escapeHtml(name)}">Unequip</button>` : `<button data-inv-equip="${escapeHtml(name)}">Equip</button>`) : ''}
        ${def && def.useAction ? `<button data-inv-use="${escapeHtml(name)}">Use</button>` : ''}
      </div>`;
  }).join('');
  listEl.querySelectorAll('[data-inv-equip]').forEach((btn) => {
    btn.onclick = () => { const name = btn.dataset.invEquip; const eqDef = (currentPlayerSettings.equipmentDefs || []).find((e) => e.itemName === name); if (eqDef) equipItemToSlot(name, eqDef.slot); renderInventoryOverlay(); };
  });
  listEl.querySelectorAll('[data-inv-unequip]').forEach((btn) => {
    btn.onclick = () => { const name = btn.dataset.invUnequip; const slot = Object.keys(playerEquipment).find((s) => playerEquipment[s].itemName === name); if (slot) unequipSlot(slot); renderInventoryOverlay(); };
  });
  listEl.querySelectorAll('[data-inv-use]').forEach((btn) => {
    btn.onclick = () => { const def = findItemDefById(btn.dataset.invUse); if (def) executeAction('useItem', { itemId: def.id }, null); renderInventoryOverlay(); };
  });
}

app.onUpdate((dt, elapsed) => {
  if (!playMode) return;
  simElapsed = elapsed; // read by damagePlayer's cooldown gate and pendingDelays
  // Wave 8 (Priority H): real accumulated playtime, for Save Slot metadata
  // (Section 51) -- only while actually unpaused (this whole callback
  // already doesn't run at all while app.paused, so no separate pause
  // check is needed here beyond that).
  window.__gamePlaytimeSeconds = (window.__gamePlaytimeSeconds || 0) + dt;
  pollGamepad(dt);
  tickSpawners(dt);
  tickTimers(dt);
  tickTweens(dt);
  tickProjectiles(dt);
  processPendingDelays();
  processDeferredCalls();
  renderHudLayer();
  // Patrol hazards: mutate position in place (.set, not reassignment) so the
  // TriggerVolume's stored `center` reference (a live pointer to this same
  // Vec3, not a snapshot) tracks the movement automatically.
  for (const item of placed) {
    if (item.kind === 'cube' && item.entity.patrol) {
      const p = item.entity.patrol;
      const offset = Math.sin(elapsed * p.speed + p.phase) * p.range;
      if (p.axis === 'x') item.entity.position.set(p.base.x + offset, item.entity.position.y, p.base.z);
      else item.entity.position.set(p.base.x, item.entity.position.y, p.base.z + offset);
    }
  }
  // Simple enemy/movement AI -- deliberately not pathfinding (no navmesh):
  // each type is a few lines of direct steering, same spirit as Patrol
  // above. 'Chase' isn't a separate type -- it's Follow at a higher
  // user-set Speed, so it doesn't need its own code path.
  for (const item of placed) {
    if (item.kind !== 'cube' || !item.entity.ai) continue;
    const ai = item.entity.ai;
    const pos = item.entity.position;
    let followTargetEntity;
    // Wave 7 (Priority D): a State Machine character's movement/attack for
    // THIS tick come from its CURRENT STATE's own `movement`/`attack`
    // sub-configs (see tickAiStateMachine below) instead of `ai` itself --
    // everything else (animation-locomotion sync excluded, handled
    // separately below) still funnels through the exact same
    // applyAiMovementStep/applyAiAttackStep every pre-Wave-7 AI type uses,
    // so a state's `movement` object is literally shaped like `ai` itself
    // (same `type`/`speed`/`radius`/`targetId`/... fields), not a second
    // movement language.
    if (ai.mode === 'stateMachine') {
      followTargetEntity = tickAiStateMachine(item, ai, pos, dt, elapsed);
    } else {
      followTargetEntity = applyAiMovementStep(item, ai, pos, dt, elapsed);
      applyAiAttackStep(item, ai, pos, followTargetEntity, elapsed);
    }
    // Wave 6 (Priority M): animated locomotion -- Idle/Walk/Run picked by
    // how far this AI-driven character actually moved THIS frame, not by
    // which AI type it's running (Follow/Patrol/Wander/Waypoint all already
    // converge on mutating `pos` in place above, so comparing `pos` against
    // its own value from the START of this frame covers every movement type
    // uniformly, with no per-AI-type animation code needed). Skipped
    // entirely while an Attack/Death override is active (`_animOverrideUntil`),
    // and skipped entirely for a State Machine character -- that character's
    // animation is explicitly authored per-state (`enterAiState`'s own
    // `animRole`), not inferred from movement delta.
    if (ai.mode !== 'stateMachine' && item.characterAnimSync && item.entity.skin && !(item._animOverrideUntil > elapsed)) {
      const lastPos = item._animLastPos;
      const movedDist = lastPos ? pos.sub(lastPos).length() : 0;
      const speedPerSec = movedDist / Math.max(dt, 1e-6);
      setCharacterLocomotionState(item, speedPerSec < 0.05 ? 'idle' : speedPerSec > (ai.speed || 3) * 0.7 ? 'run' : 'walk');
    }
    item._animLastPos = pos.clone();
  }
  // Wave 7 (Priority B): Animation Events for every skinned placed item, not
  // just AI-driven ones -- a genuinely separate, unconditional loop (any
  // object carrying an `entity.skin`, whether or not it also has `entity.ai`)
  // since event authoring is a property of the CLIP/asset, not of whichever
  // movement system happens to be driving the character.
  for (const item of placed) {
    if (item.kind === 'cube' && item.entity.skin) tickAnimationEvents(item.entity, item.assetId, item);
  }
  const previousPlayerPos = updatePlayerController(dt, elapsed);
  // Resolved AFTER every movement system above (patrol/AI/tweens) and BEFORE
  // trigger volumes read positions below -- a parented trigger/hazard riding
  // a moving parent must be checked against ITS current frame's world
  // position, not last frame's, or collision/trigger logic would read stale
  // coordinates one tick behind what just got rendered.
  updateHierarchyTransforms();
  const trackPoint = player ? player.entity.position : app.camera.eye;
  for (const { volume } of playTriggers) volume.update(trackPoint, player ? previousPlayerPos : undefined);
  updateInteract();
  if (app.input.wasPressed(effectiveInputMap.interact)) fireInteract();
  // Wave 9 (Priority A, Sections 14-17): Fire Mode dispatch -- Semi (the
  // unconditional pre-Wave-9 default, and every weapon with no `fireMode`
  // authored) stays exactly `wasPressed` (one press = one shot, holding
  // does not repeat). Automatic reads `isDown` every frame instead, and
  // fireAttack's own cooldown gate is what actually paces the real shots
  // fired -- simulation-time-driven (`simElapsed`), never frame-rate
  // dependent.
  const attackWeapon = resolveActivePlayerWeapon();
  const isAutoFire = attackWeapon && attackWeapon.fireMode === 'auto';
  if (isAutoFire ? app.input.isDown(effectiveInputMap.attack) : app.input.wasPressed(effectiveInputMap.attack)) fireAttack();
  if (app.input.wasPressed(effectiveInputMap.reload)) { const w = resolveActivePlayerWeapon(); if (w) startWeaponReload(w); }
  if (app.input.wasPressed(effectiveInputMap.switchWeapon)) switchActiveWeaponSlot();
  tickWeaponReload();
  tickRecoilRecovery(dt);
  tickCameraShake(dt);
  syncCrosshair(attackWeapon);
});
// Wave 9 (Priority A/Section 26): a bounded CSS-only crosshair -- visible
// only for a First-Person controller with an enabled, resolvable weapon
// (author opt-out via `weapon.crosshair === false`); its optional
// spread-reactive gap width scales with the weapon's own Spread Degrees.
function syncCrosshair(weapon) {
  const el = document.getElementById('crosshair');
  if (!el) return;
  const show = !!(player && player.controllerType === 'firstperson' && weapon && weapon.enabled !== false && weapon.crosshair !== false);
  el.classList.toggle('visible', show);
  if (show) el.style.setProperty('--crosshair-spread', `${Math.min(20, (weapon.spreadDegrees || 0) * 1.5)}px`);
}

// Player Attack Input (Wave 4) -- generalized enough for every controller
// via the same generic `player` accessor Camera/AI/checkpoints/Boost
// already use, not hard-coded into one specific controller. Keyboard
// default is KeyQ (Space is Boost/Jump, F is Interact already); touch gets
// its own on-screen button; gamepad reaches it through the SAME
// simulateKeyDown/Up remapping layer every other gamepad action already
// uses (pollGamepad), so this needed zero gamepad-specific code, the exact
// reasoning the Wave 3 Gamepad Utility Gate re-confirmation already
// established for Jump.
let lastAttackTime = -Infinity;
// Wave 7 (Priority B): the actual hit-dispatch half of fireAttack, pulled
// out into its own function so it can be called from TWO places -- normal
// immediate fire (the unconditional default, byte-identical to every
// project before this priority existed) and a queued Animation Event fire
// (`weapon.fireOnAnimationEvent`, opt-in only). Neither caller re-checks
// cooldown/cost here -- that gate already ran once in fireAttack() itself;
// this function's only job is "actually deal the hit right now."
// Wave 7 (Priority C/Section 20): resolves the ACTUAL weapon stats to fire
// with -- either `currentPlayerSettings.weapon` itself (the pre-existing
// "Fixed Weapon" mode, still the unconditional default) or, when
// `weapon.source === 'equipment'`, whatever the item currently equipped in
// the Primary Hand slot defines as ITS OWN weapon config. Returns null (a
// silent no-op for the caller) when Equipment Weapon mode is selected but
// nothing with a weapon config is actually equipped -- "Attack does
// nothing until you pick something up" is the correct, expected behavior,
// not an error.
// Wave 9 (Priority A/Section 22): `activeWeaponSlot` is which Equipment
// slot ('primaryHand'/'secondaryHand') is currently the ACTIVE weapon when
// `weapon.source === 'equipment'` -- switching is just changing which
// already-equipped slot resolveActivePlayerWeapon reads, not a re-equip.
// Both slots' visual entities stay attached at all times (no orphaned
// attachments, Section 23); only the active one is shown (Section 23's
// "detach old visual, attach new" in spirit -- toggling `.visible` reuses
// the already-created entity instead of destroying/recreating GPU
// resources on every switch).
let activeWeaponSlot = 'primaryHand';
function resolveActivePlayerWeapon() {
  const weapon = currentPlayerSettings.weapon;
  if (!weapon) return null;
  if (weapon.source !== 'equipment') return weapon;
  const eq = playerEquipment[activeWeaponSlot];
  if (!eq || !eq.def || !eq.def.weapon) return null;
  // cooldown/enabled/fireOnAnimationEvent stay author-level Player Settings
  // (not re-authored per equipment item, keeping this bounded); mode/damage/
  // range/speed/prefabName/ammo/reload/fireMode/spread come from the
  // equipped item's own weapon config.
  return Object.assign({}, weapon, eq.def.weapon);
}
function syncActiveWeaponVisualVisibility() {
  for (const slot in playerEquipment) {
    const eq = playerEquipment[slot];
    if (eq.entity) eq.entity.visible = (slot === activeWeaponSlot);
  }
}
// Wave 9 (Priority A, Sections 4-24): Weapon RUNTIME state -- deliberately
// separate from the Weapon DEFINITION (currentPlayerSettings.weapon or an
// Equipment Def's own `.weapon`), never mutating the shared authored data.
// Keyed by weapon SLOT identity ('fixed', or 'eq:primaryHand'/
// 'eq:secondaryHand' in Equipment mode) rather than by item name --
// matches Section 22's Primary/Secondary slot model directly: switching
// slots (Section 24) keeps each slot's own magazine/reserve, exactly as
// specified ("switching away and back should NOT magically refill").
let weaponRuntimeState = {};
function weaponRuntimeKeyForActiveSlot() {
  const settingsWeapon = currentPlayerSettings.weapon;
  return (settingsWeapon && settingsWeapon.source === 'equipment') ? ('eq:' + activeWeaponSlot) : 'fixed';
}
function ensureWeaponRuntime(weapon) {
  const key = weaponRuntimeKeyForActiveSlot();
  let rt = weaponRuntimeState[key];
  if (!rt) {
    rt = weaponRuntimeState[key] = { magazine: 0, reserve: 0, reloading: false, reloadEnd: 0 };
    if ((weapon.ammoMode || 'infinite') === 'magazine') {
      const size = weapon.magazineSize != null ? Math.max(1, weapon.magazineSize) : 30;
      rt.magazine = weapon.startingMagazine != null ? Math.max(0, Math.min(weapon.startingMagazine, size)) : size;
      rt.reserve = weapon.reserveAmmo != null ? Math.max(0, weapon.reserveAmmo) : 0;
    }
  }
  return rt;
}
// Section 11 -- reload only ever tops the magazine up from reserve, never
// discards the remainder; Section 10 -- simulation-time driven, so pause
// (which stops simElapsed advancing) correctly freezes it mid-reload.
function startWeaponReload(weapon) {
  if ((weapon.ammoMode || 'infinite') !== 'magazine') return;
  const rt = ensureWeaponRuntime(weapon);
  const size = weapon.magazineSize != null ? Math.max(1, weapon.magazineSize) : 30;
  if (rt.reloading || rt.magazine >= size || rt.reserve <= 0) return;
  rt.reloading = true;
  rt.reloadEnd = simElapsed + (weapon.reloadDuration != null && weapon.reloadDuration > 0 ? weapon.reloadDuration : 1.5);
  triggerPlayerReloadAnim(weapon.reloadDuration);
}
function tickWeaponReload() {
  if (!player) return;
  const weapon = resolveActivePlayerWeapon();
  if (!weapon || (weapon.ammoMode || 'infinite') !== 'magazine') return;
  const rt = ensureWeaponRuntime(weapon);
  if (!rt.reloading || simElapsed < rt.reloadEnd) return;
  const size = weapon.magazineSize != null ? Math.max(1, weapon.magazineSize) : 30;
  const move = Math.min(size - rt.magazine, rt.reserve);
  rt.magazine += move;
  rt.reserve -= move;
  rt.reloading = false;
}
// Wave 9 (Priority A/Section 22-23): weapon switching -- toggles which
// Equipment slot is active (Fixed Weapon mode has nothing to switch, since
// there's only ever one weapon; the action silently no-ops there). Cancels
// any in-progress reload on the OUTGOING slot (Section 23's "stop old
// reload") WITHOUT crediting the reserve back -- rounds already committed
// to a reload-in-progress are lost on switch, the simplest bounded rule.
function switchActiveWeaponSlot(toSlot) {
  const settingsWeapon = currentPlayerSettings.weapon;
  if (!settingsWeapon || settingsWeapon.source !== 'equipment') return;
  const target = toSlot || (activeWeaponSlot === 'primaryHand' ? 'secondaryHand' : 'primaryHand');
  if (target === activeWeaponSlot) return;
  const outgoingKey = weaponRuntimeKeyForActiveSlot();
  const rt = weaponRuntimeState[outgoingKey];
  if (rt) rt.reloading = false; // stop old reload -- no partial credit
  activeWeaponSlot = target;
  syncActiveWeaponVisualVisibility();
  showToast(`Switched to ${playerEquipment[target] ? playerEquipment[target].itemName : '(empty)'}`);
}
// Wave 9 (Priority A/Section 8): empty-magazine fire attempt -- no shot, no
// cooldown consumed, an authored Empty Sound (Synth beep by default so
// every project gets audible feedback with zero authoring) plays instead.
function handleEmptyFire(weapon) {
  if (weapon.emptySoundAssetId) {
    const asset = findAudioAssetById(weapon.emptySoundAssetId);
    if (asset && asset.audioBuffer) app.audio.playBuffer(asset.audioBuffer, { volume: 0.5 });
  } else {
    app.audio.playBlip({ frequency: 180, duration: 0.08, type: 'square' });
  }
  showToast('Out of ammo -- Reload');
}
// Wave 7 (Priority L, Sections 68-69): the flagship Bone Socket combat
// proof -- a weapon can name a socket (e.g. "Muzzle" on the Player
// Visual's own rig) so projectiles/hits originate from the REAL animated
// muzzle position, not the character's flat root. Reuses
// `resolveSocketSourceTransform` (Priority A) via the same duck-typed
// wrapper Equipment/Carry already established -- zero new socket-
// resolution code. `weapon.muzzleSocket` unset (every pre-Wave-7 project)
// falls straight back to the player's own root position, unchanged.
function resolveMuzzleOrigin(weapon) {
  if (weapon.muzzleSocket && playerVisualEntity && playerVisualEntity.skin && currentPlayerSettings.visual) {
    const t = resolveSocketSourceTransform({ entity: playerVisualEntity, assetId: currentPlayerSettings.visual.assetId }, weapon.muzzleSocket);
    if (t) return t.position;
  }
  return player.entity.position.clone();
}
// Wave 9 (Priority A/Section 18): Spread -- rotates the fire direction by a
// random angle bounded inside a cone of half-angle `spreadDegrees`, applied
// identically to Hitscan and Projectile (Section 18's own requirement).
// Melee ignores it (a swing has no "aim direction" to randomize). `0`
// (every pre-Wave-9 weapon) returns the exact input direction unchanged.
function applySpread(dir, spreadDegrees) {
  if (!spreadDegrees) return dir;
  const maxRad = spreadDegrees * Math.PI / 180;
  const theta = Math.random() * maxRad; // angle off-axis, uniform inside the cone (bounded, not a full Gaussian shooter-accuracy model)
  const phi = Math.random() * Math.PI * 2; // direction around the axis
  // Build an orthonormal basis around `dir`, then tilt by theta toward a
  // random point on the circle at that tilt -- a standard bounded-cone
  // perturbation, no new engine math needed beyond Vec3 already provides.
  const up = Math.abs(dir.y) < 0.99 ? new Opus.Vec3(0, 1, 0) : new Opus.Vec3(1, 0, 0);
  const right = up.cross ? up.cross(dir).normalize() : dir; // Vec3.cross is available on every build this project ships
  const trueUp = dir.cross ? dir.cross(right).normalize() : dir;
  const sinT = Math.sin(theta), cosT = Math.cos(theta);
  return dir.scale(cosT).add(right.scale(sinT * Math.cos(phi))).add(trueUp.scale(sinT * Math.sin(phi))).normalize();
}
function performPlayerWeaponFire() {
  if (!player) return;
  const weapon = resolveActivePlayerWeapon();
  if (!weapon) return;
  const isHitscan = weapon.mode === 'hitscan';
  const isMelee = weapon.mode === 'melee';
  // Wave 9 (Priority A, Sections 7-8): ammo is consumed HERE -- the moment
  // the shot actually leaves the muzzle -- not when Attack was pressed, so
  // `weapon.fireOnAnimationEvent` firing later (mid-swing/reload-race edge
  // cases) still consumes exactly one round per REAL shot, never per press.
  if ((weapon.ammoMode || 'infinite') === 'magazine' && !isMelee) {
    const rt = ensureWeaponRuntime(weapon);
    if (rt.reloading || rt.magazine <= 0) { handleEmptyFire(weapon); return; }
    rt.magazine -= 1;
  }
  const dir = applySpread(player.entity.forward, weapon.spreadDegrees || 0);
  const origin = resolveMuzzleOrigin(weapon);
  if (isHitscan) {
    const hit = fireHitscan(origin, dir, weapon.range || 50, weapon.damage, 'player', '', weapon.knockback || 0);
    // Wave 9D (Priority B, Sections 17-18, 20): exact geometric hit point
    // (`origin + direction * distance`), and fires for EVERY hit type
    // including a solid wall, not only damageable targets.
    const tracerEnd = hit ? origin.add(dir.scale(hit.t)) : origin.add(dir.scale(weapon.range || 50));
    if (hit) triggerImpactEffect(weapon, tracerEnd);
    if (weapon.tracer) spawnHitscanTracer(origin, tracerEnd);
  } else if (isMelee) {
    const hit = fireMelee(origin, dir, weapon.range || 2.5, Math.PI / 3, weapon.damage, 'player', '', weapon.knockback || 0);
    if (hit) triggerImpactEffect(weapon, origin.add(dir.scale(hit.dist)));
  } else if (weapon.prefabName) {
    // Wave 9D (Priority B/Section 19): the impact config travels WITH the
    // projectile itself (remembered on `activeProjectiles`' own entry) so
    // its later, asynchronous swept-collision hit (tickProjectiles) can
    // trigger the exact same effect at the exact real collision point,
    // never the projectile's post-step position.
    const impactConfig = (weapon.impactEffect || weapon.impactAudioAssetId) ? weapon : null;
    fireProjectile(weapon.prefabName, origin, dir, weapon.speed, weapon.damage, 'player', 3, 0.3, 0, '', impactConfig);
  } else {
    return; // nothing actually fired (e.g. Projectile mode with no prefab) -- no recoil/noise/shake for a no-op
  }
  triggerMuzzleEffect(weapon, origin);
  // Wave 9 (Priority B/Section 34): weapon fire optionally emits a Noise
  // Event AI can hear through walls -- opt-in (`weapon.emitNoiseOnFire`),
  // every pre-Wave-9 weapon stays silent to AI hearing exactly as before.
  if (weapon.emitNoiseOnFire) emitNoiseEvent(origin, weapon.noiseRadius != null ? weapon.noiseRadius : 18);
  if (player.controllerType === 'firstperson') applyWeaponRecoilKick(weapon);
  if (weapon.fireCameraShake && weapon.fireCameraShake.intensity) triggerCameraShake(weapon.fireCameraShake.intensity, weapon.fireCameraShake.duration || 0.15);
}
function fireAttack() {
  if (app.paused || !player) return;
  const settingsWeapon = currentPlayerSettings.weapon;
  if (!settingsWeapon || !settingsWeapon.enabled) return;
  // Wave 7 (Priority C/Section 20): gate against the RESOLVED weapon (Fixed
  // or, when `source === 'equipment'`, whatever's actually active right
  // now) -- so Equipment Weapon mode with nothing equipped correctly
  // no-ops here (isHitscan/isMelee both false, prefabName empty), the same
  // "Attack does nothing yet" behavior an unarmed Fixed-Weapon-disabled
  // game already has, not a special case.
  const weapon = resolveActivePlayerWeapon();
  if (!weapon) return;
  // Hitscan/Melee (Wave 5) need no prefab at all -- Hitscan is an instant
  // ray, Melee has no travel-time object either. Projectile mode still
  // requires one, exactly as before.
  const isHitscan = weapon.mode === 'hitscan';
  const isMelee = weapon.mode === 'melee';
  if (!isHitscan && !isMelee && !weapon.prefabName) return;
  if (simElapsed - lastAttackTime < weapon.cooldown) return;
  // Wave 9 (Priority A, Sections 7-9): a reload in progress blocks firing
  // entirely (no anim, no attempt, no cooldown consumed) -- Reload's own
  // Input Action is the only thing that can interrupt this state.
  if ((weapon.ammoMode || 'infinite') === 'magazine' && !isMelee) {
    const rt = ensureWeaponRuntime(weapon);
    if (rt.reloading) return;
  }
  lastAttackTime = simElapsed;
  // Wave 6B (Priority A/Section 8): a real skinned Player Character plays
  // its mapped Attack clip here, unconditionally -- needed either way,
  // since Wave 7's Animation Event fire (below) depends on this clip
  // actually being the one playing for its own crossing detection to find.
  triggerPlayerAttackAnim();
  // Wave 7 (Priority B/Section 15): `weapon.fireOnAnimationEvent` (opt-in,
  // default falsy) defers the actual hit to a `fireWeapon` Animation Event
  // authored on the Player's own Attack clip instead of firing here
  // immediately -- e.g. "the shot leaves the muzzle at the exact frame the
  // gun's own Attack animation reaches its firing pose," not the instant
  // the button was pressed. Every project that never sets this flag (every
  // project saved before this priority existed, and every new one that
  // doesn't opt in) keeps the exact old immediate-fire behavior.
  if (!weapon.fireOnAnimationEvent) performPlayerWeaponFire();
}

// --- Inspector ---

function rgbToHex(color) {
  const c = (v) => Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16).padStart(2, '0');
  return `#${c(color[0])}${c(color[1])}${c(color[2])}`;
}

function hexToRgb(hex) {
  const n = parseInt(hex.slice(1), 16);
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
}

// The scene-removal half of "delete an object" -- shared by deleteSelected
// (multi-item toolbar delete) and the Destroy Object action (single item,
// possibly mid-gameplay, never itself selected), so there's one place that
// knows how to remove each kind from both the engine and `placed`.
// Wave 7 (Priority E/Section 34): the ONE place any destruction (Destroy
// Object, Destroy Assembly, world-state restore itself) funnels through,
// so persistent-destruction tracking needs no second call site to remember.
// Gated on `playMode` -- an author deleting an object in the EDITOR itself
// (Delete Object button, prefab swap-and-replace) must never be mistaken
// for a runtime gameplay destruction.
function markPersistentDestruction(item) {
  if (!playMode || !item.persistRuntimeState) return;
  const levelId = levels[currentLevelIndex] && levels[currentLevelIndex].id;
  if (!levelId) return;
  window.__destroyedPersistentIds = window.__destroyedPersistentIds || {};
  window.__destroyedPersistentIds[levelId] = window.__destroyedPersistentIds[levelId] || new Set();
  window.__destroyedPersistentIds[levelId].add(item.id);
}
// Wave 7 (Priority E): builds ONE level's own worldState slice --
// `{[objectId]: {destroyed} | {destroyed:false, visible, position,
// rotation, health?}}` -- covering only objects with `persistRuntimeState`
// set, and only the properties that actually apply (no `health` key for an
// object with no Health system initialized). `placed` only ever holds the
// CURRENTLY LOADED level's own objects, so a level other than the active
// one is covered entirely by its own destroyed-id set (persisted runtime
// destructions, tracked live by `markPersistentDestruction` regardless of
// which level is active at the time) -- its other fields (position, etc.)
// were already captured into `window.__worldState` the last time THAT
// level was itself active, and this function is not asked to re-derive
// them from nothing.
function collectWorldStateForLevel(levelId) {
  const state = {};
  const destroyedSet = (window.__destroyedPersistentIds && window.__destroyedPersistentIds[levelId]) || new Set();
  for (const id of destroyedSet) state[id] = { destroyed: true };
  const activeLevelId = levels[currentLevelIndex] && levels[currentLevelIndex].id;
  if (levelId === activeLevelId) {
    for (const item of placed) {
      if (item.kind !== 'cube' || !item.persistRuntimeState) continue;
      const rec = {
        destroyed: false,
        visible: item.entity.visible,
        position: [item.entity.position.x, item.entity.position.y, item.entity.position.z],
        rotation: [item.entity.quaternion.x, item.entity.quaternion.y, item.entity.quaternion.z, item.entity.quaternion.w],
      };
      if (item.health) rec.health = item.health.current;
      // Wave 8 (Priority B/Section 13): Object Variables OPT IN to World
      // State persistence only alongside `persistRuntimeState` (never
      // automatically for every object with variables) -- and only real
      // ones present at capture time, never a blind clone of authored
      // defaults.
      if (item.variables && Object.keys(item.variables).length) rec.variables = { ...item.variables };
      state[item.id] = rec;
    }
  }
  return state;
}
function captureCurrentLevelWorldState() {
  const levelId = levels[currentLevelIndex] && levels[currentLevelIndex].id;
  if (!levelId) return;
  window.__worldState = window.__worldState || {};
  window.__worldState[levelId] = collectWorldStateForLevel(levelId);
}
// Applies a previously-saved worldState slice onto the CURRENTLY LOADED
// level's own freshly-rebuilt authored scene -- MUST run after that scene
// already exists (see Section 37's restore order, enforced by this
// function's own two call sites in the `loadGame` action above, never
// called any earlier). A record whose object no longer resolves (either
// truly gone, or the `destroyed:true` case) is always a silent no-op --
// nothing to restore state ONTO.
function applyWorldStateToCurrentLevel() {
  const levelId = levels[currentLevelIndex] && levels[currentLevelIndex].id;
  const stateForLevel = window.__worldState && window.__worldState[levelId];
  if (!stateForLevel) return;
  for (const id in stateForLevel) {
    const rec = stateForLevel[id];
    const item = findItemById(id);
    if (!item) continue;
    if (rec.destroyed) { removeItemFromScene(item); continue; }
    if (rec.visible != null) item.entity.visible = rec.visible;
    if (rec.position) item.entity.position.set(rec.position[0], rec.position[1], rec.position[2]);
    if (rec.rotation) item.entity.quaternion = new Opus.Quat(rec.rotation[0], rec.rotation[1], rec.rotation[2], rec.rotation[3]);
    if (rec.health != null && item.health) item.health.current = rec.health;
    if (rec.variables) item.variables = { ...(item.variables || {}), ...rec.variables };
  }
}
function removeItemFromScene(item) {
  markPersistentDestruction(item);
  // Wave 8 (Priority K dogfood/Power Grid): destroying the currently-HELD
  // object directly (e.g. "insert the carried Power Cell, consuming it" --
  // a real, natural Carry/Drop end state Wave 7's own dogfood never
  // exercised) must not leave `heldObjectItem` pointing at a destroyed
  // entity -- `syncHeldObjectPosition` would otherwise keep writing
  // position/quaternion onto a dead object every frame forever, and
  // `objectIsHeld` would keep reporting true for something no longer in
  // the scene at all.
  if (heldObjectItem === item) heldObjectItem = null;
  if (item.kind === 'cube') app.scene.remove(item.entity);
  else if (item.kind === 'terrain') app.removeTerrain(item.handle);
  else if (item.kind === 'water') app.removeWater(item.handle);
  else if (item.kind === 'emitter') app.removeEmitter(item.handle);
  else if (item.kind === 'camera') app.scene.remove(item.entity);
  else if (item.kind === 'spawner') app.scene.remove(item.entity);
  else if (item.kind === 'light') { app.scene.remove(item.entity); app.removeLight(item.lightHandle); }
  // Wave 8 (Priority I): a Path's own container item has no entity/handle
  // of its own to remove from the engine scene (nothing above matches
  // `kind === 'path'`); a deleted POINT MARKER (an ordinary `kind:'cube'`
  // item, already handled by the first branch above) additionally prunes
  // itself out of its owning path's `pointIds` here, so a path never ends
  // up referencing a dangling id.
  if (item.kind === 'cube' && item.isPathPoint && item.pathId) {
    const owner = findItemById(item.pathId);
    if (owner && owner.pointIds) owner.pointIds = owner.pointIds.filter((id) => id !== item.id);
  }
  const idx = placed.indexOf(item);
  if (idx !== -1) placed.splice(idx, 1);
  // A deleted parent must not leave children pointing at a dangling id --
  // resolveWorldTransform() fails safe against that already (falls back to
  // unparented), but unparenting them explicitly here keeps entity.* correct
  // starting THIS frame rather than depending on that fallback ever running,
  // and keeps the Scene tree from showing a orphaned-looking indent.
  for (const other of placed) {
    if (other.parentId === item.id) unparentItem(other);
    if (other.isWaypoint && other.connections) other.connections = other.connections.filter((id) => id !== item.id);
  }
  if (selectedItems.has(item)) {
    selectedItems.delete(item);
    if (selectedItem === item) selectedItem = null;
    syncSelectionMarkers();
  }
  // A destroyed item's own TriggerVolume (if any -- e.g. Destroy Object
  // fired on a runtime-spawned enemy that was itself a Trigger Volume, or
  // just had an Enter/Exit behavior) must stop being polled, or it would go
  // on calling onEnter/onExit against a position nothing is updating anymore.
  const triggerIdx = playTriggers.findIndex((t) => t.item === item);
  if (triggerIdx !== -1) playTriggers.splice(triggerIdx, 1);
}

function deleteSelected() {
  if (selectedItems.size === 0) return;
  pushUndo();
  for (const item of Array.from(selectedItems)) removeItemFromScene(item);
  // Deleting the one designated default Spawn Point would otherwise leave
  // the level with zero default -- computeSpawnPoint()'s explicit-Spawn-Point
  // priority would silently fall through to the terrain/solid-ground/safe-
  // default chain with no indication anything changed. Auto-promote whatever
  // Spawn Point remains, same "never leave zero of the thing that must exist
  // exactly once" reasoning as Start Level.
  const remainingSpawnPoints = placed.filter((p) => p.isSpawnPoint);
  if (remainingSpawnPoints.length > 0 && !remainingSpawnPoints.some((p) => p.isDefaultSpawn)) {
    remainingSpawnPoints[0].isDefaultSpawn = true;
  }
  deselectAll();
}

// A graph behavior's `graph` ({ nodes, edges }) is a nested object -- a
// plain shallow `{ ...b }` would leave a duplicate/undo-snapshot/reload
// sharing the SAME graph object as its source, so editing one later would
// silently mutate the other. Used by serializeScene, loadScene, and
// duplicateSelected -- everywhere a behaviors array gets copied.
function cloneBehaviors(behaviors) {
  return (behaviors || []).map((b) => {
    if (b.action === 'graph' && b.graph) return { ...b, graph: JSON.parse(JSON.stringify(b.graph)) };
    if (b.action === 'dialogueTree' && b.dialogueTree) return { ...b, dialogueTree: JSON.parse(JSON.stringify(b.dialogueTree)) };
    // Wave 9D -- REAL BUG found live dogfooding the new Audio Asset Prefab
    // Parameter: this fallback branch used to be a SHALLOW `{ ...b }`,
    // leaving `b.params` (an object, for every non-legacy action) as one
    // SHARED reference across every instance ever cloned from the same
    // source behaviors array (prefab spawn, Duplicate, Array, Scatter --
    // every one of them routes through instantiateCubeRecord ->
    // cloneBehaviors). Harmless as long as nothing ever mutated `params`
    // in place after cloning; the new `soundAsset` Prefab Parameter binding
    // is the first thing that does (`b.params.audioAssetId = value`,
    // applyPrefabParamBinding) -- setting one instance's audio override
    // silently overwrote EVERY sibling instance's params object too, since
    // they were kept literally the same object. The exact same bug CLASS
    // Wave 8 already fixed once for `instantiateCubeRecord`'s shared
    // `record.color` array (see that fix's own comment) -- a different
    // field, same root cause, same fix shape.
    return { ...b, params: b.params ? { ...b.params } : b.params };
  });
}

// Placing several similar objects (another crate, another hazard) meant
// re-dragging from the palette and re-adding behaviors each time -- cloning
// the current selection is much cheaper when what you want is "one more of
// this" (or several: duplicating a multi-selection clones the whole group
// and selects the clones, not the originals). Reuses each item's own mesh
// (entity.mesh), so a duplicated hazard stays a mine-shape and a duplicated
// boost pad stays a pyramid, not a generic cube.
function duplicateSelected() {
  if (selectedItems.size === 0) return;
  pushUndo();
  const newItems = [];
  // Duplicates of a grouped selection stay linked to EACH OTHER under a
  // fresh group id, not the source's -- otherwise "Duplicate All" on a
  // group would silently merge six objects into one twelve-member group
  // instead of producing two independent groups of six.
  const groupIdMap = new Map();
  function remapGroupId(srcGroupId) {
    if (!srcGroupId) return undefined;
    if (!groupIdMap.has(srcGroupId)) groupIdMap.set(srcGroupId, generateGroupId());
    return groupIdMap.get(srcGroupId);
  }
  const idMap = new Map(); // src item -> new item, for remapping parentId when a whole assembly is duplicated together
  for (const src of selectedItems) {
    let newItem;
    if (src.kind === 'cube') {
      const srcEntity = src.entity;
      const entity = app.addEntity({
        mesh: srcEntity.mesh,
        color: srcEntity.color.slice(),
        position: new Opus.Vec3(srcEntity.position.x + 1.5, srcEntity.position.y, srcEntity.position.z + 1.5),
        scale: new Opus.Vec3(srcEntity.scale.x, srcEntity.scale.y, srcEntity.scale.z),
        rotationY: srcEntity.rotationY,
      });
      if (srcEntity.spin) entity.spin = srcEntity.spin;
      // Patrol/AI carry a `base` point captured at the ORIGINAL position, so
      // a duplicate re-bases it to its own new spot rather than sharing
      // (and steering back toward) the source's base -- caught while adding
      // AI duplication support: patrol had the exact same gap already,
      // silently dropped on duplicate, fixed here too rather than left half-fixed.
      if (srcEntity.patrol) entity.patrol = { ...srcEntity.patrol, base: entity.position.clone() };
      if (srcEntity.ai) entity.ai = { ...srcEntity.ai, base: entity.position.clone() };
      if (srcEntity.solid) entity.solid = true;
      if (srcEntity.texture) entity.texture = srcEntity.texture;
      entity.unlit = srcEntity.unlit;
      entity.alpha = srcEntity.alpha;
      entity.emissiveColor = srcEntity.emissiveColor ? srcEntity.emissiveColor.slice() : [0, 0, 0];
      entity.emissiveIntensity = srcEntity.emissiveIntensity || 0;
      entity.uvScale = srcEntity.uvScale ? srcEntity.uvScale.slice() : [1, 1];
      entity.uvOffset = srcEntity.uvOffset ? srcEntity.uvOffset.slice() : [0, 0];
      newItem = { kind: 'cube', entity, behaviors: cloneBehaviors(src.behaviors), isTrigger: src.isTrigger, triggerRepeat: src.triggerRepeat, triggerShape: src.triggerShape, collider: src.collider ? JSON.parse(JSON.stringify(src.collider)) : undefined, tags: src.tags ? src.tags.slice() : undefined, assetId: src.assetId, isWaypoint: src.isWaypoint, isRamp: src.isRamp, isBillboard: src.isBillboard, billboardMode: src.billboardMode, sourcePrefabName: src.sourcePrefabName, characterAnimSync: src.characterAnimSync, textureAssetId: src.textureAssetId, isSpawnPoint: src.isSpawnPoint, isDefaultSpawn: src.isSpawnPoint ? false : undefined, animationClips: src.animationClips ? JSON.parse(JSON.stringify(src.animationClips)) : undefined, connections: src.connections ? src.connections.slice() : undefined };
    } else if (src.kind === 'terrain') {
      const opts = { ...src.options, seed: Math.floor(Math.random() * 10000) };
      opts.position = new Opus.Vec3(src.options.position.x + 8, src.options.position.y, src.options.position.z + 8);
      const handle = app.createTerrain(opts);
      newItem = { kind: 'terrain', handle, options: opts };
      syncTerrainLayerTextures(newItem);
    } else if (src.kind === 'water') {
      const opts = { ...src.options };
      opts.position = new Opus.Vec3(src.options.position.x + 8, src.options.position.y, src.options.position.z + 8);
      const handle = app.createWater(opts);
      newItem = { kind: 'water', handle, options: opts };
    } else if (src.kind === 'camera') {
      const srcEntity = src.entity;
      const newPos = new Opus.Vec3(srcEntity.position.x + 1.5, srcEntity.position.y, srcEntity.position.z + 1.5);
      const entity = app.addEntity({
        mesh: srcEntity.mesh,
        color: srcEntity.color.slice(),
        position: newPos,
        scale: new Opus.Vec3(srcEntity.scale.x, srcEntity.scale.y, srcEntity.scale.z),
      });
      const options = JSON.parse(JSON.stringify(src.options));
      options.position = newPos;
      newItem = { kind: 'camera', entity, options };
    } else if (src.kind === 'spawner') {
      const srcEntity = src.entity;
      const newPos = new Opus.Vec3(srcEntity.position.x + 1.5, srcEntity.position.y, srcEntity.position.z + 1.5);
      const entity = app.addEntity({
        mesh: srcEntity.mesh,
        color: srcEntity.color.slice(),
        position: newPos,
        scale: new Opus.Vec3(srcEntity.scale.x, srcEntity.scale.y, srcEntity.scale.z),
      });
      const options = JSON.parse(JSON.stringify(src.options));
      options.position = newPos;
      newItem = { kind: 'spawner', entity, options };
    } else if (src.kind === 'light') {
      const srcEntity = src.entity;
      const newPos = new Opus.Vec3(srcEntity.position.x + 1.5, srcEntity.position.y, srcEntity.position.z + 1.5);
      const entity = app.addEntity({ mesh: srcEntity.mesh, color: srcEntity.color.slice(), position: newPos, scale: new Opus.Vec3(srcEntity.scale.x, srcEntity.scale.y, srcEntity.scale.z) });
      const options = JSON.parse(JSON.stringify(src.options));
      options.position = newPos;
      if (options.direction) options.direction = new Opus.Vec3(options.direction.x, options.direction.y, options.direction.z);
      const lightHandle = app.createLight({ type: options.lightType, position: options.position.clone(), color: options.color, intensity: options.intensity, range: options.range, angle: options.angle, direction: options.direction, enabled: options.enabled });
      newItem = { kind: 'light', entity, options, lightHandle };
    } else {
      const opts = { ...src.options };
      opts.position = new Opus.Vec3(src.options.position.x + 1.5, src.options.position.y, src.options.position.z + 1.5);
      const handle = app.createEmitter(opts);
      newItem = { kind: 'emitter', handle, options: opts };
    }
    newItem.groupId = remapGroupId(src.groupId);
    // Copied through as-is for now; remapped below ONLY when the source's
    // parent was ALSO part of this same duplicated selection (a whole
    // assembly duplicated together should stay attached to ITS OWN new
    // parent, not silently alias back onto the original's).
    newItem.parentId = src.parentId;
    newItem.localPosition = src.localPosition ? src.localPosition.clone() : undefined;
    newItem.localRotationY = src.localRotationY;
    newItem.localQuat = src.localQuat ? src.localQuat.clone() : undefined;
    newItem.localScale = src.localScale ? src.localScale.clone() : undefined;
    idMap.set(src, newItem);
    addPlaced(newItem);
    newItems.push(newItem);
  }
  for (const newItem of newItems) {
    if (!newItem.parentId) continue;
    const srcParent = findItemById(newItem.parentId);
    const mappedParent = srcParent && idMap.get(srcParent);
    if (mappedParent) newItem.parentId = mappedParent.id;
  }
  hierarchyTickToken++; // force a fresh resolve pass -- world transforms for the new duplicates must be correct before anything reads them
  updateHierarchyTransforms();
  selectedItems.clear();
  for (const item of newItems) selectedItems.add(item);
  selectedItem = newItems[newItems.length - 1] || null;
  syncSelectionMarkers();
  renderInspector();
  renderSceneList();
}

const inspectorBody = document.getElementById('inspector-body');

function renderInspectorBody() {
  if (selectedItems.size === 0) {
    inspectorBody.innerHTML = '<p id="inspector-empty">Nothing selected.</p>';
    return;
  }

  // Editing properties across a heterogeneous multi-selection (a cube next
  // to a terrain, say) isn't attempted -- just the two operations that make
  // sense for any group: move them together (already covered by drag, no
  // inspector control needed) and duplicate/delete as a unit.
  if (selectedItems.size > 1) {
    // Grouping doesn't change how a selection moves (multi-select drag
    // already moves the whole set together, coherently, with no group
    // needed for that) -- what it adds is persistence: clicking any ONE
    // grouped member later re-selects the whole group again (see
    // selectItem), instead of the grouping only lasting as long as this one
    // marquee/shift-click selection does.
    const groupIds = new Set([...selectedItems].map((i) => i.groupId).filter(Boolean));
    const isOneWholeGroup = groupIds.size === 1 && [...selectedItems].every((i) => i.groupId === [...groupIds][0])
      && placed.filter((p) => p.groupId === [...groupIds][0]).length === selectedItems.size;
    inspectorBody.innerHTML = `
      <p style="color:#9fb3d9;margin-bottom:12px">${selectedItems.size} objects selected</p>
      <div class="field-triple">
        <button id="group-btn" class="toolbar-btn" style="margin-bottom:0">${isOneWholeGroup ? 'Ungroup' : 'Group'}</button>
        <button id="duplicate-btn" class="toolbar-btn" style="margin-bottom:0">Duplicate All</button>
      </div>
      <div class="field-triple">
        <button id="delete-btn" style="margin-bottom:0">Delete All</button>
      </div>
    `;
    document.getElementById('group-btn').onclick = () => {
      pushUndo();
      if (isOneWholeGroup) {
        for (const item of selectedItems) item.groupId = undefined;
      } else {
        const groupId = generateGroupId();
        for (const item of selectedItems) item.groupId = groupId;
      }
      renderInspector();
    };
    document.getElementById('duplicate-btn').onclick = duplicateSelected;
    document.getElementById('delete-btn').onclick = deleteSelected;
    return;
  }

  // Wave 8 (Priority I): a Path has no `.entity` at all -- handled as its
  // own early, self-contained branch rather than threading `kind==='path'`
  // checks through the (enormous) cube-item branch below.
  if (selectedItem.kind === 'path') {
    const path = selectedItem;
    const points = (path.pointIds || []).map((id) => findItemById(id)).filter(Boolean);
    inspectorBody.innerHTML = `
      <div class="field-row"><label>Path Name</label><input type="text" id="f-path-name" value="${escapeHtml(path.name || '')}" placeholder="Path name"></div>
      <div class="field-row">
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#c7d3ea"><input type="checkbox" id="f-path-loop"${path.loop ? ' checked' : ''}> Loop (closed path)</label>
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#c7d3ea;margin-top:4px"><input type="checkbox" id="f-path-smooth"${path.smooth ? ' checked' : ''}> Smooth (Catmull-Rom, not straight segments)</label>
      </div>
      <div class="field-row"><label>Points (${points.length})</label>
        <div id="path-point-list">${points.map((p, i) => `<div class="field-triple" style="margin-top:3px"><span style="font-size:11px;color:#c7d3ea;align-self:center">#${i + 1}</span><button data-path-select-point="${escapeHtml(p.id)}" class="toolbar-btn" style="margin-bottom:0">Select</button><button data-path-delete-point="${escapeHtml(p.id)}" class="hud-remove-btn">✕</button></div>`).join('')}</div>
        <button id="path-add-point-btn" class="toolbar-btn" style="margin-top:4px">+ Add Point</button>
        <div style="font-size:10.5px;color:#66759a;margin-top:3px">Drag a point marker in the viewport (same Move gizmo as any object) to reshape the path. New points append after the last one.</div>
      </div>
      <div class="field-row"><label>Populate Along Path (Wave 8 Priority I)</label>
        <div class="field-triple">
          <select id="path-populate-prefab"><option value="">(none)</option>${prefabs.map((p) => `<option value="${escapeHtml(p.name)}">${escapeHtml(p.name)}</option>`).join('')}</select>
          <input type="number" id="path-populate-spacing" placeholder="Spacing" value="2" min="0.1" step="0.5">
          <label style="display:flex;align-items:center;gap:4px;font-size:11px;color:#c7d3ea"><input type="checkbox" id="path-populate-align" checked> Align</label>
        </div>
        <button id="path-populate-btn" class="toolbar-btn" style="margin-top:4px">Populate</button>
        <div style="font-size:10.5px;color:#66759a;margin-top:3px">Fences, lamps, road markers, pipes -- output is ordinary placed objects, one Undo step.</div>
      </div>
      <div class="field-triple">
        <button id="duplicate-btn" class="toolbar-btn" style="margin-bottom:0">Duplicate</button>
        <button id="delete-btn" style="margin-bottom:0">Delete Object</button>
      </div>
    `;
    document.getElementById('f-path-name').oninput = (e) => { path.name = e.target.value; };
    document.getElementById('f-path-loop').onchange = (e) => { pushUndo(); path.loop = e.target.checked; };
    document.getElementById('f-path-smooth').onchange = (e) => { pushUndo(); path.smooth = e.target.checked; };
    document.querySelectorAll('[data-path-select-point]').forEach((btn) => { btn.onclick = () => { const p = findItemById(btn.dataset.pathSelectPoint); if (p) selectItem(p); }; });
    document.querySelectorAll('[data-path-delete-point]').forEach((btn) => {
      btn.onclick = () => { const p = findItemById(btn.dataset.pathDeletePoint); if (p) { pushUndo(); removeItemFromScene(p); renderInspector(); } };
    });
    document.getElementById('path-add-point-btn').onclick = () => {
      pushUndo();
      const last = points[points.length - 1];
      const basePos = last ? last.entity.position : new Opus.Vec3();
      addPathPoint(path, new Opus.Vec3(basePos.x + 2, basePos.y, basePos.z));
      renderInspector();
    };
    document.getElementById('path-populate-btn').onclick = () => {
      const prefabName = document.getElementById('path-populate-prefab').value;
      if (!prefabName) { showStatus('Choose a Prefab first'); return; }
      const spacing = parseFloat(document.getElementById('path-populate-spacing').value) || 2;
      const align = document.getElementById('path-populate-align').checked;
      const result = populateAlongPath(path, { prefabName, spacing, alignToPath: align, scale: 1 });
      renderSceneList();
      showStatus(`Populated ${result.placedCount} along path`);
    };
    document.getElementById('duplicate-btn').onclick = duplicateSelected;
    document.getElementById('delete-btn').onclick = deleteSelected;
    return;
  }

  if (selectedItem.kind === 'cube') {
    const entity = selectedItem.entity;
    inspectorBody.innerHTML = `
      <div class="field-row"><label>Position</label>
        <div class="field-triple">
          <input type="number" id="f-x" step="0.1" value="${entity.position.x.toFixed(2)}">
          <input type="number" id="f-y" step="0.1" value="${entity.position.y.toFixed(2)}">
          <input type="number" id="f-z" step="0.1" value="${entity.position.z.toFixed(2)}">
        </div>
      </div>
      <div class="field-row"><label>Rotation X / Y / Z (degrees)</label>
        <div class="field-triple">
          <input type="number" id="f-rotation-x" step="5" value="${(entity.quaternion.toEuler().x * 180 / Math.PI).toFixed(1)}">
          <input type="number" id="f-rotation-y" step="5" value="${(entity.quaternion.toEuler().y * 180 / Math.PI).toFixed(1)}">
          <input type="number" id="f-rotation-z" step="5" value="${(entity.quaternion.toEuler().z * 180 / Math.PI).toFixed(1)}">
        </div>
      </div>
      <div class="field-row"><label>Scale (X / Y / Z)</label>
        <div class="field-triple">
          <input type="number" id="f-scale-x" step="0.1" min="0.05" value="${entity.scale.x.toFixed(2)}">
          <input type="number" id="f-scale-y" step="0.1" min="0.05" value="${entity.scale.y.toFixed(2)}">
          <input type="number" id="f-scale-z" step="0.1" min="0.05" value="${entity.scale.z.toFixed(2)}">
        </div>
        <button id="f-scale-uniform-btn" class="toolbar-btn" style="margin-top:4px;margin-bottom:0">Make Uniform (use X)</button>
      </div>
      <div class="field-row"><label>Color${selectedItem.textureAssetId ? ' (tints the texture below)' : ''}</label>
        <input type="color" id="f-color" value="${rgbToHex(entity.color)}">
      </div>
      <div class="field-row"><label>Texture</label>
        <select id="f-texture">
          <option value="">None</option>
          ${textureAssets.map((t) => `<option value="${t.id}"${selectedItem.textureAssetId === t.id ? ' selected' : ''}>${escapeHtml(t.name)}</option>`).join('')}
        </select>
      </div>
      ${selectedItem.textureAssetId ? `
      <div class="field-row"><label>Texture Tiling (X / Y) / Offset (X / Y)</label>
        <div class="field-triple">
          <input type="number" id="f-uv-scale-x" step="0.1" min="0.01" value="${(entity.uvScale ? entity.uvScale[0] : 1).toFixed(2)}">
          <input type="number" id="f-uv-scale-y" step="0.1" min="0.01" value="${(entity.uvScale ? entity.uvScale[1] : 1).toFixed(2)}">
        </div>
        <div class="field-triple" style="margin-top:4px">
          <input type="number" id="f-uv-offset-x" step="0.05" value="${(entity.uvOffset ? entity.uvOffset[0] : 0).toFixed(2)}">
          <input type="number" id="f-uv-offset-y" step="0.05" value="${(entity.uvOffset ? entity.uvOffset[1] : 0).toFixed(2)}">
        </div>
      </div>` : ''}
      <div class="field-row"><label>Material</label>
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#c7d3ea;margin-bottom:6px">
          <input type="checkbox" id="f-unlit"${entity.unlit ? ' checked' : ''}> Unlit (flat color, ignores lighting)
        </label>
        <label style="font-size:10px;color:#66759a">Transparency (1 = opaque, 0 = invisible)</label>
        <input type="range" id="f-alpha" min="0" max="1" step="0.01" value="${entity.alpha ?? 1}">
        <label style="font-size:10px;color:#66759a;margin-top:4px">Emissive Color / Intensity</label>
        <div class="field-triple">
          <input type="color" id="f-emissive-color" value="${rgbToHex(entity.emissiveColor || [0, 0, 0])}">
          <input type="number" id="f-emissive-intensity" step="0.1" min="0" value="${entity.emissiveIntensity || 0}">
        </div>
      </div>
      <div class="field-row"><label>Animation Clips</label>
        <div id="anim-clip-list">${(selectedItem.animationClips || []).map((clip, i) => `
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
            <span style="flex:1;font-size:12px;color:#c7d3ea">${escapeHtml(clip.name)} <span style="color:#66759a">(${clip.duration}s, ${clip.loop})</span></span>
            <button data-edit-clip="${i}" style="padding:2px 8px">Edit</button>
            <button data-delete-clip="${i}" style="padding:2px 8px">✕</button>
          </div>`).join('') || '<p style="color:#66759a;font-size:11px;margin:2px 0">No animation clips yet.</p>'}
        </div>
        <button id="add-anim-clip-btn" class="toolbar-btn" style="margin-top:4px">+ Add Animation Clip</button>
      </div>
      <div class="field-row"><label>AI Behavior</label>
        <select id="f-ai-type">
          <option value="">None</option>
          <option value="follow"${entity.ai && entity.ai.type === 'follow' ? ' selected' : ''}>Follow (chase the Player, or Target below)</option>
          <option value="flee"${entity.ai && entity.ai.type === 'flee' ? ' selected' : ''}>Flee (run from the Player within Radius)</option>
          <option value="faceTarget"${entity.ai && entity.ai.type === 'faceTarget' ? ' selected' : ''}>Face Target (rotate to track, no movement)</option>
          <option value="orbit"${entity.ai && entity.ai.type === 'orbit' ? ' selected' : ''}>Orbit (circle in place)</option>
          <option value="wander"${entity.ai && entity.ai.type === 'wander' ? ' selected' : ''}>Wander (random drift)</option>
          <option value="patrolRoute"${entity.ai && entity.ai.type === 'patrolRoute' ? ' selected' : ''}>Patrol Route (visit named Waypoints in order)</option>
          <option value="navigateToTarget"${entity.ai && entity.ai.type === 'navigateToTarget' ? ' selected' : ''}>Navigate To Target (pathfind via connected Waypoints)</option>
          <option value="followPath"${entity.ai && entity.ai.type === 'followPath' ? ' selected' : ''}>Follow Path (Wave 8 -- moving platforms, patrol routes)</option>
        </select>
        <div class="field-triple" id="f-ai-params" style="${entity.ai && entity.ai.type !== 'patrolRoute' ? '' : 'display:none'}">
          <input type="number" id="f-ai-speed" step="0.1" min="0.1" placeholder="Speed" value="${entity.ai ? entity.ai.speed : 3}"${entity.ai && entity.ai.type === 'faceTarget' ? ' disabled' : ''}>
          <input type="number" id="f-ai-radius" step="0.5" min="0.5" placeholder="Radius" value="${entity.ai ? entity.ai.radius : 5}"${entity.ai && (entity.ai.type === 'follow' || entity.ai.type === 'faceTarget') ? ' disabled' : ''}>
        </div>
        ${entity.ai && (entity.ai.type === 'follow' || entity.ai.type === 'faceTarget' || entity.ai.type === 'navigateToTarget') ? `
        <div class="field-row" style="margin-top:6px"><label style="font-size:10px;color:#66759a">Target (optional -- defaults to Player)</label>
          ${renderActionFieldInput({ key: 'aiTargetId', type: 'target' }, entity.ai.targetId, 'f-ai-target')}
        </div>` : ''}
        ${entity.ai && entity.ai.type === 'patrolRoute' ? `
        <div class="field-row" style="margin-top:6px">
          <label style="font-size:10px;color:#66759a">Speed</label>
          <input type="number" id="f-ai-patrol-speed" step="0.1" min="0.1" value="${entity.ai.speed}">
          <label style="font-size:10px;color:#66759a;margin-top:4px">Waypoint names, in order (comma-separated -- set each Waypoint's Name field)</label>
          <input type="text" id="f-ai-waypoints" placeholder="WP1, WP2, WP3" value="${escapeHtml(entity.ai.waypointNames || '')}">
          <div style="display:flex;gap:10px;margin-top:4px">
            <label style="display:flex;align-items:center;gap:4px;font-size:11px;color:#c7d3ea"><input type="checkbox" id="f-ai-loop"${entity.ai.loop ? ' checked' : ''}> Loop</label>
            <label style="display:flex;align-items:center;gap:4px;font-size:11px;color:#c7d3ea"><input type="checkbox" id="f-ai-pingpong"${entity.ai.pingpong ? ' checked' : ''}> Ping-Pong</label>
          </div>
        </div>` : ''}
        ${entity.ai && entity.ai.type === 'followPath' ? `
        <div class="field-row" style="margin-top:6px">
          <label style="font-size:10px;color:#66759a">Path</label>
          <select id="f-ai-path">${placed.filter((p) => p.kind === 'path').map((p, pi) => `<option value="${escapeHtml(p.id)}"${entity.ai.pathId === p.id ? ' selected' : ''}>${escapeHtml(p.name || itemDisplayName(p, pi))}</option>`).join('') || '<option value="">(no Paths placed yet)</option>'}</select>
          <label style="font-size:10px;color:#66759a;margin-top:4px">Speed</label>
          <input type="number" id="f-ai-path-speed" step="0.1" min="0.1" value="${entity.ai.speed || 2}">
          <div style="display:flex;gap:10px;margin-top:4px">
            <label style="display:flex;align-items:center;gap:4px;font-size:11px;color:#c7d3ea"><input type="checkbox" id="f-ai-path-pingpong"${entity.ai.pingpong ? ' checked' : ''}> Ping-Pong (ignored if the Path itself loops)</label>
          </div>
        </div>` : ''}
        ${entity.ai ? `
        <div class="field-row" style="margin-top:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,0.08)">
          <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#c7d3ea">
            <input type="checkbox" id="f-ai-attack-enabled"${entity.ai.attackEnabled ? ' checked' : ''}> Ranged Attack (fires at Target/Player in range)
          </label>
          <div id="f-ai-attack-fields" style="display:${entity.ai.attackEnabled ? '' : 'none'}">
            <div class="field-row" style="margin-top:4px"><label style="font-size:10px;color:#66759a">Projectile Prefab</label>
              ${prefabs.length === 0 ? '<p style="color:#8592a8;font-size:11.5px;margin:2px 0">No prefabs saved yet.</p>' : renderActionFieldInput({ key: 'prefabName', type: 'prefab' }, entity.ai.attackPrefab, 'f-ai-attack-prefab')}
            </div>
            <div class="field-triple">
              <div><label style="font-size:10px;color:#66759a">Range</label><input type="number" id="f-ai-attack-radius" step="0.5" min="0.5" value="${entity.ai.attackRadius || 8}"></div>
              <div><label style="font-size:10px;color:#66759a">Cooldown</label><input type="number" id="f-ai-attack-cooldown" step="0.1" min="0.1" value="${entity.ai.attackCooldown || 1.5}"></div>
              <div><label style="font-size:10px;color:#66759a">Damage</label><input type="number" id="f-ai-attack-damage" step="1" min="0" value="${entity.ai.attackDamage || 10}"></div>
            </div>
          </div>
        </div>` : ''}
      </div>
      ${entity.ai ? `
      <div class="field-row">
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#c7d3ea"><input type="checkbox" id="f-ai-statemachine-mode"${entity.ai.mode === 'stateMachine' ? ' checked' : ''}> AI Mode: State Machine (Wave 7 Priority D)</label>
        <div style="font-size:10.5px;color:#66759a;margin-top:3px">When on, the AI Behavior fields above are ignored -- movement/attack come from whichever state is currently active below instead.</div>
        ${entity.ai.mode === 'stateMachine' ? '<div id="ai-perception-fields"></div><div id="ai-state-list"></div><button id="ai-state-add-btn" class="toolbar-btn" style="margin-top:4px">+ Add State</button>' : ''}
      </div>` : ''}
      <div class="field-row"><label>Attach to Socket (Wave 7 Priority A)</label>
        ${selectedItem.socketName ? `
        <p style="font-size:11.5px;color:#8fd0a0;margin:2px 0">Attached to "${escapeHtml(selectedItem.socketName)}" on ${(() => { const c = findItemById(selectedItem.parentId); return c ? escapeHtml(itemDisplayName(c, placed.indexOf(c))) : '(missing character)'; })()}</p>
        <button id="socket-detach-btn" class="toolbar-btn" style="margin-bottom:0">Detach</button>
        ` : (() => {
          const characters = placed.filter((p) => p.entity && p.entity.skin && p !== selectedItem);
          if (characters.length === 0) return '<p style="color:#8592a8;font-size:11.5px;margin:2px 0">No skinned characters placed in this scene yet.</p>';
          return `
        <div class="field-triple">
          <select id="socket-attach-character">${characters.map((c) => `<option value="${c.id}">${escapeHtml(itemDisplayName(c, placed.indexOf(c)))}</option>`).join('')}</select>
          <select id="socket-attach-socket"></select>
          <button id="socket-attach-btn" class="toolbar-btn" style="margin-bottom:0">Attach</button>
        </div>`;
        })()}
      </div>
      ${selectedItem.isTrigger ? `
      <div class="field-row"><label>Trigger Volume</label>
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#c7d3ea">
          <input type="checkbox" id="f-trigger-repeat"${selectedItem.triggerRepeat !== false ? ' checked' : ''}> Repeat (fires every crossing, not just once)
        </label>
        <label style="font-size:10px;color:#66759a;margin-top:6px;display:block">Shape</label>
        <select id="f-trigger-shape">
          <option value="box"${selectedItem.triggerShape !== 'sphere' ? ' selected' : ''}>Box (matches the marker's real bounds)</option>
          <option value="sphere"${selectedItem.triggerShape === 'sphere' ? ' selected' : ''}>Sphere (radius from the marker's largest horizontal scale)</option>
        </select>
      </div>` : `
      <div class="field-row"><label>Collision</label>
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#c7d3ea">
          <input type="checkbox" id="f-solid"${entity.solid ? ' checked' : ''}> Solid (physically blocks the craft; hidden = passable)
        </label>
        ${entity.solid ? `
        <label style="font-size:10px;color:#66759a;margin-top:6px;display:block">Collider Shape</label>
        <select id="f-collider-shape">
          <option value="auto"${!selectedItem.collider ? ' selected' : ''}>Auto (matches the mesh's own scale)</option>
          <option value="box"${selectedItem.collider && selectedItem.collider.shape === 'box' ? ' selected' : ''}>Box (custom size/offset)</option>
          <option value="sphere"${selectedItem.collider && selectedItem.collider.shape === 'sphere' ? ' selected' : ''}>Sphere</option>
        </select>
        ${selectedItem.collider && selectedItem.collider.shape === 'box' ? `
        <label style="font-size:10px;color:#66759a;margin-top:4px">Size (X, Y, Z)</label>
        <div class="field-triple">
          <input type="number" id="f-collider-size-x" step="0.1" min="0.05" value="${(selectedItem.collider.size ? selectedItem.collider.size.x : entity.scale.x).toFixed(2)}">
          <input type="number" id="f-collider-size-y" step="0.1" min="0.05" value="${(selectedItem.collider.size ? selectedItem.collider.size.y : entity.scale.y).toFixed(2)}">
          <input type="number" id="f-collider-size-z" step="0.1" min="0.05" value="${(selectedItem.collider.size ? selectedItem.collider.size.z : entity.scale.z).toFixed(2)}">
        </div>` : ''}
        ${selectedItem.collider && selectedItem.collider.shape === 'sphere' ? `
        <label style="font-size:10px;color:#66759a;margin-top:4px">Radius</label>
        <input type="number" id="f-collider-radius" step="0.1" min="0.05" value="${(selectedItem.collider.radius != null ? selectedItem.collider.radius : Math.max(entity.scale.x, entity.scale.z) / 2).toFixed(2)}">` : ''}
        ${selectedItem.collider ? `
        <label style="font-size:10px;color:#66759a;margin-top:4px">Offset (X, Y, Z)</label>
        <div class="field-triple">
          <input type="number" id="f-collider-offset-x" step="0.1" value="${(selectedItem.collider.offset ? selectedItem.collider.offset.x : 0).toFixed(2)}">
          <input type="number" id="f-collider-offset-y" step="0.1" value="${(selectedItem.collider.offset ? selectedItem.collider.offset.y : 0).toFixed(2)}">
          <input type="number" id="f-collider-offset-z" step="0.1" value="${(selectedItem.collider.offset ? selectedItem.collider.offset.z : 0).toFixed(2)}">
        </div>` : ''}` : ''}
      </div>`}
      ${selectedItem.isSpawnPoint ? `
      <div class="field-row"><label>Spawn Point</label>
        ${selectedItem.isDefaultSpawn
          ? `<div style="font-size:12px;color:#3ee6ff">★ Default Player Spawn for this level</div>`
          : `<button id="set-default-spawn-btn" class="toolbar-btn" style="margin-bottom:0">★ Set as Default Player Spawn</button>`}
      </div>` : ''}
      ${selectedItem.isWaypoint ? `
      <div class="field-row"><label>Waypoint Connections</label>
        <div id="waypoint-connection-list">${(selectedItem.connections || []).map((connId) => {
          const conn = findItemById(connId);
          if (!conn) return '';
          return `<div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
            <span style="flex:1;font-size:12px;color:#c7d3ea">${escapeHtml(itemDisplayName(conn, placed.indexOf(conn)))}</span>
            <button data-remove-connection="${connId}" style="padding:2px 8px">✕</button>
          </div>`;
        }).join('') || '<p style="color:#66759a;font-size:11px;margin:2px 0">Not connected to any other Waypoint.</p>'}
        </div>
        <div style="display:flex;gap:6px">
          <select id="add-connection-select" style="flex:1">
            <option value="">Connect to...</option>
            ${placed.filter((p) => p.isWaypoint && p !== selectedItem && !(selectedItem.connections || []).includes(p.id)).map((p) => `<option value="${p.id}">${escapeHtml(itemDisplayName(p, placed.indexOf(p)))}</option>`).join('')}
          </select>
          <button id="add-connection-btn" class="toolbar-btn" style="margin-bottom:0">+ Add</button>
        </div>
      </div>` : ''}
      ${entity.skin ? `
      <div class="field-row">
        <button id="create-animated-enemy-btn" class="toolbar-btn" style="background:#2a4a6a">✨ Create Animated Enemy</button>
        <div style="font-size:10.5px;color:#66759a;margin-top:-4px">One click: AI Follow, Health, Auto-Animate, and a ranged Attack slot (damage pre-set -- still pick a Projectile Prefab afterward to make it actually fire).</div>
      </div>
      <div class="field-row"><label>Animation Clip (Wave 6 Priority C)</label>
        <select id="f-animation-clip">
          <option value="" ${entity.animationClip == null ? 'selected' : ''}>None (bind pose)</option>
          ${entity.skin.clips.map((c, i) => `<option value="${i}" ${entity.animationClip === i ? 'selected' : ''}>${escapeHtml(c.name)} (${c.duration.toFixed(2)}s)</option>`).join('')}
        </select>
        <div style="font-size:11px;color:#66759a;margin-top:4px">${entity.skin.jointCount} joints -- plays looped from t=0 the moment a clip is selected.</div>
      </div>
      <div class="field-row"><label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#c7d3ea"><input type="checkbox" id="f-character-anim-sync" ${selectedItem.characterAnimSync ? 'checked' : ''}> Auto-Animate (Wave 6 Priority M)</label>
        <div style="font-size:10.5px;color:#66759a;margin-top:3px">Picks Idle/Walk/Run by this AI character's own movement each frame, and switches to an Attack/Death clip on hit/kill -- matched by clip NAME (must contain "idle"/"walk"/"run"/"attack"/"death", case-insensitive). Requires AI movement (Follow/Patrol/Wander/Waypoint) to drive Walk/Run.</div>
      </div>
      <div class="field-row"><label>Sockets (Wave 7 Priority A)</label>
        <div id="socket-list"></div>
        ${selectedItem.assetId ? `<div class="field-triple">
          <input type="text" id="socket-new-name" placeholder="Socket name (e.g. RightHand)">
          <select id="socket-new-bone">${entity.skin.jointNames.map((n) => `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`).join('')}</select>
          <button id="socket-add-btn" class="toolbar-btn" style="margin-bottom:0">+ Add</button>
        </div>` : '<p style="color:#8592a8;font-size:11.5px;margin:2px 0">This instance has no asset reference -- Sockets need a real Asset Library entry to save against.</p>'}
        <div style="font-size:10.5px;color:#66759a;margin-top:3px">A socket is authoring metadata on this ASSET (shared by every placed instance), not a change to the imported skeleton. Attach an ordinary object to one from that object's own Inspector.</div>
      </div>
      <div class="field-row"><label>Animation Events (Wave 7 Priority B)</label>
        <div id="anim-event-list"></div>
        <button id="anim-event-add-btn" class="toolbar-btn" style="margin-top:4px">+ Add Event</button>
        <div style="font-size:10.5px;color:#66759a;margin-top:3px">Fires an action at a specific time in a specific clip (e.g. Fire Weapon exactly when the swing animation reaches its firing pose). Authored per-asset, shared by every placed instance.</div>
      </div>` : ''}
      ${selectedItem.isBillboard ? `
      <div class="field-row"><label>Billboard Mode</label>
        <select id="f-billboard-mode">
          <option value="full" ${selectedItem.billboardMode !== 'cylindrical' ? 'selected' : ''}>Full (always faces camera)</option>
          <option value="cylindrical" ${selectedItem.billboardMode === 'cylindrical' ? 'selected' : ''}>Cylindrical (stays upright)</option>
        </select>
      </div>` : ''}
      <div class="field-row"><label>Tags (comma-separated)</label>
        <input type="text" id="f-tags" placeholder="e.g. enemy, breakable" value="${escapeHtml((selectedItem.tags || []).join(', '))}">
      </div>
      <div class="field-row">
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#c7d3ea"><input type="checkbox" id="f-persist-runtime-state"${selectedItem.persistRuntimeState ? ' checked' : ''}> Persist Runtime State (Wave 7 Priority E)</label>
        <div style="font-size:10.5px;color:#66759a;margin-top:3px">Off (default): this object always resets to its authored state on Load/Play. On: its visible/destroyed/position/rotation/Health state survives Save Game -> Load Game.</div>
      </div>
      <div class="field-row">
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#c7d3ea"><input type="checkbox" id="f-carryable"${selectedItem.carryable ? ' checked' : ''}> Carryable (Wave 7 Priority J)</label>
        <div style="font-size:10.5px;color:#66759a;margin-top:3px">Lets Pick Up Object/Drop Held Object hold this in front of the Player (or in a hand Socket, Third-Person with a skinned Visual).</div>
      </div>
      <div class="field-row"><label>Object Variables (Wave 8 Priority B)</label>
        <div id="object-variable-list"></div>
        <div class="field-triple">
          <input type="text" id="objvar-new-name" placeholder="name">
          <select id="objvar-new-type"><option value="number">Number</option><option value="boolean">Boolean</option><option value="string">String</option></select>
          <button id="objvar-add-btn" class="toolbar-btn" style="margin-bottom:0">+ Add</button>
        </div>
        <div style="font-size:10.5px;color:#66759a;margin-top:3px">Per-instance state (Number/Boolean/String) -- Set/Increment/Toggle Object Variable actions default Target to this object itself, so a reusable prefab never needs a globally-unique counter name.</div>
      </div>
      <div class="field-row"><label>Behaviors</label>
        <div id="behavior-list"></div>
        <div class="field-triple">
          <select id="b-trigger">
            <option value="click">On Click</option>
            <option value="enter">On Enter</option>
            <option value="exit">On Exit</option>
            <option value="start">On Start</option>
            <option value="stay">On Stay (every frame while inside)</option>
            <option value="interact">On Interact (F / touch button, in range)</option>
          </select>
          <select id="b-action"></select>
        </div>
        <div id="b-fields"></div>
        <button id="add-behavior-btn" class="toolbar-btn" style="margin-top:6px">Add Behavior</button>
      </div>
      <div class="field-row"><label>Save as Prefab</label>
        <div style="display:flex;gap:6px">
          <input type="text" id="prefab-name-input" placeholder="Prefab name" style="flex:1" list="prefab-name-list">
          <datalist id="prefab-name-list">${prefabs.map((p) => `<option value="${escapeHtml(p.name)}">`).join('')}</datalist>
          <button id="save-prefab-btn" class="toolbar-btn" style="margin-bottom:0;white-space:nowrap">Save</button>
        </div>
        <div style="font-size:10.5px;color:#66759a;margin-top:3px">Typing an EXISTING prefab's name updates it instead of saving a duplicate.</div>
      </div>
      ${selectedItem.sourcePrefabName ? `
      <!-- Wave 6 (Priority K): Prefab Workflow 3.0 -- only shown for a
           LINKED instance (one placed from the palette/prefab list, or a
           prior Update From Prefab). Update From Prefab is a manual,
           one-way, on-demand re-sync (no automatic propagation, no
           override tracking) -- the priority's own explicit bounded scope. -->
      <div class="field-row"><label>Linked Prefab: ${escapeHtml(selectedItem.sourcePrefabName)}</label>
        <div class="field-triple">
          <button id="update-from-prefab-btn" class="toolbar-btn" style="margin-bottom:0" ${prefabs.some((p) => p.name === selectedItem.sourcePrefabName) ? '' : 'disabled title="Source prefab no longer exists"'}>⭯ Update From Prefab</button>
          <button id="update-prefab-from-this-btn" class="toolbar-btn" style="margin-bottom:0">⭱ Update Prefab From This</button>
          <button id="unlink-prefab-btn" class="toolbar-btn" style="margin-bottom:0">Unlink</button>
        </div>
      </div>
      <div class="field-row"><label>Prefab Parameters (Wave 8 Priority C)</label>
        <div id="prefab-param-def-list"></div>
        <div class="field-triple">
          <input type="text" id="param-new-name" placeholder="name (e.g. enemySpeed)">
          <select id="param-new-type"><option value="number">Number</option><option value="boolean">Boolean</option><option value="string">String</option><option value="color">Color</option><option value="prefabReference">Prefab Reference</option><option value="meshAsset">Mesh Asset</option><option value="textureAsset">Texture Asset</option><option value="audioAsset">Audio Asset</option></select>
          <button id="param-add-btn" class="toolbar-btn" style="margin-bottom:0">+ Add</button>
        </div>
        <div style="font-size:10.5px;color:#66759a;margin-top:3px">Defined once on the PREFAB (shared by every instance); each field below also binds it to a real prefab field so setting it actually does something.</div>
        <div id="prefab-param-override-list" style="margin-top:6px"></div>
      </div>` : ''}
      ${prefabs.length > 0 ? `
      <div class="field-row"><label>Replace With Prefab</label>
        <div style="display:flex;gap:6px">
          <select id="replace-with-prefab-select"><option value="">Choose a prefab...</option>${prefabs.map((p, i) => `<option value="${i}">${escapeHtml(p.name)}</option>`).join('')}</select>
          <button id="replace-with-prefab-btn" class="toolbar-btn" style="margin-bottom:0;white-space:nowrap">Replace</button>
        </div>
      </div>` : ''}
      <div class="field-triple">
        <button id="duplicate-btn" class="toolbar-btn" style="margin-bottom:0">Duplicate</button>
        <button id="delete-btn" style="margin-bottom:0">Delete Object</button>
      </div>
    `;
    for (const id of ['f-x', 'f-y', 'f-z', 'f-rotation-x', 'f-rotation-y', 'f-rotation-z', 'f-scale-x', 'f-scale-y', 'f-scale-z', 'f-color']) {
      document.getElementById(id).onfocus = () => pushUndo();
    }
    if (entity.skin) {
      document.getElementById('f-animation-clip').onchange = (e) => {
        pushUndo();
        entity.animationClip = e.target.value === '' ? null : Number(e.target.value);
      };
      document.getElementById('f-character-anim-sync').onchange = (e) => {
        pushUndo();
        selectedItem.characterAnimSync = e.target.checked;
        selectedItem._animState = undefined; // force a fresh state pick on the next locomotion tick rather than trusting a stale one from before this was enabled
      };
      // Wave 6B (Priority I): "Create Animated Enemy" -- one click fills in
      // ordinary editor data (AI Follow, Health, Auto-Animate, an Attack
      // slot with damage pre-set) using the exact same fields/defaults an
      // author would otherwise set by hand through this same Inspector --
      // no hidden runtime, nothing that isn't also a normal saved field.
      // Projectile Prefab is deliberately left for the author to pick
      // afterward (a preset can't guess which prefab they want to fire).
      document.getElementById('create-animated-enemy-btn').onclick = () => {
        pushUndo();
        if (!entity.ai) entity.ai = { type: 'follow', speed: 3, radius: 10, base: entity.position.clone(), targetId: null };
        entity.ai.attackEnabled = true;
        entity.ai.attackRadius = entity.ai.attackRadius || 8;
        entity.ai.attackCooldown = entity.ai.attackCooldown || 1.5;
        entity.ai.attackDamage = entity.ai.attackDamage || 10;
        ensureObjectHealthInit(selectedItem);
        selectedItem.characterAnimSync = true;
        selectedItem._animState = undefined;
        renderInspector();
        showStatus('✨ Animated Enemy created -- pick a Projectile Prefab to make its attack fire');
      };
      renderSocketList(selectedItem);
      renderAnimationEventList(selectedItem);
    }
    if (selectedItem.isBillboard) {
      document.getElementById('f-billboard-mode').onchange = (e) => {
        pushUndo();
        selectedItem.billboardMode = e.target.value;
      };
    }
    document.getElementById('f-x').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) entity.position.x = v; };
    document.getElementById('f-y').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) entity.position.y = v; };
    document.getElementById('f-z').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) entity.position.z = v; };
    // Full XYZ rotation fields (Wave 5) -- each field's oninput reads ALL
    // THREE current field values (not just its own) and rebuilds the whole
    // orientation via Quat.fromEuler in one shot, rather than trying to
    // "adjust just one axis" of an already-composed quaternion (which has
    // no single correct meaning once pitch/roll are involved -- there's no
    // way to change "the yaw" of an arbitrary quaternion in isolation
    // without first deciding an Euler order, which is exactly what
    // fromEuler already commits to). This is what keeps editing one field
    // from unexpectedly destroying whatever the OTHER two fields already
    // held, e.g. typing a new Y value must not silently zero out X/Z.
    function applyRotationFields() {
      const x = parseFloat(document.getElementById('f-rotation-x').value) || 0;
      const y = parseFloat(document.getElementById('f-rotation-y').value) || 0;
      const z = parseFloat(document.getElementById('f-rotation-z').value) || 0;
      entity.quaternion = Opus.Quat.fromEuler(x * Math.PI / 180, y * Math.PI / 180, z * Math.PI / 180);
    }
    document.getElementById('f-rotation-x').oninput = applyRotationFields;
    document.getElementById('f-rotation-y').oninput = applyRotationFields;
    document.getElementById('f-rotation-z').oninput = applyRotationFields;
    // Per-axis scale (a wide thin wall, a tall thin door -- any non-uniform
    // shape) was previously only reachable through Custom Script or direct
    // property access, never through the inspector; the shipped uniform-only
    // field couldn't produce the Temple Switch Puzzle's own Door shape.
    // "Make Uniform" is a convenience for the common case, not a separate
    // mode -- the three axes stay independently editable either way.
    for (const axis of ['x', 'y', 'z']) {
      document.getElementById(`f-scale-${axis}`).oninput = (e) => {
        const v = parseFloat(e.target.value);
        if (!Number.isNaN(v) && v > 0) entity.scale[axis] = v;
      };
    }
    document.getElementById('f-scale-uniform-btn').onclick = () => {
      pushUndo();
      entity.scale.set(entity.scale.x, entity.scale.x, entity.scale.x);
      renderInspector();
    };
    document.getElementById('f-color').oninput = (e) => {
      const [r, g, b] = hexToRgb(e.target.value);
      entity.color[0] = r; entity.color[1] = g; entity.color[2] = b;
    };
    document.getElementById('f-texture').onchange = (e) => {
      pushUndo();
      const texId = e.target.value;
      if (!texId) {
        entity.texture = null;
        selectedItem.textureAssetId = undefined;
      } else {
        const asset = findTextureAssetById(texId);
        if (asset) { selectedItem.textureAssetId = asset.id; applyTextureToEntity(entity, asset); }
      }
      renderInspector();
    };
    const uvScaleX = document.getElementById('f-uv-scale-x');
    if (uvScaleX) {
      entity.uvScale = entity.uvScale || [1, 1];
      entity.uvOffset = entity.uvOffset || [0, 0];
      uvScaleX.oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) entity.uvScale[0] = v; };
      document.getElementById('f-uv-scale-y').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) entity.uvScale[1] = v; };
      document.getElementById('f-uv-offset-x').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) entity.uvOffset[0] = v; };
      document.getElementById('f-uv-offset-y').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) entity.uvOffset[1] = v; };
    }
    document.getElementById('f-unlit').onchange = (e) => { pushUndo(); entity.unlit = e.target.checked; };
    document.getElementById('f-alpha').oninput = (e) => { entity.alpha = parseFloat(e.target.value); };
    document.getElementById('f-emissive-color').oninput = (e) => { entity.emissiveColor = hexToRgb(e.target.value); };
    document.getElementById('f-emissive-intensity').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= 0) entity.emissiveIntensity = v; };
    document.getElementById('add-anim-clip-btn').onclick = () => openAnimationEditor(selectedItem, null);
    document.querySelectorAll('[data-edit-clip]').forEach((btn) => { btn.onclick = () => openAnimationEditor(selectedItem, Number(btn.dataset.editClip)); });
    document.querySelectorAll('[data-delete-clip]').forEach((btn) => {
      btn.onclick = () => { pushUndo(); selectedItem.animationClips.splice(Number(btn.dataset.deleteClip), 1); renderInspector(); };
    });
    // Wave 7 (Priority A/Section 7): Attach to Socket wiring.
    const socketDetachBtn = document.getElementById('socket-detach-btn');
    if (socketDetachBtn) {
      socketDetachBtn.onclick = () => { pushUndo(); detachFromSocket(selectedItem); renderInspector(); showStatus('Detached from socket'); };
    }
    const socketAttachCharSelect = document.getElementById('socket-attach-character');
    if (socketAttachCharSelect) {
      const socketAttachSocketSelect = document.getElementById('socket-attach-socket');
      const refreshSocketOptions = () => {
        const charItem = findItemById(socketAttachCharSelect.value);
        const asset = charItem && findAssetById(charItem.assetId);
        const sockets = (asset && asset.sockets) || [];
        socketAttachSocketSelect.innerHTML = sockets.length
          ? sockets.map((s) => `<option value="${escapeHtml(s.name)}">${escapeHtml(s.name)}</option>`).join('')
          : '<option value="">(no sockets authored on this character)</option>';
      };
      refreshSocketOptions();
      socketAttachCharSelect.onchange = refreshSocketOptions;
      document.getElementById('socket-attach-btn').onclick = () => {
        const charItem = findItemById(socketAttachCharSelect.value);
        const socketName = socketAttachSocketSelect.value;
        if (!charItem || !socketName) { showStatus('Pick a character with at least one authored socket first'); return; }
        pushUndo();
        if (attachToSocket(selectedItem, charItem, socketName)) {
          renderInspector();
          showStatus(`Attached to "${socketName}"`);
        }
      };
    }
    if (selectedItem.isTrigger) {
      document.getElementById('f-trigger-repeat').onchange = (e) => { pushUndo(); selectedItem.triggerRepeat = e.target.checked; };
      document.getElementById('f-trigger-shape').onchange = (e) => { pushUndo(); selectedItem.triggerShape = e.target.value === 'sphere' ? 'sphere' : undefined; };
    } else {
      document.getElementById('f-solid').onchange = (e) => { pushUndo(); entity.solid = e.target.checked; renderInspector(); };
      const shapeSelect = document.getElementById('f-collider-shape');
      if (shapeSelect) {
        shapeSelect.onchange = (e) => {
          pushUndo();
          if (e.target.value === 'auto') selectedItem.collider = undefined;
          else if (e.target.value === 'box') selectedItem.collider = { shape: 'box', size: { x: entity.scale.x, y: entity.scale.y, z: entity.scale.z }, offset: { x: 0, y: 0, z: 0 } };
          else selectedItem.collider = { shape: 'sphere', radius: Math.max(entity.scale.x, entity.scale.z) / 2, offset: { x: 0, y: 0, z: 0 } };
          renderInspector();
        };
        const sizeX = document.getElementById('f-collider-size-x');
        if (sizeX) {
          const syncSize = () => {
            const x = parseFloat(document.getElementById('f-collider-size-x').value) || 0.1;
            const y = parseFloat(document.getElementById('f-collider-size-y').value) || 0.1;
            const z = parseFloat(document.getElementById('f-collider-size-z').value) || 0.1;
            selectedItem.collider.size = { x: Math.max(0.05, x), y: Math.max(0.05, y), z: Math.max(0.05, z) };
          };
          sizeX.onchange = () => { pushUndo(); syncSize(); };
          document.getElementById('f-collider-size-y').onchange = () => { pushUndo(); syncSize(); };
          document.getElementById('f-collider-size-z').onchange = () => { pushUndo(); syncSize(); };
        }
        const radiusInput = document.getElementById('f-collider-radius');
        if (radiusInput) radiusInput.onchange = (e) => { pushUndo(); selectedItem.collider.radius = Math.max(0.05, parseFloat(e.target.value) || 0.1); };
        const offsetX = document.getElementById('f-collider-offset-x');
        if (offsetX) {
          const syncOffset = () => {
            const x = parseFloat(document.getElementById('f-collider-offset-x').value) || 0;
            const y = parseFloat(document.getElementById('f-collider-offset-y').value) || 0;
            const z = parseFloat(document.getElementById('f-collider-offset-z').value) || 0;
            selectedItem.collider.offset = { x, y, z };
          };
          offsetX.onchange = () => { pushUndo(); syncOffset(); };
          document.getElementById('f-collider-offset-y').onchange = () => { pushUndo(); syncOffset(); };
          document.getElementById('f-collider-offset-z').onchange = () => { pushUndo(); syncOffset(); };
        }
      }
    }
    document.getElementById('f-tags').onchange = (e) => {
      pushUndo();
      selectedItem.tags = e.target.value.split(',').map((t) => t.trim()).filter(Boolean);
    };
    document.getElementById('f-persist-runtime-state').onchange = (e) => {
      pushUndo();
      selectedItem.persistRuntimeState = e.target.checked;
    };
    document.getElementById('f-carryable').onchange = (e) => {
      pushUndo();
      selectedItem.carryable = e.target.checked;
    };
    renderObjectVariableList(selectedItem);
    // AI type/speed/radius apply immediately to entity.ai (read directly by
    // the app.onUpdate steering loop) -- radius is meaningless for Follow
    // (there's no fixed base to circle/drift around), so it's disabled
    // rather than removed, keeping the field layout stable while switching
    // types.
    const aiTypeSelect = document.getElementById('f-ai-type');
    const aiParamsEl = document.getElementById('f-ai-params');
    const aiSpeedInput = document.getElementById('f-ai-speed');
    const aiRadiusInput = document.getElementById('f-ai-radius');
    aiTypeSelect.onchange = () => {
      pushUndo();
      const type = aiTypeSelect.value;
      if (!type) {
        entity.ai = null;
      } else {
        entity.ai = {
          type,
          speed: parseFloat(aiSpeedInput.value) || 3,
          radius: parseFloat(aiRadiusInput.value) || 5,
          base: entity.position.clone(),
          loop: type === 'patrolRoute' ? true : undefined,
        };
      }
      renderInspector(); // Target field only shows for Follow/Face Target -- needs a full re-render to appear/disappear
    };
    aiSpeedInput.oninput = () => { if (entity.ai) entity.ai.speed = parseFloat(aiSpeedInput.value) || 3; };
    aiRadiusInput.oninput = () => { if (entity.ai) entity.ai.radius = parseFloat(aiRadiusInput.value) || 5; };
    const aiTargetSelect = document.getElementById('f-ai-target');
    if (aiTargetSelect) {
      aiTargetSelect.onchange = () => { if (entity.ai) entity.ai.targetId = aiTargetSelect.value || undefined; };
    }
    if (entity.ai && entity.ai.type === 'patrolRoute') {
      // Editing any of the route's own fields invalidates the cached
      // resolved-id list (see the patrolRoute tick above) -- otherwise
      // retyping the waypoint list mid-Play would keep patrolling the OLD
      // route until the next full Stop/Play cycle happened to clear it.
      const invalidateRoute = () => { delete entity.ai.resolvedWaypointIds; };
      document.getElementById('f-ai-patrol-speed').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) entity.ai.speed = v; };
      document.getElementById('f-ai-waypoints').oninput = (e) => { entity.ai.waypointNames = e.target.value; invalidateRoute(); };
      document.getElementById('f-ai-loop').onchange = (e) => { entity.ai.loop = e.target.checked; };
      document.getElementById('f-ai-pingpong').onchange = (e) => { entity.ai.pingpong = e.target.checked; invalidateRoute(); };
    }
    if (entity.ai && entity.ai.type === 'followPath') {
      const pathSel = document.getElementById('f-ai-path');
      if (pathSel) pathSel.onchange = () => { entity.ai.pathId = pathSel.value || undefined; delete entity.ai._pathLengthFor; };
      document.getElementById('f-ai-path-speed').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) entity.ai.speed = v; };
      document.getElementById('f-ai-path-pingpong').onchange = (e) => { entity.ai.pingpong = e.target.checked; };
    }
    const aiAttackEnabled = document.getElementById('f-ai-attack-enabled');
    if (aiAttackEnabled) {
      aiAttackEnabled.onchange = (e) => { entity.ai.attackEnabled = e.target.checked; renderInspector(); };
      const attackPrefabSel = document.getElementById('f-ai-attack-prefab');
      if (attackPrefabSel) attackPrefabSel.onchange = (e) => { entity.ai.attackPrefab = e.target.value; };
      const attackRadius = document.getElementById('f-ai-attack-radius');
      if (attackRadius) {
        attackRadius.oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) entity.ai.attackRadius = v; };
        document.getElementById('f-ai-attack-cooldown').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) entity.ai.attackCooldown = v; };
        document.getElementById('f-ai-attack-damage').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= 0) entity.ai.attackDamage = v; };
      }
    }
    if (entity.ai) {
      const smToggle = document.getElementById('f-ai-statemachine-mode');
      if (smToggle) {
        smToggle.onchange = (e) => {
          pushUndo();
          entity.ai.mode = e.target.checked ? 'stateMachine' : 'simple';
          if (entity.ai.mode === 'stateMachine' && !entity.ai.states) entity.ai.states = [];
          renderInspector();
        };
      }
      if (entity.ai.mode === 'stateMachine') renderAiStateList(selectedItem);
    }
    const addConnectionBtn = document.getElementById('add-connection-btn');
    if (addConnectionBtn) {
      addConnectionBtn.onclick = () => {
        const otherId = document.getElementById('add-connection-select').value;
        if (!otherId) return;
        const other = findItemById(otherId);
        if (!other) return;
        pushUndo();
        // Bidirectional by default (both edges added together) -- one-way
        // connections weren't worth the extra authoring UI this pass, per
        // the spec's own "only if easy" gate on that specific sub-feature.
        selectedItem.connections = selectedItem.connections || [];
        other.connections = other.connections || [];
        if (!selectedItem.connections.includes(otherId)) selectedItem.connections.push(otherId);
        if (!other.connections.includes(selectedItem.id)) other.connections.push(selectedItem.id);
        renderInspector();
        showStatus(`Connected to "${itemDisplayName(other, placed.indexOf(other))}"`);
      };
      document.querySelectorAll('[data-remove-connection]').forEach((btn) => {
        btn.onclick = () => {
          const otherId = btn.dataset.removeConnection;
          const other = findItemById(otherId);
          pushUndo();
          selectedItem.connections = (selectedItem.connections || []).filter((id) => id !== otherId);
          if (other) other.connections = (other.connections || []).filter((id) => id !== selectedItem.id);
          renderInspector();
        };
      });
    }
    const setDefaultSpawnBtn = document.getElementById('set-default-spawn-btn');
    if (setDefaultSpawnBtn) {
      setDefaultSpawnBtn.onclick = () => {
        pushUndo();
        for (const p of placed) { if (p.isSpawnPoint) p.isDefaultSpawn = false; }
        selectedItem.isDefaultSpawn = true;
        renderInspector();
        renderSceneList();
        showStatus('Default Player Spawn updated');
      };
    }
    document.getElementById('delete-btn').onclick = deleteSelected;
    document.getElementById('duplicate-btn').onclick = duplicateSelected;
    document.getElementById('save-prefab-btn').onclick = () => {
      const nameInput = document.getElementById('prefab-name-input');
      const name = nameInput.value.trim() || itemDisplayName(selectedItem, placed.indexOf(selectedItem));
      const { payload, memberCount } = buildPrefabPayload(selectedItem, name);
      // Wave 6 (Priority K): typing an EXISTING prefab's name now UPDATES
      // that prefab in place (overwriting its stored record/records/rootId)
      // instead of pushing a second entry sharing the same name -- the
      // "Update Prefab" half of the workflow. A genuinely new name still
      // pushes a fresh entry, byte-identical to the pre-Wave-6 behavior.
      const existingIndex = prefabs.findIndex((p) => p.name === name);
      if (existingIndex !== -1) {
        prefabs[existingIndex] = payload;
        showStatus(`Updated prefab "${name}"${memberCount > 1 ? ` (${memberCount} objects)` : ''}`);
      } else {
        prefabs.push(payload);
        showStatus(`Saved prefab "${name}"${memberCount > 1 ? ` (${memberCount} objects)` : ''}`);
      }
      selectedItem.sourcePrefabName = name; // this instance is now (or still) linked to the prefab it was just saved/updated from
      savePrefabs();
      renderPrefabPalette();
      nameInput.value = '';
      renderInspector();
    };
    if (selectedItem.sourcePrefabName) {
      const updateFromBtn = document.getElementById('update-from-prefab-btn');
      if (updateFromBtn) updateFromBtn.onclick = () => updateInstanceFromPrefab(selectedItem);
      document.getElementById('update-prefab-from-this-btn').onclick = () => {
        const { payload, memberCount } = buildPrefabPayload(selectedItem, selectedItem.sourcePrefabName);
        const existingIndex = prefabs.findIndex((p) => p.name === selectedItem.sourcePrefabName);
        if (existingIndex !== -1) prefabs[existingIndex] = payload; else prefabs.push(payload);
        savePrefabs();
        renderPrefabPalette();
        showStatus(`Updated prefab "${selectedItem.sourcePrefabName}"${memberCount > 1 ? ` (${memberCount} objects)` : ''} from this object`);
      };
      document.getElementById('unlink-prefab-btn').onclick = () => {
        pushUndo();
        selectedItem.sourcePrefabName = undefined;
        renderInspector();
        showStatus('Unlinked from prefab (this instance is now independent)');
      };
      renderPrefabParamPanel(selectedItem);
    }
    const replaceBtn = document.getElementById('replace-with-prefab-btn');
    if (replaceBtn) {
      replaceBtn.onclick = () => {
        const idx = document.getElementById('replace-with-prefab-select').value;
        if (idx === '') return;
        replaceItemWithPrefab(selectedItem, prefabs[Number(idx)]);
      };
    }
    renderBehaviorList(selectedItem);
    // Action options and their param fields both come from ACTION_TYPES
    // ('graph' appended manually, since it's the one action outside that
    // table) -- the same dynamic-field pattern the Node Graph node UI uses,
    // so a new action type gets a working Add Behavior form for free.
    const actionSelect = document.getElementById('b-action');
    actionSelect.innerHTML = Object.entries(ACTION_TYPES).map(([type, def]) => `<option value="${type}">${escapeHtml(def.label)}</option>`).join('')
      + '<option value="graph">Node Graph</option>'
      + '<option value="dialogueTree">Show Dialogue (Branching)</option>';
    function renderAddBehaviorFields() {
      const action = actionSelect.value;
      const fieldsEl = document.getElementById('b-fields');
      if (action === 'graph') {
        fieldsEl.innerHTML = '<p style="color:#8592a8;font-size:11.5px;margin:4px 0">Opens the Node Graph editor on Add.</p>';
        return;
      }
      if (action === 'dialogueTree') {
        fieldsEl.innerHTML = '<p style="color:#8592a8;font-size:11.5px;margin:4px 0">Opens the Dialogue editor on Add.</p>';
        return;
      }
      const def = ACTION_TYPES[action];
      fieldsEl.innerHTML = def.fields.length
        ? def.fields.map((f) => `<div class="field-row"><label>${escapeHtml(f.label || f.key)}</label>${renderActionFieldInput(f, undefined)}</div>`).join('')
        : '<p style="color:#8592a8;font-size:11.5px;margin:4px 0">No parameters.</p>';
    }
    actionSelect.onchange = renderAddBehaviorFields;
    renderAddBehaviorFields();
    document.getElementById('add-behavior-btn').onclick = () => {
      const action = actionSelect.value;
      if (action === 'graph') {
        // Node Graph has no param fields -- it opens its own editor instead,
        // and the behavior is only actually added once the user saves a
        // graph there (Cancel adds nothing), unlike every other action.
        openGraphEditor(selectedItem, null, document.getElementById('b-trigger').value);
        return;
      }
      if (action === 'dialogueTree') {
        // Same "opens its own editor, adds nothing until Saved there" shape
        // as Node Graph above.
        openDialogueEditor(selectedItem, null, document.getElementById('b-trigger').value);
        return;
      }
      const def = ACTION_TYPES[action];
      const params = {};
      document.querySelectorAll('#b-fields [data-field]').forEach((input) => {
        const f = def.fields.find((fld) => fld.key === input.dataset.field);
        if (!f) return;
        params[f.key] = f.type === 'checkbox' ? input.checked : f.type === 'number' ? (parseFloat(input.value) || 0) : input.value;
      });
      pushUndo();
      const behavior = { trigger: document.getElementById('b-trigger').value, action };
      // Legacy actions keep the flat `.param` string shape existing saved
      // projects already use; newer actions persist as `.params` (object).
      if (def.legacy) { if (def.legacyParam) behavior.param = params[def.legacyParam] || ''; }
      else behavior.params = params;
      selectedItem.behaviors.push(behavior);
      renderBehaviorList(selectedItem);
    };
    return;
  }

  if (selectedItem.kind === 'terrain') {
    const opts = selectedItem.options;
    inspectorBody.innerHTML = `
      <div class="field-row"><label>Seed</label><input type="number" id="f-seed" step="1" value="${opts.seed}"></div>
      <div class="field-row"><label>Size</label><input type="number" id="f-size" step="1" min="4" value="${opts.size}"></div>
      <div class="field-row"><label>Radius</label><input type="number" id="f-radius" step="0.5" min="1" value="${opts.radius}"></div>
      <div class="field-row"><label>Sculpt</label>
        <button id="sculpt-toggle-btn" class="toolbar-btn" style="margin-bottom:6px">${sculptMode ? '■ Stop Sculpting' : '⛰ Start Sculpting'}</button>
        <div class="field-triple">
          <button id="sculpt-raise-btn" class="toolbar-btn${sculptSettings.brush === 'raise' ? ' active' : ''}" style="margin-bottom:0">Raise</button>
          <button id="sculpt-lower-btn" class="toolbar-btn${sculptSettings.brush === 'lower' ? ' active' : ''}" style="margin-bottom:0">Lower</button>
          <button id="sculpt-flatten-btn" class="toolbar-btn${sculptSettings.brush === 'flatten' ? ' active' : ''}" style="margin-bottom:0">Flatten</button>
        </div>
        <div class="field-triple">
          <button id="sculpt-smooth-btn" class="toolbar-btn${sculptSettings.brush === 'smooth' ? ' active' : ''}" style="margin-bottom:0">Smooth</button>
          <input type="number" id="sculpt-radius" step="0.5" min="0.5" value="${sculptSettings.radius}" title="Brush Radius" placeholder="Radius">
          <input type="number" id="sculpt-strength" step="0.1" min="0.05" max="2" value="${sculptSettings.strength}" title="Brush Strength" placeholder="Strength">
        </div>
        ${opts.heightEdits ? `<button id="sculpt-reset-btn" class="toolbar-btn" style="margin-top:6px">Reset Sculpting to Procedural</button>` : ''}
      </div>
      <div class="field-row"><label>Paint</label>
        <button id="paint-toggle-btn" class="toolbar-btn" style="margin-bottom:6px">${paintMode ? '■ Stop Painting' : '🖌 Start Painting'}</button>
        <div id="paint-layer-list"></div>
        ${(opts.paintEdits ? opts.paintEdits.layers.length : 2) < PAINT_MAX_LAYERS ? `<button id="paint-add-layer-btn" class="toolbar-btn" style="margin-bottom:6px">+ Add Layer</button>` : ''}
        <div class="field-triple">
          <input type="number" id="paint-radius" step="0.5" min="0.5" value="${paintSettings.radius}" title="Brush Radius" placeholder="Radius">
          <input type="number" id="paint-strength" step="0.1" min="0.05" max="2" value="${paintSettings.strength}" title="Brush Strength" placeholder="Strength">
          <select id="paint-automask" title="Slope Automask">
            <option value="off" ${paintSettings.automask === 'off' ? 'selected' : ''}>No automask</option>
            <option value="flat" ${paintSettings.automask === 'flat' ? 'selected' : ''}>Favor flat ground</option>
            <option value="steep" ${paintSettings.automask === 'steep' ? 'selected' : ''}>Favor steep slopes</option>
          </select>
        </div>
        ${opts.paintEdits ? `<button id="paint-reset-btn" class="toolbar-btn" style="margin-top:6px">Reset Painting to Procedural</button>` : ''}
      </div>
      <div class="field-triple">
        <button id="duplicate-btn" class="toolbar-btn" style="margin-bottom:0">Duplicate</button>
        <button id="delete-btn" style="margin-bottom:0">Delete Terrain</button>
      </div>
    `;
    const regenerate = (patch) => { pushUndo(); regenerateTerrain(selectedItem, patch); };
    document.getElementById('f-seed').onchange = (e) => regenerate({ seed: parseFloat(e.target.value) || 0 });
    document.getElementById('f-size').onchange = (e) => { const v = parseFloat(e.target.value); if (v >= 4) regenerate({ size: v }); };
    document.getElementById('f-radius').onchange = (e) => { const v = parseFloat(e.target.value); if (v >= 1) regenerate({ radius: v }); };
    document.getElementById('sculpt-toggle-btn').onclick = () => { sculptMode = !sculptMode; if (sculptMode) paintMode = false; renderInspector(); showStatus(sculptMode ? 'Sculpt mode on -- drag on the terrain to sculpt' : 'Sculpt mode off'); };
    document.getElementById('sculpt-raise-btn').onclick = () => { sculptSettings.brush = 'raise'; renderInspector(); };
    document.getElementById('sculpt-lower-btn').onclick = () => { sculptSettings.brush = 'lower'; renderInspector(); };
    document.getElementById('sculpt-flatten-btn').onclick = () => { sculptSettings.brush = 'flatten'; renderInspector(); };
    document.getElementById('sculpt-smooth-btn').onclick = () => { sculptSettings.brush = 'smooth'; renderInspector(); };
    document.getElementById('sculpt-radius').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) sculptSettings.radius = v; };
    document.getElementById('sculpt-strength').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) sculptSettings.strength = v; };
    const resetBtn = document.getElementById('sculpt-reset-btn');
    if (resetBtn) resetBtn.onclick = () => { pushUndo(); delete opts.heightEdits; regenerateTerrain(selectedItem); renderInspector(); showStatus('Sculpting reset to procedural terrain'); };
    // Paint layer rows -- built here (not in the template literal above) so
    // each row's own color swatch <input type="color"> and Select button
    // can be wired without hand-building a second escaping/serialization
    // path for per-layer state inside one big template string.
    const paintEdits = opts.paintEdits;
    const layerListEl = document.getElementById('paint-layer-list');
    if (paintEdits) {
      // Wave 6B (Priority D): a Texture dropdown (None + every Texture
      // Asset) and a UV Scale (tiling) field per layer, right alongside the
      // existing color swatch -- a layer with no texture assigned keeps
      // rendering its flat authored color exactly as before this priority.
      layerListEl.innerHTML = paintEdits.layers.map((layer, i) => `
        <div style="margin-bottom:6px;padding-bottom:6px;${i < paintEdits.layers.length - 1 ? 'border-bottom:1px solid var(--border-color,#333)' : ''}">
          <div class="field-triple" style="align-items:center;margin-bottom:4px">
            <button data-paint-layer="${i}" class="toolbar-btn${paintSettings.activeLayer === i ? ' active' : ''}" style="margin-bottom:0;text-align:left">${paintSettings.activeLayer === i ? '● ' : ''}${escapeHtml(layer.name)}</button>
            <input type="color" data-paint-color="${i}" value="${rgbToHex(layer.color)}" title="Layer color" style="padding:0;height:28px">
          </div>
          <div class="field-triple" style="align-items:center">
            <select data-paint-texture="${i}" title="Layer texture" style="grid-column:span 2">
              <option value="">No texture (flat color)</option>
              ${textureAssets.map((t) => `<option value="${t.id}"${layer.textureAssetId === t.id ? ' selected' : ''}>${escapeHtml(t.name)}</option>`).join('')}
            </select>
            <input type="number" data-paint-uvscale="${i}" step="0.5" min="0.5" value="${layer.uvScale || 4}" title="Tile size (world units per texture repeat)" placeholder="Tile" ${layer.textureAssetId ? '' : 'disabled'}>
          </div>
        </div>`).join('');
      layerListEl.querySelectorAll('[data-paint-layer]').forEach((btn) => {
        btn.onclick = () => { paintSettings.activeLayer = Number(btn.dataset.paintLayer); renderInspector(); };
      });
      layerListEl.querySelectorAll('[data-paint-color]').forEach((input) => {
        input.oninput = () => {
          pushUndo();
          paintEdits.layers[Number(input.dataset.paintColor)].color = hexToRgb(input.value);
          regenerateTerrain(selectedItem);
        };
      });
      layerListEl.querySelectorAll('[data-paint-texture]').forEach((select) => {
        select.onchange = () => {
          pushUndo();
          const layer = paintEdits.layers[Number(select.dataset.paintTexture)];
          layer.textureAssetId = select.value || undefined;
          if (layer.textureAssetId && !layer.uvScale) layer.uvScale = 4;
          syncTerrainLayerTextures(selectedItem);
          renderInspector();
        };
      });
      layerListEl.querySelectorAll('[data-paint-uvscale]').forEach((input) => {
        input.onchange = () => {
          const v = parseFloat(input.value);
          if (!(v > 0)) return;
          pushUndo();
          paintEdits.layers[Number(input.dataset.paintUvscale)].uvScale = v;
        };
      });
    }
    const addLayerBtn = document.getElementById('paint-add-layer-btn');
    if (addLayerBtn) addLayerBtn.onclick = () => { pushUndo(); addPaintLayer(selectedItem); regenerateTerrain(selectedItem); renderInspector(); };
    document.getElementById('paint-toggle-btn').onclick = () => { paintMode = !paintMode; if (paintMode) sculptMode = false; renderInspector(); showStatus(paintMode ? 'Paint mode on -- drag on the terrain to paint' : 'Paint mode off'); };
    document.getElementById('paint-radius').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) paintSettings.radius = v; };
    document.getElementById('paint-strength').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) paintSettings.strength = v; };
    document.getElementById('paint-automask').onchange = (e) => { paintSettings.automask = e.target.value; };
    const paintResetBtn = document.getElementById('paint-reset-btn');
    if (paintResetBtn) paintResetBtn.onclick = () => { pushUndo(); delete opts.paintEdits; regenerateTerrain(selectedItem); renderInspector(); showStatus('Painting reset to procedural terrain'); };
    document.getElementById('delete-btn').onclick = deleteSelected;
    document.getElementById('duplicate-btn').onclick = duplicateSelected;
    return;
  }

  if (selectedItem.kind === 'water') {
    const opts = selectedItem.options;
    inspectorBody.innerHTML = `
      <div class="field-row"><label>Size</label><input type="number" id="f-size" step="1" min="4" value="${opts.size}"></div>
      <div class="field-triple">
        <button id="duplicate-btn" class="toolbar-btn" style="margin-bottom:0">Duplicate</button>
        <button id="delete-btn" style="margin-bottom:0">Delete Water</button>
      </div>
    `;
    document.getElementById('f-size').onchange = (e) => {
      const v = parseFloat(e.target.value);
      if (v < 4) return;
      pushUndo();
      app.removeWater(selectedItem.handle);
      opts.size = v;
      selectedItem.handle = app.createWater(opts);
    };
    document.getElementById('delete-btn').onclick = deleteSelected;
    document.getElementById('duplicate-btn').onclick = duplicateSelected;
  }

  if (selectedItem.kind === 'emitter') {
    const handle = selectedItem.handle;
    // Every field mutates the live ParticleEmitter instance directly
    // (no remove/recreate the way Terrain/Water need for their baked
    // heightfield/wave geometry) -- rate/color/life/etc. are plain
    // instance fields `update()`/`appendRenderData()` already read fresh
    // every frame, so a change is visible immediately, in both edit and Play.
    inspectorBody.innerHTML = `
      <div class="field-row"><label>Preset</label>
        <select id="f-emitter-preset">
          <option value="">(custom)</option>
          ${Object.keys(PARTICLE_PRESETS).map((name) => `<option value="${name}">${name}</option>`).join('')}
        </select>
      </div>
      <div class="field-row"><label>Position</label>
        <div class="field-triple">
          <input type="number" id="f-x" step="0.1" value="${handle.position.x.toFixed(2)}">
          <input type="number" id="f-y" step="0.1" value="${handle.position.y.toFixed(2)}">
          <input type="number" id="f-z" step="0.1" value="${handle.position.z.toFixed(2)}">
        </div>
      </div>
      <div class="field-row"><label>Color</label>
        <input type="color" id="f-color" value="${rgbToHex(handle.color)}">
      </div>
      <div class="field-row"><label>Rate (particles/sec) / Spread</label>
        <div class="field-triple">
          <input type="number" id="f-rate" step="1" min="0" value="${handle.rate}">
          <input type="number" id="f-spread" step="0.1" min="0" value="${handle.spread}">
        </div>
      </div>
      <div class="field-row"><label>Life (min / max seconds)</label>
        <div class="field-triple">
          <input type="number" id="f-life-min" step="0.1" min="0.05" value="${handle.life[0]}">
          <input type="number" id="f-life-max" step="0.1" min="0.05" value="${handle.life[1]}">
        </div>
      </div>
      <div class="field-row"><label>Rise Speed (min / max)</label>
        <div class="field-triple">
          <input type="number" id="f-rise-min" step="0.1" value="${handle.riseSpeed[0]}">
          <input type="number" id="f-rise-max" step="0.1" value="${handle.riseSpeed[1]}">
        </div>
      </div>
      <div class="field-row"><label>Gravity</label>
        <input type="number" id="f-gravity" step="0.05" value="${handle.gravity}">
      </div>
      <div class="field-triple">
        <button id="duplicate-btn" class="toolbar-btn" style="margin-bottom:0">Duplicate</button>
        <button id="delete-btn" style="margin-bottom:0">Delete Emitter</button>
      </div>
    `;
    for (const id of ['f-x', 'f-y', 'f-z', 'f-color', 'f-rate', 'f-spread', 'f-life-min', 'f-life-max', 'f-rise-min', 'f-rise-max', 'f-gravity']) {
      document.getElementById(id).onfocus = () => pushUndo();
    }
    document.getElementById('f-x').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { handle.position.x = v; selectedItem.options.position = handle.position; } };
    document.getElementById('f-y').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { handle.position.y = v; selectedItem.options.position = handle.position; } };
    document.getElementById('f-z').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { handle.position.z = v; selectedItem.options.position = handle.position; } };
    document.getElementById('f-color').oninput = (e) => { handle.color = hexToRgb(e.target.value); selectedItem.options.color = handle.color; };
    document.getElementById('f-rate').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= 0) { handle.rate = v; selectedItem.options.rate = v; } };
    document.getElementById('f-spread').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= 0) { handle.spread = v; selectedItem.options.spread = v; } };
    document.getElementById('f-life-min').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0 && v <= handle.life[1]) { handle.life = [v, handle.life[1]]; selectedItem.options.life = handle.life; } };
    document.getElementById('f-life-max').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= handle.life[0]) { handle.life = [handle.life[0], v]; selectedItem.options.life = handle.life; } };
    document.getElementById('f-rise-min').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v) && v <= handle.riseSpeed[1]) { handle.riseSpeed = [v, handle.riseSpeed[1]]; selectedItem.options.riseSpeed = handle.riseSpeed; } };
    document.getElementById('f-rise-max').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v) && v >= handle.riseSpeed[0]) { handle.riseSpeed = [handle.riseSpeed[0], v]; selectedItem.options.riseSpeed = handle.riseSpeed; } };
    document.getElementById('f-gravity').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { handle.gravity = v; selectedItem.options.gravity = v; } };
    document.getElementById('f-emitter-preset').onchange = (e) => {
      const preset = PARTICLE_PRESETS[e.target.value];
      if (!preset) return;
      pushUndo();
      Object.assign(handle, preset);
      Object.assign(selectedItem.options, preset);
      renderInspector();
    };
    document.getElementById('delete-btn').onclick = deleteSelected;
    document.getElementById('duplicate-btn').onclick = duplicateSelected;
  }

  if (selectedItem.kind === 'camera') {
    const opts = selectedItem.options;
    const showChase = opts.mode === 'chase';
    const showFixedTarget = opts.mode === 'fixed' || opts.mode === 'followLookAt';
    inspectorBody.innerHTML = `
      <div class="field-row"><label>Position</label>
        <div class="field-triple">
          <input type="number" id="f-x" step="0.1" value="${opts.position.x.toFixed(2)}">
          <input type="number" id="f-y" step="0.1" value="${opts.position.y.toFixed(2)}">
          <input type="number" id="f-z" step="0.1" value="${opts.position.z.toFixed(2)}">
        </div>
      </div>
      <div class="field-row"><label>Mode</label>
        <select id="f-mode">
          <option value="chase"${opts.mode === 'chase' ? ' selected' : ''}>Chase (follows the Player, moves with it)</option>
          <option value="orbit"${opts.mode === 'orbit' ? ' selected' : ''}>Orbit (free-look, pivots on this position)</option>
          <option value="fixed"${opts.mode === 'fixed' ? ' selected' : ''}>Fixed (static shot from this position)</option>
          <option value="followLookAt"${opts.mode === 'followLookAt' ? ' selected' : ''}>Follow Look-At (static position, tracks the Player)</option>
        </select>
      </div>
      <div class="field-row"><label>Field of View (degrees)</label>
        <input type="number" id="f-fov" step="1" min="20" max="120" value="${opts.fovDegrees}">
      </div>
      ${showChase ? `
      <div class="field-row"><label>Chase Distance / Height</label>
        <div class="field-triple">
          <input type="number" id="f-chase-distance" step="0.5" min="1" value="${opts.chase.distance}">
          <input type="number" id="f-chase-height" step="0.5" min="0" value="${opts.chase.height}">
        </div>
      </div>
      <div class="field-row"><label>Chase Smoothing (position / rotation)</label>
        <div class="field-triple">
          <input type="number" id="f-chase-lerp" step="0.5" min="0.5" value="${opts.chase.lerpSpeed}">
          <input type="number" id="f-chase-rot-lerp" step="0.5" min="0.5" value="${opts.chase.rotationLerpSpeed}">
        </div>
      </div>
      ` : ''}
      ${showFixedTarget ? `
      <div class="field-row"><label>Look At (optional -- object to aim at)</label>
        ${renderActionFieldInput({ key: 'lookAtTargetId', type: 'target' }, opts.lookAtTargetId, 'f-lookat')}
      </div>
      ` : ''}
      <div class="field-triple">
        <button id="duplicate-btn" class="toolbar-btn" style="margin-bottom:0">Duplicate</button>
        <button id="delete-btn" style="margin-bottom:0">Delete Camera</button>
      </div>
    `;
    for (const id of ['f-x', 'f-y', 'f-z', 'f-mode', 'f-fov', 'f-chase-distance', 'f-chase-height', 'f-chase-lerp', 'f-chase-rot-lerp', 'f-lookat']) {
      const el = document.getElementById(id);
      if (el) el.onfocus = () => pushUndo();
    }
    document.getElementById('f-x').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { selectedItem.entity.position.x = v; opts.position.x = v; } };
    document.getElementById('f-y').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { selectedItem.entity.position.y = v; opts.position.y = v; } };
    document.getElementById('f-z').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { selectedItem.entity.position.z = v; opts.position.z = v; } };
    document.getElementById('f-mode').onchange = (e) => { opts.mode = e.target.value; renderInspector(); };
    document.getElementById('f-fov').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= 20 && v <= 120) opts.fovDegrees = v; };
    if (showChase) {
      document.getElementById('f-chase-distance').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) opts.chase.distance = v; };
      document.getElementById('f-chase-height').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) opts.chase.height = v; };
      document.getElementById('f-chase-lerp').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) opts.chase.lerpSpeed = v; };
      document.getElementById('f-chase-rot-lerp').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) opts.chase.rotationLerpSpeed = v; };
    }
    if (showFixedTarget) {
      document.getElementById('f-lookat').onchange = (e) => { opts.lookAtTargetId = e.target.value || null; };
    }
    document.getElementById('delete-btn').onclick = deleteSelected;
    document.getElementById('duplicate-btn').onclick = duplicateSelected;
  }

  if (selectedItem.kind === 'spawner') {
    const opts = selectedItem.options;
    inspectorBody.innerHTML = `
      <div class="field-row"><label>Position</label>
        <div class="field-triple">
          <input type="number" id="f-x" step="0.1" value="${opts.position.x.toFixed(2)}">
          <input type="number" id="f-y" step="0.1" value="${opts.position.y.toFixed(2)}">
          <input type="number" id="f-z" step="0.1" value="${opts.position.z.toFixed(2)}">
        </div>
      </div>
      <div class="field-row"><label>Prefab to Spawn</label>
        ${prefabs.length === 0 ? '<p style="color:#8592a8;font-size:11.5px;margin:2px 0">No prefabs saved yet.</p>' : renderActionFieldInput({ key: 'prefabName', type: 'prefab' }, opts.prefabName, 'f-spawner-prefab')}
      </div>
      <div class="field-row"><label>Interval (sec) / Initial Delay (sec)</label>
        <div class="field-triple">
          <input type="number" id="f-interval" step="0.5" min="0.1" value="${opts.interval}">
          <input type="number" id="f-initial-delay" step="0.5" min="0" value="${opts.initialDelay || 0}">
        </div>
      </div>
      <div class="field-row"><label>Radius / Tag on spawned (optional)</label>
        <div class="field-triple">
          <input type="number" id="f-radius" step="0.5" min="0" value="${opts.radius}">
          <input type="text" id="f-spawn-tag" placeholder="e.g. enemy" value="${escapeHtml(opts.tag || '')}">
        </div>
      </div>
      <div class="field-row"><label>Max Active / Total Count (0 = unlimited)</label>
        <div class="field-triple">
          <input type="number" id="f-max-active" step="1" min="1" value="${opts.maxActive}">
          <input type="number" id="f-total-count" step="1" min="0" value="${opts.totalCount}">
        </div>
      </div>
      <div class="field-row"><label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#c7d3ea">
        <input type="checkbox" id="f-start-enabled"${opts.startEnabled !== false ? ' checked' : ''}> Enabled at level start
      </label></div>
      <div class="field-triple">
        <button id="duplicate-btn" class="toolbar-btn" style="margin-bottom:0">Duplicate</button>
        <button id="delete-btn" style="margin-bottom:0">Delete Spawner</button>
      </div>
    `;
    document.getElementById('f-x').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { selectedItem.entity.position.x = v; opts.position.x = v; } };
    document.getElementById('f-y').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { selectedItem.entity.position.y = v; opts.position.y = v; } };
    document.getElementById('f-z').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { selectedItem.entity.position.z = v; opts.position.z = v; } };
    const prefabSelect = document.getElementById('f-spawner-prefab');
    if (prefabSelect) prefabSelect.onchange = (e) => { opts.prefabName = e.target.value; };
    document.getElementById('f-interval').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) opts.interval = v; };
    document.getElementById('f-initial-delay').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= 0) opts.initialDelay = v; };
    document.getElementById('f-radius').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= 0) opts.radius = v; };
    document.getElementById('f-spawn-tag').oninput = (e) => { opts.tag = e.target.value.trim(); };
    document.getElementById('f-max-active').oninput = (e) => { const v = parseInt(e.target.value, 10); if (v >= 1) opts.maxActive = v; };
    document.getElementById('f-total-count').oninput = (e) => { const v = parseInt(e.target.value, 10); if (v >= 0) opts.totalCount = v; };
    document.getElementById('f-start-enabled').onchange = (e) => { opts.startEnabled = e.target.checked; };
    document.getElementById('delete-btn').onclick = deleteSelected;
    document.getElementById('duplicate-btn').onclick = duplicateSelected;
  }

  if (selectedItem.kind === 'light') {
    const opts = selectedItem.options;
    const isSpot = opts.lightType === 'spot';
    inspectorBody.innerHTML = `
      <div class="field-row"><label>Position</label>
        <div class="field-triple">
          <input type="number" id="f-x" step="0.1" value="${opts.position.x.toFixed(2)}">
          <input type="number" id="f-y" step="0.1" value="${opts.position.y.toFixed(2)}">
          <input type="number" id="f-z" step="0.1" value="${opts.position.z.toFixed(2)}">
        </div>
      </div>
      <div class="field-row"><label>Enabled</label><input type="checkbox" id="f-light-enabled" ${opts.enabled === false ? '' : 'checked'}></div>
      <div class="field-row"><label>Color</label><input type="color" id="f-light-color" value="${rgbToHex(opts.color)}"></div>
      <div class="field-row"><label>Intensity / Range</label>
        <div class="field-triple">
          <input type="number" id="f-light-intensity" step="0.1" min="0" value="${opts.intensity}">
          <input type="number" id="f-light-range" step="0.5" min="0.5" value="${opts.range}">
        </div>
      </div>
      ${isSpot ? `
      <div class="field-row"><label>Cone Angle (degrees)</label>
        <input type="number" id="f-light-angle" step="1" min="1" max="89" value="${Math.round(opts.angle * 180 / Math.PI)}">
      </div>
      <div class="field-row"><label>Direction (X, Y, Z)</label>
        <div class="field-triple">
          <input type="number" id="f-light-dir-x" step="0.1" value="${opts.direction.x.toFixed(2)}">
          <input type="number" id="f-light-dir-y" step="0.1" value="${opts.direction.y.toFixed(2)}">
          <input type="number" id="f-light-dir-z" step="0.1" value="${opts.direction.z.toFixed(2)}">
        </div>
      </div>` : ''}
      <div class="field-triple">
        <button id="duplicate-btn" class="toolbar-btn" style="margin-bottom:0">Duplicate</button>
        <button id="delete-btn" style="margin-bottom:0">Delete Light</button>
      </div>
    `;
    document.getElementById('f-x').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { selectedItem.entity.position.x = v; syncLightConeViz(); } };
    document.getElementById('f-y').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { selectedItem.entity.position.y = v; syncLightConeViz(); } };
    document.getElementById('f-z').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { selectedItem.entity.position.z = v; syncLightConeViz(); } };
    document.getElementById('f-light-enabled').onchange = (e) => { opts.enabled = e.target.checked ? undefined : false; selectedItem.lightHandle.enabled = e.target.checked; };
    document.getElementById('f-light-color').oninput = (e) => { const c = hexToRgb(e.target.value); opts.color = c; selectedItem.lightHandle.color = c; };
    document.getElementById('f-light-intensity').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= 0) { opts.intensity = v; selectedItem.lightHandle.intensity = v; } };
    document.getElementById('f-light-range').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) { opts.range = v; selectedItem.lightHandle.range = v; syncLightConeViz(); } };
    const angleInput = document.getElementById('f-light-angle');
    if (angleInput) angleInput.oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0 && v < 90) { const rad = v * Math.PI / 180; opts.angle = rad; selectedItem.lightHandle.angle = rad; syncLightConeViz(); } };
    const dirX = document.getElementById('f-light-dir-x');
    if (dirX) {
      const syncDir = () => { selectedItem.lightHandle.direction.set(opts.direction.x, opts.direction.y, opts.direction.z); syncLightConeViz(); };
      dirX.oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { opts.direction.x = v; syncDir(); } };
      document.getElementById('f-light-dir-y').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { opts.direction.y = v; syncDir(); } };
      document.getElementById('f-light-dir-z').oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) { opts.direction.z = v; syncDir(); } };
    }
    document.getElementById('delete-btn').onclick = deleteSelected;
    document.getElementById('duplicate-btn').onclick = duplicateSelected;
  }
}

// Object References (Track I): a user-friendly display name, editable per
// item, independent of the stable `id` used internally for references --
// people pick "the Gate" from a dropdown, not "obj47". Wrapping
// renderInspectorBody rather than editing all three kind-specific
// templates keeps this in one place regardless of how many item kinds
// exist.
function renderInspector() {
  renderInspectorBody();
  if (selectedItems.size !== 1 || !selectedItem) return;
  const nameRow = document.createElement('div');
  nameRow.className = 'field-row';
  const autoLabel = itemLabel(selectedItem, placed.indexOf(selectedItem));
  nameRow.innerHTML = `<label>Name</label><input type="text" id="f-name" placeholder="${escapeHtml(autoLabel)}" value="${escapeHtml(selectedItem.name || '')}">`;
  inspectorBody.insertBefore(nameRow, inspectorBody.firstChild);
  document.getElementById('f-name').oninput = (e) => {
    selectedItem.name = e.target.value || undefined;
    renderSceneList();
  };
  // One shared Hierarchy section for every hierarchy-capable kind (cube,
  // camera, spawner, emitter) rather than duplicating this block into each
  // kind's own inspector branch -- appended here, after the Name row, since
  // this is the one place renderInspector already runs for any single
  // selection regardless of kind.
  if (hierarchyCapable(selectedItem)) {
    const hierarchyRow = document.createElement('div');
    hierarchyRow.className = 'field-row';
    const candidates = placed.filter((p) => p !== selectedItem && hierarchyCapable(p) && !isDescendantOf(p.id, selectedItem));
    const options = candidates.map((p) => `<option value="${p.id}"${selectedItem.parentId === p.id ? ' selected' : ''}>${escapeHtml(itemDisplayName(p, placed.indexOf(p)))}</option>`).join('');
    hierarchyRow.innerHTML = `<label>Parent</label>
      <select id="f-parent"><option value="">None (root object)</option>${options}</select>`;
    inspectorBody.insertBefore(hierarchyRow, nameRow.nextSibling);
    document.getElementById('f-parent').onchange = (e) => {
      pushUndo();
      const newParentId = e.target.value;
      if (!newParentId) {
        unparentItem(selectedItem);
        showStatus('Unparented');
      } else {
        const parentItem = findItemById(newParentId);
        if (reparentItem(selectedItem, parentItem)) showStatus(`Parented to "${itemDisplayName(parentItem, placed.indexOf(parentItem))}"`);
        else renderInspector(); // rejected (cycle) -- reset the dropdown back to the actual current parent
      }
      renderSceneList();
    };
  }
}

// --- Export / Save / Load ---

const statusEl = document.getElementById('status-msg');
let statusTimer = null;
function showStatus(text) {
  statusEl.textContent = text;
  clearTimeout(statusTimer);
  statusTimer = setTimeout(() => { statusEl.textContent = ''; }, 2000);
}

// Save/Load, Export, and Undo/Redo all reuse serializeScene/loadScene, so a
// cube's mesh identity has to round-trip through all of them, not just stay
// correct in the live session. The three built-ins are cheap to tag by
// name; anything else (an imported glTF model, or any future custom mesh)
// round-trips its actual geometry via Opus.Mesh.toArrays/fromArrays -- the
// same pair fromGLTF itself is built on -- since there's no source file
// kept around to re-import from.
// --- Project Asset Library (Wave 3) ---
// One immutable geometry payload per imported model, many lightweight
// references -- the fix for the exact duplication problem Import Model had
// before this: every placed instance embedded its OWN full copy of
// positions/normals/indices (via customMesh), so 20 instances of the same
// 5000-vertex model meant 20 copies in every save/export. An asset's
// `meshHandle` (the real GPU-uploadable Opus.Mesh, built once via
// Mesh.fromArrays) is built lazily and cached -- every instance placed from
// the SAME asset shares the exact same mesh object, the same way cubeMesh/
// mineMesh/boostMesh already do for the built-in shapes.
let assets = [];
let nextAssetId = 1;
function generateAssetId() { return `asset${nextAssetId++}`; }
function reconcileAssetIdCounter(id) {
  const match = /^asset(\d+)$/.exec(id);
  if (match) nextAssetId = Math.max(nextAssetId, Number(match[1]) + 1);
}
function findAssetById(id) { return id ? assets.find((a) => a.id === id) : undefined; }
// Wave 6 (Priority C): a skin's animation clips carry Float32Array times/
// values (what parseSkinnedGLTFToArrays/computeSkinPalette both expect --
// `.subarray()` calls throughout the sampler need a real typed array, not
// a plain object). JSON.stringify/parse does NOT round-trip a typed array
// as one (it serializes as a plain `{"0":1,"1":2,...}` object, silently
// losing every typed-array method) -- these two functions are the ONE
// place that converts between the "plain JSON-safe numbers" shape a saved
// project can actually carry and the "real Float32Array" shape the runtime
// sampler needs, in each direction, so no other code has to know this
// distinction exists.
function flattenSkinForStorage(skin) {
  return {
    jointCount: skin.jointCount,
    inverseBindMatrices: skin.inverseBindMatrices.map((m) => Array.from(m)),
    jointParents: skin.jointParents.slice(),
    jointLocalBind: skin.jointLocalBind.map((b) => ({ translation: b.translation.slice(), rotation: b.rotation.slice(), scale: b.scale.slice() })),
    // Wave 7 (Priority A): joint names, for Bone Sockets -- `|| []` so a
    // hand-built/legacy skin object with no `jointNames` at all (shouldn't
    // happen post-Wave-7 import, but defensive) still serializes without
    // throwing; reviveSkinFromStorage's own fallback covers the READ side
    // for a project saved before this priority existed.
    jointNames: skin.jointNames ? skin.jointNames.slice() : [],
    clips: skin.clips.map((c) => ({
      name: c.name, duration: c.duration,
      tracks: c.tracks.map((t) => ({ jointLocalIndex: t.jointLocalIndex, path: t.path, interpolation: t.interpolation, times: Array.from(t.times), values: Array.from(t.values) })),
    })),
  };
}
function reviveSkinFromStorage(stored) {
  return {
    jointCount: stored.jointCount,
    inverseBindMatrices: stored.inverseBindMatrices,
    jointParents: stored.jointParents,
    jointLocalBind: stored.jointLocalBind,
    // Wave 7 (Priority A): a project saved BEFORE this priority existed has
    // no `jointNames` in its stored skin data at all -- fall back to the
    // same synthetic "joint<i>" naming the importer itself uses for an
    // unnamed rig, so Socket authoring against an old project's already-
    // imported asset still works (just with less legible names), never a
    // crash or a silently empty Bone dropdown.
    jointNames: (stored.jointNames && stored.jointNames.length === stored.jointCount) ? stored.jointNames : stored.jointLocalBind.map((_, i) => `joint${i}`),
    clips: stored.clips.map((c) => ({
      name: c.name, duration: c.duration,
      tracks: c.tracks.map((t) => ({ jointLocalIndex: t.jointLocalIndex, path: t.path, interpolation: t.interpolation, times: new Float32Array(t.times), values: new Float32Array(t.values) })),
    })),
  };
}
function getAssetMeshHandle(asset) {
  if (!asset.meshHandle) {
    asset.meshHandle = asset.type === 'skinnedMesh'
      ? Opus.Mesh.fromSkinnedArrays(
        new Float32Array(asset.positions),
        new Float32Array(asset.normals),
        new Uint16Array(asset.indices),
        asset.uvs ? new Float32Array(asset.uvs) : undefined,
        new Float32Array(asset.joints),
        new Float32Array(asset.weights),
        reviveSkinFromStorage(asset.skin),
      )
      : Opus.Mesh.fromArrays(
        new Float32Array(asset.positions),
        new Float32Array(asset.normals),
        new Uint16Array(asset.indices),
      );
  }
  return asset.meshHandle;
}
// Scans every level's OWN serialized objects (not just the currently live
// `placed`) for `mesh: 'asset', assetId` references -- syncs the active
// level first so an in-progress placement not yet saved still counts.
function computeAssetUsageCount(assetId) {
  syncCurrentLevelObjects();
  let count = 0;
  for (const level of levels) {
    for (const record of level.objects) {
      if (record.kind === 'cube' && record.mesh === 'asset' && record.assetId === assetId) count++;
    }
  }
  return count;
}
// Bundles only assets actually referenced somewhere in the project into
// project.assets on Export/Save, same "additive, only what's used" policy
// portable prefabs already established -- an unused import doesn't bloat
// every future export of a project just because it once got imported.
// --- Asset Library search/tags/folders (Wave 4) -- shared across all
// three asset libraries (mesh/texture/audio) rather than three separate
// implementations, since all three already follow the identical id/name/
// usage-count/rename/delete shape. `folder` is a single free-text string
// (a one-level grouping, not a nested tree -- the actual libraries here
// hold tens of assets, not thousands, so a flat folder-as-filter is enough
// without the much larger UI a real folder TREE would need); `tags` is a
// free-text array. Both are optional and default to absent/empty for every
// asset imported before this feature existed -- read defensively via these
// two accessors everywhere, never assumed present.
function assetTagsOf(asset) { return asset.tags || []; }
function assetFolderOf(asset) { return asset.folder || ''; }
function assetMatchesFilter(asset, query, folder) {
  if (folder && assetFolderOf(asset) !== folder) return false;
  if (!query) return true;
  const q = query.toLowerCase();
  if (asset.name.toLowerCase().includes(q)) return true;
  return assetTagsOf(asset).some((t) => t.toLowerCase().includes(q));
}
// Populated from the FULL list (not the filtered one) so choosing a folder
// never makes other folders disappear from the dropdown; preserves the
// current selection across a re-render.
function populateAssetFolderFilter(selectEl, list, current) {
  const folders = Array.from(new Set(list.map(assetFolderOf).filter(Boolean))).sort();
  selectEl.innerHTML = '<option value="">All folders</option>' + folders.map((f) => `<option value="${escapeHtml(f)}"${f === current ? ' selected' : ''}>${escapeHtml(f)}</option>`).join('');
}
// Folder + tags are edited together through one compact field per row
// ("Folder: tag1, tag2") rather than two separate inputs -- an asset row is
// already dense (name/meta/actions all in a small card), and a second full
// input per row would cost more space than the feature is worth.
function formatAssetTagInput(asset) {
  const folder = assetFolderOf(asset), tags = assetTagsOf(asset);
  return (folder ? folder + ': ' : '') + tags.join(', ');
}
function parseAssetTagInput(text) {
  const trimmed = text.trim();
  if (!trimmed) return { folder: '', tags: [] };
  const colonIdx = trimmed.indexOf(':');
  let folder = '', rest = trimmed;
  if (colonIdx !== -1) { folder = trimmed.slice(0, colonIdx).trim(); rest = trimmed.slice(colonIdx + 1); }
  const tags = rest.split(',').map((s) => s.trim()).filter(Boolean);
  return { folder, tags };
}
function assetTagsRowHtml(asset) {
  const tags = assetTagsOf(asset);
  const folder = assetFolderOf(asset);
  const chips = (folder ? [`📁 ${folder}`] : []).concat(tags);
  const chipsHtml = chips.length ? `<div class="asset-row-tags">${chips.map((c) => `<span class="asset-tag-chip">${escapeHtml(c)}</span>`).join('')}</div>` : '';
  return `${chipsHtml}<input type="text" class="asset-row-folder-tags-edit" data-asset-tagedit="${asset.id}" placeholder="Folder: tag1, tag2" value="${escapeHtml(formatAssetTagInput(asset))}">`;
}

// Wave 8: `usedIds` now always comes from the one `collectProjectDependencies()`
// closure (computed once per `serializeProject()` call and threaded through
// to all three asset-kind serializers below), replacing this function's own
// previously-independent, narrower scan -- see that function's own comment
// for the concrete gap this closes (Player Visual's own `visual.assetId`
// was never found by the old scan).
function serializeAssets(usedIds) {
  const used = usedIds || collectProjectDependencies().meshAssets;
  // Wave 6 (Priority C): a 'skinnedMesh' asset carries its rig data
  // (uvs/joints/weights/skin) alongside the same positions/normals/indices
  // every asset already serializes -- omitted entirely for an ordinary
  // 'mesh' asset, so a pre-Wave-6 asset's saved record stays byte-for-byte
  // identical to before this feature existed.
  return assets.filter((a) => used.has(a.id)).map((a) => ({
    id: a.id, name: a.name, type: a.type, positions: a.positions, normals: a.normals, indices: a.indices,
    uvs: a.type === 'skinnedMesh' ? a.uvs : undefined,
    joints: a.type === 'skinnedMesh' ? a.joints : undefined,
    weights: a.type === 'skinnedMesh' ? a.weights : undefined,
    skin: a.type === 'skinnedMesh' ? a.skin : undefined,
    // Wave 7 (Priority A): named Sockets are authoring metadata on the
    // ASSET itself (a "RightHand" bone offset is a property of the rig, not
    // any one placed instance) -- omitted entirely for a non-skinned asset
    // or a skinned asset with none authored, matching the same "omit at
    // default" discipline `skin` above already follows.
    sockets: (a.type === 'skinnedMesh' && a.sockets && a.sockets.length) ? a.sockets : undefined,
    // Wave 7 (Priority B): same asset-level-metadata / omit-at-default
    // pattern as sockets above -- an event is a property of the CLIP, which
    // belongs to the rig, not to any one placed instance.
    animationEvents: (a.type === 'skinnedMesh' && a.animationEvents && a.animationEvents.length) ? a.animationEvents : undefined,
    sourceFilename: a.sourceFilename, folder: a.folder || undefined, tags: (a.tags && a.tags.length) ? a.tags.slice() : undefined,
  }));
}
// Additive merge, like bundled-prefab import -- never overwrites a LOCAL
// asset of the same id, so importing a project that shares an asset id
// with something already in this library can't silently corrupt it.
function loadAssets(bundledAssets) {
  if (!Array.isArray(bundledAssets)) return;
  for (const a of bundledAssets) {
    if (findAssetById(a.id)) continue;
    reconcileAssetIdCounter(a.id);
    assets.push({
      id: a.id, name: a.name, type: a.type, positions: a.positions, normals: a.normals, indices: a.indices,
      uvs: a.uvs, joints: a.joints, weights: a.weights, skin: a.skin, sockets: a.sockets ? a.sockets.slice() : [],
      animationEvents: a.animationEvents ? a.animationEvents.slice() : [],
      sourceFilename: a.sourceFilename, meshHandle: null, folder: a.folder || '', tags: a.tags ? a.tags.slice() : [],
    });
  }
  renderAssetLibrary();
}

function renderAssetLibrary() {
  const listEl = document.getElementById('asset-library-list');
  if (!listEl) return;
  const searchEl = document.getElementById('asset-library-search');
  const folderEl = document.getElementById('asset-library-folder-filter');
  const query = searchEl ? searchEl.value.trim() : '';
  const folder = folderEl ? folderEl.value : '';
  if (folderEl) populateAssetFolderFilter(folderEl, assets, folder);
  if (assets.length === 0) {
    listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No assets imported yet.</p>';
    return;
  }
  const visible = assets.filter((a) => assetMatchesFilter(a, query, folder));
  if (visible.length === 0) {
    listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No assets match this search.</p>';
    return;
  }
  listEl.innerHTML = visible.map((a) => {
    const usage = computeAssetUsageCount(a.id);
    return `
    <div class="asset-row" data-asset-id="${a.id}">
      <div class="asset-row-header">
        <span class="asset-row-name" title="${escapeHtml(a.name)}">${escapeHtml(a.name)}</span>
      </div>
      <div class="asset-row-meta">${escapeHtml(a.type)} · ${a.positions.length / 3} verts · used ${usage}×</div>
      ${assetTagsRowHtml(a)}
      <div class="asset-row-actions">
        <button data-place-asset="${a.id}">Place</button>
        <button data-rename-asset="${a.id}">Rename</button>
        <button data-delete-asset="${a.id}">Delete</button>
      </div>
    </div>`;
  }).join('');
  listEl.querySelectorAll('[data-place-asset]').forEach((btn) => {
    btn.onclick = () => {
      const asset = findAssetById(btn.dataset.placeAsset);
      if (asset) placeAssetInstance(asset, new Opus.Vec3(0, 1, 0));
    };
  });
  listEl.querySelectorAll('[data-rename-asset]').forEach((btn) => {
    btn.onclick = () => {
      const asset = findAssetById(btn.dataset.renameAsset);
      if (!asset) return;
      const name = prompt('Asset name:', asset.name);
      if (name && name.trim()) { asset.name = name.trim(); renderAssetLibrary(); }
    };
  });
  listEl.querySelectorAll('[data-delete-asset]').forEach((btn) => {
    btn.onclick = () => {
      const asset = findAssetById(btn.dataset.deleteAsset);
      if (!asset) return;
      const usage = computeAssetUsageCount(asset.id);
      if (usage > 0) { showStatus(`Can't delete "${asset.name}" -- still used by ${usage} object${usage === 1 ? '' : 's'}`); return; }
      assets = assets.filter((a) => a.id !== asset.id);
      renderAssetLibrary();
      showStatus(`Deleted asset "${asset.name}"`);
    };
  });
  listEl.querySelectorAll('[data-asset-tagedit]').forEach((input) => {
    input.onchange = () => {
      const asset = findAssetById(input.dataset.assetTagedit);
      if (!asset) return;
      const { folder: f, tags: t } = parseAssetTagInput(input.value);
      asset.folder = f; asset.tags = t;
      renderAssetLibrary();
    };
  });
}
renderAssetLibrary();
document.getElementById('asset-library-search').addEventListener('input', renderAssetLibrary);
document.getElementById('asset-library-folder-filter').addEventListener('change', renderAssetLibrary);

// --- Texture Asset Library (Wave 3) ---
// Deliberately bounded, NOT a PBR material system: one optional base-color
// texture per cube (see 07-shader.js's own comment), authored either by
// importing an image file directly or automatically from a glTF model's
// embedded base-color texture (see the Import Model handler below). Mirrors
// the mesh Asset Library's shape (id/name/usage-count/Place-Rename-Delete)
// on purpose -- same mental model, different payload (a decoded image + a
// lazily-built GPU texture handle instead of geometry arrays).
//
// Image decode is genuinely asynchronous (`new Image().onload`), which the
// rest of this editor's synchronous scene-load path (loadScene/
// instantiateCubeRecord) isn't built around and shouldn't be forced to be
// just for this. Bridged with a small pending-callback queue per asset:
// applyTextureToEntity() assigns the GPU texture immediately if the image
// has already finished decoding, or queues the assignment for the moment it
// does -- so a textured object loaded from a fresh project briefly renders
// untextured (a color-only tint) for at most one decode's worth of time,
// never blocks or breaks the load.
let textureAssets = [];
let nextTextureId = 1;
function generateTextureId() { return `texture${nextTextureId++}`; }
function reconcileTextureIdCounter(id) {
  const match = /^texture(\d+)$/.exec(id);
  if (match) nextTextureId = Math.max(nextTextureId, Number(match[1]) + 1);
}
function findTextureAssetById(id) { return id ? textureAssets.find((t) => t.id === id) : undefined; }
function getTextureHandle(asset) {
  if (!asset.image) return null;
  if (!asset.textureHandle) asset.textureHandle = app.createTexture(asset.image);
  return asset.textureHandle;
}
function applyTextureToEntity(entity, asset) {
  const handle = getTextureHandle(asset);
  if (handle) { entity.texture = handle; return; }
  (asset.pendingCallbacks = asset.pendingCallbacks || []).push(() => { if (!entity.destroyed) entity.texture = getTextureHandle(asset); });
}
// Decodes a data: URL into an Image, resolving once loaded (or rejecting on
// a corrupt/unsupported image) -- the one place that knows how to turn
// texture-asset bytes into something app.createTexture can actually use.
function decodeTextureImage(dataURL) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('could not decode image data'));
    img.src = dataURL;
  });
}
// Wave 6B (Priority D): a terrain's own textured paint layers (up to 3,
// `record.options.paintEdits.layers[li].textureAssetId`) are collected the
// same way as a cube's single `textureAssetId` -- both usage-counting
// (below) and serialization (serializeTextureAssets) recognize them, so a
// texture referenced ONLY by a terrain layer is never wrongly reported as
// unused or dropped from a portable export.
function terrainLayerTextureIds(record) {
  const paintEdits = record.options && record.options.paintEdits;
  if (!paintEdits || !paintEdits.layers) return [];
  return paintEdits.layers.map((l) => l.textureAssetId).filter(Boolean);
}
function computeTextureUsageCount(textureId) {
  syncCurrentLevelObjects();
  let count = 0;
  for (const level of levels) {
    for (const record of level.objects) {
      if (record.kind === 'cube' && record.textureAssetId === textureId) count++;
      else if (record.kind === 'terrain') count += terrainLayerTextureIds(record).filter((id) => id === textureId).length;
    }
  }
  return count;
}
function serializeTextureAssets(usedIds) {
  const used = usedIds || collectProjectDependencies().textureAssets;
  return textureAssets.filter((t) => used.has(t.id)).map((t) => ({ id: t.id, name: t.name, dataURL: t.dataURL, sourceFilename: t.sourceFilename, folder: t.folder || undefined, tags: (t.tags && t.tags.length) ? t.tags.slice() : undefined }));
}
// Additive merge, same policy as loadAssets/portable prefabs. Starts the
// (async) image decode for each bundled texture immediately; any cube
// records already loaded that reference it get their entity.texture filled
// in once decode completes (see instantiateCubeRecord's applyTextureToEntity call).
function loadTextureAssets(bundledTextures) {
  if (!Array.isArray(bundledTextures)) return;
  for (const t of bundledTextures) {
    if (findTextureAssetById(t.id)) continue;
    reconcileTextureIdCounter(t.id);
    const asset = { id: t.id, name: t.name, dataURL: t.dataURL, sourceFilename: t.sourceFilename, image: null, textureHandle: null, pendingCallbacks: [], folder: t.folder || '', tags: t.tags ? t.tags.slice() : [] };
    textureAssets.push(asset);
    decodeTextureImage(t.dataURL).then((img) => {
      asset.image = img;
      const callbacks = asset.pendingCallbacks || [];
      asset.pendingCallbacks = [];
      callbacks.forEach((cb) => cb());
      renderTextureLibrary();
    }).catch(() => showStatus(`Texture "${asset.name}" failed to decode`));
  }
  renderTextureLibrary();
}

function renderTextureLibrary() {
  // Wave 6 (Priority H): keep the Sky Panorama dropdown's option list
  // (built off this SAME textureAssets array) in sync with the Texture
  // Library any time it changes -- import, rename, delete -- rather than
  // only refreshing it when the Environment section happens to re-render
  // for an unrelated reason.
  if (typeof renderEnvironmentPanel === 'function') renderEnvironmentPanel();
  const listEl = document.getElementById('texture-library-list');
  if (!listEl) return;
  const searchEl = document.getElementById('texture-library-search');
  const folderEl = document.getElementById('texture-library-folder-filter');
  const query = searchEl ? searchEl.value.trim() : '';
  const folder = folderEl ? folderEl.value : '';
  if (folderEl) populateAssetFolderFilter(folderEl, textureAssets, folder);
  if (textureAssets.length === 0) {
    listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No textures imported yet.</p>';
    return;
  }
  const visible = textureAssets.filter((t) => assetMatchesFilter(t, query, folder));
  if (visible.length === 0) {
    listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No textures match this search.</p>';
    return;
  }
  listEl.innerHTML = visible.map((t) => {
    const usage = computeTextureUsageCount(t.id);
    const status = t.image ? `${t.image.naturalWidth}×${t.image.naturalHeight}` : 'decoding…';
    return `
    <div class="asset-row" data-texture-id="${t.id}">
      <div class="asset-row-header">
        <span class="asset-row-name" title="${escapeHtml(t.name)}">${escapeHtml(t.name)}</span>
      </div>
      <div class="asset-row-meta">${status} · used ${usage}×</div>
      ${assetTagsRowHtml(t)}
      <div class="asset-row-actions">
        <button data-rename-texture="${t.id}">Rename</button>
        <button data-delete-texture="${t.id}">Delete</button>
      </div>
    </div>`;
  }).join('');
  listEl.querySelectorAll('[data-rename-texture]').forEach((btn) => {
    btn.onclick = () => {
      const asset = findTextureAssetById(btn.dataset.renameTexture);
      if (!asset) return;
      const name = prompt('Texture name:', asset.name);
      if (name && name.trim()) { asset.name = name.trim(); renderTextureLibrary(); renderInspector(); }
    };
  });
  listEl.querySelectorAll('[data-delete-texture]').forEach((btn) => {
    btn.onclick = () => {
      const asset = findTextureAssetById(btn.dataset.deleteTexture);
      if (!asset) return;
      const usage = computeTextureUsageCount(asset.id);
      if (usage > 0) { showStatus(`Can't delete "${asset.name}" -- still used by ${usage} object${usage === 1 ? '' : 's'}`); return; }
      if (asset.textureHandle) app.destroyTexture(asset.textureHandle);
      textureAssets = textureAssets.filter((t) => t.id !== asset.id);
      renderTextureLibrary();
      showStatus(`Deleted texture "${asset.name}"`);
    };
  });
  listEl.querySelectorAll('[data-asset-tagedit]').forEach((input) => {
    input.onchange = () => {
      const asset = findTextureAssetById(input.dataset.assetTagedit);
      if (!asset) return;
      const { folder: f, tags: tg } = parseAssetTagInput(input.value);
      asset.folder = f; asset.tags = tg;
      renderTextureLibrary();
    };
  });
}
renderTextureLibrary();
document.getElementById('texture-library-search').addEventListener('input', renderTextureLibrary);
document.getElementById('texture-library-folder-filter').addEventListener('change', renderTextureLibrary);

// --- Audio Asset Library (Wave 3) ---
// Same shape as the Texture Asset Library (id/name/usage-count/decode-then-
// use), same async-decode-bridged-with-pending-callbacks reasoning -- see
// that block's comment. Decoding here goes through the browser's OWN native
// audio decoder (AudioEngine.decodeAudio -> AudioContext.decodeAudioData),
// so whatever formats the browser itself supports (mp3/wav/ogg/...) just
// work, with no bundled codec and no format allowlist to maintain -- the
// "browser-native decode" investigation this section exists to prove out.
let audioAssets = [];
let nextAudioId = 1;
function generateAudioId() { return `audio${nextAudioId++}`; }
function reconcileAudioIdCounter(id) {
  const match = /^audio(\d+)$/.exec(id);
  if (match) nextAudioId = Math.max(nextAudioId, Number(match[1]) + 1);
}
function findAudioAssetById(id) { return id ? audioAssets.find((a) => a.id === id) : undefined; }
function dataURLToArrayBuffer(dataURL) {
  const base64 = dataURL.slice(dataURL.indexOf(',') + 1);
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}
function computeAudioUsageCount(audioId) {
  syncCurrentLevelObjects();
  let count = 0;
  for (const level of levels) {
    if (level.ambientAudio && level.ambientAudio.audioAssetId === audioId) count++;
    for (const record of level.objects) {
      if (record.kind === 'cube') {
        for (const b of record.behaviors || []) {
          if (b.action === 'sound' && b.params && b.params.audioAssetId === audioId) count++;
        }
      }
    }
  }
  return count;
}
function serializeAudioAssets(usedIds) {
  const used = usedIds || collectProjectDependencies().audioAssets;
  return audioAssets.filter((a) => used.has(a.id)).map((a) => ({ id: a.id, name: a.name, dataURL: a.dataURL, sourceFilename: a.sourceFilename, folder: a.folder || undefined, tags: (a.tags && a.tags.length) ? a.tags.slice() : undefined }));
}
function loadAudioAssets(bundledAudio) {
  if (!Array.isArray(bundledAudio)) return;
  for (const a of bundledAudio) {
    if (findAudioAssetById(a.id)) continue;
    reconcileAudioIdCounter(a.id);
    const asset = { id: a.id, name: a.name, dataURL: a.dataURL, sourceFilename: a.sourceFilename, audioBuffer: null, pendingCallbacks: [], folder: a.folder || '', tags: a.tags ? a.tags.slice() : [] };
    audioAssets.push(asset);
    app.audio.decodeAudio(dataURLToArrayBuffer(a.dataURL)).then((buf) => {
      asset.audioBuffer = buf;
      const callbacks = asset.pendingCallbacks || [];
      asset.pendingCallbacks = [];
      callbacks.forEach((cb) => cb());
      renderAudioLibrary();
    }).catch(() => showStatus(`Audio "${asset.name}" failed to decode`));
  }
  renderAudioLibrary();
}

function renderAudioLibrary() {
  const listEl = document.getElementById('audio-library-list');
  if (!listEl) return;
  const searchEl = document.getElementById('audio-library-search');
  const folderEl = document.getElementById('audio-library-folder-filter');
  const query = searchEl ? searchEl.value.trim() : '';
  const folder = folderEl ? folderEl.value : '';
  if (folderEl) populateAssetFolderFilter(folderEl, audioAssets, folder);
  if (audioAssets.length === 0) {
    listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No audio imported yet.</p>';
    return;
  }
  const visible = audioAssets.filter((a) => assetMatchesFilter(a, query, folder));
  if (visible.length === 0) {
    listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No audio matches this search.</p>';
    return;
  }
  listEl.innerHTML = visible.map((a) => {
    const usage = computeAudioUsageCount(a.id);
    const status = a.audioBuffer ? `${a.audioBuffer.duration.toFixed(1)}s` : 'decoding…';
    return `
    <div class="asset-row" data-audio-id="${a.id}">
      <div class="asset-row-header">
        <span class="asset-row-name" title="${escapeHtml(a.name)}">${escapeHtml(a.name)}</span>
      </div>
      <div class="asset-row-meta">${status} · used ${usage}×</div>
      ${assetTagsRowHtml(a)}
      <div class="asset-row-actions">
        <button data-preview-audio="${a.id}">▶ Preview</button>
        <button data-rename-audio="${a.id}">Rename</button>
        <button data-delete-audio="${a.id}">Delete</button>
      </div>
    </div>`;
  }).join('');
  listEl.querySelectorAll('[data-preview-audio]').forEach((btn) => {
    btn.onclick = () => {
      const asset = findAudioAssetById(btn.dataset.previewAudio);
      if (asset && asset.audioBuffer) app.audio.playBuffer(asset.audioBuffer, { volume: 0.7 });
    };
  });
  listEl.querySelectorAll('[data-rename-audio]').forEach((btn) => {
    btn.onclick = () => {
      const asset = findAudioAssetById(btn.dataset.renameAudio);
      if (!asset) return;
      const name = prompt('Audio name:', asset.name);
      if (name && name.trim()) { asset.name = name.trim(); renderAudioLibrary(); renderInspector(); }
    };
  });
  listEl.querySelectorAll('[data-delete-audio]').forEach((btn) => {
    btn.onclick = () => {
      const asset = findAudioAssetById(btn.dataset.deleteAudio);
      if (!asset) return;
      const usage = computeAudioUsageCount(asset.id);
      if (usage > 0) { showStatus(`Can't delete "${asset.name}" -- still used by ${usage} place${usage === 1 ? '' : 's'}`); return; }
      audioAssets = audioAssets.filter((a) => a.id !== asset.id);
      renderAudioLibrary();
      showStatus(`Deleted audio "${asset.name}"`);
    };
  });
  listEl.querySelectorAll('[data-asset-tagedit]').forEach((input) => {
    input.onchange = () => {
      const asset = findAudioAssetById(input.dataset.assetTagedit);
      if (!asset) return;
      const { folder: f, tags: tg } = parseAssetTagInput(input.value);
      asset.folder = f; asset.tags = tg;
      renderAudioLibrary();
    };
  });
}
renderAudioLibrary();
document.getElementById('audio-library-search').addEventListener('input', renderAudioLibrary);
document.getElementById('audio-library-folder-filter').addEventListener('change', renderAudioLibrary);

// --- Per-level Ambient Audio ---
// Deliberately simple: at most one looping audio-asset track per level,
// authored as {audioAssetId, volume}, no crossfade/layering/randomization.
// Distinct from AudioEngine's own startAmbientDrone() (a hardcoded
// procedural noise generator, unused by the editor) -- this is real
// author-provided content, picked per level the same way Environment or
// Player Settings are.
function defaultAmbientAudioConfig() { return { audioAssetId: null, volume: 0.4 }; }
let currentAmbientAudioConfig = defaultAmbientAudioConfig();
let activeAmbientHandle = null;
function stopAmbientAudio() {
  if (activeAmbientHandle) { activeAmbientHandle.stop(); activeAmbientHandle = null; }
  activeAudioZones.clear();
  audibleAudioZoneId = null;
}
// Wave 9B (Priority: Audio Zone overlap-stacking fix, Sections 37-40): a
// REAL active-zone membership tracker, replacing Wave 9's single "currently
// audible zone id" scalar. `activeAudioZones` holds every zone the Player
// is CURRENTLY (geometrically) inside, keyed by zone item id; the winner is
// recomputed from this whole set on every Enter/Exit, not just remembered
// as "the one that most recently became audible." This is what fixes the
// bounded gap Wave 9 documented and shipped anyway: leaving the top
// zone while a second, lower-priority zone is STILL entered now correctly
// reveals that second zone's ambience, instead of falling straight through
// to level ambient.
let activeAudioZones = new Map(); // zoneId -> {priority, audioAssetId, volume, fadeDuration}
let audibleAudioZoneId = null; // which entry in the map (if any) is the CURRENT winner -- null means level ambient
// Recomputes "highest-priority zone in `activeAudioZones`, or level
// ambient if none" and crossfades ONLY if the winner actually changed
// (Section 39's own "no unnecessary fade restart" -- entering/leaving a
// zone that was never going to win is silently a no-op here).
function recomputeAudioZoneWinner(fade) {
  let winnerId = null, winner = null;
  for (const [zoneId, cfg] of activeAudioZones) {
    if (!winner || cfg.priority > winner.priority) { winner = cfg; winnerId = zoneId; }
  }
  if (winnerId === audibleAudioZoneId) return; // Section 39: winner unchanged -- do nothing
  audibleAudioZoneId = winnerId;
  if (winner) {
    crossfadeAmbientTo(winner.audioAssetId, winner.volume, fade);
  } else {
    const base = levels[currentLevelIndex] ? levels[currentLevelIndex].ambientAudio : null;
    crossfadeAmbientTo(base ? base.audioAssetId : null, base && base.volume != null ? base.volume : 0.4, fade);
  }
}
// Wave 9 (Priority G/Section 69): the one real crossfade primitive both the
// Audio Zone action and level-ambient start/switch route through -- reuses
// the engine's new `playBuffer(...).setVolume(value, rampSeconds)` (real
// Web Audio gain automation) rather than a stop/start pop. `fade <= 0`
// keeps the exact Wave 8 hard-switch (old stops immediately, new starts at
// full target volume) so every pre-Wave-9 Audio Zone/level ambient with no
// Fade Duration authored is byte-identical to before.
function crossfadeAmbientTo(audioAssetId, volume, fade) {
  const old = activeAmbientHandle;
  if (!audioAssetId) {
    if (old) {
      if (fade > 0) { old.setVolume(0, fade); setTimeout(() => old.stop(), fade * 1000 + 60); }
      else old.stop();
    }
    activeAmbientHandle = null;
    return;
  }
  const asset = findAudioAssetById(audioAssetId);
  if (!asset || !asset.audioBuffer) return;
  const handle = app.audio.playBuffer(asset.audioBuffer, { loop: true, volume: fade > 0 ? 0 : volume, category: 'ambient' });
  if (fade > 0) handle.setVolume(volume, fade);
  activeAmbientHandle = handle;
  if (old) {
    if (fade > 0) { old.setVolume(0, fade); setTimeout(() => old.stop(), fade * 1000 + 60); }
    else old.stop();
  }
}
// Called at Play start and on every mid-play level switch -- always stops
// whatever was playing first (a level with no Ambient Audio configured
// correctly means silence, not the previous level's track continuing).
function startAmbientAudioForCurrentLevel() {
  stopAmbientAudio();
  const cfg = currentAmbientAudioConfig;
  if (!cfg.audioAssetId) return;
  const asset = findAudioAssetById(cfg.audioAssetId);
  if (!asset) return;
  if (asset.audioBuffer) {
    activeAmbientHandle = app.audio.playBuffer(asset.audioBuffer, { loop: true, volume: cfg.volume, category: 'ambient' });
  } else {
    // Still decoding (e.g. Play pressed immediately after a project just
    // loaded) -- retry once decode finishes, but only if this level's
    // config still points at the same asset by then (a fast level switch
    // in between must not start stale ambient audio for a level the
    // player has already left).
    (asset.pendingCallbacks = asset.pendingCallbacks || []).push(() => {
      if (currentAmbientAudioConfig.audioAssetId === asset.id) startAmbientAudioForCurrentLevel();
    });
  }
}
// Wave 9C (Priority C, Sections 31-37): Fog Zones -- deliberately reuses
// the EXACT same active-zone-membership shape the Audio Zone overlap fix
// (Wave 9B) already established (`Map`, recompute-on-Enter/Exit, "highest
// priority wins, exiting the top reveals the next-highest still-active
// zone"), not a second, independently-invented priority system (Section
// 34's own explicit warning not to reintroduce that bug in Fog). Scope is
// fog ONLY (`skyHorizon`/`fogDensity`, Section 36's own explicit
// exclusion of sun/shadows/panorama) -- `app.setEnvironment` is called
// with ONLY those two keys, every frame a blend is in flight, never a
// broader environment object that could stomp an author's other settings.
let activeFogZones = new Map(); // zoneId -> {priority, fogColor:[r,g,b], fogDensity, blendDuration}
let audibleFogZoneId = null;
let baseFogColor = null, baseFogDensity = null; // this level's AUTHORED fog, captured once at Play start -- never overwritten by a zone
let fogBlendState = null; // {fromColor, fromDensity, toColor, toDensity, duration, elapsed}
function initFogZonesForCurrentLevel() {
  activeFogZones.clear();
  audibleFogZoneId = null;
  fogBlendState = null;
  const env = (levels[currentLevelIndex] && levels[currentLevelIndex].environment) || {};
  baseFogColor = env.skyHorizon ? env.skyHorizon.slice() : [0.6, 0.65, 0.75];
  baseFogDensity = env.fogDensity != null ? env.fogDensity : 0.02;
}
function startFogBlend(toColor, toDensity, duration) {
  const cur = app.getEnvironment();
  const fromColor = cur.skyHorizon ? cur.skyHorizon.slice() : baseFogColor;
  const fromDensity = cur.fogDensity != null ? cur.fogDensity : baseFogDensity;
  if (!duration || duration <= 0) { app.setEnvironment({ skyHorizon: toColor, fogDensity: toDensity }); fogBlendState = null; return; }
  fogBlendState = { fromColor, fromDensity, toColor, toDensity, duration, elapsed: 0 };
}
function tickFogBlend(dt) {
  if (!fogBlendState) return;
  const b = fogBlendState;
  b.elapsed += dt;
  const t = Math.min(1, b.elapsed / b.duration);
  const color = [0, 1, 2].map((i) => b.fromColor[i] + (b.toColor[i] - b.fromColor[i]) * t);
  const density = b.fromDensity + (b.toDensity - b.fromDensity) * t;
  app.setEnvironment({ skyHorizon: color, fogDensity: Math.max(0, density) });
  if (t >= 1) fogBlendState = null;
}
// Same "recompute the whole membership set's winner, only act if it
// actually changed" shape `recomputeAudioZoneWinner` already established.
function recomputeFogZoneWinner(duration) {
  let winnerId = null, winner = null;
  for (const [zoneId, cfg] of activeFogZones) { if (!winner || cfg.priority > winner.priority) { winner = cfg; winnerId = zoneId; } }
  if (winnerId === audibleFogZoneId) return;
  audibleFogZoneId = winnerId;
  if (winner) startFogBlend(winner.fogColor, winner.fogDensity, duration != null ? duration : winner.blendDuration);
  else startFogBlend(baseFogColor, baseFogDensity, duration != null ? duration : 0.6);
}
function applyLevelAmbientAudio(index) {
  const saved = levels[index].ambientAudio;
  currentAmbientAudioConfig = saved ? { ...defaultAmbientAudioConfig(), ...saved } : defaultAmbientAudioConfig();
  renderAmbientAudioPanel();
}
function renderAmbientAudioPanel() {
  const sel = document.getElementById('ambient-audio-select');
  const volInput = document.getElementById('ambient-audio-volume');
  if (!sel || !volInput) return;
  sel.innerHTML = '<option value="">None</option>' + audioAssets.map((a) => `<option value="${a.id}"${currentAmbientAudioConfig.audioAssetId === a.id ? ' selected' : ''}>${escapeHtml(a.name)}</option>`).join('');
  volInput.value = currentAmbientAudioConfig.volume;
}
document.getElementById('import-audio-btn').addEventListener('click', () => {
  document.getElementById('import-audio-input').click();
});
document.getElementById('import-audio-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    const arrayBuffer = await file.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);
    let binary = '';
    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
    const dataURL = `data:${file.type || 'application/octet-stream'};base64,${btoa(binary)}`;
    const audioBuffer = await app.audio.decodeAudio(arrayBuffer);
    const asset = { id: generateAudioId(), name: file.name.replace(/\.[^.]+$/, ''), dataURL, sourceFilename: file.name, audioBuffer, pendingCallbacks: [] };
    audioAssets.push(asset);
    renderAudioLibrary();
    renderAmbientAudioPanel();
    showStatus(`Imported ${file.name} to Audio Library`);
  } catch (err) {
    showStatus(`Audio import failed: ${err.message}`);
  }
});
document.getElementById('ambient-audio-select').addEventListener('change', (e) => {
  currentAmbientAudioConfig.audioAssetId = e.target.value || null;
});
document.getElementById('ambient-audio-volume').addEventListener('input', (e) => {
  const v = parseFloat(e.target.value);
  if (!Number.isNaN(v) && v >= 0 && v <= 1) currentAmbientAudioConfig.volume = v;
});
renderAmbientAudioPanel();

function meshTag(mesh) {
  if (mesh === cubeMesh) return 'cube';
  if (mesh === mineMesh) return 'mine';
  if (mesh === boostMesh) return 'boost';
  if (mesh === wedgeMesh) return 'wedge';
  if (mesh === billboardMesh) return 'billboard';
  return 'custom';
}

// Shared by serializeScene AND "Save as Prefab" -- a prefab is exactly one
// cube's serialized record, minus position, so there's exactly one place
// that knows how to turn a live item into portable data.
// Dogfood (Signal Relay) fix: strips the runtime-only fields a State
// Machine AI's own tick writes directly onto its `movement` object at play
// time (`wanderTarget`/`wanderTimer` for Wander; kept as an explicit
// per-field allowlist deletion, not a generic "any key not in the authored
// schema" filter, so a future movement type's own runtime field just needs
// adding here, matching the existing per-field whitelist convention this
// whole record already follows). Deep-clones `states` (never mutates the
// live array) so the object still ticking in `placed` is unaffected by a
// Save happening mid-session.
function sanitizeAiStatesForSave(states) {
  if (!Array.isArray(states)) return states;
  return states.map((s) => {
    const clone = JSON.parse(JSON.stringify(s));
    if (clone.movement) { delete clone.movement.wanderTarget; delete clone.movement.wanderTimer; }
    return clone;
  });
}
function serializeCubeRecord(item) {
  const tag = item.assetId ? 'asset' : meshTag(item.entity.mesh);
  const record = {
    kind: 'cube',
    id: item.id,
    name: item.name,
    position: [item.entity.position.x, item.entity.position.y, item.entity.position.z],
    scale: [item.entity.scale.x, item.entity.scale.y, item.entity.scale.z],
    color: item.entity.color.slice(),
    rotationY: item.entity.rotationY,
    // Full XYZ orientation (Wave 5) -- omitted entirely for a pure-yaw
    // object (every pre-Wave-5 save, and any object nobody has pitched or
    // rolled), so an untouched object's record stays byte-for-byte
    // identical to before this feature existed. Present (and authoritative
    // over `rotationY` on load) only once an object genuinely has pitch/roll.
    quaternion: hasPitchOrRoll(item.entity) ? quatToArray(item.entity.quaternion) : undefined,
    behaviors: cloneBehaviors(item.behaviors),
    spin: item.entity.spin || 0,
    patrol: item.entity.patrol ? {
      axis: item.entity.patrol.axis,
      range: item.entity.patrol.range,
      speed: item.entity.patrol.speed,
      phase: item.entity.patrol.phase,
      base: [item.entity.patrol.base.x, item.entity.patrol.base.y, item.entity.patrol.base.z],
    } : null,
    // targetId (Follow Object/Face Target) and waypointNames/loop/pingpong
    // (Patrol Route) were previously silently DROPPED by this whitelist --
    // a Follow Object enemy retargeted onto something other than the
    // Player would revert to Follow-the-Player on the very next Save/Load,
    // with no error. Found and fixed while adding Patrol Route's own
    // fields, which would otherwise have shipped with the exact same gap.
    ai: item.entity.ai ? {
      type: item.entity.ai.type,
      speed: item.entity.ai.speed,
      radius: item.entity.ai.radius,
      base: [item.entity.ai.base.x, item.entity.ai.base.y, item.entity.ai.base.z],
      targetId: item.entity.ai.targetId || undefined,
      waypointNames: item.entity.ai.waypointNames || undefined,
      pathId: item.entity.ai.pathId || undefined, // Wave 8 (Priority I): Follow Path's own reference field
      loop: item.entity.ai.loop || undefined,
      pingpong: item.entity.ai.pingpong || undefined,
      // Ranged Attack (Wave 4) -- same finding-#48 lesson applied proactively
      // this time: every ai.* field gets added to this whitelist AS it's
      // introduced, not discovered missing later by a silent Save/Load drop.
      attackEnabled: item.entity.ai.attackEnabled || undefined,
      attackPrefab: item.entity.ai.attackPrefab || undefined,
      attackRadius: item.entity.ai.attackRadius || undefined,
      attackCooldown: item.entity.ai.attackCooldown || undefined,
      attackDamage: item.entity.ai.attackDamage || undefined,
      // Wave 7 (Priority D): applying finding-#48's own lesson proactively
      // again -- `mode`/`states`/`startState` added to this whitelist in the
      // SAME change that introduces them, not discovered missing later.
      // `_currentState`/runtime caches (`resolvedWaypointIds` etc, living
      // inside each state's own `movement`) are deliberately NOT persisted
      // here -- they're live runtime state, not authored data, and a fresh
      // Play/Load correctly starts every AI at `startState` again.
      mode: item.entity.ai.mode === 'stateMachine' ? 'stateMachine' : undefined,
      // Dogfood (Signal Relay) fix: this used to assign the LIVE `states`
      // array by direct reference, contradicting the comment right above --
      // a Wander state's `movement.wanderTarget`/`movement.wanderTimer` are
      // written directly onto that SAME live object during Play (see the
      // tick code that does `ai.wanderTarget = new Opus.Vec3(...)`), and
      // Stop does not reset them (nothing here rebuilds `placed` from
      // records between Stop and Play). So any project Saved after so much
      // as ONE Play session touched a Wander AI baked a plain (non-Vec3)
      // `wanderTarget` object straight into the project file -- which then
      // threw `wanderTarget.sub is not a function` on the very next load's
      // first wander tick, since a deserialized plain object has no Vec3
      // methods. Now actually strips the runtime-only fields per state,
      // matching what the comment already claimed happened.
      states: item.entity.ai.mode === 'stateMachine' ? sanitizeAiStatesForSave(item.entity.ai.states) : undefined,
      startState: item.entity.ai.mode === 'stateMachine' ? item.entity.ai.startState : undefined,
    } : null,
    mesh: tag,
    isTrigger: item.isTrigger || undefined,
    triggerRepeat: item.isTrigger ? item.triggerRepeat !== false : undefined,
    triggerShape: item.isTrigger && item.triggerShape === 'sphere' ? 'sphere' : undefined,
    isWaypoint: item.isWaypoint || undefined,
    isRamp: item.isRamp || undefined,
    isBillboard: item.isBillboard || undefined,
    billboardMode: (item.isBillboard && item.billboardMode === 'cylindrical') ? 'cylindrical' : undefined,
    // Wave 6 (Priority K): the linked-prefab reference -- see the
    // instantiation call sites' own comment for why this is root-only and
    // manual-sync-only, never automatically propagated.
    sourcePrefabName: item.sourcePrefabName || undefined,
    // Wave 6 (Priority M): opt-in clip-name-driven Idle/Walk/Run/Attack/Death.
    characterAnimSync: item.characterAnimSync || undefined,
    isSpawnPoint: item.isSpawnPoint || undefined,
    isDefaultSpawn: item.isSpawnPoint ? (item.isDefaultSpawn || undefined) : undefined,
    groupId: item.groupId || undefined,
    solid: item.entity.solid || undefined,
    collider: item.collider ? { shape: item.collider.shape, enabled: item.collider.enabled === false ? false : undefined, offset: item.collider.offset, size: item.collider.size, radius: item.collider.radius } : undefined,
    tags: (item.tags && item.tags.length) ? item.tags.slice() : undefined,
    textureAssetId: item.textureAssetId || undefined,
    // Transform hierarchy (Wave 4). Local fields are plain numbers/arrays,
    // never live Vec3 references -- parentId is a stable id, not an object
    // pointer, so this stays plain portable data with no circular references
    // even when the hierarchy itself has depth.
    parentId: item.parentId || undefined,
    // Wave 7 (Priority A): socketName, saved alongside parentId -- an item
    // attached to a socket IS a hierarchy child (same parentId field), just
    // with this one extra marker telling resolveWorldTransform which of the
    // parent's animated joints to splice into the composition.
    socketName: item.socketName || undefined,
    // Wave 7 (Priority E): OFF by default (undefined, matching every other
    // "omit at default" field in this whitelist) -- opts this object into
    // World State Save Game persistence.
    persistRuntimeState: item.persistRuntimeState || undefined,
    carryable: item.carryable || undefined,
    variables: (item.variables && Object.keys(item.variables).length) ? item.variables : undefined,
    prefabParams: (item.prefabParams && Object.keys(item.prefabParams).length) ? item.prefabParams : undefined,
    localPosition: item.localPosition ? [item.localPosition.x, item.localPosition.y, item.localPosition.z] : undefined,
    localRotationY: (item.parentId && !item.localQuat) ? (item.localRotationY || 0) : undefined,
    localQuat: (item.parentId && item.localQuat) ? quatToArray(item.localQuat) : undefined,
    localScale: item.localScale ? [item.localScale.x, item.localScale.y, item.localScale.z] : undefined,
    // Materials 2.0 -- omitted entirely at defaults so an untouched cube's
    // saved record is byte-for-byte identical to before this feature existed.
    unlit: item.entity.unlit || undefined,
    alpha: (item.entity.alpha !== undefined && item.entity.alpha !== 1) ? item.entity.alpha : undefined,
    emissiveColor: (item.entity.emissiveIntensity) ? item.entity.emissiveColor.slice() : undefined,
    emissiveIntensity: item.entity.emissiveIntensity || undefined,
    uvScale: (item.entity.uvScale && (item.entity.uvScale[0] !== 1 || item.entity.uvScale[1] !== 1)) ? item.entity.uvScale.slice() : undefined,
    uvOffset: (item.entity.uvOffset && (item.entity.uvOffset[0] !== 0 || item.entity.uvOffset[1] !== 0)) ? item.entity.uvOffset.slice() : undefined,
    // Property Animation clips -- plain data (keyframe values are arrays/
    // numbers, never live Vec3s), deep-cloned so a duplicate/reload never
    // aliases the source's track arrays. Runtime playback state (`_anim`)
    // is deliberately NOT included here -- see the definition above.
    animationClips: (item.animationClips && item.animationClips.length) ? JSON.parse(JSON.stringify(item.animationClips)) : undefined,
    // Waypoint Graph connections (Wave 4) -- an array of other Waypoints'
    // stable ids, plain strings, so it rides through the exact same
    // remapObjectIds() whole-JSON id-remapping mechanism Prefabs/Duplicate
    // Level already use for every other internal reference, with zero
    // connections-specific remap code.
    connections: (item.connections && item.connections.length) ? item.connections.slice() : undefined,
    // Wave 9C -- REAL BUG found live dogfooding Forest Range's Scatter
    // Layer Save/Reload: `scatterLayerId` (Wave 8's own ownership tag) was
    // never added to this whitelist, so it was silently dropped by every
    // Save/export since Scatter ownership was introduced -- a generated
    // object still LOOKED owned in the current in-memory session (Erase
    // Scatter Layer worked fine right after painting), but a fresh reload
    // of the exact same saved project produced 0 objects any layer
    // recognized as its own. Exactly the finding-#48 failure mode this
    // whitelist's own comments warn about, which slipped through anyway.
    scatterLayerId: item.scatterLayerId || undefined,
  };
  if (tag === 'custom') {
    const arrays = Opus.Mesh.toArrays(item.entity.mesh);
    record.customMesh = {
      positions: Array.from(arrays.positions),
      normals: Array.from(arrays.normals),
      indices: Array.from(arrays.indices),
    };
  } else if (tag === 'asset') {
    record.assetId = item.assetId; // the shared payload lives in project.assets, not here
    // Wave 6 (Priority C): which clip THIS instance is playing is
    // per-instance state (two placed copies of the same animated asset can
    // play different clips, or one can be frozen while the other loops), so
    // it lives on the record, not the shared asset payload. Omitted when
    // absent/at the asset's own clip-0 default -- an untouched instance's
    // saved record stays unaffected by this field existing at all.
    if (item.entity.skin && item.entity.animationClip !== 0) record.animationClip = item.entity.animationClip;
  }
  return record;
}

// One shared record-shape function for any placed item, cube or not --
// factored out of serializeScene so prefab saving (below) can reuse the
// exact same shape instead of a second, drifting implementation.
function serializeItemRecord(item) {
  if (item.kind === 'cube') return serializeCubeRecord(item);
  // Wave 8 (Priority I): a Path's own container item has no `options`
  // shape at all (unlike camera/spawner/emitter/light below) -- its own
  // fields (`pointIds`/`loop`/`smooth`) ARE the record, no position/
  // direction vectors to convert.
  if (item.kind === 'path') return { kind: 'path', id: item.id, name: item.name, pointIds: (item.pointIds || []).slice(), loop: item.loop || undefined, smooth: item.smooth || undefined };
  const opts = item.options;
  return {
    kind: item.kind,
    id: item.id,
    name: item.name,
    groupId: item.groupId || undefined,
    options: {
      ...opts,
      position: opts.position ? [opts.position.x, opts.position.y, opts.position.z] : undefined,
      direction: opts.direction ? [opts.direction.x, opts.direction.y, opts.direction.z] : undefined,
    },
    parentId: item.parentId || undefined,
    // Wave 7 (Priority A): socketName, saved alongside parentId -- an item
    // attached to a socket IS a hierarchy child (same parentId field), just
    // with this one extra marker telling resolveWorldTransform which of the
    // parent's animated joints to splice into the composition.
    socketName: item.socketName || undefined,
    // Wave 7 (Priority E): OFF by default (undefined, matching every other
    // "omit at default" field in this whitelist) -- opts this object into
    // World State Save Game persistence.
    persistRuntimeState: item.persistRuntimeState || undefined,
    carryable: item.carryable || undefined,
    variables: (item.variables && Object.keys(item.variables).length) ? item.variables : undefined,
    prefabParams: (item.prefabParams && Object.keys(item.prefabParams).length) ? item.prefabParams : undefined,
    localPosition: item.localPosition ? [item.localPosition.x, item.localPosition.y, item.localPosition.z] : undefined,
    localRotationY: (item.parentId && !item.localQuat) ? (item.localRotationY || 0) : undefined,
    localQuat: (item.parentId && item.localQuat) ? quatToArray(item.localQuat) : undefined,
    localScale: item.localScale ? [item.localScale.x, item.localScale.y, item.localScale.z] : undefined,
  };
}
function serializeScene() {
  return placed.map(serializeItemRecord);
}

// The inverse of serializeCubeRecord -- builds a fresh placed item (a new
// engine entity, NOT yet added to `placed` or given an id) from a cube
// record, at the given position. Shared by loadScene (position = the
// record's own saved position) and prefab placement (position = wherever
// the user drops it), so there's one place that knows how to reconstruct a
// cube item from data, instead of two reconstructions drifting apart.
function instantiateCubeRecord(record, position) {
  let mesh = cubeMesh;
  if (record.mesh === 'mine') mesh = mineMesh;
  else if (record.mesh === 'boost') mesh = boostMesh;
  else if (record.mesh === 'wedge') mesh = wedgeMesh;
  else if (record.mesh === 'billboard') mesh = billboardMesh;
  else if (record.mesh === 'custom' && record.customMesh) {
    mesh = Opus.Mesh.fromArrays(
      new Float32Array(record.customMesh.positions),
      new Float32Array(record.customMesh.normals),
      new Uint16Array(record.customMesh.indices),
    );
  } else if (record.mesh === 'asset' && record.assetId) {
    const asset = findAssetById(record.assetId);
    // Missing asset (e.g. a project.assets bundle that failed to load) --
    // falls back to a visible placeholder rather than throwing and aborting
    // the whole scene load, so the rest of the level still comes in intact.
    mesh = asset ? getAssetMeshHandle(asset) : cubeMesh;
  }
  const entity = app.addEntity({
    // Wave 8 (Priority C dogfood, a real bug found via Prefab Parameters'
    // own Color binding): `.slice()`, not the SAME array reference from
    // `record`. `record` (a prefab's own stored record, or a normal
    // instantiate-from-save-data record) is reused for EVERY instance
    // spawned/instantiated from it -- `Entity` stores whatever color array
    // it's given directly (no internal clone), so multiple entities built
    // from the same record used to share ONE mutable color array. A
    // parameter binding (or anything else) mutating one instance's own
    // `entity.color[i]` in place therefore silently repainted EVERY other
    // instance built from the same record too, including ones spawned
    // earlier. Reproduced live: 3 waves of a "ConfigurableEnemy" prefab
    // spawned with 3 different Color parameter overrides all ended up the
    // LAST wave's own color. Fixed with `.slice()` here, the one place
    // every cube-kind instantiation path (palette placement, Spawner,
    // runtime Spawn Prefab, Save/Load) already funnels through.
    mesh, color: record.color.slice(), position, scale: new Opus.Vec3(...record.scale), rotationY: record.rotationY,
  });
  // Full XYZ orientation (Wave 5) -- present only on a record that has
  // genuine pitch/roll (see hasPitchOrRoll's own comment); overrides the
  // Y-only `rotationY` already applied above. A pre-Wave-5 record has no
  // `quaternion` field at all, so `entity.quaternion` stays exactly the
  // pure-Y quaternion the constructor's own `rotationY` param already set.
  if (record.quaternion) entity.quaternion = quatFromArray(record.quaternion);
  if (record.spin) entity.spin = record.spin;
  if (record.patrol) entity.patrol = { ...record.patrol, base: new Opus.Vec3(...record.patrol.base) };
  // `sanitizeAiStatesForSave` on the load side too, defensively -- a project
  // saved before this fix existed (or one hand-edited/round-tripped
  // outside the editor) can already have a polluted plain-object
  // `wanderTarget` baked into `states[*].movement` on disk; loading it
  // straight through would carry that same non-Vec3 object into a fresh
  // session and throw on the very first wander tick.
  if (record.ai) entity.ai = { ...record.ai, base: new Opus.Vec3(...record.ai.base), states: record.ai.mode === 'stateMachine' ? sanitizeAiStatesForSave(record.ai.states) : record.ai.states };
  if (record.solid) entity.solid = true;
  // Wave 6 (Priority C): App.addEntity already set entity.skin/animationClip
  // (defaulting to clip 0) if this asset is a skinned mesh -- override the
  // default ONLY when the record explicitly saved a different clip for
  // THIS instance (see serializeCubeRecord's own comment on why that's
  // per-instance, not per-asset).
  if (entity.skin && record.animationClip !== undefined) entity.animationClip = record.animationClip;
  if (record.textureAssetId) {
    const texAsset = findTextureAssetById(record.textureAssetId);
    if (texAsset) applyTextureToEntity(entity, texAsset);
  }
  if (record.unlit) entity.unlit = true;
  if (record.alpha !== undefined) entity.alpha = record.alpha;
  if (record.emissiveColor) entity.emissiveColor = record.emissiveColor.slice();
  if (record.emissiveIntensity) entity.emissiveIntensity = record.emissiveIntensity;
  if (record.uvScale) entity.uvScale = record.uvScale.slice();
  if (record.uvOffset) entity.uvOffset = record.uvOffset.slice();
  const animationClips = record.animationClips ? JSON.parse(JSON.stringify(record.animationClips)) : undefined;
  return {
    kind: 'cube', entity, behaviors: cloneBehaviors(record.behaviors),
    isTrigger: record.isTrigger || undefined, triggerRepeat: record.triggerRepeat !== false,
    triggerShape: record.triggerShape === 'sphere' ? 'sphere' : undefined,
    collider: record.collider ? JSON.parse(JSON.stringify(record.collider)) : undefined,
    isWaypoint: record.isWaypoint || undefined,
    isRamp: record.isRamp || undefined,
    isBillboard: record.isBillboard || undefined,
    billboardMode: record.billboardMode === 'cylindrical' ? 'cylindrical' : 'full',
    sourcePrefabName: record.sourcePrefabName || undefined,
    characterAnimSync: record.characterAnimSync || undefined,
    isSpawnPoint: record.isSpawnPoint || undefined,
    isDefaultSpawn: record.isDefaultSpawn || undefined,
    tags: record.tags ? record.tags.slice() : undefined,
    assetId: record.assetId || undefined,
    textureAssetId: record.textureAssetId || undefined,
    parentId: record.parentId || undefined,
    socketName: record.socketName || undefined,
    persistRuntimeState: record.persistRuntimeState || undefined,
    carryable: record.carryable || undefined,
    // Wave 8 (Priority B): a plain copy, not a shared reference -- each
    // revived instance (including every member of a Duplicate/Array/Scatter
    // batch built from the SAME source record) gets its own independent
    // `variables` object, never one shared mutable object two instances
    // could silently cross-contaminate through.
    variables: record.variables ? { ...record.variables } : undefined,
    // Dogfood (Signal Relay) fix: a second, untouched copy of the AUTHORED
    // variables, kept alongside the live/mutable `variables` above. Play
    // mutates `variables` in place on this SAME item object (Stop/Play does
    // not rebuild `placed` from records), so without a separate baseline
    // there was nothing for enterPlayMode's fresh-session reset to restore
    // `variables` back to -- every other piece of runtime state
    // (gameState/worldState/objectives/flags/inventory/equipment/held
    // object/...) already resets on every fresh Play, but an object's own
    // `setObjectVariable` writes silently leaked from one Play attempt into
    // the next. See the matching reset in enterPlayMode.
    _authoredVariables: record.variables ? { ...record.variables } : {},
    prefabParams: record.prefabParams ? { ...record.prefabParams } : undefined,
    localPosition: record.localPosition ? new Opus.Vec3(...record.localPosition) : undefined,
    localRotationY: record.parentId ? (record.localRotationY || 0) : undefined,
    localQuat: (record.parentId && record.localQuat) ? quatFromArray(record.localQuat) : undefined,
    localScale: record.localScale ? new Opus.Vec3(...record.localScale) : undefined,
    animationClips,
    connections: record.connections ? record.connections.slice() : undefined,
    scatterLayerId: record.scatterLayerId || undefined, // Wave 9C -- see serializeCubeRecord's own comment; this is the read-back half of that same fix
  };
}

// The non-cube counterpart to instantiateCubeRecord -- camera/spawner/
// emitter only (terrain/water are excluded from both hierarchy and Prefabs
// 2.0: large environment pieces, not the "reusable assembly of parts" use
// case either feature targets). Builds a fresh item, NOT yet added to
// `placed` or given an id/name/groupId (caller's job, same contract as
// instantiateCubeRecord) -- shared by loadScene and Prefabs 2.0 instantiation
// so there is exactly one place that knows how to reconstruct each kind.
function instantiateItemFromRecord(record) {
  const opts = { ...record.options };
  if (opts.position) opts.position = new Opus.Vec3(...opts.position);
  if (opts.direction) opts.direction = new Opus.Vec3(...opts.direction);
  const hierarchyFields = {
    parentId: record.parentId || undefined,
    socketName: record.socketName || undefined,
    persistRuntimeState: record.persistRuntimeState || undefined,
    carryable: record.carryable || undefined,
    // Wave 8 (Priority B): a plain copy, not a shared reference -- each
    // revived instance (including every member of a Duplicate/Array/Scatter
    // batch built from the SAME source record) gets its own independent
    // `variables` object, never one shared mutable object two instances
    // could silently cross-contaminate through.
    variables: record.variables ? { ...record.variables } : undefined,
    _authoredVariables: record.variables ? { ...record.variables } : {}, // see instantiateCubeRecord's own comment on this field
    prefabParams: record.prefabParams ? { ...record.prefabParams } : undefined,
    localPosition: record.localPosition ? new Opus.Vec3(...record.localPosition) : undefined,
    localRotationY: record.parentId ? (record.localRotationY || 0) : undefined,
    localQuat: (record.parentId && record.localQuat) ? quatFromArray(record.localQuat) : undefined,
    localScale: record.localScale ? new Opus.Vec3(...record.localScale) : undefined,
  };
  // Wave 8 (Priority I): a Path has no entity/handle at all -- its own
  // point markers (ordinary `kind:'cube'` records elsewhere in the same
  // level) carry the actual positions; this container just remembers
  // which marker ids, in what order.
  if (record.kind === 'path') return { kind: 'path', name: record.name, pointIds: (record.pointIds || []).slice(), loop: record.loop || false, smooth: record.smooth || false };
  if (record.kind === 'camera') {
    const entity = app.addEntity({ mesh: cubeMesh, color: [0.95, 0.75, 0.15], position: opts.position.clone(), scale: new Opus.Vec3(0.45, 0.45, 0.7) });
    return { kind: 'camera', entity, options: opts, ...hierarchyFields };
  }
  if (record.kind === 'spawner') {
    const entity = app.addEntity({ mesh: cubeMesh, color: [0.95, 0.5, 0.2], position: opts.position.clone(), scale: new Opus.Vec3(0.5, 1.2, 0.5) });
    return { kind: 'spawner', entity, options: opts, ...hierarchyFields };
  }
  if (record.kind === 'light') {
    const isSpot = opts.lightType === 'spot';
    const entity = app.addEntity({ mesh: cubeMesh, color: isSpot ? [1, 0.85, 0.3] : [1, 0.95, 0.6], position: opts.position.clone(), scale: new Opus.Vec3(0.35, 0.35, 0.35) });
    const lightHandle = app.createLight({ type: opts.lightType, position: opts.position.clone(), color: opts.color, intensity: opts.intensity, range: opts.range, angle: opts.angle, direction: opts.direction, enabled: opts.enabled });
    return { kind: 'light', entity, options: opts, lightHandle, ...hierarchyFields };
  }
  // emitter
  const handle = app.createEmitter(opts);
  return { kind: 'emitter', handle, options: opts, ...hierarchyFields };
}

function loadScene(data) {
  deselectAll();
  for (const item of placed.slice()) {
    if (item.kind === 'cube') app.scene.remove(item.entity);
    else if (item.kind === 'terrain') app.removeTerrain(item.handle);
    else if (item.kind === 'water') app.removeWater(item.handle);
    else if (item.kind === 'emitter') app.removeEmitter(item.handle);
    else if (item.kind === 'camera') app.scene.remove(item.entity);
    else if (item.kind === 'spawner') app.scene.remove(item.entity);
    else if (item.kind === 'light') { app.scene.remove(item.entity); app.removeLight(item.lightHandle); }
  }
  placed.length = 0;

  for (const record of data) {
    let item;
    if (record.kind === 'cube') {
      item = instantiateCubeRecord(record, new Opus.Vec3(...record.position));
    } else if (record.kind === 'camera' || record.kind === 'spawner' || record.kind === 'emitter' || record.kind === 'light' || record.kind === 'path') {
      item = instantiateItemFromRecord(record);
    } else {
      const opts = { ...record.options };
      if (opts.position) opts.position = new Opus.Vec3(...opts.position);
      const handle = record.kind === 'terrain' ? app.createTerrain(opts) : app.createWater(opts);
      item = { kind: record.kind, handle, options: opts };
      if (record.kind === 'terrain') syncTerrainLayerTextures(item);
    }
    item.id = record.id;
    item.name = record.name;
    item.groupId = record.groupId;
    addPlaced(item);
  }
  hierarchyTickToken++; // force a fresh resolve pass so every parented item's entity.* reflects its loaded local transform immediately, not next frame
  updateHierarchyTransforms();
  renderSceneList();
}

// --- Undo / redo ---
// Reuses serializeScene/loadScene as the history representation instead of
// a parallel command system — a snapshot IS a full valid scene already.

const MAX_HISTORY = 50;
const undoStack = [];
const redoStack = [];

function updateUndoRedoButtons() {
  document.getElementById('undo-btn').disabled = undoStack.length === 0;
  document.getElementById('redo-btn').disabled = redoStack.length === 0;
}

function pushUndo() {
  undoStack.push(serializeScene());
  if (undoStack.length > MAX_HISTORY) undoStack.shift();
  redoStack.length = 0;
  updateUndoRedoButtons();
}

function undo() {
  if (undoStack.length === 0) return;
  redoStack.push(serializeScene());
  loadScene(undoStack.pop());
  updateUndoRedoButtons();
  showStatus('Undo');
}

function redo() {
  if (redoStack.length === 0) return;
  undoStack.push(serializeScene());
  loadScene(redoStack.pop());
  updateUndoRedoButtons();
  showStatus('Redo');
}

document.getElementById('undo-btn').addEventListener('click', undo);
document.getElementById('redo-btn').addEventListener('click', redo);
window.addEventListener('keydown', (e) => {
  if (!(e.ctrlKey || e.metaKey)) return;
  if (e.key === 'z' && !e.shiftKey) { e.preventDefault(); undo(); }
  else if (e.key === 'y' || (e.key === 'z' && e.shiftKey)) { e.preventDefault(); redo(); }
  else if (e.key === 'd' && !playMode && selectedItem) { e.preventDefault(); duplicateSelected(); }
});
updateUndoRedoButtons();

// Escape to deselect, Delete/Backspace to delete the selection, [ / ] to
// nudge a selected cube's height -- drag-to-move covers X/Z, but Y still
// meant the number field even for a quick lift. All mouse-only otherwise
// (click empty space; the inspector's Delete/number fields) even after
// drag-to-move made the viewport itself the primary way to work with an
// object. Guarded against typing in a field so this can't eat a keystroke
// meant for the message/script textarea or a number input.
window.addEventListener('keydown', (e) => {
  if (playMode) return;
  const tag = document.activeElement && document.activeElement.tagName;
  const isTyping = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT';
  if (e.key === 'Escape') {
    if (isTyping) document.activeElement.blur();
    else deselectAll();
  } else if ((e.key === 'Delete' || e.key === 'Backspace') && !isTyping && selectedItem) {
    e.preventDefault();
    deleteSelected();
  } else if ((e.key === '[' || e.key === ']') && !isTyping && selectedItems.size > 0) {
    const cubes = [...selectedItems].filter((item) => item.kind === 'cube');
    if (cubes.length === 0) return;
    e.preventDefault();
    if (!e.repeat) pushUndo();
    const delta = e.key === ']' ? 0.25 : -0.25;
    for (const item of cubes) item.entity.position.y += delta;
    renderInspector();
  }
});

// Wave 8 (Priority A, Sections 3-7): the ONE generic project dependency
// collector, replacing four independently hand-maintained scanners
// (usedPrefabNames/usedPrefabNamesFromPlayerSettings below, plus one each
// inline in serializeAssets/serializeTextureAssets/serializeAudioAssets)
// that each had to be separately remembered and updated every time a new
// reference-shaped field was added -- confirmed to have already silently
// missed THREE real reference shapes before this fix (Player Visual's own
// `visual.assetId`, an AI State Machine state's own `attack.attackPrefab`,
// and an Animation Event's own `sound` action `audioAssetId` -- see
// API-FRICTION.md #70-72), not assumed from reading the code alone: each
// was verified live by constructing a project where that field was the
// ONLY reference to some asset/prefab and confirming the old scanner
// dropped it silently.
//
// Declarative where practical (Section 6): any `{action, params}`-shaped
// object -- an ordinary fixed-dropdown Behavior, a Node Graph action node
// (whose field values live directly ON the node, not nested under
// `params` -- `runGraphActionNode` calls `executeAction(node.type, node,
// item)`), or an Animation Event -- is scanned via `ACTION_TYPES[action]
// .fields`'s own declared `type` (`'prefab'` -> prefabs, `'audioAsset'`
// -> audio), ONE field-type table, not a hand-copied case per action. This
// is not a general reflection framework (Section 6's own explicit
// boundary): it only ever reads the two field `type`s that are actually
// asset-shaped; every other field type (`text`/`number`/`select`/`target`/
// `objectiveRef`/...) is deliberately never touched here, since a `target`
// is an Object ID reference (a different, already-stable concern this
// collector doesn't need to solve -- Object IDs never travel across an
// export the way prefab/asset library entries do).
const DEPENDENCY_FIELD_BUCKETS = { prefab: 'prefabs', audioAsset: 'audioAssets' };
function collectProjectDependencies() {
  syncCurrentLevelObjects();
  const dep = { prefabs: new Set(), meshAssets: new Set(), textureAssets: new Set(), audioAssets: new Set() };
  function scanActionParams(actionType, params) {
    const def = ACTION_TYPES[actionType];
    if (!def || !params) return;
    for (const f of def.fields) {
      const bucketName = DEPENDENCY_FIELD_BUCKETS[f.type];
      if (bucketName && params[f.key]) dep[bucketName].add(params[f.key]);
    }
  }
  function scanGraph(graph) {
    if (!graph) return;
    for (const node of graph.nodes || []) {
      if (node.type === 'graph' || node.type === 'dialogueTree') continue; // no ACTION_TYPES entry to look field metadata up against
      scanActionParams(node.type, node); // graph nodes store field values directly on themselves
    }
  }
  function scanBehaviors(behaviors) {
    for (const b of behaviors || []) {
      if (b.action === 'graph') scanGraph(b.graph);
      else scanActionParams(b.action, behaviorParams(b, ACTION_TYPES[b.action]));
    }
  }
  function scanAnimationEvents(events) {
    for (const ev of events || []) scanActionParams(ev.action, ev.params);
  }
  // The one place both AI reference shapes (Simple-AI's own `ai.attackPrefab`
  // and a State Machine state's own `attack.attackPrefab`, Wave 7 Priority
  // D) are scanned together -- the exact gap the second State-Machine-only
  // shape fell through before this fix.
  function scanAi(ai) {
    if (!ai) return;
    if (ai.attackEnabled && ai.attackPrefab) dep.prefabs.add(ai.attackPrefab);
    for (const s of ai.states || []) {
      if (s.attack && s.attack.attackEnabled && s.attack.attackPrefab) dep.prefabs.add(s.attack.attackPrefab);
      for (const ea of s.entryActions || []) scanActionParams(ea.action, ea.params);
    }
  }
  // Wave 8 (Priority C/Section 23): a prefab parameter override may itself
  // be a Prefab/Mesh/Texture/Audio reference (e.g. an `attackPrefab`-bound
  // parameter overridden per-instance or per-Spawner-wave) -- resolved
  // against the SOURCE PREFAB's own `parameters` definition (which alone
  // knows each param's declared `type`) to know which bucket a given
  // override value belongs in, since `prefabParams` itself is just
  // `{paramId: value}` with no type info inline.
  function scanPrefabParams(sourcePrefabName, prefabParams) {
    if (!prefabParams) return;
    const prefab = prefabs.find((p) => p.name === sourcePrefabName);
    if (!prefab || !prefab.parameters) return;
    for (const param of prefab.parameters) {
      const value = prefabParams[param.id];
      if (value == null) continue;
      if (param.type === 'prefabReference') dep.prefabs.add(value);
      else if (param.type === 'meshAsset') dep.meshAssets.add(value);
      else if (param.type === 'textureAsset') dep.textureAssets.add(value);
      else if (param.type === 'audioAsset') dep.audioAssets.add(value);
    }
  }
  function scanObjectRecord(record) {
    if (record.kind === 'cube') {
      if (record.mesh === 'asset' && record.assetId) dep.meshAssets.add(record.assetId);
      if (record.textureAssetId) dep.textureAssets.add(record.textureAssetId);
      scanAi(record.ai);
      scanBehaviors(record.behaviors);
      // Post-Wave-9 dogfood -- REAL BUG found live building Signal Relay:
      // a placed instance LINKED to a prefab (`sourcePrefabName`) never
      // added that prefab's own name to `dep.prefabs` -- only a Spawner/
      // AI-attack/weapon-projectile REFERENCE to a prefab name did. A
      // prefab used only for ordinary linked placement (the Wave 6
      // flagship "place from the palette, Duplicate for more, Update From
      // Prefab to re-sync" workflow -- exactly what a real game creator
      // does with a reusable prop) was therefore silently dropped from
      // every Save/Export, even though its PLACED INSTANCES still render
      // correctly (their own resolved fields are baked into the record) --
      // it's continued AUTHORING (Update From Prefab / further Duplicate)
      // after a reload that silently broke, since the prefab definition
      // itself, including its own `parameters`, was simply gone.
      if (record.sourcePrefabName) { dep.prefabs.add(record.sourcePrefabName); scanPrefabParams(record.sourcePrefabName, record.prefabParams); }
    } else if (record.kind === 'terrain') {
      for (const id of terrainLayerTextureIds(record)) dep.textureAssets.add(id);
    } else if (record.kind === 'spawner' && record.options && record.options.prefabName) {
      dep.prefabs.add(record.options.prefabName);
      // Wave 9D (Priority A/Section 9-10): a Spawner's own per-wave
      // `paramOverrides` reuses the SAME `scanPrefabParams` helper the
      // instance-override scan above already calls -- exactly the reuse
      // that helper's own comment already anticipated ("per-Spawner-wave")
      // but this branch had never actually been wired to call.
      scanPrefabParams(record.options.prefabName, record.options.paramOverrides);
    }
  }
  // Player Settings carry their own project-LEVEL reference fields (not
  // attached to any one placed object) -- Fixed Weapon's prefab, the
  // Player Visual's own skinned mesh asset (the fix this collector exists
  // for), and Wave 7's Equipment defs (a visual asset + an optional
  // Projectile-mode weapon prefab per item).
  function scanPlayerSettings(ps) {
    if (!ps) return;
    if (ps.weapon && ps.weapon.enabled && ps.weapon.prefabName) dep.prefabs.add(ps.weapon.prefabName);
    // Wave 9 (Priority A/Section 105): Weapons 2.0's own new asset
    // reference -- the authored Empty Sound -- flows through this SAME
    // generic Player Settings scan, not a feature-specific scanner
    // (Section 105's explicit "do not add feature-specific bundling
    // scanners"). Fixed Weapon's own Empty Sound.
    if (ps.weapon && ps.weapon.emptySoundAssetId) dep.audioAssets.add(ps.weapon.emptySoundAssetId);
    if (ps.visual && ps.visual.assetId) dep.meshAssets.add(ps.visual.assetId);
    for (const eq of ps.equipmentDefs || []) {
      if (eq.assetId) dep.meshAssets.add(eq.assetId);
      if (eq.weapon && eq.weapon.mode === 'projectile' && eq.weapon.prefabName) dep.prefabs.add(eq.weapon.prefabName);
      if (eq.weapon && eq.weapon.emptySoundAssetId) dep.audioAssets.add(eq.weapon.emptySoundAssetId);
    }
  }
  for (const level of levels) {
    for (const record of level.objects) scanObjectRecord(record);
    scanPlayerSettings(level.playerSettings);
    if (level.ambientAudio && level.ambientAudio.audioAssetId) dep.audioAssets.add(level.ambientAudio.audioAssetId);
    // Wave 9C (Priority A/Section 9): Scatter Layer prefab sources flow
    // through this SAME generic per-level scan -- no `usedScatterPrefabNames()`
    // or other feature-specific scanner. A Layer's generated INSTANCES are
    // already ordinary placed cube records (scanned by `scanObjectRecord`
    // above via their own `assetId`/prefab-instance fields); this covers
    // the Layer's own DEFINITION referencing a prefab with zero generated
    // instances yet (e.g. authored, then only ever Undo'd/never painted).
    for (const layer of level.scatterLayers || []) {
      for (const source of layer.sources || []) { if (source.prefabName) dep.prefabs.add(source.prefabName); }
    }
  }
  // Every currently-loaded skinned asset may carry its own Animation Events
  // (asset-level metadata, Wave 7 Priority B) -- scanned unconditionally for
  // every asset (not just ones already known-used), since an event's own
  // action (e.g. `sound`) is what might be the ONLY thing pulling in an
  // audio dependency in the first place.
  for (const asset of assets) if (asset.animationEvents) scanAnimationEvents(asset.animationEvents);
  // Recursive prefab closure (Section 7): a bundled prefab's own record(s)
  // may themselves reference further prefabs/assets (a nested Spawner, a
  // nested Behavior, nested AI) -- repeat until no new prefab name is
  // discovered. `visitedPrefabs` guards cycles (a prefab chain that
  // eventually references itself is scanned exactly once, never looped
  // forever).
  const visitedPrefabs = new Set();
  let frontier = Array.from(dep.prefabs);
  while (frontier.length > 0) {
    const name = frontier.pop();
    if (visitedPrefabs.has(name)) continue;
    visitedPrefabs.add(name);
    const prefab = prefabs.find((p) => p.name === name);
    if (!prefab) continue;
    const records = prefab.records || (prefab.record ? [prefab.record] : []);
    for (const record of records) {
      const before = dep.prefabs.size;
      scanObjectRecord(record);
      if (dep.prefabs.size > before) for (const n of dep.prefabs) if (!visitedPrefabs.has(n)) frontier.push(n);
    }
    // A prefab's own parameter DEFAULTS (not just an instance's override)
    // may themselves be Prefab/Mesh/Texture/Audio references -- real even
    // if no placed instance ever overrides that parameter.
    for (const param of prefab.parameters || []) {
      if (param.default == null) continue;
      if (param.type === 'prefabReference' && !visitedPrefabs.has(param.default)) { dep.prefabs.add(param.default); frontier.push(param.default); }
      else if (param.type === 'meshAsset') dep.meshAssets.add(param.default);
      else if (param.type === 'textureAsset') dep.textureAssets.add(param.default);
      else if (param.type === 'audioAsset') dep.audioAssets.add(param.default);
    }
  }
  return dep;
}

// Wave 8: the two hand-maintained scanners that used to live here
// (`usedPrefabNames`/`usedPrefabNamesFromPlayerSettings`) are superseded by
// `collectProjectDependencies()` above and were removed rather than kept
// dead -- every call site now goes through the one collector.

// --- Levels ---
// A project can hold more than one level (`levels`, declared near
// `placed`); this is the editor-side UI + persistence for it. Kept as
// data alongside `placed`, not a rewrite of `placed` itself, so every
// existing single-level project/game (all of them, as of this batch)
// keeps working unchanged -- a one-entry `levels` array behaves exactly
// like there was never a levels concept at all.
function renderLevelList() {
  const select = document.getElementById('level-select');
  select.innerHTML = levels.map((l, i) => `<option value="${i}"${i === currentLevelIndex ? ' selected' : ''}>${i === startLevelIndex ? '★ ' : ''}${escapeHtml(l.name)}${i === currentLevelIndex ? ' (active)' : ''}</option>`).join('');
  syncLevelDescriptionField();
}
function syncLevelDescriptionField() {
  const index = Number(document.getElementById('level-select').value);
  document.getElementById('level-description-input').value = (!Number.isNaN(index) && levels[index]) ? (levels[index].description || '') : '';
}
document.getElementById('level-select').addEventListener('change', syncLevelDescriptionField);
document.getElementById('level-description-input').addEventListener('input', (e) => {
  const index = Number(document.getElementById('level-select').value);
  if (!Number.isNaN(index) && levels[index]) levels[index].description = e.target.value;
});
document.getElementById('level-transition-mode').addEventListener('change', (e) => { levelTransitionConfig.mode = e.target.value; });
document.getElementById('level-transition-duration').addEventListener('input', (e) => {
  const v = parseFloat(e.target.value);
  if (v > 0) levelTransitionConfig.duration = v;
});
// Sequence required for a fade transition: fade out -> switch level
// (establishes Player/camera/On-Start state exactly like an instant switch
// already does, since it's the SAME underlying function) -> fade in. Uses
// real wall-clock time (setTimeout), not the simulation clock, so it fires
// identically whether or not the game happens to be paused, and needs zero
// special-casing for Delay nodes/timers/Save Game -- none of those are
// touched by this wrapper, only WHEN the existing switch function is called.
function switchLevelWithTransition(index, duringPlay) {
  const switchFn = duringPlay ? switchToLevelDuringPlay : switchToLevel;
  if (levelTransitionConfig.mode !== 'fade') { switchFn(index); return; }
  const overlay = document.getElementById('level-fade-overlay');
  overlay.style.transitionDuration = `${levelTransitionConfig.duration}s`;
  overlay.classList.add('visible');
  setTimeout(() => {
    switchFn(index);
    requestAnimationFrame(() => overlay.classList.remove('visible'));
  }, levelTransitionConfig.duration * 1000);
}
renderLevelList();

// --- Environment ---
// Sky/fog/sun color + fog density (App.setEnvironment, engine/src/22-api.js)
// -- kept PER LEVEL (a night level shouldn't inherit a day level's mood),
// synced lazily the same way `objects` already is: syncCurrentLevelObjects
// captures app.getEnvironment() right before a switch/save/export, so
// there's no separate "dirty" tracking to keep in sync by hand.
// Wave 6 (Priority H): which Texture Asset (if any) is the current level's
// Sky Panorama -- kept as a plain editor-side variable (not read off the
// live app.getEnvironment(), which only ever has the resolved GPU handle,
// never the asset id it came from) so syncCurrentLevelObjects always knows
// what to persist regardless of whether the texture has finished decoding
// yet.
let currentSkyTextureAssetId = null;
function applyLevelEnvironment(index) {
  // normalizeEnvironment reconstructs a real Opus.Vec3 for lightDir --
  // required here because Duplicate Level clones a level's environment via
  // JSON.parse(JSON.stringify(...)) (see duplicate-level-btn), which
  // silently downgrades lightDir from a Vec3 instance to a plain {x,y,z}
  // object; App.setEnvironment validates `instanceof Vec3` and throws on
  // that plain object. The project-load path already normalized on the way
  // in; this in-session path (switching to a level right after duplicating
  // it) never did, so it crashed the moment the duplicate became active --
  // found live dogfooding the Duplicate Level workflow during the UI pass.
  const env = levels[index].environment;
  app.setEnvironment(normalizeEnvironment(env) || DEFAULT_ENVIRONMENT);
  currentSkyTextureAssetId = (env && env.skyTextureAssetId) || null;
  const skyAsset = findTextureAssetById(currentSkyTextureAssetId);
  if (skyAsset) {
    const handle = getTextureHandle(skyAsset);
    if (handle) app.setEnvironment({ skyTexture: handle });
    else (skyAsset.pendingCallbacks = skyAsset.pendingCallbacks || []).push(() => app.setEnvironment({ skyTexture: getTextureHandle(skyAsset) }));
  } else {
    app.setEnvironment({ skyTexture: null });
  }
  renderEnvironmentPanel();
}
function renderEnvironmentPanel() {
  const env = app.getEnvironment();
  document.getElementById('env-sky-horizon').value = rgbToHex(env.skyHorizon);
  document.getElementById('env-sun-color').value = rgbToHex(env.sunColor);
  document.getElementById('env-fog-density').value = env.fogDensity.toFixed(3);
  document.getElementById('env-shadows-enabled').checked = env.shadows.enabled;
  document.getElementById('env-shadows-resolution').value = env.shadows.resolution;
  document.getElementById('env-shadows-distance').value = env.shadows.distance;
  document.getElementById('env-shadows-bias').value = env.shadows.bias;
  const skySelect = document.getElementById('env-sky-texture');
  if (skySelect) {
    skySelect.innerHTML = `<option value="">None (procedural gradient)</option>${textureAssets.map((t) => `<option value="${t.id}" ${currentSkyTextureAssetId === t.id ? 'selected' : ''}>${escapeHtml(t.name)}</option>`).join('')}`;
  }
}
for (const [id, key] of [['env-sky-horizon', 'skyHorizon'], ['env-sun-color', 'sunColor']]) {
  document.getElementById(id).oninput = (e) => app.setEnvironment({ [key]: hexToRgb(e.target.value) });
}
document.getElementById('env-fog-density').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (!Number.isNaN(v) && v >= 0) app.setEnvironment({ fogDensity: v });
};
// Wave 6 (Priority H): switching the Sky Panorama selector resolves the
// chosen Texture Asset to a live handle (or clears it entirely for "None"),
// the same lazy getTextureHandle any OTHER texture picker in this editor
// already uses -- no second texture-loading path for sky panoramas.
document.getElementById('env-sky-texture').onchange = (e) => {
  pushUndo();
  currentSkyTextureAssetId = e.target.value || null;
  const asset = findTextureAssetById(currentSkyTextureAssetId);
  if (asset) {
    const handle = getTextureHandle(asset);
    if (handle) app.setEnvironment({ skyTexture: handle });
    else (asset.pendingCallbacks = asset.pendingCallbacks || []).push(() => app.setEnvironment({ skyTexture: getTextureHandle(asset) }));
  } else {
    app.setEnvironment({ skyTexture: null });
  }
};
// Priority H's shadow feature had a real engine API (App.configureShadows)
// but no editor authoring surface at all until now -- meaning no shipped
// project could ever actually turn it on. Folded into the same
// setEnvironment/getEnvironment round-trip as every other environment
// field (see 22-api.js), so this is the ONE new place it needed wiring.
document.getElementById('env-shadows-enabled').onchange = (e) => app.setEnvironment({ shadows: { enabled: e.target.checked } });
document.getElementById('env-shadows-resolution').onchange = (e) => {
  const v = parseInt(e.target.value, 10);
  if (v > 0) app.setEnvironment({ shadows: { resolution: v } });
};
document.getElementById('env-shadows-distance').onchange = (e) => {
  const v = parseFloat(e.target.value);
  if (v > 0) app.setEnvironment({ shadows: { distance: v } });
};
document.getElementById('env-shadows-bias').onchange = (e) => {
  const v = parseFloat(e.target.value);
  if (!Number.isNaN(v) && v >= 0) app.setEnvironment({ shadows: { bias: v } });
};

function applyLevelPlayerSettings(index) {
  const saved = levels[index].playerSettings;
  currentPlayerSettings = saved ? Object.assign(defaultPlayerSettings(saved.controllerType), saved) : defaultPlayerSettings('hovercraft');
  renderPlayerSettingsPanel();
}
// Wave 6B (Priority A/Sections 3-6): the dynamic body of the Player Visual
// section -- built in JS (not static HTML) because the clip-mapping
// dropdowns need options populated from whichever skinned asset is
// currently selected, and that set changes as the author picks a
// different asset.
function renderPlayerVisualPanel() {
  const visual = currentPlayerSettings.visual || (currentPlayerSettings.visual = defaultPlayerVisual());
  document.getElementById('player-visual-mode').value = visual.mode;
  const bodyEl = document.getElementById('player-visual-body');
  if (visual.mode !== 'skinned') { bodyEl.innerHTML = ''; return; }
  const skinnedAssets = assets.filter((a) => a.type === 'skinnedMesh');
  const selectedAsset = findAssetById(visual.assetId);
  const clipNames = (selectedAsset && selectedAsset.skin) ? selectedAsset.skin.clips.map((c) => c.name) : [];
  const roleRow = (role, label) => `
    <div class="field-row"><label style="font-size:10px;color:#66759a">${label}</label>
      <select data-visual-clip-role="${role}">
        <option value="">None</option>
        ${clipNames.map((n, i) => `<option value="${i}" ${visual.clipMap[role] === i ? 'selected' : ''}>${escapeHtml(n)}</option>`).join('')}
      </select>
    </div>`;
  bodyEl.innerHTML = `
    <div class="field-row"><label style="font-size:10px;color:#66759a">Mesh Asset</label>
      <select id="player-visual-asset">
        <option value="">Choose a skinned asset...</option>
        ${skinnedAssets.map((a) => `<option value="${a.id}" ${visual.assetId === a.id ? 'selected' : ''}>${escapeHtml(a.name)}</option>`).join('')}
      </select>
    </div>
    ${skinnedAssets.length === 0 ? '<p style="color:#66759a;font-size:11px;margin:2px 0">No skinned assets imported yet -- use Import Model with a skinned glTF/GLB file.</p>' : ''}
    <div class="field-triple">
      <div><label style="font-size:10px;color:#66759a">Scale</label><input type="number" id="player-visual-scale" step="0.1" min="0.05" value="${visual.scale}"></div>
      <div><label style="font-size:10px;color:#66759a">Rotation Offset (deg)</label><input type="number" id="player-visual-rot" step="5" value="${visual.rotationOffsetY}"></div>
    </div>
    <div class="field-triple">
      <div><label style="font-size:10px;color:#66759a">Offset X</label><input type="number" id="player-visual-offx" step="0.05" value="${visual.positionOffset.x}"></div>
      <div><label style="font-size:10px;color:#66759a">Offset Y</label><input type="number" id="player-visual-offy" step="0.05" value="${visual.positionOffset.y}"></div>
      <div><label style="font-size:10px;color:#66759a">Offset Z</label><input type="number" id="player-visual-offz" step="0.05" value="${visual.positionOffset.z}"></div>
    </div>
    ${selectedAsset ? `
    <div class="field-row"><label>Animation Clip Mapping</label>
      <button id="player-visual-autodetect-btn" class="toolbar-btn" style="margin-bottom:6px">Auto Detect Clips</button>
    </div>
    ${roleRow('idle', 'Idle Clip')}${roleRow('walk', 'Walk Clip')}${roleRow('run', 'Run / Sprint Clip')}
    ${roleRow('jump', 'Jump Clip')}${roleRow('fall', 'Fall Clip (optional)')}
    ${roleRow('attack', 'Attack Clip')}${roleRow('death', 'Death Clip (optional)')}
    <div class="field-row"><label style="font-size:10px;color:#66759a">Locomotion Blend Time (s)</label><input type="number" id="player-visual-blend" step="0.05" min="0" value="${visual.blendTime}"></div>
    ` : ''}
  `;
  const assetSelect = document.getElementById('player-visual-asset');
  if (assetSelect) assetSelect.onchange = (e) => { pushUndo(); visual.assetId = e.target.value || null; renderPlayerVisualPanel(); };
  const scaleEl = document.getElementById('player-visual-scale');
  if (scaleEl) scaleEl.oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) visual.scale = v; };
  const rotEl = document.getElementById('player-visual-rot');
  if (rotEl) rotEl.oninput = (e) => { visual.rotationOffsetY = parseFloat(e.target.value) || 0; };
  for (const axis of ['x', 'y', 'z']) {
    const el = document.getElementById(`player-visual-off${axis}`);
    if (el) el.oninput = (e) => { visual.positionOffset[axis] = parseFloat(e.target.value) || 0; };
  }
  const blendEl = document.getElementById('player-visual-blend');
  if (blendEl) blendEl.oninput = (e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v) && v >= 0) visual.blendTime = v; };
  bodyEl.querySelectorAll('[data-visual-clip-role]').forEach((sel) => {
    sel.onchange = (e) => {
      pushUndo();
      visual.clipMap[sel.dataset.visualClipRole] = e.target.value === '' ? null : Number(e.target.value);
    };
  });
  // Section 6: Auto Detect -- the SAME name-matching keyword table
  // CHARACTER_ANIM_KEYWORDS already uses for AI Auto-Animate, applied once
  // to fill every unmapped role, then left fully overridable (this is a
  // one-shot convenience button, not a live/continuous auto-detect that
  // would fight an author's own explicit choice).
  const autoBtn = document.getElementById('player-visual-autodetect-btn');
  if (autoBtn) {
    autoBtn.onclick = () => {
      pushUndo();
      const mapped = autoDetectPlayerClips(visual, selectedAsset);
      renderPlayerVisualPanel();
      showStatus(`Auto-detected clip mapping from clip names (${mapped}/7 mapped)`);
    };
  }
}
// Factored out of the "Auto Detect Clips" button above so the Priority H
// "Create Animated Player" preset helper (below) can run the exact same
// name-matching pass -- one shared implementation, not two copies that
// could drift apart. Returns how many of the 7 roles got mapped.
function autoDetectPlayerClips(visual, selectedAsset) {
  const fakeEntity = { skin: selectedAsset.skin };
  let mapped = 0;
  for (const role of Object.keys(visual.clipMap)) {
    const idx = findCharacterClip(fakeEntity, CHARACTER_ANIM_KEYWORDS[role] || [role]);
    if (idx !== null) { visual.clipMap[role] = idx; mapped++; }
  }
  return mapped;
}
// Wave 6B (Priority H): "Create Animated Player" -- the one-click version of
// "choose skinned asset -> auto-detect clips -> choose controller ->
// configure speeds" the spec asks for. Reuses every existing piece (the
// real controller-type <select>'s own onchange handler for the
// preserve-across-switch logic, defaultPlayerVisual, autoDetectPlayerClips
// above) rather than a second parallel setup path -- speeds are left at
// Third-Person's own sensible DEFAULT_PLAYER_SETTINGS (already configured,
// nothing new needed there).
document.getElementById('create-animated-player-btn').addEventListener('click', () => {
  const skinnedAssets = assets.filter((a) => a.type === 'skinnedMesh');
  if (skinnedAssets.length === 0) { showStatus('Import a skinned model first (Assets tab -> Import Model)'); return; }
  pushUndo();
  const typeSelect = document.getElementById('player-controller-type');
  typeSelect.value = 'thirdperson';
  typeSelect.dispatchEvent(new Event('change'));
  const visual = currentPlayerSettings.visual || (currentPlayerSettings.visual = defaultPlayerVisual());
  visual.mode = 'skinned';
  if (!visual.assetId || !findAssetById(visual.assetId)) visual.assetId = skinnedAssets[0].id;
  const selectedAsset = findAssetById(visual.assetId);
  const mapped = autoDetectPlayerClips(visual, selectedAsset);
  renderPlayerSettingsPanel();
  showStatus(`✨ Animated Player created -- ${selectedAsset.name}, ${mapped}/7 clips auto-mapped`);
});
function renderPlayerSettingsPanel() {
  const s = currentPlayerSettings;
  document.getElementById('player-controller-type').value = s.controllerType;
  const tunablesEl = document.getElementById('player-tunables');
  if (s.controllerType === 'hovercraft') {
    tunablesEl.style.display = 'none';
  } else {
    tunablesEl.style.display = '';
    document.getElementById('player-move-speed').value = s.moveSpeed;
    document.getElementById('player-acceleration').value = s.acceleration;
  }
  // Jump/vertical physics is Third-Person's OPT-IN toggle (Hovercraft
  // already flies, Top-Down has no camera angle that would show vertical
  // motion) -- off by default, see the comment above updateThirdPersonController.
  // First-Person always has vertical physics (there's no "FPS without
  // gravity" default worth offering), so it shows the same Gravity/Jump
  // Speed tunables unconditionally, with no enable checkbox at all.
  const jumpRowEl = document.getElementById('player-jump-row');
  const jumpTunablesEl = document.getElementById('player-jump-tunables');
  const fpTunablesEl = document.getElementById('player-fp-tunables');
  if (s.controllerType === 'thirdperson') {
    jumpRowEl.style.display = '';
    document.getElementById('player-jump-enabled').checked = !!s.jumpEnabled;
    jumpTunablesEl.style.display = s.jumpEnabled ? '' : 'none';
    document.getElementById('player-gravity').value = s.gravity != null ? s.gravity : 20;
    document.getElementById('player-jump-speed').value = s.jumpSpeed != null ? s.jumpSpeed : 8;
    fpTunablesEl.style.display = 'none';
  } else if (s.controllerType === 'firstperson') {
    jumpRowEl.style.display = 'none';
    jumpTunablesEl.style.display = '';
    document.getElementById('player-gravity').value = s.gravity != null ? s.gravity : 20;
    document.getElementById('player-jump-speed').value = s.jumpSpeed != null ? s.jumpSpeed : 8;
    fpTunablesEl.style.display = '';
    document.getElementById('player-fp-fov').value = s.fovDegrees != null ? s.fovDegrees : 70;
    document.getElementById('player-fp-eye-height').value = s.eyeHeight != null ? s.eyeHeight : 0.6;
    document.getElementById('player-fp-sensitivity').value = s.mouseSensitivity != null ? s.mouseSensitivity : 0.0022;
  } else {
    jumpRowEl.style.display = 'none';
    jumpTunablesEl.style.display = 'none';
    fpTunablesEl.style.display = 'none';
  }
  // Wave 6B (Priority J): Footstep audio -- Third-Person/First-Person only,
  // same scoping Crouch/Sprint (Priority B) already established.
  const footstepRowEl = document.getElementById('player-footstep-row');
  if (s.controllerType === 'thirdperson' || s.controllerType === 'firstperson') {
    footstepRowEl.style.display = '';
    const assetSelect = document.getElementById('player-footstep-asset');
    assetSelect.innerHTML = `<option value="">None</option>${audioAssets.map((a) => `<option value="${escapeHtml(a.id)}"${s.footstepAudioAssetId === a.id ? ' selected' : ''}>${escapeHtml(a.name)}</option>`).join('')}`;
    document.getElementById('player-footstep-interval').value = s.footstepInterval ?? 0.4;
    document.getElementById('player-footstep-walk-vol').value = s.footstepWalkVolume ?? 0.5;
    document.getElementById('player-footstep-run-vol').value = s.footstepRunVolume ?? 0.7;
  } else {
    footstepRowEl.style.display = 'none';
  }
  // Wave 6B (Priority A/Section 2): Player Visual only offered for
  // Third-Person/Top-Down -- First-Person keeps its invisible-body
  // convention, per this priority's own explicit scope.
  const visualSectionEl = document.getElementById('player-visual-section');
  if (s.controllerType === 'thirdperson' || s.controllerType === 'topdown') {
    visualSectionEl.style.display = '';
    renderPlayerVisualPanel();
  } else {
    visualSectionEl.style.display = 'none';
  }
  document.getElementById('player-max-health').value = s.maxHealth != null ? s.maxHealth : 100;
  // Weapon (Wave 4) -- a single reusable primitive attached to Player
  // Settings rather than a separate placeable "Weapon" object, per the
  // explicit "do not build an inventory full of weapons, one reusable
  // primitive is enough" scope. Fires via Fire Projectile internally (see
  // fireProjectile()), so the runtime projectile system has exactly one
  // implementation regardless of whether it's the Player, an AI, or a
  // Node Graph that triggered it.
  const weapon = s.weapon || defaultWeaponConfig();
  document.getElementById('player-weapon-enabled').checked = !!weapon.enabled;
  document.getElementById('player-weapon-tunables').style.display = weapon.enabled ? '' : 'none';
  // Wave 7 (Priority C/Section 20): Weapon Source -- 'fixed' (default,
  // every pre-Wave-7 project) keeps the fields below as the real weapon.
  // 'equipment' means those fields describe nothing at runtime; the fields
  // below stay visible (not worth a second parallel form) but are
  // explicitly noted as ignored, and the ACTUAL stats come from whatever
  // Equipment Item's own `weapon` sub-config is currently in Primary Hand
  // (see resolveActivePlayerWeapon).
  document.getElementById('player-weapon-source').value = weapon.source === 'equipment' ? 'equipment' : 'fixed';
  document.getElementById('player-weapon-mode-row').style.opacity = weapon.source === 'equipment' ? '0.45' : '1';
  document.getElementById('player-weapon-prefab-row').style.opacity = weapon.source === 'equipment' ? '0.45' : '1';
  // Weapon Mode (Wave 5, Priority F/section 33) -- Projectile keeps a real
  // travel-time object (needs a Prefab, has a Speed); Hitscan is an
  // instant ray and Melee an instant radius/cone check (neither needs a
  // Prefab or Speed; both reuse the Range field -- ray length for Hitscan,
  // reach for Melee). All three ultimately resolve through the same
  // applyHitDamage -- see fireAttack/fireHitscan/fireMelee.
  const isHitscan = weapon.mode === 'hitscan';
  const isMelee = weapon.mode === 'melee';
  const isPrefabless = isHitscan || isMelee;
  document.getElementById('player-weapon-mode').value = isHitscan ? 'hitscan' : isMelee ? 'melee' : 'projectile';
  document.getElementById('player-weapon-prefab-row').style.display = isPrefabless ? 'none' : '';
  document.getElementById('player-weapon-speed-wrap').style.display = isPrefabless ? 'none' : '';
  document.getElementById('player-weapon-range-wrap').style.display = isPrefabless ? '' : 'none';
  document.getElementById('player-weapon-prefab-wrap').innerHTML = prefabs.length === 0
    ? '<p style="color:#8592a8;font-size:11.5px;margin:2px 0">No prefabs saved yet.</p>'
    : renderActionFieldInput({ key: 'prefabName', type: 'prefab' }, weapon.prefabName, 'player-weapon-prefab');
  const prefabSel = document.getElementById('player-weapon-prefab');
  if (prefabSel) prefabSel.onchange = (e) => { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.prefabName = e.target.value; };
  document.getElementById('player-weapon-cooldown').value = weapon.cooldown;
  document.getElementById('player-weapon-damage').value = weapon.damage;
  document.getElementById('player-weapon-speed').value = weapon.speed;
  document.getElementById('player-weapon-range').value = weapon.range != null ? weapon.range : 50;
  document.getElementById('player-weapon-fire-on-event').checked = !!weapon.fireOnAnimationEvent;
  document.getElementById('player-weapon-knockback').value = weapon.knockback || 0;
  document.getElementById('player-weapon-muzzle-socket').value = weapon.muzzleSocket || '';
  // Wave 9 (Priority A): Ammo/Reload/Fire Mode/Spread/Recoil/Noise/
  // Crosshair -- same "always render, exec() reads whichever mode applies"
  // pattern the rest of this panel already uses.
  document.getElementById('player-weapon-ammomode').value = weapon.ammoMode || 'infinite';
  document.getElementById('player-weapon-ammo-fields').style.display = (weapon.ammoMode === 'magazine') ? '' : 'none';
  document.getElementById('player-weapon-magsize').value = weapon.magazineSize != null ? weapon.magazineSize : 30;
  document.getElementById('player-weapon-startmag').value = weapon.startingMagazine != null ? weapon.startingMagazine : 30;
  document.getElementById('player-weapon-reserve').value = weapon.reserveAmmo != null ? weapon.reserveAmmo : 90;
  document.getElementById('player-weapon-reload-duration').value = weapon.reloadDuration != null ? weapon.reloadDuration : 1.5;
  document.getElementById('player-weapon-firemode').value = weapon.fireMode === 'auto' ? 'auto' : 'semi';
  document.getElementById('player-weapon-spread').value = weapon.spreadDegrees || 0;
  document.getElementById('player-weapon-recoil-v').value = weapon.recoilVertical || 0;
  document.getElementById('player-weapon-recoil-h').value = weapon.recoilHorizontal || 0;
  document.getElementById('player-weapon-emit-noise').checked = !!weapon.emitNoiseOnFire;
  document.getElementById('player-weapon-noise-radius').value = weapon.noiseRadius != null ? weapon.noiseRadius : 18;
  document.getElementById('player-weapon-crosshair').checked = weapon.crosshair !== false;
  // Wave 9D (Priority B): muzzle/impact effect fields -- same "always
  // render, exec() reads whichever fields apply" pattern this whole panel
  // already established.
  document.getElementById('player-weapon-fire-audio-wrap').innerHTML = renderActionFieldInput({ key: 'fireAudioAssetId', type: 'audioAsset' }, weapon.fireAudioAssetId, 'player-weapon-fire-audio');
  const fireAudioSel = document.getElementById('player-weapon-fire-audio');
  if (fireAudioSel) fireAudioSel.onchange = (e) => { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.fireAudioAssetId = e.target.value || undefined; };
  document.getElementById('player-weapon-muzzle-fx').checked = !!weapon.muzzleEffect;
  document.getElementById('player-weapon-muzzle-color').value = weapon.muzzleEffectColor || '#ffcc55';
  document.getElementById('player-weapon-impact-audio-wrap').innerHTML = renderActionFieldInput({ key: 'impactAudioAssetId', type: 'audioAsset' }, weapon.impactAudioAssetId, 'player-weapon-impact-audio');
  const impactAudioSel = document.getElementById('player-weapon-impact-audio');
  if (impactAudioSel) impactAudioSel.onchange = (e) => { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.impactAudioAssetId = e.target.value || undefined; };
  document.getElementById('player-weapon-impact-fx').checked = !!weapon.impactEffect;
  document.getElementById('player-weapon-impact-color').value = weapon.impactEffectColor || '#e6e6dd';
  document.getElementById('player-weapon-tracer').checked = !!weapon.tracer;
  renderEquipmentDefList();
}
// Wave 7 (Priority C/Section 18): Equipment Items editor -- a real list-row
// UI over `currentPlayerSettings.equipmentDefs`, the same "build the DOM in
// JS, wire handlers after" pattern the Socket Editor/Animation Events list
// already established. Each row: Item Name (must match an Inventory item
// name to actually be equippable), Slot, visual Asset, Socket name (a plain
// text field -- the socket itself is authored on the PLAYER VISUAL's own
// asset, via that asset's ordinary Socket Editor, Priority A), and an
// optional Weapon sub-config (Mode/Damage/Range/Speed/Prefab) gated behind
// a checkbox so a purely-cosmetic equip (a flashlight, a badge) doesn't
// need to fill in irrelevant weapon fields.
function equipmentSlotOptions(current) {
  return ['primaryHand', 'secondaryHand', 'body'].map((s) => `<option value="${s}"${current === s ? ' selected' : ''}>${s}</option>`).join('');
}
function renderEquipmentDefList() {
  const listEl = document.getElementById('equipment-def-list');
  if (!listEl) return;
  currentPlayerSettings.equipmentDefs = currentPlayerSettings.equipmentDefs || [];
  const defs = currentPlayerSettings.equipmentDefs;
  const skinnedAssets = assets.filter((a) => a.type === 'skinnedMesh' || a.type === 'mesh');
  if (defs.length === 0) {
    listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No equipment items yet -- add one below.</p>';
  } else {
    listEl.innerHTML = defs.map((d, i) => `
      <div class="hud-element-row" data-eqdef-index="${i}">
        <div class="hud-element-row-header">
          <span>${escapeHtml(d.itemName || '(unnamed)')} -> ${escapeHtml(d.slot)}</span>
          <button class="hud-remove-btn" data-eqdef-remove="${i}" title="Delete">✕</button>
        </div>
        <div class="field-triple">
          <input type="text" data-eqdef-name="${i}" value="${escapeHtml(d.itemName || '')}" placeholder="Item name (e.g. Rifle)">
          <select data-eqdef-slot="${i}">${equipmentSlotOptions(d.slot)}</select>
          <select data-eqdef-asset="${i}"><option value="">(no visual)</option>${skinnedAssets.map((a) => `<option value="${a.id}"${d.assetId === a.id ? ' selected' : ''}>${escapeHtml(a.name)}</option>`).join('')}</select>
        </div>
        <div class="field-triple" style="margin-top:4px">
          <input type="text" data-eqdef-socket="${i}" value="${escapeHtml(d.socketName || '')}" placeholder="Socket name (e.g. RightHand)">
          <label style="display:flex;align-items:center;gap:6px;font-size:11px;color:#c7d3ea"><input type="checkbox" data-eqdef-hasweapon="${i}"${d.weapon ? ' checked' : ''}> Weapon</label>
        </div>
        ${d.weapon ? `
        <div class="field-triple" style="margin-top:4px">
          <select data-eqdef-wmode="${i}">
            <option value="projectile"${d.weapon.mode === 'projectile' || !d.weapon.mode ? ' selected' : ''}>Projectile</option>
            <option value="hitscan"${d.weapon.mode === 'hitscan' ? ' selected' : ''}>Hitscan</option>
            <option value="melee"${d.weapon.mode === 'melee' ? ' selected' : ''}>Melee</option>
          </select>
          <input type="number" data-eqdef-wdamage="${i}" value="${d.weapon.damage != null ? d.weapon.damage : 10}" placeholder="Damage">
          <input type="number" data-eqdef-wrange="${i}" value="${d.weapon.range != null ? d.weapon.range : 20}" placeholder="Range">
        </div>` : ''}
      </div>`).join('');
  }
  listEl.querySelectorAll('[data-eqdef-remove]').forEach((btn) => {
    btn.onclick = () => { pushUndo(); defs.splice(Number(btn.dataset.eqdefRemove), 1); renderEquipmentDefList(); };
  });
  listEl.querySelectorAll('[data-eqdef-name]').forEach((input) => { input.oninput = () => { defs[Number(input.dataset.eqdefName)].itemName = input.value; }; });
  listEl.querySelectorAll('[data-eqdef-slot]').forEach((sel) => { sel.onchange = () => { pushUndo(); defs[Number(sel.dataset.eqdefSlot)].slot = sel.value; }; });
  listEl.querySelectorAll('[data-eqdef-asset]').forEach((sel) => { sel.onchange = () => { pushUndo(); defs[Number(sel.dataset.eqdefAsset)].assetId = sel.value || null; }; });
  listEl.querySelectorAll('[data-eqdef-socket]').forEach((input) => { input.oninput = () => { defs[Number(input.dataset.eqdefSocket)].socketName = input.value; }; });
  listEl.querySelectorAll('[data-eqdef-hasweapon]').forEach((cb) => {
    cb.onchange = () => { pushUndo(); const d = defs[Number(cb.dataset.eqdefHasweapon)]; d.weapon = cb.checked ? { mode: 'hitscan', damage: 10, range: 20 } : undefined; renderEquipmentDefList(); };
  });
  listEl.querySelectorAll('[data-eqdef-wmode]').forEach((sel) => { sel.onchange = () => { defs[Number(sel.dataset.eqdefWmode)].weapon.mode = sel.value; }; });
  listEl.querySelectorAll('[data-eqdef-wdamage]').forEach((input) => { input.oninput = () => { const v = parseFloat(input.value); if (!Number.isNaN(v)) defs[Number(input.dataset.eqdefWdamage)].weapon.damage = v; }; });
  listEl.querySelectorAll('[data-eqdef-wrange]').forEach((input) => { input.oninput = () => { const v = parseFloat(input.value); if (!Number.isNaN(v)) defs[Number(input.dataset.eqdefWrange)].weapon.range = v; }; });
  const addBtn = document.getElementById('equipment-def-add-btn');
  if (addBtn) {
    addBtn.onclick = () => {
      pushUndo();
      defs.push({ itemName: '', slot: 'primaryHand', assetId: null, socketName: '', weapon: undefined });
      renderEquipmentDefList();
    };
  }
}
// `mode: 'projectile'` is the default -- every project saved before Wave 5
// has no `mode` field at all, and reads it as `undefined`, which every
// `weapon.mode === 'hitscan'` check below treats as "not hitscan," i.e.
// projectile, its only possible behavior before this field existed.
function defaultWeaponConfig() { return { enabled: false, prefabName: '', cooldown: 0.4, damage: 10, speed: 18, mode: 'projectile', range: 50 }; }
document.getElementById('player-controller-type').onchange = (e) => {
  const prevMaxHealth = currentPlayerSettings.maxHealth;
  const prevVisual = currentPlayerSettings.visual; // Wave 6B: a configured Player Visual survives a controller switch too, same reasoning as maxHealth below
  // Wave 6B (Priority J): footstep config survives a controller switch too --
  // switching from Third-Person to First-Person (both footstep-eligible)
  // shouldn't silently lose an author's chosen sound/interval/volumes.
  const prevFootsteps = { footstepAudioAssetId: currentPlayerSettings.footstepAudioAssetId, footstepInterval: currentPlayerSettings.footstepInterval, footstepWalkVolume: currentPlayerSettings.footstepWalkVolume, footstepRunVolume: currentPlayerSettings.footstepRunVolume };
  currentPlayerSettings = defaultPlayerSettings(e.target.value);
  if (prevMaxHealth != null) currentPlayerSettings.maxHealth = prevMaxHealth; // switching controller shouldn't reset health tuning
  if (prevVisual) currentPlayerSettings.visual = prevVisual;
  if (prevFootsteps.footstepAudioAssetId != null) Object.assign(currentPlayerSettings, prevFootsteps);
  renderPlayerSettingsPanel();
  renderInputActionPanel(); // Wave 5: which actions are relevant/shown depends on the controller type
};
document.getElementById('player-visual-mode').onchange = (e) => {
  pushUndo();
  const visual = currentPlayerSettings.visual || (currentPlayerSettings.visual = defaultPlayerVisual());
  visual.mode = e.target.value;
  renderPlayerVisualPanel();
};
document.getElementById('player-move-speed').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (!Number.isNaN(v) && v > 0) currentPlayerSettings.moveSpeed = v;
};
document.getElementById('player-acceleration').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (!Number.isNaN(v) && v > 0) currentPlayerSettings.acceleration = v;
};
document.getElementById('player-max-health').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (!Number.isNaN(v) && v > 0) currentPlayerSettings.maxHealth = v;
};
document.getElementById('player-jump-enabled').onchange = (e) => {
  currentPlayerSettings.jumpEnabled = e.target.checked;
  renderPlayerSettingsPanel();
};
document.getElementById('player-gravity').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (!Number.isNaN(v) && v > 0) currentPlayerSettings.gravity = v;
};
document.getElementById('player-jump-speed').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (!Number.isNaN(v) && v > 0) currentPlayerSettings.jumpSpeed = v;
};
document.getElementById('player-fp-fov').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (!Number.isNaN(v) && v >= 30 && v <= 120) { currentPlayerSettings.fovDegrees = v; if (playMode && player && player.controllerType === 'firstperson') app.camera.fovY = v * Math.PI / 180; }
};
document.getElementById('player-fp-eye-height').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (!Number.isNaN(v) && v >= 0) currentPlayerSettings.eyeHeight = v;
};
document.getElementById('player-fp-sensitivity').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (!Number.isNaN(v) && v > 0) currentPlayerSettings.mouseSensitivity = v;
};
document.getElementById('player-footstep-asset').onchange = (e) => { currentPlayerSettings.footstepAudioAssetId = e.target.value || null; };
document.getElementById('player-footstep-interval').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (!Number.isNaN(v) && v > 0) currentPlayerSettings.footstepInterval = v;
};
document.getElementById('player-footstep-walk-vol').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (!Number.isNaN(v) && v >= 0 && v <= 1) currentPlayerSettings.footstepWalkVolume = v;
};
document.getElementById('player-footstep-run-vol').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (!Number.isNaN(v) && v >= 0 && v <= 1) currentPlayerSettings.footstepRunVolume = v;
};
document.getElementById('player-weapon-enabled').onchange = (e) => {
  currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig();
  currentPlayerSettings.weapon.enabled = e.target.checked;
  renderPlayerSettingsPanel();
};
document.getElementById('player-weapon-cooldown').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (v > 0) { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.cooldown = v; }
};
document.getElementById('player-weapon-damage').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (v >= 0) { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.damage = v; }
};
document.getElementById('player-weapon-speed').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (v > 0) { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.speed = v; }
};
document.getElementById('player-weapon-mode').onchange = (e) => {
  currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig();
  currentPlayerSettings.weapon.mode = e.target.value;
  renderPlayerSettingsPanel();
};
document.getElementById('player-weapon-range').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (v > 0) { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.range = v; }
};
document.getElementById('player-weapon-fire-on-event').onchange = (e) => {
  currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig();
  currentPlayerSettings.weapon.fireOnAnimationEvent = e.target.checked;
};
document.getElementById('player-weapon-knockback').oninput = (e) => {
  const v = parseFloat(e.target.value);
  if (v >= 0) { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.knockback = v; }
};
document.getElementById('player-weapon-muzzle-socket').oninput = (e) => {
  currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig();
  currentPlayerSettings.weapon.muzzleSocket = e.target.value || undefined;
};
document.getElementById('player-weapon-source').onchange = (e) => {
  currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig();
  currentPlayerSettings.weapon.source = e.target.value;
  renderPlayerSettingsPanel();
};
// Wave 9 (Priority A) -- Ammo/Reload/Fire Mode/Spread/Recoil/Noise/Crosshair wiring.
document.getElementById('player-weapon-ammomode').onchange = (e) => {
  currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig();
  currentPlayerSettings.weapon.ammoMode = e.target.value;
  renderPlayerSettingsPanel();
};
document.getElementById('player-weapon-magsize').oninput = (e) => { const v = parseInt(e.target.value, 10); if (v > 0) { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.magazineSize = v; } };
document.getElementById('player-weapon-startmag').oninput = (e) => { const v = parseInt(e.target.value, 10); if (v >= 0) { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.startingMagazine = v; } };
document.getElementById('player-weapon-reserve').oninput = (e) => { const v = parseInt(e.target.value, 10); if (v >= 0) { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.reserveAmmo = v; } };
document.getElementById('player-weapon-reload-duration').oninput = (e) => { const v = parseFloat(e.target.value); if (v > 0) { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.reloadDuration = v; } };
document.getElementById('player-weapon-firemode').onchange = (e) => { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.fireMode = e.target.value; };
document.getElementById('player-weapon-spread').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= 0) { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.spreadDegrees = v; } };
document.getElementById('player-weapon-recoil-v').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= 0) { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.recoilVertical = v; } };
document.getElementById('player-weapon-recoil-h').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= 0) { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.recoilHorizontal = v; } };
document.getElementById('player-weapon-emit-noise').onchange = (e) => { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.emitNoiseOnFire = e.target.checked; };
document.getElementById('player-weapon-noise-radius').oninput = (e) => { const v = parseFloat(e.target.value); if (v >= 0) { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.noiseRadius = v; } };
document.getElementById('player-weapon-crosshair').onchange = (e) => { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.crosshair = e.target.checked; };
document.getElementById('player-weapon-muzzle-fx').onchange = (e) => { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.muzzleEffect = e.target.checked; };
document.getElementById('player-weapon-muzzle-color').oninput = (e) => { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.muzzleEffectColor = e.target.value; };
document.getElementById('player-weapon-impact-fx').onchange = (e) => { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.impactEffect = e.target.checked; };
document.getElementById('player-weapon-impact-color').oninput = (e) => { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.impactEffectColor = e.target.value; };
document.getElementById('player-weapon-tracer').onchange = (e) => { currentPlayerSettings.weapon = currentPlayerSettings.weapon || defaultWeaponConfig(); currentPlayerSettings.weapon.tracer = e.target.checked; };

// --- HUD/UI authoring ---
const HUD_KIND_LABELS = { label: 'Text Label', counter: 'Counter Display', timer: 'Timer Display', health: 'Health Bar', objective: 'Objective Text', button: 'Button', panel: 'Panel' };
const HUD_ANCHORS = ['top-left', 'top-center', 'top-right', 'middle-left', 'middle-center', 'middle-right', 'bottom-left', 'bottom-center', 'bottom-right'];

function applyLevelUiConfig(index) {
  const saved = levels[index].ui;
  currentUiConfig = saved ? Object.assign(defaultUiConfig(), saved, { startScreen: Object.assign(defaultUiConfig().startScreen, saved.startScreen) }) : defaultUiConfig();
  renderUiConfigPanel();
}
function applyLevelSequences(index) {
  currentSequences = (levels[index].sequences || []).map((s) => JSON.parse(JSON.stringify(s)));
  selectedSequenceId = currentSequences.length ? currentSequences[0].id : null;
  renderSequencePanel();
}
function applyLevelObjectiveDefs(index) {
  currentObjectiveDefs = (levels[index].objectiveDefs || []).map((o) => JSON.parse(JSON.stringify(o)));
  renderObjectiveDefPanel();
  renderScatterPanel(); // Wave 7 (Priority G): cheap to refresh here too -- keeps the Prefab/Asset source dropdowns from ever going stale after a level switch
}
// Wave 9C: Scatter Layers are level-scoped -- deep-cloned like every other
// per-level array (Section 5's own "Duplicate Level must deep-clone it").
// Stable ids stay unique across levels because `generateScatterLayerId`'s
// counter is never reset per-level, matching every other id generator in
// this file (Objectives, Items, Sockets) -- the SAME reasoning Duplicate
// Level already relies on for objective/object ids.
function applyLevelScatterLayers(index) {
  currentScatterLayers = (levels[index].scatterLayers || []).map((l) => JSON.parse(JSON.stringify(l)));
  selectedScatterLayerId = currentScatterLayers.length ? currentScatterLayers[0].id : null;
  renderScatterLayerPanel();
}
function renderUiConfigPanel() {
  document.getElementById('start-screen-enabled').checked = currentUiConfig.startScreen.enabled;
  document.getElementById('start-screen-title').value = currentUiConfig.startScreen.title;
  document.getElementById('start-screen-subtitle').value = currentUiConfig.startScreen.subtitle;
  document.getElementById('start-screen-button').value = currentUiConfig.startScreen.buttonText;
  document.getElementById('start-screen-howtoplay').value = currentUiConfig.startScreen.howToPlay || '';
  document.getElementById('start-screen-credits').value = currentUiConfig.startScreen.credits || '';
  document.getElementById('win-title').value = currentUiConfig.winTitle;
  document.getElementById('win-message').value = currentUiConfig.winMessage;
  document.getElementById('lose-title').value = currentUiConfig.loseTitle;
  document.getElementById('lose-message').value = currentUiConfig.loseMessage;
  renderHudElementList();
}
document.getElementById('start-screen-enabled').onchange = (e) => { currentUiConfig.startScreen.enabled = e.target.checked; };
document.getElementById('start-screen-title').oninput = (e) => { currentUiConfig.startScreen.title = e.target.value; };
document.getElementById('start-screen-subtitle').oninput = (e) => { currentUiConfig.startScreen.subtitle = e.target.value; };
document.getElementById('start-screen-button').oninput = (e) => { currentUiConfig.startScreen.buttonText = e.target.value; };
document.getElementById('start-screen-howtoplay').oninput = (e) => { currentUiConfig.startScreen.howToPlay = e.target.value; };
document.getElementById('start-screen-credits').oninput = (e) => { currentUiConfig.startScreen.credits = e.target.value; };
document.getElementById('win-title').oninput = (e) => { currentUiConfig.winTitle = e.target.value; };
document.getElementById('win-message').oninput = (e) => { currentUiConfig.winMessage = e.target.value; };
document.getElementById('lose-title').oninput = (e) => { currentUiConfig.loseTitle = e.target.value; };
document.getElementById('lose-message').oninput = (e) => { currentUiConfig.loseMessage = e.target.value; };

function hudElementFieldsHTML(el) {
  const anchorSelect = `<select data-hud-field="anchor">${HUD_ANCHORS.map((a) => `<option value="${a}"${el.anchor === a ? ' selected' : ''}>${a}</option>`).join('')}</select>`;
  if (el.kind === 'label' || el.kind === 'objective') {
    return anchorSelect + `<input type="text" data-hud-field="text" placeholder="Text (use {counterName} to bind)" value="${escapeHtml(el.text || '')}">`;
  }
  if (el.kind === 'counter') {
    return anchorSelect + `<input type="text" data-hud-field="counterName" placeholder="Counter name" value="${escapeHtml(el.counterName || '')}">`
      + `<input type="text" data-hud-field="text" placeholder="Label (use {value})" value="${escapeHtml(el.text || 'Score: {value}')}">`;
  }
  if (el.kind === 'timer') {
    return anchorSelect + `<input type="text" data-hud-field="timerName" placeholder="Timer name" value="${escapeHtml(el.timerName || '')}">`
      + `<input type="text" data-hud-field="text" placeholder="Label (use {value})" value="${escapeHtml(el.text || 'Time: {value}')}">`;
  }
  if (el.kind === 'health') return anchorSelect;
  if (el.kind === 'button') {
    const actionOptions = Object.keys(ACTION_TYPES).filter((t) => t !== 'script').map((t) => `<option value="${t}"${el.buttonAction === t ? ' selected' : ''}>${escapeHtml(ACTION_TYPES[t].label)}</option>`).join('');
    return anchorSelect + `<input type="text" data-hud-field="text" placeholder="Button label" value="${escapeHtml(el.text || 'Button')}">`
      + `<select data-hud-field="buttonAction">${actionOptions}</select>`;
  }
  if (el.kind === 'panel') {
    return anchorSelect + `<div class="field-triple"><input type="number" data-hud-field="panelWidth" placeholder="Width" value="${el.panelWidth || 120}"><input type="number" data-hud-field="panelHeight" placeholder="Height" value="${el.panelHeight || 60}"></div>`;
  }
  return anchorSelect;
}

function renderHudElementList() {
  const listEl = document.getElementById('hud-element-list');
  if (currentUiConfig.hudElements.length === 0) {
    listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No HUD elements yet.</p>';
    return;
  }
  listEl.innerHTML = currentUiConfig.hudElements.map((el) => `
    <div class="hud-element-row" data-hud-id="${el.id}">
      <div class="hud-element-row-header">
        <span>${HUD_KIND_LABELS[el.kind]}</span>
        <button class="hud-remove-btn" data-hud-remove="${el.id}" title="Remove">✕</button>
      </div>
      ${hudElementFieldsHTML(el)}
    </div>
  `).join('');
  listEl.querySelectorAll('[data-hud-remove]').forEach((btn) => {
    btn.onclick = () => {
      currentUiConfig.hudElements = currentUiConfig.hudElements.filter((el) => el.id !== btn.dataset.hudRemove);
      renderHudElementList();
    };
  });
  listEl.querySelectorAll('.hud-element-row').forEach((row) => {
    const el = currentUiConfig.hudElements.find((e) => e.id === row.dataset.hudId);
    row.querySelectorAll('[data-hud-field]').forEach((input) => {
      const handler = () => {
        const key = input.dataset.hudField;
        el[key] = input.type === 'number' ? (parseFloat(input.value) || 0) : input.value;
      };
      input.addEventListener(input.tagName === 'SELECT' ? 'change' : 'input', handler);
    });
  });
}
document.getElementById('hud-add-btn').addEventListener('click', () => {
  const kind = document.getElementById('hud-add-kind').value;
  currentUiConfig.hudElements.push({ id: generateHudElementId(), kind, anchor: 'top-left', offsetX: 0, offsetY: 0, text: '', visible: true, buttonAction: 'message', panelWidth: 120, panelHeight: 60 });
  renderHudElementList();
});

// Wave 6B (Priority E): Sequence Editor -- a simple LIST UI, deliberately
// not a timeline. Rebuilds the step list from `currentSequences` on every
// change (add/remove/reorder/edit), same "small enough to just re-render"
// approach the HUD element list above already uses. Per-step fields reuse
// `renderActionFieldInput` directly -- the exact same field renderer the
// fixed-dropdown Add Behavior UI and the Node Graph node UI already share,
// so a new field TYPE still only needs handling written once anywhere in
// this file.
// Wave 7 (Priority F): the Objectives editor -- same "build the DOM in JS,
// wire handlers after" list pattern every other Wave 7 list editor already
// established. Each row: Title, optional Description, and an optional
// Next Objective (a simple linear chain -- auto-activates on Complete, per
// the spec's own explicit bound on how far chaining should go).
function renderObjectiveDefPanel() {
  const listEl = document.getElementById('objective-def-list');
  if (!listEl) return;
  if (currentObjectiveDefs.length === 0) {
    listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No objectives yet -- add one below.</p>';
  } else {
    listEl.innerHTML = currentObjectiveDefs.map((o, i) => `
      <div class="hud-element-row" data-objdef-index="${i}">
        <div class="hud-element-row-header">
          <span>${escapeHtml(o.title || '(untitled)')} <span style="color:#66759a;font-size:10px">(${escapeHtml(o.id)})</span></span>
          <button data-objdef-remove="${i}" class="hud-remove-btn" title="Delete">✕</button>
        </div>
        <input type="text" data-objdef-title="${i}" value="${escapeHtml(o.title || '')}" placeholder="Title (e.g. Find the weapon)">
        <input type="text" data-objdef-desc="${i}" value="${escapeHtml(o.description || '')}" placeholder="Description (optional)" style="margin-top:4px">
        <select data-objdef-next="${i}" style="margin-top:4px">
          <option value="">(no automatic next objective)</option>
          ${currentObjectiveDefs.filter((o2) => o2.id !== o.id).map((o2) => `<option value="${escapeHtml(o2.id)}"${o.nextObjective === o2.id ? ' selected' : ''}>${escapeHtml(o2.title)}</option>`).join('')}
        </select>
        <div class="field-triple" style="margin-top:4px">
          <select data-objdef-progtype="${i}"><option value="">(no progress)</option><option value="counter"${o.progress && o.progress.type === 'counter' ? ' selected' : ''}>Counter</option><option value="inventory"${o.progress && o.progress.type === 'inventory' ? ' selected' : ''}>Inventory Item</option></select>
          <input type="text" data-objdef-progkey="${i}" value="${escapeHtml((o.progress && o.progress.key) || '')}" placeholder="name/item id">
          <input type="number" data-objdef-progtarget="${i}" value="${(o.progress && o.progress.target) || ''}" placeholder="target">
        </div>
      </div>`).join('');
  }
  listEl.querySelectorAll('[data-objdef-remove]').forEach((btn) => { btn.onclick = () => { pushUndo(); currentObjectiveDefs.splice(Number(btn.dataset.objdefRemove), 1); renderObjectiveDefPanel(); }; });
  listEl.querySelectorAll('[data-objdef-title]').forEach((input) => { input.oninput = () => { currentObjectiveDefs[Number(input.dataset.objdefTitle)].title = input.value; }; });
  listEl.querySelectorAll('[data-objdef-desc]').forEach((input) => { input.oninput = () => { currentObjectiveDefs[Number(input.dataset.objdefDesc)].description = input.value; }; });
  listEl.querySelectorAll('[data-objdef-next]').forEach((sel) => { sel.onchange = () => { pushUndo(); currentObjectiveDefs[Number(sel.dataset.objdefNext)].nextObjective = sel.value || undefined; }; });
  // Wave 8 (Priority G/Section 47): optional numeric progress, reusing
  // EXISTING state (a Counter or an Inventory item's own quantity) rather
  // than a second progress-storage system.
  listEl.querySelectorAll('[data-objdef-progtype]').forEach((sel) => {
    sel.onchange = () => { pushUndo(); const o = currentObjectiveDefs[Number(sel.dataset.objdefProgtype)]; o.progress = sel.value ? { type: sel.value, key: (o.progress && o.progress.key) || '', target: (o.progress && o.progress.target) || 0 } : undefined; renderObjectiveDefPanel(); };
  });
  listEl.querySelectorAll('[data-objdef-progkey]').forEach((input) => {
    input.oninput = () => { const o = currentObjectiveDefs[Number(input.dataset.objdefProgkey)]; if (o.progress) o.progress.key = input.value; };
  });
  listEl.querySelectorAll('[data-objdef-progtarget]').forEach((input) => {
    input.oninput = () => { const o = currentObjectiveDefs[Number(input.dataset.objdefProgtarget)]; const v = parseFloat(input.value); if (o.progress && !Number.isNaN(v)) o.progress.target = v; };
  });
  const addBtn = document.getElementById('objective-def-add-btn');
  if (addBtn) {
    addBtn.onclick = () => {
      pushUndo();
      currentObjectiveDefs.push({ id: generateObjectiveDefId(), title: `Objective ${currentObjectiveDefs.length + 1}`, description: '', nextObjective: undefined });
      renderObjectiveDefPanel();
    };
  }
}
// Wave 7 (Priority G/H): populates the Scatter source dropdowns (Prefab
// list + skinned/plain-mesh Asset list) -- called whenever the Level tab
// section renders, same lazy-populate pattern other dropdowns already use.
function renderScatterPanel() {
  const prefabSel = document.getElementById('scatter-prefab');
  const assetSel = document.getElementById('scatter-asset');
  if (!prefabSel || !assetSel) return;
  prefabSel.innerHTML = '<option value="">(none)</option>' + prefabs.map((p) => `<option value="${escapeHtml(p.name)}">${escapeHtml(p.name)}</option>`).join('');
  assetSel.innerHTML = '<option value="">(none)</option>' + assets.map((a) => `<option value="${a.id}">${escapeHtml(a.name)}</option>`).join('');
}
// --- Wave 9C (Priority A): Scatter Layers -- a real, persisted authoring
// surface over the existing weighted Scatter machinery. Same "build the
// DOM in JS, wire handlers after" pattern every other list editor already
// established (Sockets, Equipment, Objectives, Prefab Parameters). ---
function renderScatterLayerPanel() {
  const selectEl = document.getElementById('scatter-layer-select');
  const fieldsEl = document.getElementById('scatter-layer-fields');
  if (!selectEl || !fieldsEl) return;
  if (!selectedScatterLayerId || !findScatterLayerById(selectedScatterLayerId)) {
    selectedScatterLayerId = currentScatterLayers.length ? currentScatterLayers[0].id : null;
  }
  selectEl.innerHTML = currentScatterLayers.length === 0
    ? '<option value="">(no layers yet)</option>'
    : currentScatterLayers.map((l) => `<option value="${escapeHtml(l.id)}"${l.id === selectedScatterLayerId ? ' selected' : ''}>${escapeHtml(l.name)}</option>`).join('');
  const layer = findScatterLayerById(selectedScatterLayerId);
  if (!layer) { fieldsEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No layer selected -- Add one above.</p>'; return; }
  const ownedCount = placed.filter((p) => p.scatterLayerId === layer.id).length;
  fieldsEl.innerHTML = `
    <input type="text" id="sl-name" value="${escapeHtml(layer.name)}" placeholder="Layer name">
    <div style="font-size:10.5px;color:#66759a;margin-top:2px">${ownedCount} object${ownedCount === 1 ? '' : 's'} owned by this layer.</div>
    <div style="margin-top:6px;font-size:10px;color:#66759a">Sources (weighted):</div>
    <div id="sl-sources">${layer.sources.map((s, i) => `
      <div class="field-triple" style="margin-top:3px">
        <select data-sl-source-prefab="${i}">${prefabs.length === 0 ? '<option value="">(no prefabs)</option>' : prefabs.map((p) => `<option value="${escapeHtml(p.name)}"${s.prefabName === p.name ? ' selected' : ''}>${escapeHtml(p.name)}</option>`).join('')}</select>
        <input type="number" min="0" step="1" data-sl-source-weight="${i}" value="${s.weight != null ? s.weight : 1}" placeholder="Weight">
        <button data-sl-source-remove="${i}" class="hud-remove-btn">✕</button>
      </div>`).join('') || '<p style="color:#8592a8;font-size:11px;margin:2px 0">No sources yet.</p>'}</div>
    <button id="sl-source-add-btn" class="toolbar-btn" style="margin-top:3px;padding:2px 8px">+ Add Source</button>
    <div class="field-triple" style="margin-top:6px">
      <div><label style="font-size:10px;color:#66759a">Seed</label><input type="number" id="sl-seed" value="${layer.seed}"></div>
      <div><label style="font-size:10px;color:#66759a">Brush Radius</label><input type="number" id="sl-brush-radius" step="0.5" min="0.5" value="${layer.brushRadius}"></div>
      <div><label style="font-size:10px;color:#66759a">Density</label><input type="number" id="sl-density" step="0.05" min="0.05" max="1" value="${layer.density}"></div>
    </div>
    <div class="field-triple" style="margin-top:4px">
      <div><label style="font-size:10px;color:#66759a">Min Spacing</label><input type="number" id="sl-min-spacing" step="0.1" min="0" value="${layer.minSpacing}"></div>
      <div><label style="font-size:10px;color:#66759a">Scale Min</label><input type="number" id="sl-scale-min" step="0.05" min="0.05" value="${layer.scaleMin}"></div>
      <div><label style="font-size:10px;color:#66759a">Scale Max</label><input type="number" id="sl-scale-max" step="0.05" min="0.05" value="${layer.scaleMax}"></div>
    </div>
    <div class="field-row" style="margin-top:4px"><label style="font-size:10px;color:#66759a">Max Slope (degrees)</label><input type="number" id="sl-max-slope" step="1" min="0" max="90" value="${layer.maxSlope}"></div>
    <label style="display:flex;align-items:center;gap:6px;font-size:11px;color:#c7d3ea;margin-top:4px"><input type="checkbox" id="sl-random-yaw"${layer.randomYaw ? ' checked' : ''}> Random Y Rotation</label>
    <div class="field-triple" style="margin-top:8px">
      <button id="sl-brush-paint-btn" class="toolbar-btn" style="margin-bottom:0${scatterBrushMode === 'paint' ? ';outline:2px solid #6fd6bd' : ''}">🖌 Paint</button>
      <button id="sl-brush-erase-btn" class="toolbar-btn" style="margin-bottom:0${scatterBrushMode === 'erase' ? ';outline:2px solid #d66f6f' : ''}">🧹 Erase</button>
      <button id="sl-brush-off-btn" class="toolbar-btn" style="margin-bottom:0${scatterBrushMode === null ? ';outline:2px solid #66759a' : ''}">Off</button>
    </div>
    <div style="font-size:10.5px;color:#66759a;margin-top:3px">Paint/Erase: drag over the viewport. One drag = one Undo step. Terrain height/slope, min spacing, and weighted sources all come from THIS layer's own settings above.</div>
    ${selectedItem && selectedItem.scatterLayerId ? '<button id="sl-detach-btn" class="toolbar-btn" style="margin-top:6px">Detach Selected From Scatter Layer</button>' : ''}
  `;
  const setField = (id, fn) => { const el = document.getElementById(id); if (el) el.oninput = fn; };
  setField('sl-name', (e) => { layer.name = e.target.value; renderScatterLayerPanel(); });
  document.getElementById('sl-name').onchange = () => renderScatterLayerPanel(); // refresh the <select> label too, but not on every keystroke
  setField('sl-seed', (e) => { const v = parseInt(e.target.value, 10); if (!Number.isNaN(v)) layer.seed = v; });
  setField('sl-brush-radius', (e) => { const v = parseFloat(e.target.value); if (v > 0) layer.brushRadius = v; });
  setField('sl-density', (e) => { const v = parseFloat(e.target.value); if (v > 0) layer.density = v; });
  setField('sl-min-spacing', (e) => { const v = parseFloat(e.target.value); if (v >= 0) layer.minSpacing = v; });
  setField('sl-scale-min', (e) => { const v = parseFloat(e.target.value); if (v > 0) layer.scaleMin = v; });
  setField('sl-scale-max', (e) => { const v = parseFloat(e.target.value); if (v > 0) layer.scaleMax = v; });
  setField('sl-max-slope', (e) => { const v = parseFloat(e.target.value); if (v >= 0) layer.maxSlope = v; });
  const yawCb = document.getElementById('sl-random-yaw');
  if (yawCb) yawCb.onchange = (e) => { layer.randomYaw = e.target.checked; };
  document.querySelectorAll('[data-sl-source-prefab]').forEach((sel) => { sel.onchange = () => { layer.sources[Number(sel.dataset.slSourcePrefab)].prefabName = sel.value; }; });
  document.querySelectorAll('[data-sl-source-weight]').forEach((input) => { input.oninput = () => { const v = parseFloat(input.value); if (v >= 0) layer.sources[Number(input.dataset.slSourceWeight)].weight = v; }; });
  document.querySelectorAll('[data-sl-source-remove]').forEach((btn) => { btn.onclick = () => { pushUndo(); layer.sources.splice(Number(btn.dataset.slSourceRemove), 1); renderScatterLayerPanel(); }; });
  const addSourceBtn = document.getElementById('sl-source-add-btn');
  if (addSourceBtn) addSourceBtn.onclick = () => { pushUndo(); layer.sources.push({ prefabName: prefabs[0] ? prefabs[0].name : '', weight: 1 }); renderScatterLayerPanel(); };
  const paintBtn = document.getElementById('sl-brush-paint-btn');
  const eraseBtn = document.getElementById('sl-brush-erase-btn');
  const offBtn = document.getElementById('sl-brush-off-btn');
  if (paintBtn) paintBtn.onclick = () => { scatterBrushMode = 'paint'; renderScatterLayerPanel(); };
  if (eraseBtn) eraseBtn.onclick = () => { scatterBrushMode = 'erase'; renderScatterLayerPanel(); };
  if (offBtn) offBtn.onclick = () => { scatterBrushMode = null; renderScatterLayerPanel(); };
  const detachBtn = document.getElementById('sl-detach-btn');
  if (detachBtn) detachBtn.onclick = () => { pushUndo(); delete selectedItem.scatterLayerId; renderScatterLayerPanel(); showStatus('Detached from Scatter Layer'); };
}
document.getElementById('scatter-layer-select').onchange = (e) => { selectedScatterLayerId = e.target.value || null; renderScatterLayerPanel(); };
document.getElementById('scatter-layer-add-btn').onclick = () => {
  pushUndo();
  const layer = defaultScatterLayer();
  currentScatterLayers.push(layer);
  selectedScatterLayerId = layer.id;
  renderScatterLayerPanel();
};
document.getElementById('scatter-layer-delete-btn').onclick = () => {
  if (!selectedScatterLayerId) return;
  pushUndo();
  currentScatterLayers = currentScatterLayers.filter((l) => l.id !== selectedScatterLayerId);
  selectedScatterLayerId = currentScatterLayers.length ? currentScatterLayers[0].id : null;
  renderScatterLayerPanel();
  showStatus('Scatter Layer deleted (its generated objects were NOT removed -- Erase first if you want them gone too)');
};
document.getElementById('scatter-btn').onclick = () => {
  const config = {
    prefabName: document.getElementById('scatter-prefab').value || undefined,
    assetId: document.getElementById('scatter-asset').value || undefined,
    region: document.getElementById('scatter-region').value,
    centerX: parseFloat(document.getElementById('scatter-center-x').value) || 0,
    centerZ: parseFloat(document.getElementById('scatter-center-z').value) || 0,
    radius: parseFloat(document.getElementById('scatter-radius').value) || 10,
    width: parseFloat(document.getElementById('scatter-width').value) || 20,
    depth: parseFloat(document.getElementById('scatter-depth').value) || 20,
    count: Math.max(1, parseInt(document.getElementById('scatter-count').value, 10) || 1),
    minSpacing: parseFloat(document.getElementById('scatter-spacing').value) || 0,
    seed: parseInt(document.getElementById('scatter-seed').value, 10) || 1,
    scaleMin: parseFloat(document.getElementById('scatter-scale-min').value) || 1,
    scaleMax: parseFloat(document.getElementById('scatter-scale-max').value) || 1,
    maxSlopeDegrees: document.getElementById('scatter-max-slope').value !== '' ? parseFloat(document.getElementById('scatter-max-slope').value) : null,
    randomYRotation: document.getElementById('scatter-random-yrot').checked,
    terrainConform: document.getElementById('scatter-terrain-conform').checked,
  };
  if (!config.prefabName && !config.assetId) { showStatus('Choose a Prefab or Asset source first'); return; }
  const result = performScatter(config);
  renderSceneList();
  showStatus(`Scattered ${result.placedCount}/${config.count} (${result.attempts} attempts)`);
};
document.getElementById('array-mode').onchange = (e) => {
  const isGrid = e.target.value === 'grid';
  document.getElementById('array-linear-fields').style.display = isGrid ? 'none' : '';
  document.getElementById('array-grid-fields').style.display = isGrid ? '' : 'none';
  document.getElementById('array-grid-fields2').style.display = isGrid ? '' : 'none';
};
document.getElementById('array-btn').onclick = () => {
  if (!selectedItem || selectedItem.kind !== 'cube') { showStatus('Select a single object first'); return; }
  const mode = document.getElementById('array-mode').value;
  const config = mode === 'grid'
    ? { mode: 'grid', countX: Math.max(1, parseInt(document.getElementById('array-count-x').value, 10) || 1), countZ: Math.max(1, parseInt(document.getElementById('array-count-z').value, 10) || 1), spacingX: parseFloat(document.getElementById('array-spacing-x').value) || 2, spacingZ: parseFloat(document.getElementById('array-spacing-z').value) || 2 }
    : { mode: 'linear', axis: document.getElementById('array-axis').value, count: Math.max(1, parseInt(document.getElementById('array-count').value, 10) || 1), spacing: parseFloat(document.getElementById('array-spacing').value) || 2 };
  const newItems = performArrayDuplicate(selectedItem, config);
  renderSceneList();
  showStatus(`Array created ${newItems.length} copies`);
};
// Wave 8 (Priority B): the Object Variables editor -- same "build the DOM
// in JS, wire handlers after" list pattern every other Wave 7/8 list
// editor already established. `item.variables` is a plain
// `{name: number|boolean|string}` map (Section 10's own explicit bound --
// no nested objects), authored directly on the placed item (or prefab
// record), separate from World-State's own opt-in persistence of it.
function objectVariableTypeOf(v) {
  return typeof v === 'boolean' ? 'boolean' : typeof v === 'number' ? 'number' : 'string';
}
// Wave 8 (Priority C, Sections 15-24): Prefab Parameters editor -- two
// linked lists for the currently-selected LINKED instance's source prefab:
// the parameter DEFINITIONS themselves (shared by every instance -- Add
// Parameter/name/type/default/bound field, Section 17) and this ONE
// instance's own OVERRIDES (Section 20 -- only overridden values are ever
// stored on the instance; an un-overridden field just shows/edits the
// prefab's own default, and typing a value there creates the override).
let nextPrefabParamCounter = 1;
function generatePrefabParamStableId() { return `p${nextPrefabParamCounter++}_${Date.now().toString(36)}`; }
function renderPrefabParamPanel(item) {
  const defListEl = document.getElementById('prefab-param-def-list');
  const overrideListEl = document.getElementById('prefab-param-override-list');
  if (!defListEl || !overrideListEl || !item.sourcePrefabName) return;
  const prefab = prefabs.find((p) => p.name === item.sourcePrefabName);
  if (!prefab) { defListEl.innerHTML = ''; overrideListEl.innerHTML = ''; return; }
  prefab.parameters = prefab.parameters || [];
  if (prefab.parameters.length === 0) {
    defListEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No parameters defined yet -- add one below.</p>';
    overrideListEl.innerHTML = '';
  } else {
    defListEl.innerHTML = prefab.parameters.map((param) => `
      <div class="hud-element-row" data-param-id="${escapeHtml(param.id)}">
        <div class="hud-element-row-header">
          <span>${escapeHtml(param.label || param.id)} <span style="color:#66759a;font-size:10px">(${param.type})</span></span>
          <button data-param-remove="${escapeHtml(param.id)}" class="hud-remove-btn">✕</button>
        </div>
        <div class="field-triple">
          <input type="text" data-param-label="${escapeHtml(param.id)}" value="${escapeHtml(param.label || '')}" placeholder="Display label">
          <select data-param-bind="${escapeHtml(param.id)}">
            <option value="">(not bound to a field yet)</option>
            ${Object.entries(PREFAB_PARAM_BINDINGS).map(([k, def]) => `<option value="${k}"${param.bindingField === k ? ' selected' : ''}>${escapeHtml(def.label)}</option>`).join('')}
          </select>
          ${param.bindingField === 'variable' ? `<input type="text" data-param-varname="${escapeHtml(param.id)}" value="${escapeHtml(param.variableName || '')}" placeholder="variable name">` : '<span></span>'}
        </div>
        <div style="margin-top:3px">${renderActionFieldInput({ key: 'default', type: param.type === 'prefabReference' ? 'prefab' : param.type }, param.default, null)}</div>
      </div>`).join('');
    overrideListEl.innerHTML = `<label style="font-size:10.5px;color:#66759a">This instance's overrides (blank = use the prefab's default):</label>` + prefab.parameters.map((param) => {
      item.prefabParams = item.prefabParams || {};
      const hasOverride = item.prefabParams[param.id] !== undefined;
      const effective = resolveEffectivePrefabParamValue(item, param);
      // Wave 9D (Priority A/Section 8): Mesh/Texture/Audio Asset overrides
      // use the exact same real Asset Library dropdowns the parameter's own
      // Default row already renders (`renderActionFieldInput`), never a
      // raw-text-typed id -- the spec's own explicit "do not require typing
      // raw IDs." An empty first option keeps "blank = use the prefab's
      // default" working identically to every other override type.
      const isAssetType = param.type === 'meshAsset' || param.type === 'textureAsset' || param.type === 'audioAsset';
      const inputHtml = param.type === 'boolean'
        ? `<select data-override-value="${escapeHtml(param.id)}"><option value="">(default: ${param.default})</option><option value="true"${hasOverride && effective === true ? ' selected' : ''}>true</option><option value="false"${hasOverride && effective === false ? ' selected' : ''}>false</option></select>`
        : isAssetType
        ? renderActionFieldInput({ key: 'default', type: param.type }, hasOverride ? effective : '', null).replace('data-field="default"', `data-override-value="${escapeHtml(param.id)}"`)
        : `<input type="${param.type === 'number' ? 'number' : param.type === 'color' ? 'color' : 'text'}" data-override-value="${escapeHtml(param.id)}" value="${hasOverride ? escapeHtml(String(effective)) : ''}" placeholder="default: ${escapeHtml(String(param.default))}">`;
      return `<div class="field-triple" style="margin-top:3px"><span style="font-size:11px;color:#c7d3ea;align-self:center">${escapeHtml(param.label || param.id)}</span>${inputHtml}<button data-override-clear="${escapeHtml(param.id)}" class="hud-remove-btn" title="Clear override">✕</button></div>`;
    }).join('');
  }
  defListEl.querySelectorAll('[data-param-remove]').forEach((btn) => {
    btn.onclick = () => { pushUndo(); prefab.parameters = prefab.parameters.filter((pp) => pp.id !== btn.dataset.paramRemove); renderPrefabParamPanel(item); };
  });
  defListEl.querySelectorAll('[data-param-label]').forEach((input) => {
    input.oninput = () => { const pp = prefab.parameters.find((x) => x.id === input.dataset.paramLabel); if (pp) pp.label = input.value; };
  });
  defListEl.querySelectorAll('[data-param-bind]').forEach((sel) => {
    sel.onchange = () => { pushUndo(); const pp = prefab.parameters.find((x) => x.id === sel.dataset.paramBind); if (pp) pp.bindingField = sel.value || undefined; renderPrefabParamPanel(item); };
  });
  defListEl.querySelectorAll('[data-param-varname]').forEach((input) => {
    input.oninput = () => { const pp = prefab.parameters.find((x) => x.id === input.dataset.paramVarname); if (pp) pp.variableName = input.value; };
  });
  defListEl.querySelectorAll('[data-field="default"]').forEach((input) => {
    const row = input.closest('[data-param-id]');
    if (!row) return;
    const id = row.dataset.paramId;
    const handler = () => {
      const pp = prefab.parameters.find((x) => x.id === id);
      if (!pp) return;
      pp.default = pp.type === 'number' ? (parseFloat(input.value) || 0) : pp.type === 'boolean' ? input.checked : input.value;
    };
    input.oninput = handler;
    input.onchange = handler;
  });
  overrideListEl.querySelectorAll('[data-override-value]').forEach((input) => {
    const handler = () => {
      const param = prefab.parameters.find((x) => x.id === input.dataset.overrideValue);
      if (!param) return;
      item.prefabParams = item.prefabParams || {};
      if (input.value === '') { delete item.prefabParams[param.id]; }
      else {
        item.prefabParams[param.id] = param.type === 'number' ? (parseFloat(input.value) || 0) : param.type === 'boolean' ? input.value === 'true' : input.value;
      }
      applyPrefabParamBinding(item, param, resolveEffectivePrefabParamValue(item, param));
    };
    input.oninput = handler;
    input.onchange = handler;
  });
  overrideListEl.querySelectorAll('[data-override-clear]').forEach((btn) => {
    btn.onclick = () => { pushUndo(); if (item.prefabParams) delete item.prefabParams[btn.dataset.overrideClear]; applyPrefabParameters(prefab, item); renderPrefabParamPanel(item); };
  });
  const addBtn = document.getElementById('param-add-btn');
  if (addBtn) {
    addBtn.onclick = () => {
      const nameInput = document.getElementById('param-new-name');
      const label = nameInput.value.trim();
      if (!label) { showStatus('Name the parameter first'); return; }
      const type = document.getElementById('param-new-type').value;
      pushUndo();
      prefab.parameters.push({ id: generatePrefabParamStableId(), label, type, default: type === 'number' ? 0 : type === 'boolean' ? false : type === 'color' ? '#ffffff' : '' });
      nameInput.value = '';
      renderPrefabParamPanel(item);
    };
  }
}
function renderObjectVariableList(item) {
  const listEl = document.getElementById('object-variable-list');
  if (!listEl) return;
  item.variables = item.variables || {};
  const names = Object.keys(item.variables);
  if (names.length === 0) {
    listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No variables yet -- add one below.</p>';
  } else {
    listEl.innerHTML = names.map((name) => {
      const v = item.variables[name];
      const type = objectVariableTypeOf(v);
      const inputHtml = type === 'boolean'
        ? `<select data-objvar-value="${escapeHtml(name)}"><option value="true"${v ? ' selected' : ''}>true</option><option value="false"${!v ? ' selected' : ''}>false</option></select>`
        : `<input type="${type === 'number' ? 'number' : 'text'}" data-objvar-value="${escapeHtml(name)}" value="${escapeHtml(String(v))}">`;
      return `
      <div class="field-triple" data-objvar-row="${escapeHtml(name)}" style="margin-top:3px">
        <span style="font-size:11.5px;color:#c7d3ea;align-self:center">${escapeHtml(name)} <span style="color:#66759a;font-size:10px">(${type})</span></span>
        ${inputHtml}
        <button data-objvar-remove="${escapeHtml(name)}" class="hud-remove-btn">✕</button>
      </div>`;
    }).join('');
  }
  listEl.querySelectorAll('[data-objvar-remove]').forEach((btn) => {
    btn.onclick = () => { pushUndo(); delete item.variables[btn.dataset.objvarRemove]; renderObjectVariableList(item); };
  });
  listEl.querySelectorAll('[data-objvar-value]').forEach((input) => {
    const handler = () => {
      const name = input.dataset.objvarValue;
      const type = objectVariableTypeOf(item.variables[name]);
      if (type === 'boolean') item.variables[name] = input.value === 'true';
      else if (type === 'number') { const v = parseFloat(input.value); if (!Number.isNaN(v)) item.variables[name] = v; }
      else item.variables[name] = input.value;
    };
    input.oninput = handler;
    input.onchange = handler;
  });
  const addBtn = document.getElementById('objvar-add-btn');
  if (addBtn) {
    addBtn.onclick = () => {
      const nameInput = document.getElementById('objvar-new-name');
      const name = nameInput.value.trim();
      if (!name) { showStatus('Name the variable first'); return; }
      if (name in item.variables) { showStatus(`"${name}" already exists`); return; }
      const type = document.getElementById('objvar-new-type').value;
      pushUndo();
      item.variables[name] = type === 'number' ? 0 : type === 'boolean' ? false : '';
      nameInput.value = '';
      renderObjectVariableList(item);
    };
  }
}
// Wave 8 (Priority D): the Item Definitions editor -- same list-row
// pattern every other Wave 7/8 list editor already established. Bounded
// (Section 28's own explicit "do not create spreadsheets or a giant
// database editor") -- Name/Description/Icon/Stackable+Max Stack/Equip
// Slot/an optional Use Action, nothing deeper.
function renderItemDefList() {
  const listEl = document.getElementById('item-def-list');
  if (!listEl) return;
  if (currentItemDefs.length === 0) {
    listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No items yet -- add one below.</p>';
  } else {
    listEl.innerHTML = currentItemDefs.map((d, i) => `
      <div class="hud-element-row" data-itemdef-index="${i}">
        <div class="hud-element-row-header">
          <span>${escapeHtml(d.name || '(unnamed)')} <span style="color:#66759a;font-size:10px">(${escapeHtml(d.id)})</span></span>
          <button data-itemdef-remove="${i}" class="hud-remove-btn" title="Delete">✕</button>
        </div>
        <input type="text" data-itemdef-name="${i}" value="${escapeHtml(d.name || '')}" placeholder="Name">
        <input type="text" data-itemdef-desc="${i}" value="${escapeHtml(d.description || '')}" placeholder="Description (optional)" style="margin-top:4px">
        <div class="field-triple" style="margin-top:4px">
          <label style="display:flex;align-items:center;gap:6px;font-size:11px;color:#c7d3ea"><input type="checkbox" data-itemdef-stackable="${i}"${d.stackable !== false ? ' checked' : ''}> Stackable</label>
          <input type="number" data-itemdef-maxstack="${i}" value="${d.maxStack || 99}" placeholder="Max stack" min="1">
          <input type="text" data-itemdef-slot="${i}" value="${escapeHtml(d.equipSlot || '')}" placeholder="Equip slot (optional)">
        </div>
        <div class="field-triple" style="margin-top:4px">
          ${textureAssets.length === 0 ? '<span style="font-size:10.5px;color:#8592a8">No textures imported (icon optional)</span>' : renderActionFieldInput({ key: 'iconTextureAssetId', type: 'select', options: ['', ...textureAssets.map((t) => t.id)] }, d.iconTextureAssetId || '', `itemdef-icon-${i}`)}
          <label style="display:flex;align-items:center;gap:6px;font-size:11px;color:#c7d3ea"><input type="checkbox" data-itemdef-hasuse="${i}"${d.useAction ? ' checked' : ''}> Use Action</label>
        </div>
        ${d.useAction ? `<div class="field-triple" style="margin-top:4px"><select data-itemdef-useaction="${i}">${Object.entries(ACTION_TYPES).filter(([t]) => t !== 'graph' && t !== 'dialogueTree').map(([t, def]) => `<option value="${t}"${d.useAction.action === t ? ' selected' : ''}>${escapeHtml(def.label)}</option>`).join('')}</select></div>` : ''}
      </div>`).join('');
  }
  listEl.querySelectorAll('[data-itemdef-remove]').forEach((btn) => { btn.onclick = () => { pushUndo(); currentItemDefs.splice(Number(btn.dataset.itemdefRemove), 1); renderItemDefList(); }; });
  listEl.querySelectorAll('[data-itemdef-name]').forEach((input) => { input.oninput = () => { currentItemDefs[Number(input.dataset.itemdefName)].name = input.value; }; });
  listEl.querySelectorAll('[data-itemdef-desc]').forEach((input) => { input.oninput = () => { currentItemDefs[Number(input.dataset.itemdefDesc)].description = input.value; }; });
  listEl.querySelectorAll('[data-itemdef-stackable]').forEach((cb) => { cb.onchange = () => { pushUndo(); currentItemDefs[Number(cb.dataset.itemdefStackable)].stackable = cb.checked; }; });
  listEl.querySelectorAll('[data-itemdef-maxstack]').forEach((input) => { input.oninput = () => { const v = parseInt(input.value, 10); if (v > 0) currentItemDefs[Number(input.dataset.itemdefMaxstack)].maxStack = v; }; });
  listEl.querySelectorAll('[data-itemdef-slot]').forEach((input) => { input.oninput = () => { currentItemDefs[Number(input.dataset.itemdefSlot)].equipSlot = input.value || undefined; }; });
  listEl.querySelectorAll('[id^="itemdef-icon-"]').forEach((sel) => { sel.onchange = () => { const i = Number(sel.id.replace('itemdef-icon-', '')); currentItemDefs[i].iconTextureAssetId = sel.value || undefined; }; });
  listEl.querySelectorAll('[data-itemdef-hasuse]').forEach((cb) => {
    cb.onchange = () => { pushUndo(); const d = currentItemDefs[Number(cb.dataset.itemdefHasuse)]; d.useAction = cb.checked ? { action: 'message', params: {} } : undefined; renderItemDefList(); };
  });
  listEl.querySelectorAll('[data-itemdef-useaction]').forEach((sel) => {
    sel.onchange = () => { pushUndo(); currentItemDefs[Number(sel.dataset.itemdefUseaction)].useAction = { action: sel.value, params: {} }; };
  });
  const addBtn = document.getElementById('item-def-add-btn');
  if (addBtn) {
    addBtn.onclick = () => {
      pushUndo();
      currentItemDefs.push({ id: generateItemDefId(), name: `Item ${currentItemDefs.length + 1}`, description: '', stackable: true, maxStack: 99 });
      renderItemDefList();
    };
  }
}
function renderSequencePanel() {
  const select = document.getElementById('sequence-select');
  if (currentSequences.length === 0) {
    select.innerHTML = '<option value="">No sequences yet</option>';
  } else {
    if (!findSequenceById(selectedSequenceId)) selectedSequenceId = currentSequences[0].id;
    select.innerHTML = currentSequences.map((s) => `<option value="${escapeHtml(s.id)}"${s.id === selectedSequenceId ? ' selected' : ''}>${escapeHtml(s.name)}</option>`).join('');
  }
  // Every ACTION_TYPES entry works as a Sequence step EXCEPT the two that
  // open their own sub-editor (Node Graph/Dialogue Tree have no flat field
  // list a Sequence step could execute standalone) -- plus a synthetic
  // Delay/Wait choice, which isn't a real action at all.
  const stepTypeSelect = document.getElementById('sequence-add-step-type');
  const actionOptions = Object.entries(ACTION_TYPES)
    .filter(([type]) => type !== 'graph' && type !== 'dialogueTree')
    .map(([type, def]) => `<option value="${type}">${escapeHtml(def.label)}</option>`).join('');
  stepTypeSelect.innerHTML = `<option value="__delay">⏱ Delay / Wait</option>${actionOptions}`;
  renderSequenceStepList();
}
function renderSequenceStepList() {
  const listEl = document.getElementById('sequence-step-list');
  const seq = findSequenceById(selectedSequenceId);
  if (!seq) { listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No sequence selected -- create one above.</p>'; return; }
  if (seq.steps.length === 0) { listEl.innerHTML = '<p style="color:#66759a;font-size:11px;margin:2px 0">No steps yet -- add one below.</p>'; return; }
  listEl.innerHTML = seq.steps.map((step, i) => {
    const isDelay = step.kind === 'delay';
    const def = !isDelay ? ACTION_TYPES[step.actionType] : null;
    const label = isDelay ? `⏱ Delay ${step.seconds || 0}s` : (def ? def.label : step.actionType);
    const fieldsHTML = isDelay
      ? `<div class="field-row"><label>Seconds</label><input type="number" step="0.1" min="0" data-seq-delay value="${step.seconds || 0}" placeholder="Seconds"></div>`
      : (def ? def.fields.map((f) => `<div class="field-row"><label>${escapeHtml(f.label || f.key)}</label>${renderActionFieldInput(f, step.params ? step.params[f.key] : undefined)}</div>`).join('') : '<p style="color:#c0524f;font-size:11px;margin:2px 0">Unknown action type.</p>');
    return `
      <div class="hud-element-row" data-seq-step="${i}">
        <div class="hud-element-row-header">
          <span>${i + 1}. ${escapeHtml(label)}</span>
          <button class="hud-remove-btn" data-seq-step-remove="${i}" title="Delete step">✕</button>
        </div>
        <div class="field-triple" style="margin-bottom:4px">
          <button class="toolbar-btn" data-seq-step-up="${i}" style="margin-bottom:0"${i === 0 ? ' disabled' : ''}>↑</button>
          <button class="toolbar-btn" data-seq-step-down="${i}" style="margin-bottom:0"${i === seq.steps.length - 1 ? ' disabled' : ''}>↓</button>
          <button class="toolbar-btn" data-seq-step-dup="${i}" style="margin-bottom:0">⧉ Dup</button>
        </div>
        ${fieldsHTML}
      </div>`;
  }).join('');
  listEl.querySelectorAll('[data-seq-step]').forEach((row) => {
    const i = Number(row.dataset.seqStep);
    const step = seq.steps[i];
    row.querySelectorAll('[data-seq-delay]').forEach((input) => {
      input.addEventListener('input', () => { step.seconds = parseFloat(input.value) || 0; });
    });
    if (step.kind === 'action' && ACTION_TYPES[step.actionType]) {
      const def = ACTION_TYPES[step.actionType];
      row.querySelectorAll('[data-field]').forEach((input) => {
        const f = def.fields.find((fld) => fld.key === input.dataset.field);
        if (!f) return;
        const handler = () => {
          step.params = step.params || {};
          step.params[f.key] = f.type === 'checkbox' ? input.checked : f.type === 'number' ? (parseFloat(input.value) || 0) : input.value;
        };
        input.addEventListener(input.tagName === 'SELECT' ? 'change' : 'input', handler);
      });
    }
  });
  listEl.querySelectorAll('[data-seq-step-remove]').forEach((btn) => {
    btn.onclick = () => { pushUndo(); seq.steps.splice(Number(btn.dataset.seqStepRemove), 1); renderSequenceStepList(); };
  });
  listEl.querySelectorAll('[data-seq-step-up]').forEach((btn) => {
    btn.onclick = () => {
      const i = Number(btn.dataset.seqStepUp);
      if (i === 0) return;
      pushUndo();
      [seq.steps[i - 1], seq.steps[i]] = [seq.steps[i], seq.steps[i - 1]];
      renderSequenceStepList();
    };
  });
  listEl.querySelectorAll('[data-seq-step-down]').forEach((btn) => {
    btn.onclick = () => {
      const i = Number(btn.dataset.seqStepDown);
      if (i === seq.steps.length - 1) return;
      pushUndo();
      [seq.steps[i + 1], seq.steps[i]] = [seq.steps[i], seq.steps[i + 1]];
      renderSequenceStepList();
    };
  });
  listEl.querySelectorAll('[data-seq-step-dup]').forEach((btn) => {
    btn.onclick = () => {
      pushUndo();
      const i = Number(btn.dataset.seqStepDup);
      const copy = JSON.parse(JSON.stringify(seq.steps[i]));
      seq.steps.splice(i + 1, 0, copy);
      renderSequenceStepList();
    };
  });
}
document.getElementById('sequence-select').addEventListener('change', (e) => {
  selectedSequenceId = e.target.value || null;
  renderSequenceStepList();
});
document.getElementById('sequence-add-btn').addEventListener('click', () => {
  pushUndo();
  const seq = defaultSequence();
  currentSequences.push(seq);
  selectedSequenceId = seq.id;
  renderSequencePanel();
});
document.getElementById('sequence-rename-btn').addEventListener('click', () => {
  const seq = findSequenceById(selectedSequenceId);
  if (!seq) return;
  const name = prompt('Rename sequence:', seq.name);
  if (name && name.trim()) { pushUndo(); seq.name = name.trim(); renderSequencePanel(); }
});
document.getElementById('sequence-duplicate-btn').addEventListener('click', () => {
  const seq = findSequenceById(selectedSequenceId);
  if (!seq) return;
  pushUndo();
  const copy = { id: generateSequenceId(), name: `${seq.name} Copy`, steps: JSON.parse(JSON.stringify(seq.steps)) };
  currentSequences.push(copy);
  selectedSequenceId = copy.id;
  renderSequencePanel();
});
document.getElementById('sequence-delete-btn').addEventListener('click', () => {
  const seq = findSequenceById(selectedSequenceId);
  if (!seq) return;
  pushUndo();
  currentSequences = currentSequences.filter((s) => s.id !== seq.id);
  selectedSequenceId = currentSequences.length ? currentSequences[0].id : null;
  renderSequencePanel();
});
document.getElementById('sequence-add-step-btn').addEventListener('click', () => {
  const seq = findSequenceById(selectedSequenceId);
  if (!seq) { showStatus('Create a Sequence first'); return; }
  const type = document.getElementById('sequence-add-step-type').value;
  pushUndo();
  if (type === '__delay') seq.steps.push({ kind: 'delay', seconds: 1 });
  else seq.steps.push({ kind: 'action', actionType: type, params: {} });
  renderSequenceStepList();
});

// Runtime rendering -- rebuilt (not just updated) every play-mode frame
// from currentUiConfig.hudElements, since the authoring list itself can
// change live (add/remove) while iterating on a game. Bindings resolve
// against the same window.__gameState/__gameTimers/health every other
// Wave-2 system already reads, so a HUD label and a Node Graph condition
// can reference the exact same counter with no separate wiring.
function resolveHudBindingText(template, value) {
  return String(template || '').replace('{value}', value != null ? String(value) : '0');
}
// Wave 6B (Priority G): binding-aware HUD prompts -- `{bind:actionName}`
// resolves to the CURRENT effective binding's readable label (reusing the
// exact same `keyCodeToLabel` the Controls/rebind panel already uses, so a
// rebound key shows correctly here too -- e.g. authored "[{bind:interact}]
// Open Door" reads "[E] Open Door" by default, or "[Mouse 2] Open Door"
// once rebound, with zero icon art needed). Touch deliberately never shows
// a keyboard/mouse binding at all (there isn't one to show) -- it always
// reads a generic "Interact"/"Attack"/etc. label instead, per this
// priority's own explicit touch-prompt requirement. A referenced action
// name that doesn't exist in INPUT_ACTION_LABELS is left as literal text
// (`{bind:notReal}`) rather than silently vanishing, so an author notices
// the typo instead of shipping a blank prompt.
// Wave 7 (Priority F/Section 44): the current active objective's own
// title -- the FIRST objective def whose window.__gameObjectives state is
// 'active' (authored order), or '' if none is active. Bounded: no attempt
// to show multiple simultaneously-active objectives at once.
function currentActiveObjectiveTitle() {
  if (!window.__gameObjectives) return '';
  const def = currentObjectiveDefs.find((o) => window.__gameObjectives[o.id] === 'active');
  return def ? def.title : '';
}
// Wave 9 (Priority A/Section 25): Ammo HUD via binding tokens -- reuses the
// exact same `{name}` HUD label mechanism every other counter already
// binds through, rather than a dedicated Ammo Display element type.
// `{ammo}`/`{reserveAmmo}` read the CURRENT active weapon's own runtime
// state (Infinite-ammo weapons show 'INF' rather than a bare 0, so an
// author's HUD doesn't misleadingly imply an empty gun); `{weaponName}`
// resolves the active Equipment slot's item name in Equipment Weapon mode,
// or the Fixed Weapon's own authored label otherwise.
function resolveWeaponHudTokens(text) {
  if (!/\{(ammo|reserveAmmo|weaponName)\}/.test(text)) return text;
  const weapon = resolveActivePlayerWeapon();
  let ammoStr = 'INF', reserveStr = '', nameStr = '';
  if (weapon) {
    if ((weapon.ammoMode || 'infinite') === 'magazine') {
      const rt = ensureWeaponRuntime(weapon);
      ammoStr = String(rt.magazine);
      reserveStr = String(rt.reserve);
    }
    const settingsWeapon = currentPlayerSettings.weapon;
    if (settingsWeapon && settingsWeapon.source === 'equipment') {
      const eq = playerEquipment[activeWeaponSlot];
      nameStr = eq ? eq.itemName : '(none)';
    } else {
      nameStr = 'Weapon';
    }
  }
  return text.replace(/\{ammo\}/g, ammoStr).replace(/\{reserveAmmo\}/g, reserveStr).replace(/\{weaponName\}/g, nameStr);
}
function resolveHudBindText(text) {
  return resolveWeaponHudTokens(String(text || '').replace(/\{bind:(\w+)\}/g, (whole, action) => {
    if (!INPUT_ACTION_LABELS[action]) return whole;
    if (isTouchDevice) return INPUT_ACTION_LABELS[action];
    return keyCodeToLabel(effectiveInputMap[action]);
  }).replace(/\{activeObjective\}/g, () => currentActiveObjectiveTitle()));
}
function renderHudLayer() {
  const layer = document.getElementById('hud-elements-layer');
  if (!playMode || currentUiConfig.hudElements.length === 0) { layer.innerHTML = ''; return; }
  layer.innerHTML = currentUiConfig.hudElements.map((el) => {
    if (el.visible === false) return '';
    // Dogfood-02 fix: this used to unconditionally emit `left:${offsetX||0}px;
    // top:${offsetY||0}px` for EVERY element, regardless of anchor. An inline
    // `left`/`top` always wins over a CSS class's own `right`/`bottom`/
    // `transform: translateX(-50%)` positioning (higher specificity), so
    // every anchor except literally top-left silently collapsed to the
    // viewport's top-left corner the instant this HUD layer started
    // rendering with the default offsetX/offsetY of 0 -- found live: an
    // Objective Text element explicitly anchored `top-right` rendered
    // directly overlapping a `top-left` Health Bar instead. `margin-left`/
    // `margin-top` (rather than `left`/`top`) apply as a pure nudge on top
    // of whatever position the anchor class already computed (via right/
    // bottom/transform) without ever overriding it, so this only emits
    // them at all when an author has actually set a nonzero offset --
    // the overwhelmingly common default (offset 0) now correctly renders
    // exactly at its anchor's own position for every anchor, not just
    // top-left.
    const styleParts = [];
    if (el.offsetX) styleParts.push(`margin-left:${el.offsetX}px`);
    if (el.offsetY) styleParts.push(`margin-top:${el.offsetY}px`);
    const style = styleParts.join(';');
    if (el.kind === 'label') {
      let text = resolveHudBindText(el.text || '');
      text = text.replace(/\{(\w+)\}/g, (_, name) => (window.__gameState && window.__gameState[name] != null) ? window.__gameState[name] : '0');
      return `<div class="hud-element hud-anchor-${el.anchor}" data-hud-id="${el.id}" style="${style}">${escapeHtml(text)}</div>`;
    }
    if (el.kind === 'objective') {
      // Wave 7 (Priority F): an Objective Text element with no authored
      // text at all auto-displays the current active Objective's title
      // (matching the spec's own "auto-displays... when bound
      // appropriately" -- leaving it empty IS the binding). Any explicit
      // text still resolves {activeObjective} if the author includes it.
      return `<div class="hud-element hud-anchor-${el.anchor}" data-hud-id="${el.id}" style="${style}">${escapeHtml(resolveHudBindText(el.text || '{activeObjective}'))}</div>`;
    }
    if (el.kind === 'counter') {
      const value = (window.__gameState && window.__gameState[el.counterName]) || 0;
      return `<div class="hud-element hud-anchor-${el.anchor}" data-hud-id="${el.id}" style="${style}">${escapeHtml(resolveHudBindingText(el.text || 'Score: {value}', value))}</div>`;
    }
    if (el.kind === 'timer') {
      const t = window.__gameTimers && window.__gameTimers[el.timerName];
      const value = t ? t.elapsed.toFixed(1) : '0';
      return `<div class="hud-element hud-anchor-${el.anchor}" data-hud-id="${el.id}" style="${style}">${escapeHtml(resolveHudBindingText(el.text || 'Time: {value}', value))}</div>`;
    }
    if (el.kind === 'health') {
      ensureHealthInit(); // shows full, not empty, before any Damage/Heal action has run yet
      const pct = Math.max(0, Math.min(100, (window.__gameState.health / window.__gameState.maxHealth) * 100));
      return `<div class="hud-element hud-anchor-${el.anchor}" data-kind="healthBar" data-hud-id="${el.id}" style="${style}"><div class="hud-health-fill" style="width:${pct}%"></div></div>`;
    }
    if (el.kind === 'panel') {
      return `<div class="hud-element hud-anchor-${el.anchor}" data-kind="panel" data-hud-id="${el.id}" style="${style};width:${el.panelWidth || 120}px;height:${el.panelHeight || 60}px"></div>`;
    }
    if (el.kind === 'button') {
      return `<div class="hud-element hud-anchor-${el.anchor}" data-kind="button" data-hud-id="${el.id}" style="${style}"><button data-hud-button="${el.id}">${escapeHtml(el.text || 'Button')}</button></div>`;
    }
    return '';
  }).join('');
  layer.querySelectorAll('[data-hud-button]').forEach((btn) => {
    btn.onclick = () => {
      const el = currentUiConfig.hudElements.find((e) => e.id === btn.dataset.hudButton);
      if (el) executeAction(el.buttonAction, el.buttonParams || {}, null);
    };
  });
}

function switchToLevel(index) {
  if (index === currentLevelIndex || index < 0 || index >= levels.length) return;
  syncCurrentLevelObjects();
  currentLevelIndex = index;
  deselectAll();
  loadScene(levels[index].objects);
  applyLevelEnvironment(index);
  applyLevelPlayerSettings(index);
  applyLevelUiConfig(index);
  applyLevelSequences(index);
  applyLevelObjectiveDefs(index);
  applyLevelScatterLayers(index);
  applyLevelAmbientAudio(index);
  // A level switch is as much a document boundary as loading a different
  // project entirely -- undoing past it into a DIFFERENT level's history
  // would be confusing, not useful, so the stack resets clean.
  undoStack.length = 0;
  redoStack.length = 0;
  updateUndoRedoButtons();
  renderLevelList();
  showStatus(`Switched to "${levels[index].name}"`);
}

// The mid-PLAY counterpart to switchToLevel -- used by the Switch Level
// action (a gameplay-triggered transition, not an editor authoring action).
// Deliberately does NOT reset window.__gameState/undo/selection the way
// the editor-authoring path does: this happens mid-session, so score/lives
// must carry over (see the Switch Level action's own comment), and there's
// no editor selection or undo history to speak of during Play anyway.
function switchToLevelDuringPlay(index) {
  syncCurrentLevelObjects();
  currentLevelIndex = index;
  playTriggers = [];
  // Wave 6B (Priority E): cancel every in-flight Sequence cleanly on Restart
  // Level / Switch Level (both funnel through here) -- a mid-cutscene Delay
  // must never fire its continuation into a level it no longer belongs to.
  // Scoped to sequence-tagged deferred calls specifically (`sequenceRun:
  // true`), leaving any unrelated deferred work (e.g. a Priority M death-
  // animation removal already in flight) undisturbed.
  runningSequenceIds = [];
  deferredCalls = deferredCalls.filter((d) => !d.sequenceRun);
  activeCameraBlend = null; // Priority K: a mid-blend camera transition must never keep interpolating into a level it no longer belongs to
  activeCameraPath = null; // Wave 9C (Section 27): a mid-flight Camera Path must not keep sampling a Path object that no longer belongs to the current level either
  loadScene(levels[index].objects);
  applyLevelEnvironment(index);
  applyLevelPlayerSettings(index);
  applyLevelUiConfig(index);
  applyLevelSequences(index);
  applyLevelObjectiveDefs(index);
  applyLevelScatterLayers(index);
  applyLevelAmbientAudio(index);
  startAmbientAudioForCurrentLevel();
  initFogZonesForCurrentLevel();
  preparePlacedForPlay();
  for (const item of placed) wireItemTrigger(item);
  // Wave 9B -- same fix as enterPlayMode's own (see its comment): the OLD
  // level's Player must be despawned and the NEW level's Player spawned
  // BEFORE this level's own Start behaviors run, so an Equip Item (or any
  // other Player-touching) Start behavior on the newly entered level acts
  // on a real, live Player instead of `null` or a about-to-be-destroyed one.
  despawnPlayer();
  spawnPlayer(computeSpawnPoint());
  runStartBehaviors();
  renderLevelList();
}

document.getElementById('add-level-btn').addEventListener('click', () => {
  const name = document.getElementById('level-name-input').value.trim() || `Level ${levels.length + 1}`;
  syncCurrentLevelObjects();
  levels.push({ id: generateLevelId(), name, objects: [], environment: null, playerSettings: null, ui: null, description: '', ambientAudio: null, sequences: [], scatterLayers: [] });
  switchToLevel(levels.length - 1);
});
document.getElementById('rename-level-btn').addEventListener('click', () => {
  const index = Number(document.getElementById('level-select').value);
  const name = document.getElementById('level-name-input').value.trim();
  if (!name || Number.isNaN(index)) return;
  levels[index].name = name;
  renderLevelList();
});
document.getElementById('switch-level-btn').addEventListener('click', () => {
  const index = Number(document.getElementById('level-select').value);
  if (!Number.isNaN(index)) switchToLevel(index);
});
document.getElementById('delete-level-btn').addEventListener('click', () => {
  if (levels.length <= 1) { showStatus("Can't delete the only level"); return; }
  const index = Number(document.getElementById('level-select').value);
  if (Number.isNaN(index)) return;
  const deletedName = levels[index].name;
  levels.splice(index, 1);
  if (currentLevelIndex >= levels.length) currentLevelIndex = levels.length - 1;
  else if (index < currentLevelIndex) currentLevelIndex -= 1;
  else if (index === currentLevelIndex) {
    // The active level was deleted out from under itself -- load whichever
    // level now sits at that same slot instead of leaving `placed` pointing
    // at data that no longer exists anywhere in `levels`.
    currentLevelIndex = Math.min(index, levels.length - 1);
    loadScene(levels[currentLevelIndex].objects);
    applyLevelEnvironment(currentLevelIndex);
    applyLevelPlayerSettings(currentLevelIndex);
    applyLevelUiConfig(currentLevelIndex);
    applyLevelSequences(currentLevelIndex);
    applyLevelObjectiveDefs(currentLevelIndex);
  applyLevelScatterLayers(currentLevelIndex);
  }
  renderLevelList();
  showStatus(`Deleted "${deletedName}"`);
});
// Every object inside a duplicated level gets a FRESH id, with every
// internal reference (targetId/aiTargetId/lookAtTargetId/groupId/...)
// remapped to match -- otherwise the duplicate's behaviors/Node Graphs
// would keep pointing at the ORIGINAL level's objects by coincidence of
// sharing the same id strings. Fresh ids are guaranteed never to have
// existed before (monotonic counter), so a straightforward quoted-string
// swap across the whole serialized subtree is safe and exact -- no risk of
// a fresh id colliding with another old id mid-remap.
// Wave 6B (Priority M): optional second array (`extraArray`) -- when
// passed, IDs are collected from `objectsArray` exactly as before, but the
// substitution pass runs across BOTH arrays together, so any reference to a
// remapped object id living OUTSIDE `objectsArray` itself (a Sequence
// step's `cameraId`/`targetId` param, see Duplicate Level below) gets
// rewritten consistently too -- for free, via the same whole-JSON-string
// substitution trick, no separate per-field-name reference-walking code.
// Existing single-argument callers (Prefab instantiation) are unaffected:
// omitting `extraArray` returns exactly the old single-array shape.
function remapObjectIds(objectsArray, extraArray) {
  const idMap = new Map();
  for (const record of objectsArray) {
    if (record.id) idMap.set(record.id, generateItemId());
  }
  let json = JSON.stringify(extraArray !== undefined ? [objectsArray, extraArray] : objectsArray);
  for (const [oldId, newId] of idMap) json = json.split(`"${oldId}"`).join(`"${newId}"`);
  const parsed = JSON.parse(json);
  return extraArray !== undefined ? { objects: parsed[0], extra: parsed[1] } : parsed;
}
// "<Name> Copy", then "<Name> Copy 2", "<Name> Copy 3", ... -- never two
// levels silently sharing a display name.
function collisionSafeLevelName(baseName) {
  let candidate = `${baseName} Copy`;
  let n = 2;
  while (levels.some((l) => l.name === candidate)) { candidate = `${baseName} Copy ${n}`; n += 1; }
  return candidate;
}
document.getElementById('duplicate-level-btn').addEventListener('click', () => {
  const index = Number(document.getElementById('level-select').value);
  if (Number.isNaN(index)) return;
  syncCurrentLevelObjects(); // capture any in-progress edits on the active level before cloning ANY level's data
  const src = levels[index];
  // Deep-cloned, not shared references -- editing the duplicate's objects/
  // environment/HUD later must never silently also edit the source's.
  // Wave 6B (Priority M): `sequences` included here too -- an earlier
  // version of this handler (matching the same gap `serializeProject` had,
  // see Priority E's own CHANGELOG entry) silently dropped every Sequence
  // on Duplicate Level, found by this exact priority's own asset-heavy
  // dogfood requirement, not assumed correct from reading the code alone.
  const clone = JSON.parse(JSON.stringify({ objects: src.objects, environment: src.environment, playerSettings: src.playerSettings, ui: src.ui, description: src.description, ambientAudio: src.ambientAudio, sequences: src.sequences, objectiveDefs: src.objectiveDefs, scatterLayers: src.scatterLayers }));
  // Remapping objects and sequences TOGETHER (not two separate passes) is
  // what lets a Sequence step's own `cameraId`/`targetId` param -- an object
  // id reference living OUTSIDE `objects` itself -- get rewritten to point
  // at the DUPLICATE's own remapped objects, not silently left pointing at
  // the original level's (or nothing, since a re-generated id would no
  // longer exist in either level otherwise).
  const remapped = remapObjectIds(clone.objects, clone.sequences || []);
  clone.objects = remapped.objects;
  clone.sequences = remapped.extra;
  // Wave 9C (Section 5): Scatter Layer ids stay independent between the
  // source and the duplicate -- freshly generated here, then every cloned
  // object's own `scatterLayerId` tag is remapped to match, the same
  // "remap ids, then rewrite every reference to them together" approach
  // `remapObjectIds` already established for objects/sequences just above.
  if (Array.isArray(clone.scatterLayers) && clone.scatterLayers.length) {
    const layerIdMap = {};
    clone.scatterLayers = clone.scatterLayers.map((l) => {
      const newId = generateScatterLayerId();
      layerIdMap[l.id] = newId;
      return { ...l, id: newId };
    });
    for (const obj of clone.objects) { if (obj.scatterLayerId && layerIdMap[obj.scatterLayerId]) obj.scatterLayerId = layerIdMap[obj.scatterLayerId]; }
  }
  levels.splice(index + 1, 0, { id: generateLevelId(), name: collisionSafeLevelName(src.name), objects: clone.objects, environment: clone.environment, playerSettings: clone.playerSettings, ui: clone.ui, description: clone.description, ambientAudio: clone.ambientAudio, sequences: clone.sequences, objectiveDefs: clone.objectiveDefs, scatterLayers: clone.scatterLayers });
  if (startLevelIndex > index) startLevelIndex += 1;
  switchToLevel(index + 1);
  showStatus(`Duplicated "${src.name}"`);
});
document.getElementById('set-start-level-btn').addEventListener('click', () => {
  const index = Number(document.getElementById('level-select').value);
  if (Number.isNaN(index)) return;
  startLevelIndex = index;
  renderLevelList();
  showStatus(`"${levels[index].name}" is now the Start Level`);
});
function moveLevel(index, direction) {
  const target = index + direction;
  if (target < 0 || target >= levels.length) return;
  syncCurrentLevelObjects();
  [levels[index], levels[target]] = [levels[target], levels[index]];
  // Every index-based reference (which level is open, which level Play
  // boots into) must move WITH its level, not silently point at whatever
  // now occupies that slot after the swap.
  const remap = (i) => (i === index ? target : i === target ? index : i);
  currentLevelIndex = remap(currentLevelIndex);
  startLevelIndex = remap(startLevelIndex);
  renderLevelList();
}
document.getElementById('move-level-up-btn').addEventListener('click', () => {
  const index = Number(document.getElementById('level-select').value);
  if (!Number.isNaN(index)) moveLevel(index, -1);
});
document.getElementById('move-level-down-btn').addEventListener('click', () => {
  const index = Number(document.getElementById('level-select').value);
  if (!Number.isNaN(index)) moveLevel(index, 1);
});

// Bundles every level (not just the active one) so Export/Save/Import
// carry a whole multi-level project, not just whatever happened to be
// loaded at the moment -- syncCurrentLevelObjects first, so the active
// level's in-progress edits are included, not a stale snapshot from the
// last switch.
// Project format identity (Wave 3) -- every export from here on stamps
// this; nothing pre-Wave-3 ever had it, which is exactly the signal
// normalizeProjectData below uses to route older shapes through migration
// instead of trusting them to already match the current shape.
const PROJECT_FORMAT = 'digital-opus-project';
const PROJECT_FORMAT_VERSION = 3;

function serializeProject() {
  // Wave 8 (Priority A): ONE dependency-collection pass feeds every
  // asset-kind serializer below -- prefabs (now including the full
  // recursive closure, Section 7), mesh/texture/audio assets -- instead of
  // four independent scans that could (and did -- see the collector's own
  // comment) silently disagree about what's actually referenced.
  const deps = collectProjectDependencies();
  const bundledPrefabs = prefabs.filter((p) => deps.prefabs.has(p.name));
  return {
    format: PROJECT_FORMAT,
    version: PROJECT_FORMAT_VERSION,
    levels: levels.map((l) => ({ id: l.id, name: l.name, objects: l.objects, environment: l.environment, playerSettings: l.playerSettings, ui: l.ui, description: l.description, ambientAudio: l.ambientAudio, sequences: l.sequences, objectiveDefs: l.objectiveDefs, scatterLayers: l.scatterLayers })),
    currentLevelIndex,
    startLevelIndex,
    levelTransition: levelTransitionConfig,
    prefabs: bundledPrefabs,
    assets: serializeAssets(deps.meshAssets),
    textures: serializeTextureAssets(deps.textureAssets),
    audio: serializeAudioAssets(deps.audioAssets),
    meta: projectMeta,
    inputActionMap,
    itemDefs: currentItemDefs,
  };
}

// A round-tripped environment's `lightDir` comes back from JSON as a plain
// {x,y,z} object, not a real Opus.Vec3 instance -- App.setEnvironment
// validates `instanceof Vec3`, so passing it through unreconstructed would
// throw the moment a saved project with a customized environment reloads.
function normalizeEnvironment(env) {
  if (!env) return null;
  const out = { ...env };
  if (out.lightDir && !(out.lightDir instanceof Opus.Vec3)) out.lightDir = new Opus.Vec3(out.lightDir.x, out.lightDir.y, out.lightDir.z);
  return out;
}

// The ONE normalization path every generation of project data this editor
// has ever produced funnels through -- a raw array (oldest), `{objects,
// prefabs}` (pre-levels), unversioned `{levels, currentLevelIndex,
// prefabs}` (Wave 2), and the current versioned/asset-bearing shape (Wave
// 3) -- so loading never needs a second migration path scattered elsewhere,
// and NEVER mutates the caller's `parsed` object (the original imported
// file stays exactly as the user provided it; only the in-memory result of
// this function reflects the current shape). An unrecognized future
// `version` fails loudly rather than guessing at a shape it doesn't know.
function normalizeProjectData(parsed) {
  let newLevels;
  let newIndex = 0;
  let newStartIndex = 0;
  let newLevelTransition = { mode: 'instant', duration: 0.4 };
  let bundledPrefabs;
  let assets;
  let textures;
  let audio;
  let meta;
  let newInputActionMap;
  let itemDefs = [];
  if (Array.isArray(parsed)) {
    newLevels = [{ name: 'Level 1', objects: parsed, environment: null, playerSettings: null, ui: null, description: '', ambientAudio: null }];
  } else if (Number.isInteger(parsed.version) && parsed.version > PROJECT_FORMAT_VERSION) {
    throw new Error(`This project was saved by a newer version of the editor (format version ${parsed.version}, this editor supports up to ${PROJECT_FORMAT_VERSION}). Open it in a newer editor build.`);
  } else if (Array.isArray(parsed.levels)) {
    newLevels = parsed.levels.map((l) => ({ id: l.id, name: l.name || 'Level', objects: Array.isArray(l.objects) ? l.objects : [], environment: normalizeEnvironment(l.environment), playerSettings: l.playerSettings || null, ui: l.ui || null, description: l.description || '', ambientAudio: l.ambientAudio || null, sequences: Array.isArray(l.sequences) ? l.sequences : [], objectiveDefs: Array.isArray(l.objectiveDefs) ? l.objectiveDefs : [], scatterLayers: Array.isArray(l.scatterLayers) ? l.scatterLayers : [] }));
    if (Number.isInteger(parsed.currentLevelIndex) && parsed.currentLevelIndex >= 0 && parsed.currentLevelIndex < newLevels.length) newIndex = parsed.currentLevelIndex;
    newStartIndex = (Number.isInteger(parsed.startLevelIndex) && parsed.startLevelIndex >= 0 && parsed.startLevelIndex < newLevels.length) ? parsed.startLevelIndex : 0;
    bundledPrefabs = parsed.prefabs;
    assets = parsed.assets;
    textures = parsed.textures;
    audio = parsed.audio;
    meta = parsed.meta;
    newInputActionMap = parsed.inputActionMap;
    itemDefs = Array.isArray(parsed.itemDefs) ? parsed.itemDefs : [];
    if (parsed.levelTransition && (parsed.levelTransition.mode === 'instant' || parsed.levelTransition.mode === 'fade')) newLevelTransition = { mode: parsed.levelTransition.mode, duration: parsed.levelTransition.duration > 0 ? parsed.levelTransition.duration : 0.4 };
  } else if (Array.isArray(parsed.objects)) {
    newLevels = [{ name: 'Level 1', objects: parsed.objects, environment: null, playerSettings: null, ui: null, description: '', ambientAudio: null }];
    bundledPrefabs = parsed.prefabs;
  } else {
    throw new Error('not a valid project file');
  }
  ensureLevelIds(newLevels);
  return { levels: newLevels, currentLevelIndex: newIndex, startLevelIndex: newStartIndex, levelTransition: newLevelTransition, prefabs: bundledPrefabs, assets, textures, audio, meta, inputActionMap: newInputActionMap, itemDefs };
}

function loadProjectFull(parsed, sourceLabel) {
  const normalized = normalizeProjectData(parsed);
  loadingProjectGuard = true;
  levels = normalized.levels;
  currentLevelIndex = normalized.currentLevelIndex;
  startLevelIndex = normalized.startLevelIndex;
  levelTransitionConfig = normalized.levelTransition;
  document.getElementById('level-transition-mode').value = levelTransitionConfig.mode;
  document.getElementById('level-transition-duration').value = levelTransitionConfig.duration;
  projectMeta = normalized.meta ? { ...defaultProjectMeta(), ...normalized.meta } : defaultProjectMeta();
  renderProjectMetaPanel();
  // A project saved before Wave 5 has an inputActionMap with only
  // interact/attack (or none at all) -- merged over INPUT_ACTION_DEFAULTS
  // so every new action (moveForward/Back/Left/Right/jump) still gets its
  // exact pre-Wave-5 hardcoded key, never `undefined`.
  inputActionMap = { ...INPUT_ACTION_DEFAULTS, ...(normalized.inputActionMap || {}) };
  renderInputActionPanel();
  // Wave 8 (Priority D): project-level, not per-level -- loaded once here,
  // like prefabs/assets, not inside applyLevel*() the way Objectives (a
  // deliberately per-level registry) are.
  currentItemDefs = Array.isArray(normalized.itemDefs) ? normalized.itemDefs.map((d) => ({ ...d })) : [];
  renderItemDefList();
  loadAssets(normalized.assets);
  loadTextureAssets(normalized.textures);
  loadAudioAssets(normalized.audio);
  loadProjectData(levels[currentLevelIndex].objects, sourceLabel, normalized.prefabs);
  loadingProjectGuard = false;
  applyLevelEnvironment(currentLevelIndex);
  applyLevelPlayerSettings(currentLevelIndex);
  applyLevelUiConfig(currentLevelIndex);
  applyLevelSequences(currentLevelIndex);
  applyLevelObjectiveDefs(currentLevelIndex);
  applyLevelScatterLayers(currentLevelIndex);
  applyLevelAmbientAudio(currentLevelIndex);
  renderLevelList();
}

document.getElementById('export-btn').addEventListener('click', () => {
  const project = serializeProject();
  const blob = new Blob([JSON.stringify(project, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'scene.json';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
});

// Multiple named local projects, not the one hardcoded 'editor-project'
// slot -- `SaveSystem` already supported arbitrary slot names and now
// `.list()` (new: engine/src/16-save.js) can enumerate them, so this is
// purely an editor-side UI on top of existing/newly-exposed engine
// capability. This is the bounded slice of "multi-scene" actually built
// this batch: several independently-named LOCAL projects to switch
// between, not multiple levels loaded within one running project (a
// bigger, still-open architectural change -- see the final report).
function renderProjectMetaPanel() {
  document.getElementById('meta-title-input').value = projectMeta.title;
  document.getElementById('meta-author-input').value = projectMeta.author;
  document.getElementById('meta-version-input').value = projectMeta.version;
  document.getElementById('meta-description-input').value = projectMeta.description;
}
renderProjectMetaPanel();
for (const [id, key] of [['meta-title-input', 'title'], ['meta-author-input', 'author'], ['meta-version-input', 'version'], ['meta-description-input', 'description']]) {
  document.getElementById(id).addEventListener('input', (e) => { projectMeta[key] = e.target.value; });
}

function renderProjectList() {
  const select = document.getElementById('project-list-select');
  const slots = app.save.list();
  if (slots.length === 0) {
    select.innerHTML = '<option value="">(no saved projects yet)</option>';
    return;
  }
  select.innerHTML = slots.map((s) => {
    const when = s.savedAt ? new Date(s.savedAt).toLocaleString() : 'unknown time';
    return `<option value="${escapeHtml(s.slot)}">${escapeHtml(s.slot)} — ${escapeHtml(when)}</option>`;
  }).join('');
}
renderProjectList();

document.getElementById('save-btn').addEventListener('click', () => {
  const name = document.getElementById('project-name-input').value.trim() || 'editor-project';
  const ok = app.save.save(name, serializeProject());
  showStatus(ok ? `Saved as "${name}"` : 'Save failed');
  renderProjectList();
});

document.getElementById('delete-project-btn').addEventListener('click', () => {
  const select = document.getElementById('project-list-select');
  const name = select.value;
  if (!name) return;
  app.save.delete(name);
  showStatus(`Deleted "${name}"`);
  renderProjectList();
});

// Export Tiers -- Editable Game and Playable Game share this ONE builder
// (not two divergent copies): both inline the exact same engine bundle and
// the exact same editor/runtime script (this very file) into one file, and
// boot through the exact same loadProjectFull/enterPlayMode path Crate Run
// itself ships through. The only difference between tiers is one embedded
// boolean (window.__OPUS_PLAYABLE_ONLY__) that the SAME script reads at its
// own boot time to decide whether the chrome-toggle button stays reachable
// (see playableOnlyMode, set near setEditorVisible) -- deliberately not a
// second, separately-built "player-only" runtime, which would inevitably
// drift from whatever the real editor/gameplay code actually does. Assets
// (mesh/texture/audio, all embedded as base64 in project JSON already) are
// carried through for free since both tiers embed the full serialized
// project either way -- there's no separate "asset embedding" step tiers
// need to differ on.
// Wave 6B (Priority G) fixed a real, severe bug here once already (an
// export silently missing the entire engine bundle -- see git history/
// CHANGELOG for the full story if this block's own shape ever needs
// touching again: the dev-time cache-busting block below is matched by
// ONE regex in `composeExportHTML`, not two independent replaces that can
// drift out of sync with each other).
//
// Game-catalog pass: the actual templating logic (the regex-replace that
// assembles engine+editor+project into one HTML page) now lives in
// build/export-template.js's `composeExportHTML`, shared verbatim with the
// build-time catalog build script (build/build-games.js) -- ONE export
// implementation, not two. This function's own job is now just gathering
// the four inputs that only exist in a live browser (fetches + the current
// in-memory project) and handing them to that shared function.
async function buildExportHTML(playableOnly) {
  const [engineJS, editorJS, htmlTemplate, templateJS] = await Promise.all([
    fetch('../dist/opus-engine.js', { cache: 'reload' }).then((r) => r.text()),
    fetch('src/01-editor.js', { cache: 'reload' }).then((r) => r.text()),
    fetch('index.html', { cache: 'reload' }).then((r) => r.text()),
    fetch('../build/export-template.js', { cache: 'reload' }).then((r) => r.text()),
  ]);
  const embedded = JSON.stringify(serializeProject());
  // Dogfood-02 fix: the fallback here used to be the literal string
  // 'Digital Opus — Crate Run' -- the starter demo's own name -- so any
  // project whose author filled in the Start Screen's own Title (an
  // entirely separate field from this Project Meta title, easy to never
  // notice exists) but never touched the less-discoverable Project tab's
  // Title field shipped an exported .html carrying a COMPLETELY UNRELATED
  // other game's name in its browser tab, every time. Falls back to the
  // Start Screen's own title (something every dogfooded game so far has
  // actually set) before finally falling back to a neutral, non-demo-
  // specific name.
  const title = projectMeta.title || currentUiConfig.startScreen.title || 'Digital Opus Game';
  return composeExportHTML({ htmlTemplate, engineJS, editorJS, templateJS, embeddedProjectJSON: embedded, playableOnly, title });
}

// Export size safety warning -- shown regardless of tier (both embed the
// same assets), since a multi-megabyte export is still valid but worth
// flagging before someone emails it or hits a host's upload limit. 15MB is
// comfortably under common free-tier upload caps (itch.io: 1GB, but email/
// chat attachment limits are often 10-25MB) while being far above what any
// text-heavy or lightly-textured project should ever reach.
const EXPORT_SIZE_WARNING_BYTES = 15 * 1024 * 1024;
function checkExportSize(byteLength) {
  const warningEl = document.getElementById('export-size-warning');
  if (!warningEl) return;
  if (byteLength > EXPORT_SIZE_WARNING_BYTES) {
    warningEl.textContent = `⚠ This export is ${(byteLength / (1024 * 1024)).toFixed(1)}MB -- large for a single file (usually from embedded textures/audio/models). Still valid, but worth checking before sharing it.`;
    warningEl.style.display = '';
  } else {
    warningEl.style.display = 'none';
  }
}
function downloadHTML(html, filename) {
  const blob = new Blob([html], { type: 'text/html' });
  checkExportSize(blob.size);
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
document.getElementById('export-standalone-btn').addEventListener('click', async () => {
  showStatus('Building editable game export…');
  try {
    const html = await buildExportHTML(false);
    downloadHTML(html, 'editable-game.html');
    showStatus('Editable game exported');
  } catch (err) {
    showStatus(`Export failed: ${err.message}`);
  }
});
document.getElementById('export-playable-btn').addEventListener('click', async () => {
  showStatus('Building playable game export…');
  try {
    const html = await buildExportHTML(true);
    downloadHTML(html, 'playable-game.html');
    showStatus('Playable game exported (no editor access)');
  } catch (err) {
    showStatus(`Export failed: ${err.message}`);
  }
});

// --- Custom Script trust gate (AUDIT.md finding #1) ---
// Defaults to trusted for the live authoring session -- building and
// testing your own project should just work, no friction. Re-gates to
// untrusted whenever a project is loaded from OUTSIDE the current
// session (localStorage or a file) and that project actually contains a
// Custom Script behavior. Node Graph is deliberately not gated: its nodes
// are a fixed, safe vocabulary (message/counter/win/...), not arbitrary
// code -- there's nothing in it to distrust.
let scriptsTrusted = true;
const scriptTrustBanner = document.getElementById('script-trust-banner');

function projectHasScripts(data) {
  return data.some((record) => record.kind === 'cube' && (record.behaviors || []).some((b) => b.action === 'script' && b.param));
}

// Additive only: a bundled prefab whose name already exists locally is
// left alone (the local copy is treated as canonical), so importing
// someone else's project can never silently overwrite your own prefab of
// the same name.
function mergeBundledPrefabs(bundled) {
  if (!Array.isArray(bundled) || bundled.length === 0) return 0;
  let added = 0;
  for (const p of bundled) {
    if (!p || !p.name || !p.record) continue;
    if (prefabs.some((existing) => existing.name === p.name)) continue;
    // Multi-object prefabs (Prefabs 2.0) carry `records`/`rootId` alongside
    // `record` -- omitting them here silently downgraded EVERY multi-piece
    // prefab (a Spawner's own enemy assembly, a Save-as-Prefab'd Door/
    // Turret) to single-object-only the moment a player loaded a project
    // for the first time (or with a differently-shaped local copy already
    // merged), since a Spawner/Spawn Prefab action reads this SAME shared
    // `prefabs` array and only spawns the root when `records` is absent.
    // Found live during Wave 5's performance sweep: a fresh, empty-
    // localStorage load of a real shipped multi-level game (`Sentry`, a
    // tagged root + one parented child) merged in as `{name, record}` only
    // -- every Spawner-produced enemy from then on had zero children.
    const entry = { name: p.name, record: p.record };
    if (p.records) entry.records = p.records;
    if (p.rootId) entry.rootId = p.rootId;
    prefabs.push(entry);
    added++;
  }
  if (added > 0) { savePrefabs(); renderPrefabPalette(); }
  return added;
}

function loadProjectData(data, sourceLabel, bundledPrefabs) {
  if (projectHasScripts(data)) {
    scriptsTrusted = false;
    scriptTrustBanner.classList.add('visible');
  }
  loadScene(data);
  const addedPrefabCount = mergeBundledPrefabs(bundledPrefabs);
  showStatus(`${sourceLabel} loaded${addedPrefabCount ? ` (+${addedPrefabCount} prefab${addedPrefabCount === 1 ? '' : 's'})` : ''}`);
}

document.getElementById('script-trust-enable-btn').addEventListener('click', () => {
  scriptsTrusted = true;
  scriptTrustBanner.classList.remove('visible');
  showStatus('Custom Script enabled for this project');
});

document.getElementById('load-btn').addEventListener('click', () => {
  const name = document.getElementById('project-list-select').value;
  if (!name) { showStatus('No project selected'); return; }
  const data = app.save.load(name);
  if (!data) {
    showStatus('No saved project found');
    return;
  }
  document.getElementById('project-name-input').value = name;
  loadProjectFull(data, `Project "${name}"`);
});

document.getElementById('import-project-btn').addEventListener('click', () => {
  document.getElementById('import-project-input').click();
});
document.getElementById('import-project-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    const parsed = JSON.parse(await file.text());
    loadProjectFull(parsed, `Imported ${file.name}`);
  } catch (err) {
    showStatus(`Import failed: ${err.message}`);
  }
});

// Geometry-only import (Opus.Mesh.fromGLTF, engine/src/21-gltf.js) for a
// static model -- no materials/textures beyond the one bounded base-color
// texture already extracted. Wave 6 (Priority C) added a genuine second
// case: a SKINNED model (Opus.Mesh.fromSkinnedGLTF), auto-detected by
// trying the skinned path FIRST and falling back to the static one --
// one Import Model button serves both, rather than asking the author to
// already know which kind of file they're dropping in. A real model still
// reads as "built with this editor" the same way a hand-authored one does:
// placed as an ordinary cube-kind item with the imported mesh, draggable,
// duplicable, deletable, and behavior-attachable exactly like any other --
// a skinned instance ALSO gets `entity.skin` set automatically by
// App.addEntity, so it's already animating (clip 0, looped) the moment
// it's placed, no extra author step.
document.getElementById('import-model-btn').addEventListener('click', () => {
  document.getElementById('import-model-input').click();
});
// Places one instance of a mesh asset -- shared by the import handler
// (first instance) and the Asset Library's own Place button (every
// subsequent one). Every instance shares the SAME mesh handle (see
// getAssetMeshHandle) -- one GPU buffer, however many placed copies.
function placeAssetInstance(asset, position) {
  pushUndo();
  const entity = app.addEntity({ mesh: getAssetMeshHandle(asset), color: [0.8, 0.8, 0.85], position, scale: new Opus.Vec3(1, 1, 1) });
  const item = { kind: 'cube', entity, behaviors: [], assetId: asset.id };
  addPlaced(item);
  selectItem(item);
  renderSceneList();
  return item;
}
document.getElementById('import-texture-btn').addEventListener('click', () => {
  document.getElementById('import-texture-input').click();
});
document.getElementById('import-texture-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    const dataURL = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error('could not read file'));
      reader.readAsDataURL(file);
    });
    const img = await decodeTextureImage(dataURL);
    const asset = { id: generateTextureId(), name: file.name.replace(/\.[^.]+$/, ''), dataURL, sourceFilename: file.name, image: img, textureHandle: null, pendingCallbacks: [] };
    textureAssets.push(asset);
    renderTextureLibrary();
    showStatus(`Imported ${file.name} to Texture Library`);
  } catch (err) {
    showStatus(`Texture import failed: ${err.message}`);
  }
});
document.getElementById('import-model-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = ''; // clear now so re-selecting the same file still fires 'change'
  if (!file) return;
  try {
    const isGLB = file.name.toLowerCase().endsWith('.glb');
    const data = isGLB ? await file.arrayBuffer() : await file.text();
    // Wave 6 (Priority C): try the skinned import path FIRST -- a skinned
    // file dropped in as a plain static import would silently lose its
    // whole rig (fromGLTF bakes world transforms and never reads
    // JOINTS_0/WEIGHTS_0/skins at all). fromSkinnedGLTF throws a specific,
    // recognizable reason ('no skinned mesh node found') for an ordinary
    // static file, which is exactly the fallback signal needed here -- any
    // OTHER thrown reason (a malformed accessor, too many joints, etc) is a
    // real problem with a real skinned file and should surface as an
    // Import failed status, not be silently swallowed into a static import
    // attempt that would only confuse the actual error.
    let asset;
    let arrays;
    try {
      const skinnedArrays = Opus.Mesh.toSkinnedArrays(Opus.Mesh.fromSkinnedGLTF(data));
      asset = {
        id: generateAssetId(), name: file.name.replace(/\.(glb|gltf)$/i, ''), type: 'skinnedMesh',
        positions: Array.from(skinnedArrays.positions), normals: Array.from(skinnedArrays.normals), indices: Array.from(skinnedArrays.indices),
        uvs: Array.from(skinnedArrays.uvs), joints: Array.from(skinnedArrays.joints), weights: Array.from(skinnedArrays.weights),
        skin: flattenSkinForStorage(skinnedArrays.skin),
        sourceFilename: file.name, meshHandle: null,
      };
      arrays = { textureDataURL: null }; // skinned import has no texture-extraction path yet -- bounded scope, see CHANGELOG
    } catch (skinErr) {
      if (!/no skinned mesh node found/.test(skinErr.message)) throw skinErr;
      const meshDesc = Opus.Mesh.fromGLTF(data);
      arrays = Opus.Mesh.toArrays(meshDesc);
      asset = {
        id: generateAssetId(), name: file.name.replace(/\.(glb|gltf)$/i, ''), type: 'mesh',
        positions: Array.from(arrays.positions), normals: Array.from(arrays.normals), indices: Array.from(arrays.indices),
        sourceFilename: file.name, meshHandle: meshDesc,
      };
    }
    assets.push(asset);
    renderAssetLibrary();
    const item = placeAssetInstance(asset, new Opus.Vec3(0, 1, 0));
    // Bounded auto-texturing: if the glTF embedded a base-color texture
    // (see 21-gltf.js), turn it into a real Texture Asset and apply it to
    // the just-placed instance immediately -- the whole point of extracting
    // it was to make an imported textured model actually LOOK textured
    // without a separate manual step.
    if (arrays.textureDataURL) {
      try {
        const img = await decodeTextureImage(arrays.textureDataURL);
        const texAsset = { id: generateTextureId(), name: `${asset.name} texture`, dataURL: arrays.textureDataURL, sourceFilename: file.name, image: img, textureHandle: null, pendingCallbacks: [] };
        textureAssets.push(texAsset);
        renderTextureLibrary();
        item.textureAssetId = texAsset.id;
        applyTextureToEntity(item.entity, texAsset);
        showStatus(`Imported ${file.name} to Asset Library (with embedded texture)`);
      } catch (texErr) {
        showStatus(`Imported ${file.name} (embedded texture failed to decode: ${texErr.message})`);
      }
    } else if (asset.type === 'skinnedMesh') {
      const clipNames = asset.skin.clips.map((c) => c.name).join(', ') || '(no clips)';
      showStatus(`Imported ${file.name} to Asset Library (animated -- ${asset.skin.jointCount} joints, clips: ${clipNames})`);
    } else {
      showStatus(`Imported ${file.name} to Asset Library`);
    }
  } catch (err) {
    showStatus(`Import failed: ${err.message}`);
  }
});

// --- Game/editor hybrid shell ---
// The shipped artifact opens as a real, complete, playable game (not a
// blank canvas) with the editor one click away — proof the shipped game
// is genuinely built from, and editable with, the same no-code tool.

// Boost pads: a fixed 'enter' trigger + a new 'boost' action, giving the
// craft a forward velocity impulse when driven through. Route/traversal
// variety (a shortcut lane worth aiming for) rather than pure collect-and-
// avoid — and exposed as a real palette-adjacent no-code action (the
// dropdown), not just something reachable via Custom Script.
function spawnBoostPad(position, force = 11) {
  const entity = app.addEntity({ mesh: boostMesh, color: [0.3, 0.85, 1], position: position.clone(), scale: new Opus.Vec3(1.3, 0.7, 1.3) });
  entity.spin = 1.5; // slow spin reads as "interactive", same trick crates already use
  const item = { kind: 'cube', entity, behaviors: [{ trigger: 'enter', action: 'boost', param: String(force) }] };
  addPlaced(item);
  return item;
}

function buildStarterGame() {
  // Two islands connected by open water — more area to actually drive
  // across, not just a bigger single landmass. Proves multi-terrain works,
  // not just a config tweak.
  const islandDefs = [
    { seed: 7, position: new Opus.Vec3(-11, 0, 0), crateOffsets: [[5, 1], [-4, 4], [3, -5]], hazardOffset: [-3, -2] },
    // Patrol hazard: the same static 'lose' cube, but oscillating along one
    // axis, so avoiding it takes timing, not just memorized position.
    { seed: 91, position: new Opus.Vec3(11, 0, 0), crateOffsets: [[5, 1], [-4, 4], [3, -5]], hazardOffset: [-3, -2], hazardPatrol: { axis: 'x', range: 2.5, speed: 1.1 } },
    // Off the east-west line, not just further out on it -- a triangular
    // layout gives real navigation choices, not just "further".
    { seed: 233, position: new Opus.Vec3(0, 0, 19), crateOffsets: [[4, 3], [-5, 2], [0, -4]], hazardOffset: [3, 4], hazardPatrol: { axis: 'z', range: 2.5, speed: 0.9 } },
    { seed: 458, position: new Opus.Vec3(0, 0, -19), crateOffsets: [[-3, -4], [4, -2], [-1, 5]], hazardOffset: [4, 3] },
    { seed: 612, position: new Opus.Vec3(20, 0, 20), crateOffsets: [[2, 5], [-5, -1], [4, -4]], hazardOffset: [-4, 2] },
    // Two more, filling out the SW/NW corners to balance island5's NE
    // corner -- same ~28-unit distance from origin, so both MAP_BOUNDARY
    // (40) and the water size (84) already have enough headroom to cover
    // them without adjustment.
    { seed: 799, position: new Opus.Vec3(-20, 0, -20), crateOffsets: [[3, 2], [-4, -3], [2, -5]], hazardOffset: [-3, 4], hazardPatrol: { axis: 'x', range: 2.5, speed: 1.0 } },
    { seed: 911, position: new Opus.Vec3(-20, 0, 20), crateOffsets: [[-2, 4], [4, -1], [-5, -3]], hazardOffset: [3, -4] },
  ];
  const TOTAL_CRATES = islandDefs.reduce((sum, def) => sum + def.crateOffsets.length, 0);
  // Recoloring the crate green on pickup was easy to miss at a glance or in
  // motion -- disappearing entirely is unambiguous. The visible-check guard
  // stops a re-entry (driving away and back over the same spot) from
  // double-counting; enterPlayMode resets every cube back to visible at the
  // start of each fresh session, so this isn't a one-way flag.
  const COLLECT_SCRIPT = "if(!entity.visible)return;entity.visible=false;"
    + "window.__gameState.crates=(window.__gameState.crates||0)+1;"
    + "app.audio.playBlip({frequency:660+window.__gameState.crates*40,duration:0.12,type:'sine'});"
    + `game.setObjective('Crates: '+window.__gameState.crates+'/${TOTAL_CRATES}');`
    + `if(window.__gameState.crates>=${TOTAL_CRATES})game.win();`;

  for (const def of islandDefs) {
    const terrainOpts = { seed: def.seed, size: 22, segments: 48, radius: 9, position: def.position };
    const terrain = app.createTerrain(terrainOpts);
    addPlaced({ kind: 'terrain', handle: terrain, options: terrainOpts });

    for (const [dx, dz] of def.crateOffsets) {
      const x = def.position.x + dx;
      const z = def.position.z + dz;
      const y = terrain.sampleHeight(x, z) + 0.5;
      const entity = app.addEntity({ mesh: cubeMesh, color: [1, 0.75, 0.15], position: new Opus.Vec3(x, y, z), scale: new Opus.Vec3(0.8, 0.8, 0.8) });
      entity.spin = 0.8;
      addPlaced({ kind: 'cube', entity, behaviors: [{ trigger: 'enter', action: 'script', param: COLLECT_SCRIPT }] });
    }

    const hx = def.position.x + def.hazardOffset[0];
    const hz = def.position.z + def.hazardOffset[1];
    const hy = terrain.sampleHeight(hx, hz) + 0.5;
    const hazard = app.addEntity({ mesh: mineMesh, color: [0.85, 0.2, 0.2], position: new Opus.Vec3(hx, hy, hz), scale: new Opus.Vec3(1.1, 1.1, 1.1) });
    if (def.hazardPatrol) {
      hazard.patrol = { base: hazard.position.clone(), phase: Math.random() * Math.PI * 2, ...def.hazardPatrol };
      hazard.spin = 2.2; // spinning + moving reads as "active danger" vs. the static hazards
    }
    addPlaced({ kind: 'cube', entity: hazard, behaviors: [{ trigger: 'enter', action: 'lose', param: '' }] });
  }

  // Landmark, imported via Opus.Mesh.fromGLTF -- a real model (multi-node,
  // see beaconMesh above) rather than another hand-built shape, on the
  // home island, clear of its crates/hazard.
  {
    const homeTerrainItem = placed.find((p) => p.kind === 'terrain' && p.options.seed === islandDefs[0].seed);
    const bx = islandDefs[0].position.x, bz = islandDefs[0].position.z + 6;
    const by = homeTerrainItem.handle.sampleHeight(bx, bz);
    const beacon = app.addEntity({ mesh: beaconMesh, color: [0.85, 0.82, 0.9], position: new Opus.Vec3(bx, by, bz), scale: new Opus.Vec3(1, 1, 1) });
    addPlaced({ kind: 'cube', entity: beacon, behaviors: [] });
  }

  // A bonus crate authored via the node graph (start -> Increment Counter
  // -> Message), not Custom Script -- proves the graph system on real
  // shipped content, not just the editor's own tests. Optional: doesn't
  // gate the main win condition, just a small discoverable extra.
  {
    const bonusIsland = islandDefs[1];
    const bx = bonusIsland.position.x, bz = bonusIsland.position.z - 6;
    const bonusTerrainItem = placed.find((p) => p.kind === 'terrain' && p.options.seed === bonusIsland.seed);
    const by = bonusTerrainItem.handle.sampleHeight(bx, bz) + 0.5;
    const bonusGraph = {
      nodes: [
        { id: 'b1', type: 'incrementCounter', counter: 'bonus' },
        { id: 'b2', type: 'message', text: '✨ Bonus crate found!' },
      ],
      edges: [
        { from: 'start', to: 'b1', kind: 'next' },
        { from: 'b1', to: 'b2', kind: 'next' },
      ],
    };
    const bonusEntity = app.addEntity({ mesh: cubeMesh, color: [0.85, 0.4, 1], position: new Opus.Vec3(bx, by, bz), scale: new Opus.Vec3(1, 1, 1) });
    bonusEntity.spin = 1.6;
    addPlaced({ kind: 'cube', entity: bonusEntity, behaviors: [{ trigger: 'enter', action: 'graph', graph: bonusGraph }] });
  }

  const waterOpts = { size: 84, segments: 48, position: new Opus.Vec3(0, -1.6, 0) };
  const water = app.createWater(waterOpts);
  addPlaced({ kind: 'water', handle: water, options: waterOpts });

  // Boost pads on the open-water routes between islands — a shortcut lane
  // worth steering for, not just open water to cross. Hover height over
  // water is waterY + 0.55, so pads sit close to that to be actually driven
  // through rather than under or over.
  spawnBoostPad(new Opus.Vec3(0, -1.0, 0));
  spawnBoostPad(new Opus.Vec3(-5, -1.0, 10));
  spawnBoostPad(new Opus.Vec3(10, -1.0, -10));
  spawnBoostPad(new Opus.Vec3(-15, -1.0, -10));
  spawnBoostPad(new Opus.Vec3(-15, -1.0, 10));

  renderSceneList();
}

const appEl = document.getElementById('app');
const chromeToggleBtn = document.getElementById('chrome-toggle-btn');
// Export Tiers: an "Export Playable Game" sets window.__OPUS_PLAYABLE_ONLY__
// (see the export handler below) before this same editor/runtime script
// runs -- the identical code executes either way (see that handler's own
// comment on why: NOT a second, divergent runtime), this flag only decides
// whether the ONE entry point back into editing (the chrome-toggle button)
// is left reachable. Checked inside the click handler itself, not just by
// hiding the button, so a button re-shown by some other bug still can't
// actually open the editor.
let playableOnlyMode = false;

function setEditorVisible(visible) {
  if (playableOnlyMode && visible) return;
  appEl.classList.toggle('editor-hidden', !visible);
  chromeToggleBtn.textContent = visible ? '✕ Close Editor' : '🛠 Edit This Game';
  if (visible) {
    if (playMode) exitPlayMode();
  } else if (!playMode) {
    window.__gameState = {};
    enterPlayMode();
    // Starter-scene-specific initial readout; a generic "on level start"
    // objective hook is the natural next step once there's more than one
    // authored scenario to support.
    const collectibleCount = placed.filter((item) => item.kind === 'cube' && item.behaviors.some((b) => b.action === 'script' && b.param.includes('__gameState.crates'))).length;
    if (collectibleCount > 0) setObjective(`Crates: 0/${collectibleCount}`);
  }
}

chromeToggleBtn.addEventListener('click', () => setEditorVisible(appEl.classList.contains('editor-hidden')));

// --- Editor shell: tab strips, collapsible sections, palette search ---
// (UI/UX rearchitecture pass -- see EDITOR-UI-REARCHITECTURE-REPORT.md.)
// Every element these functions touch already existed under the old single-
// column layout; this only changes which tab/section shows it, never how it
// works, so no other function in this file needed to change to support it.
function activateTab(groupAttr, name) {
  document.querySelectorAll(`[data-${groupAttr}]`).forEach((btn) => {
    btn.classList.toggle('active', btn.dataset[groupAttr === 'left-tab' ? 'leftTab' : 'rightTab'] === name);
  });
  document.querySelectorAll(`[data-tab-panel]`).forEach((panel) => {
    if (panel.closest(groupAttr === 'left-tab' ? '#left-panel' : '#right-panel')) {
      panel.classList.toggle('active', panel.dataset.tabPanel === name);
    }
  });
}
document.querySelectorAll('#left-tabs [data-left-tab]').forEach((btn) => {
  btn.addEventListener('click', () => activateTab('left-tab', btn.dataset.leftTab));
});
document.querySelectorAll('#right-tabs [data-right-tab]').forEach((btn) => {
  btn.addEventListener('click', () => activateTab('right-tab', btn.dataset.rightTab));
});

// Collapsible sections (Environment/Player/Ambient Audio/HUD/Start Screen/
// Win-Lose/Save/Import-Export) -- one level of collapse, state kept only in
// the DOM class (not project data, not even localStorage yet -- editor
// layout preferences are explicitly NOT project data, see section 70 of the
// rearchitecture spec; local persistence of the collapse state itself is a
// small enough follow-up to skip this pass without losing anything users
// can't just re-expand in one click).
document.querySelectorAll('.section-header[data-section]').forEach((header) => {
  header.addEventListener('click', () => {
    const body = document.querySelector(`[data-section-body="${header.dataset.section}"]`);
    header.classList.toggle('collapsed');
    if (body) body.classList.toggle('collapsed');
  });
});

// Palette search (Objects tab) -- filters the existing static palette items
// by their own visible text; category headers hide themselves too once
// every item under them is filtered out, so a search never leaves a bare
// "World" label over nothing.
document.getElementById('palette-search').addEventListener('input', (e) => {
  const q = e.target.value.trim().toLowerCase();
  const objectsTab = document.getElementById('left-tab-objects');
  const items = Array.from(objectsTab.querySelectorAll('.palette-item'));
  let anyVisible = false;
  for (const el of items) {
    const match = !q || el.textContent.toLowerCase().includes(q);
    el.classList.toggle('palette-hidden', !match);
    if (match) anyVisible = true;
  }
  objectsTab.querySelectorAll('.palette-category').forEach((cat) => {
    let node = cat.nextElementSibling;
    let hasVisible = false;
    while (node && node.classList.contains('palette-item')) {
      if (!node.classList.contains('palette-hidden')) hasVisible = true;
      node = node.nextElementSibling;
    }
    cat.style.display = hasVisible ? '' : 'none';
  });
  document.getElementById('palette-empty').style.display = anyVisible ? 'none' : '';
});

// Narrow-screen drawers (see the @media rule in index.html) -- at desktop
// widths these buttons/scrim are display:none and this code is simply never
// triggered by anything, so it costs nothing there. Opening one drawer
// closes the other (both are wide enough to fully cover the viewport at
// narrow widths, so showing both at once would just stack one over the
// other uselessly); the scrim closes whichever is open, same as tapping
// outside a normal mobile drawer.
function setNarrowPanel(panelId, visible) {
  document.getElementById(panelId).classList.toggle('narrow-visible', visible);
  const otherOpen = document.getElementById('left-panel').classList.contains('narrow-visible')
    || document.getElementById('right-panel').classList.contains('narrow-visible');
  document.getElementById('narrow-scrim').classList.toggle('visible', otherOpen);
}
document.getElementById('narrow-left-toggle').addEventListener('click', () => {
  const willShow = !document.getElementById('left-panel').classList.contains('narrow-visible');
  setNarrowPanel('right-panel', false);
  setNarrowPanel('left-panel', willShow);
});
document.getElementById('narrow-right-toggle').addEventListener('click', () => {
  const willShow = !document.getElementById('right-panel').classList.contains('narrow-visible');
  setNarrowPanel('left-panel', false);
  setNarrowPanel('right-panel', willShow);
});
document.getElementById('narrow-scrim').addEventListener('click', () => {
  setNarrowPanel('left-panel', false);
  setNarrowPanel('right-panel', false);
});

// The Project tab's Save/Export buttons are the SAME action as the top
// bar's -- not a second implementation, just a second entry point for
// anyone who's already in the Project tab and doesn't want to look up top.
document.getElementById('save-alt-btn').addEventListener('click', () => document.getElementById('save-btn').click());
document.getElementById('export-standalone-alt-btn').addEventListener('click', () => document.getElementById('export-standalone-btn').click());

// --- Command Palette (Wave 4, Ctrl+K) --------------------------------
// A faster way to REACH functionality the editor already has, not a second
// implementation of any of it -- every entry below either clicks a real
// existing button (so it's the exact same code path a mouse click on that
// button would take) or calls a real existing function directly (the same
// ones the Add Object palette's drag-drop, tab-switching, and Undo/Redo
// keyboard shortcuts already call). "Add Object" entries place at a fixed
// point near the viewport's usual working area (a small offset per call so
// several adds in a row don't stack exactly on top of each other) since the
// Palette itself is a drag-drop source, not a click target -- placeItem is
// the same function the drop handler calls once a drag completes.
let cmdPaletteAddOffset = 0;
function cmdPlaceObject(type) {
  cmdPaletteAddOffset = (cmdPaletteAddOffset + 1) % 6;
  const point = new Opus.Vec3(cmdPaletteAddOffset * 1.2, 0, cmdPaletteAddOffset * 1.2);
  placeItem(type, point);
}
const COMMAND_PALETTE_ACTIONS = [
  { label: 'Play', hint: 'P', run: () => document.getElementById('play-btn').click() },
  { label: 'Pause / Resume', hint: '', run: () => document.getElementById('pause-btn').click() },
  { label: 'Undo', hint: 'Ctrl+Z', run: () => document.getElementById('undo-btn').click() },
  { label: 'Redo', hint: 'Ctrl+Y', run: () => document.getElementById('redo-btn').click() },
  { label: 'Save Project', hint: '', run: () => document.getElementById('save-btn').click() },
  { label: 'Export Standalone Game', hint: '', run: () => document.getElementById('export-standalone-btn').click() },
  { label: 'Import Project JSON', hint: '', run: () => document.getElementById('import-project-btn').click() },
  { label: 'Duplicate Selected', hint: 'Ctrl+D', run: () => { if (!playMode && selectedItem) duplicateSelected(); } },
  { label: 'Delete Selected', hint: 'Del', run: () => { if (!playMode && selectedItem) deleteSelected(); } },
  { label: 'Deselect', hint: 'Esc', run: () => deselectAll() },
  { label: 'Go to Objects Tab', hint: '', run: () => activateTab('left-tab', 'objects') },
  { label: 'Go to Assets Tab', hint: '', run: () => activateTab('left-tab', 'assets') },
  { label: 'Go to Prefabs Tab', hint: '', run: () => activateTab('left-tab', 'prefabs') },
  { label: 'Go to Inspector Tab', hint: '', run: () => activateTab('right-tab', 'inspector') },
  { label: 'Go to Scene Tab', hint: '', run: () => activateTab('right-tab', 'scene') },
  { label: 'Go to Level Tab', hint: '', run: () => activateTab('right-tab', 'level') },
  { label: 'Go to UI Tab', hint: '', run: () => activateTab('right-tab', 'ui') },
  { label: 'Go to Project Tab', hint: '', run: () => activateTab('right-tab', 'project') },
  ...PLACEABLE_TYPES.map((type) => ({
    label: `Add ${PALETTE_LABELS[type] || type}`, hint: 'Add Object', run: () => cmdPlaceObject(type),
  })),
];
let cmdPaletteActive = -1;
let cmdPaletteFiltered = COMMAND_PALETTE_ACTIONS;
const cmdPaletteOverlay = document.getElementById('command-palette-overlay');
const cmdPaletteInput = document.getElementById('command-palette-input');
const cmdPaletteListEl = document.getElementById('command-palette-list');
function renderCommandPalette() {
  // Matched word-by-word (every typed word must appear somewhere in the
  // label), not as one contiguous substring -- found live-testing "add
  // cube": the palette's own emoji icons (PALETTE_LABELS, e.g. "Add ▢
  // Cube") break substring contiguity between words, so a whole-string
  // `.includes()` match would silently fail on the most natural query for
  // exactly the "Add Object" commands this palette exists to reach.
  const words = cmdPaletteInput.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
  cmdPaletteFiltered = words.length
    ? COMMAND_PALETTE_ACTIONS.filter((a) => { const label = a.label.toLowerCase(); return words.every((w) => label.includes(w)); })
    : COMMAND_PALETTE_ACTIONS;
  cmdPaletteActive = cmdPaletteFiltered.length ? 0 : -1;
  cmdPaletteListEl.innerHTML = cmdPaletteFiltered.length === 0
    ? `<div id="command-palette-empty">No matching command</div>`
    : cmdPaletteFiltered.map((a, i) => `<div class="cmd-item${i === 0 ? ' active' : ''}" data-cmd-index="${i}">${escapeHtml(a.label)}${a.hint ? `<span class="cmd-item-hint">${escapeHtml(a.hint)}</span>` : ''}</div>`).join('');
}
function openCommandPalette() {
  cmdPaletteOverlay.classList.add('visible');
  cmdPaletteInput.value = '';
  renderCommandPalette();
  cmdPaletteInput.focus();
}
function closeCommandPalette() {
  cmdPaletteOverlay.classList.remove('visible');
}
function runActiveCommand() {
  const action = cmdPaletteFiltered[cmdPaletteActive];
  if (!action) return;
  closeCommandPalette();
  action.run();
}
cmdPaletteInput.addEventListener('input', renderCommandPalette);
cmdPaletteListEl.addEventListener('click', (e) => {
  const el = e.target.closest('[data-cmd-index]');
  if (!el) return;
  cmdPaletteActive = Number(el.dataset.cmdIndex);
  runActiveCommand();
});
cmdPaletteOverlay.addEventListener('click', (e) => { if (e.target === cmdPaletteOverlay) closeCommandPalette(); });
cmdPaletteInput.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') { e.preventDefault(); closeCommandPalette(); }
  else if (e.key === 'ArrowDown') { e.preventDefault(); if (cmdPaletteFiltered.length) { cmdPaletteActive = (cmdPaletteActive + 1) % cmdPaletteFiltered.length; renderCommandPaletteActiveOnly(); } }
  else if (e.key === 'ArrowUp') { e.preventDefault(); if (cmdPaletteFiltered.length) { cmdPaletteActive = (cmdPaletteActive - 1 + cmdPaletteFiltered.length) % cmdPaletteFiltered.length; renderCommandPaletteActiveOnly(); } }
  else if (e.key === 'Enter') { e.preventDefault(); runActiveCommand(); }
});
function renderCommandPaletteActiveOnly() {
  cmdPaletteListEl.querySelectorAll('.cmd-item').forEach((el) => el.classList.toggle('active', Number(el.dataset.cmdIndex) === cmdPaletteActive));
}
// Global open shortcut -- Ctrl+K/Cmd+K, guarded the same way every other
// global shortcut in this file already is (never fires while actually
// typing in an unrelated field, never fires mid-Play).
window.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    if (cmdPaletteOverlay.classList.contains('visible')) closeCommandPalette();
    else if (!playMode) openCommandPalette();
  }
});

// A standalone export (see the Export Standalone Game handler, below) sets
// this before the engine/editor scripts run, so the exact same boot path
// Crate Run itself uses -- open straight into a playable game, "Edit This
// Game" reveals the full live editor on the exact same scene -- works for
// any embedded project, not just the hardcoded starter game.
if (window.__OPUS_EMBEDDED_PROJECT__) {
  loadProjectFull(window.__OPUS_EMBEDDED_PROJECT__, 'Embedded Game');
} else {
  buildStarterGame();
  renderEnvironmentPanel(); // loadProjectFull syncs this itself; the starter-game path doesn't go through it
  renderPlayerSettingsPanel(); // same reasoning -- currentPlayerSettings already defaults to hovercraft
  renderUiConfigPanel(); // same reasoning -- currentUiConfig already defaults to defaultUiConfig()
}
if (window.__OPUS_PLAYABLE_ONLY__) {
  playableOnlyMode = true;
  chromeToggleBtn.style.display = 'none';
}
setEditorVisible(false);
